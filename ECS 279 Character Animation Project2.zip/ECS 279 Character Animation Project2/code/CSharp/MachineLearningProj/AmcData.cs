using System;
using System.Collections.Generic;
using System.Text;

namespace HMMInitialization
{
    class AmcMotionFrame
    {
        public AmcMotionFrame(int iFrame)
        {
            m_iFrame = iFrame;
        }
        public String ToString()
        {
            String str = m_upbodyFrame.ToString();
            str += m_lowBodyFrame.ToString();
            return str;
        }
        public int m_iFrame = 0;
        public AmcUpBodyFrame m_upbodyFrame = new AmcUpBodyFrame();
        public AmcLowerBodyFrame m_lowBodyFrame = new AmcLowerBodyFrame();
    }
    class AmcUpBodyFrame
    {
        public static AmcUpBodyFrame GetInterpolatedFrame(AmcUpBodyFrame frmStart, AmcUpBodyFrame frmEnd, float fPortion)
        {
            AmcUpBodyFrame frmNew = new AmcUpBodyFrame(frmStart);
            frmNew.m_lowerback = AmcItem3.GetInterpolatedItem(frmStart.m_lowerback, frmEnd.m_lowerback, fPortion);
            frmNew.m_upperback = AmcItem3.GetInterpolatedItem(frmStart.m_upperback, frmEnd.m_upperback, fPortion);
            frmNew.m_thorax = AmcItem3.GetInterpolatedItem(frmStart.m_thorax, frmEnd.m_thorax, fPortion);
            frmNew.m_lowerneck = AmcItem3.GetInterpolatedItem(frmStart.m_lowerneck, frmEnd.m_lowerneck, fPortion);
            frmNew.m_upperneck = AmcItem3.GetInterpolatedItem(frmStart.m_upperneck, frmEnd.m_upperback, fPortion);
            frmNew.m_head = AmcItem3.GetInterpolatedItem(frmStart.m_head, frmEnd.m_head, fPortion);

            frmNew.m_rclavicle = AmcItem2.GetInterpolatedItem(frmStart.m_rclavicle, frmEnd.m_rclavicle, fPortion);
            frmNew.m_rhumerus = AmcItem3.GetInterpolatedItem(frmStart.m_rhumerus, frmEnd.m_rhumerus, fPortion);
            frmNew.m_rradius = AmcItem1.GetInterpolatedItem(frmStart.m_rradius, frmEnd.m_rradius, fPortion);
            frmNew.m_rwrist = AmcItem1.GetInterpolatedItem(frmStart.m_rwrist, frmEnd.m_rwrist, fPortion);
            frmNew.m_rhand = AmcItem2.GetInterpolatedItem(frmStart.m_rhand, frmEnd.m_rhand, fPortion);
            frmNew.m_rfingers = AmcItem1.GetInterpolatedItem(frmStart.m_rfingers, frmEnd.m_rfingers, fPortion);
            frmNew.m_rthumb = AmcItem2.GetInterpolatedItem(frmStart.m_rthumb, frmEnd.m_rthumb, fPortion);

            frmNew.m_lclavicle = AmcItem2.GetInterpolatedItem(frmStart.m_lclavicle, frmEnd.m_lclavicle, fPortion);
            frmNew.m_lhumerus = AmcItem3.GetInterpolatedItem(frmStart.m_lhumerus, frmEnd.m_lhumerus, fPortion);
            frmNew.m_lradius = AmcItem1.GetInterpolatedItem(frmStart.m_lradius, frmEnd.m_lradius, fPortion);
            frmNew.m_lwrist = AmcItem1.GetInterpolatedItem(frmStart.m_lwrist, frmEnd.m_lwrist, fPortion);
            frmNew.m_lhand = AmcItem2.GetInterpolatedItem(frmStart.m_lhand, frmEnd.m_lhand, fPortion);
            frmNew.m_lfingers = AmcItem1.GetInterpolatedItem(frmStart.m_lfingers, frmEnd.m_lfingers, fPortion);
            frmNew.m_lthumb = AmcItem2.GetInterpolatedItem(frmStart.m_lthumb, frmEnd.m_lthumb, fPortion);
            return frmNew;
        }

        public AmcItem3 m_lowerback;
        public AmcItem3 m_upperback;
        public AmcItem3 m_thorax;
        public AmcItem3 m_lowerneck;
        public AmcItem3 m_upperneck;
        public AmcItem3 m_head;

        public AmcItem2 m_rclavicle;
        public AmcItem3 m_rhumerus;
        public AmcItem1 m_rradius;
        public AmcItem1 m_rwrist;
        public AmcItem2 m_rhand;
        public AmcItem1 m_rfingers;
        public AmcItem2 m_rthumb;

        public AmcItem2 m_lclavicle;
        public AmcItem3 m_lhumerus;
        public AmcItem1 m_lradius;
        public AmcItem1 m_lwrist;
        public AmcItem2 m_lhand;
        public AmcItem1 m_lfingers;
        public AmcItem2 m_lthumb;

        public int m_iStateId = -1;

        public String ToString()
        {
            String str = "";
            str += m_lowerback.ToString();
            str += m_upperback.ToString();
            str += m_thorax.ToString();
            str += m_lowerneck.ToString();
            str += m_upperneck.ToString();
            str += m_head.ToString();

            str += m_rclavicle.ToString();
            str += m_rhumerus.ToString();
            str += m_rradius.ToString();
            str += m_rwrist.ToString();
            str += m_rhand.ToString();
            str += m_rfingers.ToString();
            str += m_rthumb.ToString();

            str += m_lclavicle.ToString();
            str += m_lhumerus.ToString();
            str += m_lradius.ToString();
            str += m_lwrist.ToString();
            str += m_lhand.ToString();
            str += m_lfingers.ToString();
            str += m_lthumb.ToString();

            return str;
        }

        public float Distance(AmcUpBodyFrame uFrame)
        {
            float dis = 0;
            //dis += m_root.Distance(uFrame.m_root);
            dis += m_lowerback.Distance(uFrame.m_lowerback);
            dis += m_upperback.Distance(uFrame.m_upperback);
            //dis += m_thorax.Distance(uFrame.m_thorax);
            //dis += m_lowerneck.Distance(uFrame.m_lowerneck);
            //dis += m_upperneck.Distance(uFrame.m_upperneck);
            //dis += m_head.Distance(uFrame.m_head);

            dis += m_rclavicle.Distance(uFrame.m_rclavicle);
            dis += m_rhumerus.Distance(uFrame.m_rhumerus);
            dis += m_rradius.Distance(uFrame.m_rradius);
            //dis += m_rwrist.Distance(uFrame.m_rwrist);
            //dis += m_rhand.Distance(uFrame.m_rhand);
            //dis += m_rfingers.Distance(uFrame.m_rfingers);
            //dis += m_rthumb.Distance(uFrame.m_rthumb);

            dis += m_lclavicle.Distance(uFrame.m_lclavicle);
            dis += m_lhumerus.Distance(uFrame.m_lhumerus);
            dis += m_lradius.Distance(uFrame.m_lradius);
            //dis += m_lwrist.Distance(uFrame.m_lwrist);
            //dis += m_lhand.Distance(uFrame.m_lhand);
            //dis += m_lfingers.Distance(uFrame.m_lfingers);
            //dis += m_lthumb.Distance(uFrame.m_lthumb);

            return dis/8;

        }
        public AmcUpBodyFrame(AmcUpBodyFrame uFrame)
        {
            m_lowerback = new AmcItem3(uFrame.m_lowerback);
            m_upperback = new AmcItem3(uFrame.m_upperback);
            m_thorax = new AmcItem3(uFrame.m_thorax);
            m_lowerneck = new AmcItem3(uFrame.m_lowerneck);
            m_upperneck = new AmcItem3(uFrame.m_upperneck);
            m_head = new AmcItem3(uFrame.m_head);

            m_rclavicle = new AmcItem2(uFrame.m_rclavicle);
            m_rhumerus = new AmcItem3(uFrame.m_rhumerus);
            m_rradius = new AmcItem1(uFrame.m_rradius);
            m_rwrist = new AmcItem1(uFrame.m_rwrist);
            m_rhand = new AmcItem2(uFrame.m_rhand);
            m_rfingers = new AmcItem1(uFrame.m_rfingers);
            m_rthumb = new AmcItem2(uFrame.m_rthumb);
            
            m_lclavicle = new AmcItem2(uFrame.m_lclavicle);
            m_lhumerus = new AmcItem3(uFrame.m_lhumerus);
            m_lradius = new AmcItem1(uFrame.m_lradius);
            m_lwrist = new AmcItem1(uFrame.m_lwrist);
            m_lhand = new AmcItem2(uFrame.m_lhand);
            m_lfingers = new AmcItem1(uFrame.m_lfingers);
            m_lthumb = new AmcItem2(uFrame.m_lthumb); 
        }
        public AmcUpBodyFrame()
        { }
    }
    class AmcLowerBodyFrame
    {
        public AmcItem6 m_root;
     
        public AmcItem3 m_rfemur;
        public AmcItem1 m_rtibia;
        public AmcItem2 m_rfoot;
        public AmcItem1 m_rtoes;

        public AmcItem3 m_lfemur;
        public AmcItem1 m_ltibia;
        public AmcItem2 m_lfoot;
        public AmcItem1 m_ltoes;

        public int m_iObsId = -1;

        public String ToString()
        {
            String str = "";
            str += m_root.ToString();
            str += m_rfemur.ToString();
            str += m_rtibia.ToString();
            str += m_rfoot.ToString();
            str += m_rtoes.ToString();

            str += m_lfemur.ToString();
            str += m_ltibia.ToString();
            str += m_lfoot.ToString();
            str += m_ltoes.ToString();

            return str;
        }
        public float Distance(AmcLowerBodyFrame lFrame)
        {
            float dis = 0;
            dis += m_rfemur.Distance(lFrame.m_rfemur);
            dis += m_rtibia.Distance(lFrame.m_rtibia);
            //dis += m_rfoot.Distance(lFrame.m_rfoot);
            //dis += m_rtoes.Distance(lFrame.m_rtoes);

            dis += m_lfemur.Distance(lFrame.m_lfemur);
            dis += m_ltibia.Distance(lFrame.m_ltibia);
            //dis += m_lfoot.Distance(lFrame.m_lfoot);
            //dis += m_ltoes.Distance(lFrame.m_ltoes);

            return dis/4;
        }
        public AmcLowerBodyFrame(AmcLowerBodyFrame lFrame)
        {
            m_root = new AmcItem6(lFrame.m_root);
            m_rfemur = new AmcItem3(lFrame.m_rfemur);
            m_rtibia = new AmcItem1(lFrame.m_rtibia);
            m_rfoot = new AmcItem2(lFrame.m_rfoot);
            m_rtoes = new AmcItem1(lFrame.m_rtoes);

            m_lfemur = new AmcItem3(lFrame.m_lfemur);
            m_ltibia = new AmcItem1(lFrame.m_ltibia);
            m_lfoot = new AmcItem2(lFrame.m_lfoot);
            m_ltoes = new AmcItem1(lFrame.m_ltoes);
        }
        public AmcLowerBodyFrame()
        { }
    }

    enum AmcItemType
    {
        root,
        lowerback,
        upperback, 
        thorax, 
        lowerneck, 
        upperneck, 
        head, 
        rclavicle, 
        rhumerus, 
        rradius,
        rwrist, 
        rhand, 
        rfingers, 
        rthumb, 
        lclavicle, 
        lhumerus, 
        lradius, 
        lwrist, 
        lhand, 
        lfingers, 
        lthumb, 
        rfemur, 
        rtibia,
        rfoot,
        rtoes, 
        lfemur, 
        ltibia, 
        lfoot,
        ltoes,
        unknown
    }   

    class AmcItem6
    {
        public static AmcItem6 GetInterpolatedItem(AmcItem6 itemStart, AmcItem6 itemEnd, float fPortion)
        {
            AmcItem6 itemNew = new AmcItem6(itemStart);
            itemNew.m_fVar1 = fPortion * itemStart.m_fVar1 + (1 - fPortion) * itemEnd.m_fVar1;
            itemNew.m_fVar2 = fPortion * itemStart.m_fVar2 + (1 - fPortion) * itemEnd.m_fVar2;
            itemNew.m_fVar3 = fPortion * itemStart.m_fVar3 + (1 - fPortion) * itemEnd.m_fVar3;
            itemNew.m_fVar4 = fPortion * itemStart.m_fVar4 + (1 - fPortion) * itemEnd.m_fVar4;
            itemNew.m_fVar5 = fPortion * itemStart.m_fVar5 + (1 - fPortion) * itemEnd.m_fVar5;
            itemNew.m_fVar6 = fPortion * itemStart.m_fVar6 + (1 - fPortion) * itemEnd.m_fVar6;
            return itemNew;
        }

        public AmcItemType m_eType = AmcItemType.unknown;
        public String m_strJoint = "";
        public float m_fVar1 = 0;
        public float m_fVar2 = 0;
        public float m_fVar3 = 0;
        public float m_fVar4 = 0;
        public float m_fVar5 = 0;
        public float m_fVar6 = 0;
        
        public AmcItem6(String strLine)
        {
            int idxBlank1 = strLine.IndexOf(" ");
            m_strJoint = strLine.Substring(0, idxBlank1);

            int idxBlank2 = strLine.IndexOf(" ", idxBlank1 + 1);
            if (idxBlank2 == -1)
                idxBlank2 = strLine.Length;
            String strVal = strLine.Substring(idxBlank1 + 1, idxBlank2 - idxBlank1 - 1);
            float.TryParse(strVal, out m_fVar1);

            idxBlank1 = idxBlank2;
            idxBlank2 = strLine.IndexOf(" ", idxBlank1 + 1);
            if (idxBlank2 == -1)
                idxBlank2 = strLine.Length;
            strVal = strLine.Substring(idxBlank1 + 1, idxBlank2 - idxBlank1 - 1);
            float.TryParse(strVal, out m_fVar2);

            idxBlank1 = idxBlank2;
            idxBlank2 = strLine.IndexOf(" ", idxBlank1 + 1);
            if (idxBlank2 == -1)
                idxBlank2 = strLine.Length;
            strVal = strLine.Substring(idxBlank1 + 1, idxBlank2 - idxBlank1 - 1);
            float.TryParse(strVal, out m_fVar3);

            idxBlank1 = idxBlank2;
            idxBlank2 = strLine.IndexOf(" ", idxBlank1 + 1);
            if (idxBlank2 == -1)
                idxBlank2 = strLine.Length;
            strVal = strLine.Substring(idxBlank1 + 1, idxBlank2 - idxBlank1 - 1);
            float.TryParse(strVal, out m_fVar4);

            idxBlank1 = idxBlank2;
            idxBlank2 = strLine.IndexOf(" ", idxBlank1 + 1);
            if (idxBlank2 == -1)
                idxBlank2 = strLine.Length;
            strVal = strLine.Substring(idxBlank1 + 1, idxBlank2 - idxBlank1 - 1);
            float.TryParse(strVal, out m_fVar5);

            idxBlank1 = idxBlank2;
            idxBlank2 = strLine.IndexOf(" ", idxBlank1 + 1);
            if (idxBlank2 == -1)
                idxBlank2 = strLine.Length;
            strVal = strLine.Substring(idxBlank1 + 1, idxBlank2 - idxBlank1 - 1);
            float.TryParse(strVal, out m_fVar6);
        }
        public AmcItem6(AmcItem6 item)
        {
            if (item == null)
                return;

            m_eType = item.m_eType;
            m_strJoint = item.m_strJoint;
            m_fVar1 = item.m_fVar1;
            m_fVar2 = item.m_fVar2;
            m_fVar3 = item.m_fVar3;
            m_fVar4 = item.m_fVar4;
            m_fVar5 = item.m_fVar5;
            m_fVar6 = item.m_fVar6;
        }
        public String ToString()
        {
            String str = m_strJoint;
            str += " " + m_fVar1.ToString() + " " + m_fVar2.ToString() + " " + m_fVar3.ToString() + 
                " " + m_fVar4.ToString() + " " + m_fVar5.ToString() + " " + m_fVar6.ToString() + "\n";
            return str;
        }
        public float Distance(AmcItem6 item6)
        {
            return (Math.Abs(m_fVar1 - item6.m_fVar1) +
                Math.Abs(m_fVar2 - item6.m_fVar2) +
                Math.Abs(m_fVar3 - item6.m_fVar3) +
                Math.Abs(m_fVar4 - item6.m_fVar4) +
                Math.Abs(m_fVar5 - item6.m_fVar5) +
                Math.Abs(m_fVar6 - item6.m_fVar6))/6; 
        }

    }
    class AmcItem3
    {
        public static AmcItem3 GetInterpolatedItem(AmcItem3 itemStart, AmcItem3 itemEnd, float fPortion)
        {
            AmcItem3 itemNew = new AmcItem3(itemStart);
            itemNew.m_fVar1 = fPortion * itemStart.m_fVar1 + (1 - fPortion) * itemEnd.m_fVar1;
            itemNew.m_fVar2 = fPortion * itemStart.m_fVar2 + (1 - fPortion) * itemEnd.m_fVar2;
            itemNew.m_fVar3 = fPortion * itemStart.m_fVar3 + (1 - fPortion) * itemEnd.m_fVar3;
            return itemNew;
        }

        public AmcItemType m_eType = AmcItemType.unknown;
        public String m_strJoint = "";
        public float m_fVar1 = 0;
        public float m_fVar2 = 0 ;
        public float m_fVar3 = 0;

        public AmcItem3(String strLine)
        {
            int idxBlank1 = strLine.IndexOf(" ");
            m_strJoint = strLine.Substring(0, idxBlank1);

            int idxBlank2 = strLine.IndexOf(" ", idxBlank1 + 1);
            if (idxBlank2 == -1)
                idxBlank2 = strLine.Length;
            String strVal = strLine.Substring(idxBlank1 + 1, idxBlank2 - idxBlank1 - 1);
            float.TryParse(strVal, out m_fVar1);

            idxBlank1 = idxBlank2;
            idxBlank2 = strLine.IndexOf(" ", idxBlank1 + 1);
            if (idxBlank2 == -1)
                idxBlank2 = strLine.Length;
            strVal = strLine.Substring(idxBlank1 + 1, idxBlank2 - idxBlank1 - 1);
            float.TryParse(strVal, out m_fVar2);

            idxBlank1 = idxBlank2;
            idxBlank2 = strLine.IndexOf(" ", idxBlank1 + 1);
            if (idxBlank2 == -1)
                idxBlank2 = strLine.Length;
            strVal = strLine.Substring(idxBlank1 + 1, idxBlank2 - idxBlank1 - 1);
            float.TryParse(strVal, out m_fVar3);  
        }
        public AmcItem3(AmcItem3 item)
        {
            if (item == null)
                return;

            m_eType = item.m_eType;
            m_strJoint = item.m_strJoint;
            m_fVar1 = item.m_fVar1;
            m_fVar2 = item.m_fVar2;
            m_fVar3 = item.m_fVar3;
        }
        public String ToString()
        {
            String str = m_strJoint;
            str += " " + m_fVar1.ToString() + " " + m_fVar2.ToString() + " " + m_fVar3.ToString() + "\n";
            return str;
        }
        public float Distance(AmcItem3 item3)
        {
            return (Math.Abs(m_fVar1 - item3.m_fVar1) +
                Math.Abs(m_fVar2 - item3.m_fVar2) +
                Math.Abs(m_fVar3 - item3.m_fVar3))/3;
        }
    }
    class AmcItem2
    {
        public static AmcItem2 GetInterpolatedItem(AmcItem2 itemStart, AmcItem2 itemEnd, float fPortion)
        {
            AmcItem2 itemNew = new AmcItem2(itemStart);
            itemNew.m_fVar1 = fPortion * itemStart.m_fVar1 + (1 - fPortion) * itemEnd.m_fVar1;
            itemNew.m_fVar2 = fPortion * itemStart.m_fVar2 + (1 - fPortion) * itemEnd.m_fVar2;
            return itemNew;
        }

        public AmcItemType m_eType = AmcItemType.unknown;
        public String m_strJoint = "";
        public float m_fVar1 = 0;
        public float m_fVar2 = 0;

        public AmcItem2(String strLine)
        {
            int idxBlank1 = strLine.IndexOf(" ");
            m_strJoint = strLine.Substring(0, idxBlank1);

            int idxBlank2 = strLine.IndexOf(" ", idxBlank1 + 1);
            if (idxBlank2 == -1)
                idxBlank2 = strLine.Length;
            String strVal = strLine.Substring(idxBlank1 + 1, idxBlank2 - idxBlank1 - 1);
            float.TryParse(strVal, out m_fVar1);

            idxBlank1 = idxBlank2;
            idxBlank2 = strLine.IndexOf(" ", idxBlank1 + 1);
            if (idxBlank2 == -1)
                idxBlank2 = strLine.Length;
            strVal = strLine.Substring(idxBlank1 + 1, idxBlank2 - idxBlank1 - 1);
            float.TryParse(strVal, out m_fVar2);            
        }
        public AmcItem2(AmcItem2 item)
        {
            if (item == null)
                return;

            m_eType = item.m_eType;
            m_strJoint = item.m_strJoint;
            m_fVar1 = item.m_fVar1;
            m_fVar2 = item.m_fVar2;
        }
        public String ToString()
        {
            String str = m_strJoint;
            str += " " + m_fVar1.ToString() + " " + m_fVar2.ToString() + "\n";
            return str;
        }
        public float Distance(AmcItem2 item2)
        {
            return (Math.Abs(m_fVar1 - item2.m_fVar1) +
                Math.Abs(m_fVar2 - item2.m_fVar2))/2;
        }

    }
    class AmcItem1
    {
        public static AmcItem1 GetInterpolatedItem(AmcItem1 itemStart, AmcItem1 itemEnd, float fPortion)
        {
            AmcItem1 itemNew = new AmcItem1(itemStart);
            itemNew.m_fVar1 = fPortion * itemStart.m_fVar1 + (1 - fPortion) * itemEnd.m_fVar1;
            return itemNew;
        }
        public AmcItemType m_eType = AmcItemType.unknown;
        public String m_strJoint = "";
        public float m_fVar1 = 0;
        public AmcItem1(String strLine)
        {
            int idxBlank1 = strLine.IndexOf(" ");
            m_strJoint = strLine.Substring(0, idxBlank1);

            int idxBlank2 = strLine.IndexOf(" ", idxBlank1 + 1);
            if (idxBlank2 == -1)
                idxBlank2 = strLine.Length;
            String strVal = strLine.Substring(idxBlank1 + 1, idxBlank2 - idxBlank1 - 1);
            float.TryParse(strVal, out m_fVar1);
        }
        public AmcItem1(AmcItem1 item)
        {
            if (item == null)
                return;

            m_eType = item.m_eType;
            m_strJoint = item.m_strJoint;
            m_fVar1 = item.m_fVar1;
        }
        public String ToString()
        {
            String str = m_strJoint;
            str += " " + m_fVar1.ToString() + "\n";
            return str;
        }
        public float Distance(AmcItem1 item1)
        {
            return Math.Abs(m_fVar1 - item1.m_fVar1);
        }
    }

}
