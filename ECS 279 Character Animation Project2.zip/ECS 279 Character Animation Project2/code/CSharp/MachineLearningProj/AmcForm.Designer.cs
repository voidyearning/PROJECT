namespace HMMInitialization
{
    partial class AmcForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_tbFileName = new System.Windows.Forms.TextBox();
            this.m_btnBrowse = new System.Windows.Forms.Button();
            this.m_dlgAmcFile = new System.Windows.Forms.OpenFileDialog();
            this.m_lbTrainingSet = new System.Windows.Forms.ListBox();
            this.m_btnProcess = new System.Windows.Forms.Button();
            this.m_btnPredict = new System.Windows.Forms.Button();
            this.m_btnSeq = new System.Windows.Forms.Button();
            this.m_tbSeq = new System.Windows.Forms.TextBox();
            this.m_btnTransMatrix = new System.Windows.Forms.Button();
            this.m_btnSyn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // m_tbFileName
            // 
            this.m_tbFileName.Location = new System.Drawing.Point(27, 184);
            this.m_tbFileName.Name = "m_tbFileName";
            this.m_tbFileName.Size = new System.Drawing.Size(329, 20);
            this.m_tbFileName.TabIndex = 0;
            // 
            // m_btnBrowse
            // 
            this.m_btnBrowse.Location = new System.Drawing.Point(371, 11);
            this.m_btnBrowse.Name = "m_btnBrowse";
            this.m_btnBrowse.Size = new System.Drawing.Size(117, 26);
            this.m_btnBrowse.TabIndex = 1;
            this.m_btnBrowse.Text = "Select Training Set";
            this.m_btnBrowse.UseVisualStyleBackColor = true;
            this.m_btnBrowse.Click += new System.EventHandler(this.m_btnBrowse_Click);
            // 
            // m_dlgAmcFile
            // 
            this.m_dlgAmcFile.FileName = "openFileDialog1";
            // 
            // m_lbTrainingSet
            // 
            this.m_lbTrainingSet.FormattingEnabled = true;
            this.m_lbTrainingSet.HorizontalScrollbar = true;
            this.m_lbTrainingSet.Location = new System.Drawing.Point(27, 44);
            this.m_lbTrainingSet.Name = "m_lbTrainingSet";
            this.m_lbTrainingSet.Size = new System.Drawing.Size(461, 134);
            this.m_lbTrainingSet.TabIndex = 2;
            this.m_lbTrainingSet.Sorted = true;
            // 
            // m_btnProcess
            // 
            this.m_btnProcess.Location = new System.Drawing.Point(27, 11);
            this.m_btnProcess.Name = "m_btnProcess";
            this.m_btnProcess.Size = new System.Drawing.Size(193, 27);
            this.m_btnProcess.TabIndex = 3;
            this.m_btnProcess.Text = "Construct HMM";
            this.m_btnProcess.UseVisualStyleBackColor = true;
            this.m_btnProcess.Click += new System.EventHandler(this.m_btnProcess_Click);
            // 
            // m_btnPredict
            // 
            this.m_btnPredict.Location = new System.Drawing.Point(362, 184);
            this.m_btnPredict.Name = "m_btnPredict";
            this.m_btnPredict.Size = new System.Drawing.Size(125, 24);
            this.m_btnPredict.TabIndex = 4;
            this.m_btnPredict.Text = "Select file to predict";
            this.m_btnPredict.UseVisualStyleBackColor = true;
            this.m_btnPredict.Click += new System.EventHandler(this.m_btnPredict_Click);
            // 
            // m_btnSeq
            // 
            this.m_btnSeq.Location = new System.Drawing.Point(27, 574);
            this.m_btnSeq.Name = "m_btnSeq";
            this.m_btnSeq.Size = new System.Drawing.Size(77, 23);
            this.m_btnSeq.TabIndex = 5;
            this.m_btnSeq.Text = "Get Seq";
            this.m_btnSeq.UseVisualStyleBackColor = true;
            this.m_btnSeq.Click += new System.EventHandler(this.m_btnSeq_Click);
            // 
            // m_tbSeq
            // 
            this.m_tbSeq.Location = new System.Drawing.Point(27, 214);
            this.m_tbSeq.Multiline = true;
            this.m_tbSeq.Name = "m_tbSeq";
            this.m_tbSeq.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_tbSeq.Size = new System.Drawing.Size(460, 354);
            this.m_tbSeq.TabIndex = 6;
            // 
            // m_btnTransMatrix
            // 
            this.m_btnTransMatrix.Location = new System.Drawing.Point(111, 574);
            this.m_btnTransMatrix.Name = "m_btnTransMatrix";
            this.m_btnTransMatrix.Size = new System.Drawing.Size(109, 23);
            this.m_btnTransMatrix.TabIndex = 7;
            this.m_btnTransMatrix.Text = "Get Matrix";
            this.m_btnTransMatrix.UseVisualStyleBackColor = true;
            this.m_btnTransMatrix.Click += new System.EventHandler(this.m_btnTransMatrix_Click);
            // 
            // m_btnSyn
            // 
            this.m_btnSyn.Location = new System.Drawing.Point(229, 575);
            this.m_btnSyn.Name = "m_btnSyn";
            this.m_btnSyn.Size = new System.Drawing.Size(114, 22);
            this.m_btnSyn.TabIndex = 8;
            this.m_btnSyn.Text = "Synthesize";
            this.m_btnSyn.UseVisualStyleBackColor = true;
            this.m_btnSyn.Click += new System.EventHandler(this.m_btnSyn_Click);
            // 
            // AmcForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 625);
            this.Controls.Add(this.m_btnSyn);
            this.Controls.Add(this.m_btnTransMatrix);
            this.Controls.Add(this.m_tbSeq);
            this.Controls.Add(this.m_btnSeq);
            this.Controls.Add(this.m_btnPredict);
            this.Controls.Add(this.m_btnProcess);
            this.Controls.Add(this.m_lbTrainingSet);
            this.Controls.Add(this.m_btnBrowse);
            this.Controls.Add(this.m_tbFileName);
            this.Name = "AmcForm";
            this.Text = "HMM Initialization Project";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox m_tbFileName;
        private System.Windows.Forms.Button m_btnBrowse;
        private System.Windows.Forms.OpenFileDialog m_dlgAmcFile;
        private System.Windows.Forms.ListBox m_lbTrainingSet;
        private System.Windows.Forms.Button m_btnProcess;
        private System.Windows.Forms.Button m_btnPredict;
        private System.Windows.Forms.Button m_btnSeq;
        private System.Windows.Forms.TextBox m_tbSeq;
        private System.Windows.Forms.Button m_btnTransMatrix;
        private System.Windows.Forms.Button m_btnSyn;
    }
}

