using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.IO;

namespace HMMInitialization
{
    class AmcFileIO
    {
        static public ArrayList m_arAmcFileName = new ArrayList();
        static public void ConstructHMM()
        {
            //load training set
            m_hmm = new HMM();
            for (int i = 0; i < m_arAmcFileName.Count; ++i)
            {
                AmcFile file = ProcessAmcFile(m_arAmcFileName[i].ToString());
                m_hmm.m_arTrainingSetFiles.Add(file);
            }

            //construct model
            m_hmm.ConstructModel();
        }
        
        static public String StatesAndObsToString()
        {
            AmcFile file = ProcessAmcFile(m_strInputFilePath);
            return m_hmm.StatesAndObsToString(file);
        }
        static public String TransAndObsMatrixToString()
        {
            return "trans: " + m_hmm.TransMatrixToString() + 
                "\nobs: " + m_hmm.ObsMatrixToString();
        }
        static public String Synthesize(String strStateSeq)
        {
            return m_hmm.SynthesizeWithSmoothing(strStateSeq);
        }

        static public int m_iLineNum = 0;
        static public string m_strInputFilePath = "";
        static public string m_strFile = "";
        static public HMM m_hmm;
        
        public static string FileReadLine(string strFileName, int iLineNum)
        {
            FileStream fsMyfile = new FileStream(strFileName, FileMode.Open, FileAccess.Read);
            StreamReader srMyfile = new StreamReader(fsMyfile);
            srMyfile.BaseStream.Seek(0, SeekOrigin.Begin);
            string s1;
            int LineCount = 0;
            while ((s1 = srMyfile.ReadLine()) != null)
            {
                if (LineCount == iLineNum)
                {
                    fsMyfile.Close();
                    return (s1);
                }
                LineCount++;
            }
            fsMyfile.Close();
            return (null);
        }

        public static string GetNextLineStr(String strFilePath)
        {
            string strAddr = FileReadLine(strFilePath, m_iLineNum);
            m_iLineNum++;
            return strAddr;
        }

        public static void WriteLine(string strFileName, string strLine)
        {
            FileStream fsMyfile = new FileStream(strFileName, FileMode.Create, FileAccess.ReadWrite);
            StreamWriter swMyfile = new StreamWriter(fsMyfile);
            swMyfile.WriteLine(strLine);
            swMyfile.Flush();
            fsMyfile.Close();
        }

        public static void WriteWholeFile(string strFileName, string strFile)
        {
            FileStream fsMyfile = new FileStream(strFileName, FileMode.Create, FileAccess.ReadWrite);
            StreamWriter swMyfile = new StreamWriter(fsMyfile);
            swMyfile.Write(strFile);
            swMyfile.Flush();
            fsMyfile.Close();
        }

        public static AmcFile ProcessAmcFile(String strFileName)
        {
            m_iLineNum = 0;
            AmcFile file = new AmcFile();

            AmcMotionFrame motionFrame = null;
            while (true)
            {
                String strLine = GetNextLineStr(strFileName);
                if (strLine == null)
                    break;

                int iFrameNum = -1;
                bool bNum = Int32.TryParse(strLine, out iFrameNum);
                if (bNum)
                {
                    if (motionFrame != null)
                        file.m_arFrames.Add(motionFrame);
                    motionFrame = new AmcMotionFrame(iFrameNum);
                }

                if (motionFrame == null)
                    continue;

                if (strLine.StartsWith("root"))
                {
                    AmcItem6 item6 = new AmcItem6(strLine);
                    item6.m_eType = AmcItemType.root;
                    motionFrame.m_lowBodyFrame.m_root = item6;
                }


                if (strLine.StartsWith("lowerback"))
                {
                    AmcItem3 item3 = new AmcItem3(strLine);
                    item3.m_eType = AmcItemType.lowerback;
                    motionFrame.m_upbodyFrame.m_lowerback = item3;
                }

                if (strLine.StartsWith("upperback"))
                {
                    AmcItem3 item3 = new AmcItem3(strLine);
                    item3.m_eType = AmcItemType.upperback;
                    motionFrame.m_upbodyFrame.m_upperback = item3;
                }

                if (strLine.StartsWith("thorax"))
                {
                    AmcItem3 item3 = new AmcItem3(strLine);
                    item3.m_eType = AmcItemType.thorax;
                    motionFrame.m_upbodyFrame.m_thorax = item3; 
                }

                if (strLine.StartsWith("lowerneck"))
                {
                    AmcItem3 item3 = new AmcItem3(strLine);
                    item3.m_eType = AmcItemType.lowerneck;
                    motionFrame.m_upbodyFrame.m_lowerneck= item3;
                }

                if (strLine.StartsWith("upperneck"))
                {
                    AmcItem3 item3 = new AmcItem3(strLine);
                    item3.m_eType = AmcItemType.upperneck;
                    motionFrame.m_upbodyFrame.m_upperneck = item3;
                }

                if (strLine.StartsWith("head"))
                {
                    AmcItem3 item3 = new AmcItem3(strLine);
                    item3.m_eType = AmcItemType.head;
                    motionFrame.m_upbodyFrame.m_head = item3;
                }

                if (strLine.StartsWith("rclavicle"))
                {
                    AmcItem2 item2 = new AmcItem2(strLine);
                    item2.m_eType = AmcItemType.rclavicle;
                    motionFrame.m_upbodyFrame.m_rclavicle = item2;
                }

                if (strLine.StartsWith("rhumerus"))
                {
                    AmcItem3 item3 = new AmcItem3(strLine);
                    item3.m_eType = AmcItemType.rhumerus;
                    motionFrame.m_upbodyFrame.m_rhumerus = item3;
                }

                if (strLine.StartsWith("rradius"))
                {
                    AmcItem1 item1 = new AmcItem1(strLine);
                    item1.m_eType = AmcItemType.rradius;
                    motionFrame.m_upbodyFrame.m_rradius = item1;
                }

                if (strLine.StartsWith("rwrist"))
                {
                    AmcItem1 item1 = new AmcItem1(strLine);
                    item1.m_eType = AmcItemType.rwrist;
                    motionFrame.m_upbodyFrame.m_rwrist = item1;
                }

                if (strLine.StartsWith("rhand"))
                {
                    AmcItem2 item2 = new AmcItem2(strLine);
                    item2.m_eType = AmcItemType.rhand;
                    motionFrame.m_upbodyFrame.m_rhand = item2;
                }

                if (strLine.StartsWith("rfingers"))
                {
                    AmcItem1 item1 = new AmcItem1(strLine);
                    item1.m_eType = AmcItemType.rfingers;
                    motionFrame.m_upbodyFrame.m_rfingers = item1;
                }

                if (strLine.StartsWith("rthumb"))
                {
                    AmcItem2 item2 = new AmcItem2(strLine);
                    item2.m_eType = AmcItemType.rthumb;
                    motionFrame.m_upbodyFrame.m_rthumb = item2;
                }

                if (strLine.StartsWith("lclavicle"))
                {
                    AmcItem2 item2 = new AmcItem2(strLine);
                    item2.m_eType = AmcItemType.lclavicle;
                    motionFrame.m_upbodyFrame.m_lclavicle = item2;
                }

                if (strLine.StartsWith("lhumerus"))
                {
                    AmcItem3 item3 = new AmcItem3(strLine);
                    item3.m_eType = AmcItemType.lhumerus;
                    motionFrame.m_upbodyFrame.m_lhumerus = item3;
                }

                if (strLine.StartsWith("lradius"))
                {
                    AmcItem1 item1 = new AmcItem1(strLine);
                    item1.m_eType = AmcItemType.lradius;
                    motionFrame.m_upbodyFrame.m_lradius = item1;
                }

                if (strLine.StartsWith("lwrist"))
                {
                    AmcItem1 item1 = new AmcItem1(strLine);
                    item1.m_eType = AmcItemType.lwrist;
                    motionFrame.m_upbodyFrame.m_lwrist = item1;
                }

                if (strLine.StartsWith("lhand"))
                {
                    AmcItem2 item2 = new AmcItem2(strLine);
                    item2.m_eType = AmcItemType.lhand;
                    motionFrame.m_upbodyFrame.m_lhand = item2;
                }

                if (strLine.StartsWith("lfingers"))
                {
                    AmcItem1 item1 = new AmcItem1(strLine);
                    item1.m_eType = AmcItemType.lfingers;
                    motionFrame.m_upbodyFrame.m_lfingers = item1;
                }

                if (strLine.StartsWith("lthumb"))
                {
                    AmcItem2 item2 = new AmcItem2(strLine);
                    item2.m_eType = AmcItemType.lowerneck;
                    motionFrame.m_upbodyFrame.m_lthumb = item2;
                }

                if (strLine.StartsWith("rfemur"))
                {
                    AmcItem3 item3 = new AmcItem3(strLine);
                    item3.m_eType = AmcItemType.rfemur;
                    motionFrame.m_lowBodyFrame.m_rfemur = item3;
                }

                if (strLine.StartsWith("rtibia"))
                {
                    AmcItem1 item1 = new AmcItem1(strLine);
                    item1.m_eType = AmcItemType.rtibia;
                    motionFrame.m_lowBodyFrame.m_rtibia = item1;
                }

                if (strLine.StartsWith("rfoot"))
                {
                    AmcItem2 item2 = new AmcItem2(strLine);
                    item2.m_eType = AmcItemType.rfoot;
                    motionFrame.m_lowBodyFrame.m_rfoot = item2;
                }

                if (strLine.StartsWith("rtoes"))
                {
                    AmcItem1 item1 = new AmcItem1(strLine);
                    item1.m_eType = AmcItemType.rtoes;
                    motionFrame.m_lowBodyFrame.m_rtoes = item1;
                }

                if (strLine.StartsWith("lfemur"))
                {
                    AmcItem3 item3 = new AmcItem3(strLine);
                    item3.m_eType = AmcItemType.lfemur;
                    motionFrame.m_lowBodyFrame.m_lfemur = item3;
                }

                if (strLine.StartsWith("ltibia"))
                {
                    AmcItem1 item1 = new AmcItem1(strLine);
                    item1.m_eType = AmcItemType.ltibia;
                    motionFrame.m_lowBodyFrame.m_ltibia = item1;
                }

                if (strLine.StartsWith("lfoot"))
                {
                    AmcItem2 item2 = new AmcItem2(strLine);
                    item2.m_eType = AmcItemType.lfoot;
                    motionFrame.m_lowBodyFrame.m_lfoot = item2;
                }

                if (strLine.StartsWith("ltoes"))
                {
                    AmcItem1 item1 = new AmcItem1(strLine);
                    item1.m_eType = AmcItemType.ltoes;
                    motionFrame.m_lowBodyFrame.m_ltoes = item1;
                }
            }
            return file;
        }

    }

    class AmcFile
    {
        public ArrayList m_arFrames = new ArrayList();
        public String ToString()
        {
            String strResult = @"#!OML:ASF H:\Terrain\Patient Classification 1\Takeo\Monday\TakeoMonday.ASF
:FULLY-SPECIFIED
:DEGREES";
            strResult += "\n";
            for (int i = 0; i < m_arFrames.Count; ++i)
            {
                int iFrameId = i + 1;
                strResult += iFrameId.ToString() +"\n";
                AmcMotionFrame frm = m_arFrames[i] as AmcMotionFrame;
                strResult += frm.ToString(); 
            }
            return strResult;
        }
        public void InterpolateUpBodyBetween(int iStartIdx, int iEndIdx)//inclusive
        {
            AmcMotionFrame frmStart = m_arFrames[iStartIdx] as AmcMotionFrame;
            AmcMotionFrame frmEnd = null;
            int iSpan = iEndIdx - iStartIdx + 1;
            if(iEndIdx < m_arFrames.Count)
                frmEnd = m_arFrames[iEndIdx] as AmcMotionFrame;
            else
            {
                frmEnd = m_arFrames[m_arFrames.Count-1] as AmcMotionFrame;
                iSpan = m_arFrames.Count - iStartIdx + 1;
            }


            for (int i = 1; i < iSpan; ++i)
            {
                AmcMotionFrame frm = m_arFrames[iStartIdx + i] as AmcMotionFrame;
                float fPortion = 1 - (i / ((float)iSpan));

                frm.m_upbodyFrame = AmcUpBodyFrame.GetInterpolatedFrame(frmStart.m_upbodyFrame, frmEnd.m_upbodyFrame, fPortion);
            }
        }
    }

}
