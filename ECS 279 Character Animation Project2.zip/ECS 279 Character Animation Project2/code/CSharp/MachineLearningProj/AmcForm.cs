using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace HMMInitialization
{
    public partial class AmcForm : Form
    {
        public AmcForm()
        {
            InitializeComponent();
        }

        private void m_btnBrowse_Click(object sender, EventArgs e)
        {
            m_dlgAmcFile.FileName = "*.amc";
            m_dlgAmcFile.Multiselect = true;
            DialogResult result = m_dlgAmcFile.ShowDialog();
            if (result == DialogResult.OK)
            {
                m_lbTrainingSet.Items.Clear();
                AmcFileIO.m_arAmcFileName.Clear();
                for (int i = 0; i < m_dlgAmcFile.FileNames.Length; ++i)
                {
                    m_lbTrainingSet.Items.Add(m_dlgAmcFile.FileNames[i]);
                }
                for(int i = 0; i < m_lbTrainingSet.Items.Count; ++i)
                    AmcFileIO.m_arAmcFileName.Add(m_lbTrainingSet.Items[i]);
            }
        }

        private void m_btnProcess_Click(object sender, EventArgs e)
        {
            AmcFileIO.ConstructHMM();
            String str = "states num: " + AmcFileIO.m_hmm.m_arStates.Count.ToString() + "\n" + 
                "observation num: " + AmcFileIO.m_hmm.m_arObservations.Count.ToString();
            m_tbSeq.Text = str;
        }

        private void m_btnPredict_Click(object sender, EventArgs e)
        {
            m_dlgAmcFile.FileName = "*.amc";
            m_dlgAmcFile.Multiselect = false;
            DialogResult result = m_dlgAmcFile.ShowDialog();
            if (result == DialogResult.OK)
            {
                m_tbFileName.Text = m_dlgAmcFile.FileName;
            }
        }

        private void m_btnSeq_Click(object sender, EventArgs e)
        {
            AmcFileIO.m_strInputFilePath = m_tbFileName.Text;
            m_tbSeq.Text = AmcFileIO.StatesAndObsToString();
        }

        private void m_btnTransMatrix_Click(object sender, EventArgs e)
        {
            m_tbSeq.Text = AmcFileIO.TransAndObsMatrixToString();
        }

        private void m_btnSyn_Click(object sender, EventArgs e)
        {
            m_tbSeq.Text = AmcFileIO.Synthesize(m_tbSeq.Text);
        }
    }
}