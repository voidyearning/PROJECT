using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.IO;

namespace HMMInitialization
{
    class HMM
    {
        public ArrayList m_arTrainingSetFiles = new ArrayList();
        public ArrayList m_arStates = new ArrayList();
        public ArrayList m_arObservations = new ArrayList();
        public AmcFile m_targetFile;

        float[,] m_tranMatrix;//iStateNum x iStateNum
        float[,] m_obsMatrix;//iStateNum x iObsNum
        float[] m_initialProb;

        public void ConstructModel()
        {
            SeperateStateAndObs();
            CalcMatrix();
            int iStateNum = m_arStates.Count;
            m_initialProb = new float[iStateNum];
            float fProb = 1 / iStateNum;
            for (int i = 0; i < iStateNum; ++i)
                m_initialProb[i] = fProb;
        }
        public void ClearMatrix()
        {
            int iStateNum = m_arStates.Count;
            int iObsNum = m_arObservations.Count;
            m_tranMatrix = new float[iStateNum, iStateNum];
            m_obsMatrix = new float[iStateNum, iObsNum];

            for (int s = 0; s < iStateNum; ++s)
            {
                for (int s1 = 0; s1 < iStateNum; ++s1)
                    m_tranMatrix[s, s1] = 0;

                for (int o = 0; o < iObsNum; ++o)
                    m_obsMatrix[s, o] = 0; 
            } 
        }
        public void NormalizeMatrix()
        {
            int iStateNum = m_arStates.Count;
            int iObsNum = m_arObservations.Count;

            for (int sc = 0; sc < iStateNum; ++sc) 
            {
                float iCount = 0;
                for (int sn = 0; sn < iStateNum; ++sn)
                    iCount += m_tranMatrix[sc, sn];

                for (int sn = 0; sn < iStateNum; ++sn)
                    m_tranMatrix[sc, sn] = m_tranMatrix[sc, sn] / iCount;

                iCount = 0;
                for (int ob = 0; ob < iObsNum; ++ob)
                    iCount += m_obsMatrix[sc, ob];

                for (int ob = 0; ob < iObsNum; ++ob)
                    m_obsMatrix[sc, ob] = m_obsMatrix[sc, ob] / iCount;
            }
        }
        public void CalcMatrix()
        {
            ClearMatrix();
            for (int i = 0; i < m_arTrainingSetFiles.Count; ++i)
            {
                AmcFile file = m_arTrainingSetFiles[i] as AmcFile;
                if (file == null)
                    continue;

                //states
                for (int j = 0; j < file.m_arFrames.Count; ++j)
                {
                    AmcMotionFrame mFrame = file.m_arFrames[j] as AmcMotionFrame;
                    if (mFrame == null)
                        continue;

                    if (j + 1 >= file.m_arFrames.Count)
                        break;

                    AmcMotionFrame mFrameSuc = file.m_arFrames[j + 1] as AmcMotionFrame;
                    if (mFrameSuc == null)
                        continue;

                    int iCurrentState = mFrame.m_upbodyFrame.m_iStateId-1;
                    int iNextState = mFrameSuc.m_upbodyFrame.m_iStateId-1;
                    int iCurrentObs = mFrame.m_lowBodyFrame.m_iObsId-1;
                    m_tranMatrix[iCurrentState,iNextState] = m_tranMatrix[iCurrentState,iNextState] + 1;
                    m_obsMatrix[iCurrentState,iCurrentObs] = m_obsMatrix[iCurrentState,iCurrentObs] + 1;
                }
            }
            NormalizeMatrix();            
        }
        public void SeperateStateAndObs()
        {
            for (int i = 0; i < m_arTrainingSetFiles.Count; ++i)
            {
                AmcFile file = m_arTrainingSetFiles[i] as AmcFile;
                if (file == null)
                    continue;

                //states
                for (int j = 0; j < file.m_arFrames.Count; ++j)
                {
                    AmcMotionFrame mFrame = file.m_arFrames[j] as AmcMotionFrame;
                    if (mFrame == null)
                        continue;

                    //state
                    int idx = -1;
                    if (i == 0)
                        idx = FindStateByThreshold(mFrame.m_upbodyFrame);
                    else
                        idx = FindStateByDistance(mFrame.m_upbodyFrame);

                    if (idx != -1)
                    {
                        AmcUpBodyFrame stFrame = m_arStates[idx] as AmcUpBodyFrame;
                        //average it or not
                        mFrame.m_upbodyFrame.m_iStateId = idx + 1;
                    }
                    else
                    {
                        m_arStates.Add(mFrame.m_upbodyFrame);
                        mFrame.m_upbodyFrame.m_iStateId = m_arStates.Count;
                    }

                    //observations
                    idx = -1;
                    if (i == 0)
                        idx = FindObsByThreshold(mFrame.m_lowBodyFrame);
                    else
                        idx = FindObsByDistance(mFrame.m_lowBodyFrame);

                    if (idx != -1)
                    {
                        AmcLowerBodyFrame obFrame = m_arObservations[idx] as AmcLowerBodyFrame;
                        //average it or not
                        mFrame.m_lowBodyFrame.m_iObsId = idx+1;
                    }
                    else
                    {
                        m_arObservations.Add(mFrame.m_lowBodyFrame);
                        mFrame.m_lowBodyFrame.m_iObsId = m_arObservations.Count;
                    }
                }
            }
        }
        public int FindStateByThreshold(AmcUpBodyFrame uFrame)
        {
            for (int i = 0; i < m_arStates.Count; ++i)
            {
                AmcUpBodyFrame st = m_arStates[i] as AmcUpBodyFrame;
                if (st == null)
                    continue;

                if (st.Distance(uFrame) < 1)
                    return i;
            }
            return -1;
        }
        public int FindObsByThreshold(AmcLowerBodyFrame lFrame)
        {
            for (int i = 0; i < m_arObservations.Count; ++i)
            {
                AmcLowerBodyFrame obs = m_arObservations[i] as AmcLowerBodyFrame;
                if (obs == null)
                    continue;

                if (obs.Distance(lFrame) < 3)
                    return i;
            }
            return -1;
        }
        public int FindStateByDistance(AmcUpBodyFrame uFrame)
        {
            int idx = -1;
            float dis = 9000;
            for (int i = 0; i < m_arStates.Count; ++i)
            {
                AmcUpBodyFrame st = m_arStates[i] as AmcUpBodyFrame;
                if (st == null)
                    continue;

                float dis1 = st.Distance(uFrame);
                if (dis1 < dis)
                {
                    dis = dis1;
                    idx = i;
                }
            }
            return idx;
        }
        public int FindObsByDistance(AmcLowerBodyFrame lFrame)
        {
            int idx = -1;
            float dis = 9000;
            for (int i = 0; i < m_arObservations.Count; ++i)
            {
                AmcLowerBodyFrame obs = m_arObservations[i] as AmcLowerBodyFrame;
                if (obs == null)
                    continue;

                float dis1 = obs.Distance(lFrame);
                if (dis1 < dis)
                {
                    dis = dis1;
                    idx = i;
                }
            }
            return idx;
        }

        public String StatesAndObsToString(AmcFile file)
        {
            m_targetFile = file;
            //states
            String strStates = "";
            String strObs = "";
            for (int j = 0; j < file.m_arFrames.Count; ++j)
            {
                AmcMotionFrame mFrame = file.m_arFrames[j] as AmcMotionFrame;
                if (mFrame == null)
                    continue;

                //state
                int idx = FindStateByDistance(mFrame.m_upbodyFrame);
                idx++;
                strStates += idx.ToString() + ",";

                //observations
                idx = FindObsByDistance(mFrame.m_lowBodyFrame);
                idx++;
                strObs += idx.ToString() + ",";

                if (j % 15 == 0)
                {
                    strStates += "\r\n";
                    strObs += "\r\n";
                }
            }
            return "states: " + strStates + "\r\n" + "observations: " + strObs + "\n";
        }
        public String TransMatrixToString()
        {
            int iStateNum = m_arStates.Count;
            String strResult = "";

            for (int sc = 0; sc < iStateNum; ++sc)
            {
                for (int sn = 0; sn < iStateNum; ++sn)
                {
                    strResult += Convert.ToString(m_tranMatrix[sc, sn]);
                    if (sn == iStateNum - 1)
                        strResult += ";\r\n";
                    else
                        strResult += ",";
                }
            }
            return strResult;
        }
        public String ObsMatrixToString()
        {
            int iStateNum = m_arStates.Count;
            int iObsNum = m_arObservations.Count;
            String strResult = "";

            for (int sc = 0; sc < iStateNum; ++sc)
            {
                for (int ob = 0; ob < iObsNum; ++ob)
                {
                    strResult += Convert.ToString(m_obsMatrix[sc, ob]);
                    if (ob == iObsNum - 1)
                        strResult += ";\r\n";
                    else
                        strResult += ",";
                }
            }
            return strResult;
        }

        public String Synthesize(String strStateSeq)
        {
            int iTab = strStateSeq.IndexOf("\t");
            int iStart = 0;
            int iFrame = 0;
            while (iTab != -1)
            {
                String strState = strStateSeq.Substring(iStart, iTab - iStart);
                int iStateId = Convert.ToInt32(strState);

                AmcMotionFrame frm = m_targetFile.m_arFrames[iFrame] as AmcMotionFrame;
                frm.m_upbodyFrame = m_arStates[iStateId - 1] as AmcUpBodyFrame;

                iFrame++;
                iStart = iTab + 1;
                iTab = strStateSeq.IndexOf("\t", iStart);
            }

            return m_targetFile.ToString(); 
        }
        public String SynthesizeWithSmoothing(String strStateSeq)
        {
            int iTab = strStateSeq.IndexOf("\t");
            int iStart = 0;
            int iFrame = 0;

            int iPrevStateId = -1;
            int iPrevStateStartIdx = -1;
            while (iTab != -1)
            {
                String strState = strStateSeq.Substring(iStart, iTab - iStart);
                int iStateId = Convert.ToInt32(strState);

                if (iPrevStateId == -1)
                {
                    iPrevStateId = iStateId;
                    iPrevStateStartIdx = iFrame;
                    AmcMotionFrame frm = m_targetFile.m_arFrames[iFrame] as AmcMotionFrame;
                    frm.m_upbodyFrame = m_arStates[iStateId - 1] as AmcUpBodyFrame; 
                }
                else if (iStateId == iPrevStateId)
                {
                    AmcMotionFrame frm = m_targetFile.m_arFrames[iFrame] as AmcMotionFrame;
                    frm.m_upbodyFrame = m_arStates[iStateId - 1] as AmcUpBodyFrame;
                }
                else
                {
                    AmcMotionFrame frm = m_targetFile.m_arFrames[iFrame] as AmcMotionFrame;
                    frm.m_upbodyFrame = m_arStates[iStateId - 1] as AmcUpBodyFrame;
                    m_targetFile.InterpolateUpBodyBetween(iPrevStateStartIdx, iFrame);
                    iPrevStateStartIdx = iFrame;
                    iPrevStateId = iStateId;
                }              

                iFrame++;
                iStart = iTab + 1;
                iTab = strStateSeq.IndexOf("\t", iStart);
            }

            return m_targetFile.ToString();
        }
    }
}
