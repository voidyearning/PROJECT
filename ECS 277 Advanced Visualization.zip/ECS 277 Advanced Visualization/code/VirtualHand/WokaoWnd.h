#pragma once


// CWokaoWnd dialog

class CWokaoWnd : public CDialog
{
	DECLARE_DYNAMIC(CWokaoWnd)

public:
	CWokaoWnd(CWnd* pParent = NULL);   // standard constructor
	virtual ~CWokaoWnd();

// Dialog Data
	enum { IDD = IDD_DIALOG_WOKAO };

protected:

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCancel();
};
