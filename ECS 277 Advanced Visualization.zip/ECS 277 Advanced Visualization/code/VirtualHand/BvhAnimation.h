#pragma once
#include <vector>
#include "BaseAnimation.h"
#include "GloveAnimation.h"
#include "RawAnimation.h"

enum BVH_JOINT_TYPE
{
	BVH_ROOT = 0,
	BVH_JOINT,
	BVH_ENDSITE,
};

enum BVH_CHANNEL_TYPE
{
	BVH_X_POS,
	BVH_Y_POS,
	BVH_Z_POS,
	BVH_X_ROT,
	BVH_Y_ROT,
	BVH_Z_ROT,
	unknown
};

class CBvhJoint
{
public:
	CBvhJoint()
	{
		m_strJointName = L"";
		m_type = BVH_JOINT;
		m_arOffset.clear();
		m_arChannel.clear();
		m_arChildIdx.clear();
		m_iParentIdx = -1;
	}
	CString m_strJointName;
	BVH_JOINT_TYPE m_type;
	std::vector<float> m_arOffset;
	std::vector<BVH_CHANNEL_TYPE> m_arChannel;
	std::vector<int> m_arChildIdx;
	int m_iParentIdx;
};

class CBvhStructure
{
public:
	CBvhStructure()
	{
		m_arJoint.clear();
	}
	void Parse(CString strHierarchy);
	CString ParseNodes(CString strNodes, std::vector<CBvhJoint>& arJoint);
	BVH_CHANNEL_TYPE GetChannelTypeFromString(CString strChannel);
	CString GetChannelStringFromType(BVH_CHANNEL_TYPE typeChannel);
	CString ToString();
	int GetDataSize();
	CString GetDataNameAt(int idxData);

	std::vector<CBvhJoint> m_arJoint;
	CString m_strHeader;
};

class CBvhFrame :  public CBaseFrame
{
};

class CBvhClip : public CBaseClip
{
public:
	CBvhStructure m_bvhStructure;
	std::vector<CBvhFrame> m_arFrame;
	int m_iTotalFrames;
	float m_fIntervalTime;//in seconds

public:
	virtual void SaveToFile(std::string strPath);
	virtual void LoadFromFile(std::string strPath);
	virtual int GetFrameCount();
	virtual CBaseFrame* GetFrameAt(int iFrmIdx);	
	virtual void SetFrameAt(int iFrmIdx, CBaseFrame*);	
	virtual CBvhFrame GetAveragePose();

	void FillingBodyConsistent(CString strOutputPath, CRawClip clipHandL, CRawClip clipHandR);

	void FillInVirtualHand(CString strInputPath, CString strOutputPath, CGlvClip glvFilerLeft, int iOffsetLeft, CGlvClip glvFilerRight, int iOffsetRight, CGloveBvhRetarget glvRetarget, CGloveBvhInsert glvInsert, bool bInsert);
	CBvhFrame FillInVirtualHand(CBvhFrame bvhFrame, CGlvFrame glvFrameLeft, CGlvFrame glvFrameRight, CGloveBvhRetarget glvRetarget, CGloveBvhInsert glvInsert, bool bInsert);
};

class CGloveMappingItem
{
public:
	CGloveMappingItem()
	{
		m_fWeight = 0;
		m_iGlvIdx = -1;
	}
	float m_fWeight;
	int m_iGlvIdx;
};
class CGloveMapping
{
public:
	CGloveMapping()
	{
		m_iBvhIdx = -1;
	}
	std::vector<CGloveMappingItem> m_arMappingLeft;
	std::vector<CGloveMappingItem> m_arMappingRight;
	int m_iBvhIdx;

	bool IsNone();
	bool IsNoneLeft();
	bool IsNoneRight();
	CGloveMappingItem GetMappingItemOf(int idxGlv, bool bLeft);
	void SetMappingItemOf(int idxGlv, bool bLeft, CGloveMappingItem item);
	void SaveTo(std::ostream fout);
	void LoadFrom(std::istream fin);
};

class CGloveBvhRetarget
{
public:
	CGloveBvhRetarget(){}
	void Init(CBvhStructure bvhStructure, CGlvStructre glvStructure);
	void Reset();
	int GetBvhDataSize();
	CString GetBvhDataNameAt(int idxData);
	int GetGlvDataSize();
	CString GetGlvDataNameAt(int idxData);
	CGloveMapping GetMappingOf(int idxBvhData);
	void SetMappingOf(int idxBvhData, CGloveMapping mapping);
	CString GetExpressionOf(CGloveMapping mapping);
	void SaveTo(CString strPath);
	void LoadFrom(CString strPath);
	
	std::vector<CGloveMapping> m_arMapping;
private:
	CBvhStructure m_bvhStructure;
	CGlvStructre m_glvStructure;
};
class CGloveBvhInsert
{
public:
	CGloveBvhInsert()
	{		
		m_iStartIdxLeft = -1;
		m_iEndIdxLeft = -1;
		m_iStartIdxRight = -1;
		m_iEndIdxRight = -1;
	}
	void Init(CBvhStructure bvhStructure, CGlvStructre glvStructure)
	{
		m_bvhStructure = bvhStructure;
		m_glvStructure = glvStructure;

		m_iStartIdxLeft = 54;
		m_iEndIdxLeft = 59;
		m_iStartIdxRight = 72;
		m_iEndIdxRight = 77;
	}
	int GetBvhDataSize();
	CString GetBvhDataNameAt(int idxData);

	int m_iStartIdxLeft;
	int m_iEndIdxLeft;
	int m_iStartIdxRight;
	int m_iEndIdxRight;
	CBvhStructure m_bvhStructure;
	CGlvStructre m_glvStructure;
};




