#pragma once
#include "OpenGLWnd.h"
#include "GloveRenderer.h"
class CRawClip;
class CGloveMocapMgr;
class CGloveCalibration;

// CPlaybackCtrl dialog

class CPlaybackCtrl : public CDialog
{
	DECLARE_DYNAMIC(CPlaybackCtrl)

public:
	CPlaybackCtrl(bool bLeft = true, CWnd* pParent = NULL);   // standard constructor
	virtual ~CPlaybackCtrl();
	CRawClip* m_pClipRaw;
	CRawFrame m_frmRaw;
	int m_iCurIdx;
	COpenGLWnd m_wndOpenGL;
	CGloveMocapMgr* m_pGlvMgr;
	CGloveCalibration* m_pLinearCalibration;
	bool m_bLeft;
	int m_iCalibMethod;
	virtual BOOL OnInitDialog();
	void PlayCurFrame();
	void PlayRealtimeFrame();
	void SynchronizeToKinRot();
	void RefreshOpenGL();

// Dialog Data
	enum { IDD = IDD_CTRL_PLAYBACK };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonPlaybackBeg();
	afx_msg void OnBnClickedButtonPlaybackBackward();
	afx_msg void OnBnClickedButtonPlaybackPlay();
	afx_msg void OnBnClickedButtonPlaybackStop();
	afx_msg void OnBnClickedButtonPlaybackForward();
	afx_msg void OnBnClickedButtonPlaybackEnd();
	afx_msg void OnEnChangeEditPlaybackCurIdx();
	afx_msg void OnBnClickedButtonPlaybackLoadMotion();
	afx_msg void OnBnClickedButtonPlaybackSaveMotion();
	afx_msg void OnBnClickedButtonPlaybackLoadPose();
	afx_msg void OnBnClickedButtonPlaybackSavePose();
	afx_msg void OnBnClickedCheckPlaybackRealtime();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedRadioPlaybackRaw();
	afx_msg void OnBnClickedRadioPlaybackLinearCalibrated();
	afx_msg void OnBnClickedRadioPlaybackLmcgprCalibrated();
	afx_msg void OnBnClickedRadioPlaybackSpgpsCalibrated();
};
