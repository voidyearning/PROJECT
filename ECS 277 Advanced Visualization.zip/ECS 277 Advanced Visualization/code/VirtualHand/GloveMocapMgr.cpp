#include <vhandtk/vhtBase.h>
#include "GloveMocapMgr.h"
#include "stdio.h"

vhtIOConn * g_pGloveDict_r = NULL;
vhtCyberGlove * g_pGlove_r = NULL;
vhtIOConn * g_pTrackerDict_r = NULL;
vhtTracker * g_pTracker_r = NULL;

vhtIOConn * g_pGloveDict_l = NULL;
vhtCyberGlove * g_pGlove_l = NULL;
vhtIOConn * g_pTrackerDict_l = NULL;
vhtTracker * g_pTracker_l = NULL;



CGloveMocapMgr* CGloveMocapMgr::s_pGloveMocapMgrLeft = NULL;
CGloveMocapMgr* CGloveMocapMgr::s_pGloveMocapMgrRight = NULL;

CGloveMocapMgr* CGloveMocapMgr::GetGloveMgr(GLV_MOCAP_HANDNESS eHandness)
{
	if(eHandness == LEFT_HAND)
	{
		if(s_pGloveMocapMgrLeft == NULL)
			s_pGloveMocapMgrLeft = new CGloveMocapMgr();
		return s_pGloveMocapMgrLeft;
	}

	if(eHandness == RIGHT_HAND)
	{
		if(s_pGloveMocapMgrRight == NULL)
			s_pGloveMocapMgrRight = new CGloveMocapMgr();
		s_pGloveMocapMgrRight->SetHandness(true);
		/*Let's keep it standard
		s_pGloveMocapMgrRight->m_pCalib->m_arAdjustItem[21].m_fGain = 1.4;
		s_pGloveMocapMgrRight->m_pCalib->m_arAdjustItem[21].m_fOffset = -0.68;
		s_pGloveMocapMgrRight->m_pCalib->m_arAdjustItem[22].m_fGain = -2;
		s_pGloveMocapMgrRight->m_pCalib->m_arAdjustItem[22].m_fOffset = 0;*/

		return s_pGloveMocapMgrRight;
	}
}

CGloveMocapMgr::CGloveMocapMgr(CGloveMocapMgr&)
{
}
CGloveMocapMgr::CGloveMocapMgr(string strPath)
{
	m_bRightHand = false;
	m_bConnected = false;
	m_iOnes = 0;
	SetName(strPath);
	m_pCalib = new CGloveCalibration();
}

CGloveMocapMgr::CGloveMocapMgr()
{
	m_bRightHand = false;
	m_bConnected = false;
	m_iOnes = 0;
	SetName("");	
	m_pCalib = new CGloveCalibration();
}
void CGloveMocapMgr::SetName(string strPath)
{
	m_strPath = strPath;
}
void CGloveMocapMgr::SetHandness(bool bRightHand)
{
	m_bRightHand = bRightHand;
}
void CGloveMocapMgr::Connect()
{
	if(m_bRightHand)
		ConnectRight();
	else 
		ConnectLeft();
}
void CGloveMocapMgr::ConnectLeft()
{
	try
	{
		if(g_pGloveDict_l == NULL)
			g_pGloveDict_l = new vhtIOConn("cyberglove", "localhost", "12345","com5", "115200");
		
		if(g_pGlove_l == NULL)
			g_pGlove_l = new vhtCyberGlove(g_pGloveDict_l);
		else 
			g_pGlove_l->connect();

		m_bConnected = true;
		WriteStandardBaseCalibration();
	}
	catch (vhtBaseException *e)
	{
		printf("Error: %s\nPress <enter> to exit.\n", e->getMessage());
		getchar();
		m_bConnected = false;
	}
}
void CGloveMocapMgr::ConnectRight()
{	
	try
	{
		if(g_pGloveDict_r == NULL)
			g_pGloveDict_r = new vhtIOConn("cyberglove", "localhost", "12345","com6", "115200");

		if(g_pGlove_r == NULL)
			g_pGlove_r = new vhtCyberGlove(g_pGloveDict_r);
		else 
			g_pGlove_r->connect();
		m_bConnected = true;
		WriteStandardBaseCalibration();
	}
	catch (vhtBaseException *e)
	{
		printf("Error: %s\nPress <enter> to exit.\n", e->getMessage());
		getchar();
		m_bConnected = false;
	}
}

bool CGloveMocapMgr::IsConnected()
{
	return m_bConnected;
}

void CGloveMocapMgr::WriteStandardBaseCalibration()
{
	SetStandardBaseCalibration();
	WriteBaseCalibration();
}
void CGloveMocapMgr::SetStandardBaseCalibration()
{
	m_pCalib->ResetStandardBaseCalibration();
}
void CGloveMocapMgr::WriteBaseCalibration()
{
	if(!m_bConnected)
		return;

	vhtCyberGlove * pGlove = g_pGlove_l;
	if(m_bRightHand)
		pGlove = g_pGlove_r;

	for (int i=0; i < m_pCalib->m_arBaseItem.size(); ++i)
	{
		GHM::Fingers aFinger = (GHM::Fingers)(i/4);
		GHM::Joints aJoint = (GHM::Joints)(i%4);
		pGlove->setSensorGain(aFinger, aJoint, m_pCalib->m_arBaseItem[i].m_fGain);
		pGlove->setSensorOffset(aFinger, aJoint, m_pCalib->m_arBaseItem[i].m_fOffset);
	}
}
void CGloveMocapMgr::SetBaseGain(int iJointIdx, float fGain)
{
	if(!m_bConnected)
		return;

	vhtCyberGlove * pGlove = g_pGlove_l;
	if(m_bRightHand)
		pGlove = g_pGlove_r;

	GHM::Fingers aFinger = (GHM::Fingers)(iJointIdx/4);
	GHM::Joints aJoint = (GHM::Joints)(iJointIdx%4);
	pGlove->setSensorGain(aFinger, aJoint, fGain);
	m_pCalib->m_arBaseItem[iJointIdx].m_fGain = fGain;
}
float CGloveMocapMgr::GetBaseGain(int iJointIdx)
{
	return m_pCalib->m_arBaseItem[iJointIdx].m_fGain;
}
void CGloveMocapMgr::SetBaseOffset(int iJointIdx, float fOffset)
{
	if(!m_bConnected)
		return;

	vhtCyberGlove * pGlove = g_pGlove_l;
	if(m_bRightHand)
		pGlove = g_pGlove_r;

	GHM::Fingers aFinger = (GHM::Fingers)(iJointIdx/4);
	GHM::Joints aJoint = (GHM::Joints)(iJointIdx%4);	
	pGlove->setSensorOffset(aFinger, aJoint, fOffset);
	m_pCalib->m_arBaseItem[iJointIdx].m_fOffset = fOffset;
}
float CGloveMocapMgr::GetBaseOffset(int iJointIdx)
{
	return m_pCalib->m_arBaseItem[iJointIdx].m_fOffset;
}

void CGloveMocapMgr::SetAdjustGain(int iJointIdx, float fGain)
{
	m_pCalib->m_arAdjustItem[iJointIdx].m_fGain = fGain;
}
float CGloveMocapMgr::GetAdjustGain(int iJointIdx)
{
	return m_pCalib->m_arAdjustItem[iJointIdx].m_fGain;
}
void CGloveMocapMgr::SetAdjustOffset(int iJointIdx, float fOffset)
{
	m_pCalib->m_arAdjustItem[iJointIdx].m_fOffset = fOffset;
}
float CGloveMocapMgr::GetAdjustOffset(int iJointIdx)
{
	return m_pCalib->m_arAdjustItem[iJointIdx].m_fOffset;
}

std::vector<float> CGloveMocapMgr::RetrieveSensorData()
{
	std::vector<float> arData;
	if(!m_bConnected)
		return arData;

	vhtCyberGlove * pGlove = g_pGlove_l;
	if(m_bRightHand)
		pGlove = g_pGlove_r;
	
	//first entry is the time
	arData.push_back(pGlove->getLastUpdateTime());

	pGlove->update();
	int iSensorNum = pGlove->getDimensionRange();
	for (int i=0; i < iSensorNum; ++i)
	{
		arData.push_back(pGlove->getData(i));
	}
	return arData;
}
std::vector<float> CGloveMocapMgr::RetrieveAdjustedDataLinear()
{
	std::vector<float> arData;
	if(!m_bConnected)
		return arData;

	vhtCyberGlove * pGlove = g_pGlove_l;
	if(m_bRightHand)
		pGlove = g_pGlove_r;
	
	//first entry is the time
	arData.push_back(pGlove->getLastUpdateTime());

	pGlove->update();
	int iSensorNum = pGlove->getDimensionRange();
	for (int i=0; i < iSensorNum; ++i)
	{
		CGloveCalibrationItem adjustItem = m_pCalib->m_arAdjustItem[i];
		arData.push_back(adjustItem.m_fGain*(pGlove->getData(i) + adjustItem.m_fOffset));
	}
	return arData;
}
std::vector<float> CGloveMocapMgr::RetrieveRawData()
{
	std::vector<float> arData;
	if(!m_bConnected)
		return arData;

	vhtCyberGlove * pGlove = g_pGlove_l;
	if(m_bRightHand)
		pGlove = g_pGlove_r;
	
	//first entry is the time
	arData.push_back(pGlove->getLastUpdateTime());

	pGlove->update();
	int iSensorNum = pGlove->getDimensionRange();
	for (int i=0; i < iSensorNum; ++i)
		arData.push_back(pGlove->getRawData(i));
	return arData;
}
void CGloveMocapMgr::RecordData()
{
	if(!m_bConnected)
		return;

	vhtCyberGlove * pGlove = g_pGlove_l;
	if(m_bRightHand)
		pGlove = g_pGlove_r;
	
	if(!m_foutSensorData.is_open())
	{
		int idxDot = m_strPath.find_last_of('.');
		string strPath = m_strPath;
		strPath.insert(idxDot-1, "snr_");
		m_foutSensorData.open(strPath.c_str());
	}

	if(!m_foutAdjustedDataLinear.is_open())
		m_foutAdjustedDataLinear.open(m_strPath.c_str());

	m_tStart = clock();
	m_dBaseTime = pGlove->getLastUpdateTime();
	m_iOnes = 0;
	RecordTxt();
}

string CGloveMocapMgr::EndRecord()
{
	vhtCyberGlove * pGlove = g_pGlove_l;
	if(m_bRightHand)
		pGlove = g_pGlove_r;

	m_tEnd = clock();
	int iSensorNum = pGlove->getDimensionRange();
	char arChar[500];
	int len = sprintf(arChar, "start time %d\nend time %d\nelapsed time %d ms\nsampled frames %d\nnumber of sensors %d", m_tStart, m_tEnd, m_tEnd - m_tStart, m_iOnes, iSensorNum);
	string strMsg(arChar);

	m_foutSensorData << "\n";
	m_foutSensorData.write(arChar, len);
	m_foutSensorData.flush();
	m_foutSensorData.close();

	m_foutAdjustedDataLinear << "\n";
	m_foutAdjustedDataLinear.write(arChar, len);
	m_foutAdjustedDataLinear.flush();
	m_foutAdjustedDataLinear.close();
	
	return strMsg;
}

void CGloveMocapMgr::RecordTxt()
{
	if(!m_bConnected)
		return;

	vhtCyberGlove * pGlove = g_pGlove_l;
	if(m_bRightHand)
		pGlove = g_pGlove_r;

	// update data from the physical device
	pGlove->update();

	// Get update time delta
	m_foutSensorData << "frame" << m_iOnes << " time " << pGlove->getLastUpdateTime() - m_dBaseTime <<"\n";
	m_foutAdjustedDataLinear << "frame" << m_iOnes << " time " << pGlove->getLastUpdateTime() - m_dBaseTime <<"\n";
	//sensors
	int iSensorNum = pGlove->getDimensionRange();
	for (int i=0; i < iSensorNum; ++i)
	{
		CGloveCalibrationItem adjustItem = m_pCalib->m_arAdjustItem[i];
		m_foutSensorData << pGlove->getData(i) << " ";
		m_foutAdjustedDataLinear << adjustItem.m_fGain*(pGlove->getData(i)+adjustItem.m_fOffset) << " ";
	}
	m_foutSensorData << "\n";
	m_foutAdjustedDataLinear<<"\n";

	/*for( int finger = 0; finger < GHM::nbrFingers; finger++ ) 
	{
		m_fout << "finger" << finger << " \n";

		m_fout << "angle ";
		for( int joint = 0; joint <= GHM::nbrJoints; joint++ ) 
			m_fout << pGlove->getAngle( (GHM::Fingers)finger, (GHM::Joints)joint ) << " ";
		m_fout << "\n";
	}
	m_foutSensorData << "wrist abduct " << pGlove->getData(GHM::HandParts::palm,GHM::Joints::wristAbduction)<< "\n";
	m_foutSensorData << "writst flexion " << pGlove->getData(GHM::HandParts::palm, GHM::Joints::wristFlexion) << "\n";
	m_foutSensorData << "writst palmArch " << pGlove->getData(GHM::HandParts::palm, GHM::Joints::palmArch) << "\n";*/

	m_foutSensorData.flush();
	m_foutAdjustedDataLinear.flush();
	m_iOnes ++;
}