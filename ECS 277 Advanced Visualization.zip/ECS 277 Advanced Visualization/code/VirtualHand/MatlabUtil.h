#pragma once
#include "engine.h"
#include "mat.h"
#include "RawAnimation.h"
#include "GloveAnimation.h"
#include "PRED.h"
#include "GloveCalibration.h"

typedef CRawFrame CRawData;

class CMatlabEngine
{
public:
	static Engine* GetEngine()
	{
		if(s_pMatlabEngine == NULL)
		{
			s_pMatlabEngine = engOpen(NULL);
			engOutputBuffer(s_pMatlabEngine, NULL, 0);
			char strCmd[2000];
			sprintf(strCmd, "addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\Fast');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\Editing');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\IKSampling');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\full');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\full\\calibrate');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\full\\data');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\full\\hp');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\full\\model');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\full\\pre_generate');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\full\\train');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\fitc');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\fitc\\calibrate');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\fitc\\data');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\fitc\\hp');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\fitc\\model');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\fitc\\pre_generate');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\fitc\\train');\
addpath('C:\\Users\\wangyi\\Documents\\MATLAB\\GPRCalibration\\bc');\
addpath('C:\\wangyi\\software\\gpml-matlab-v3.1-2010-09-27');\
addpath('C:\\wangyi\\software\\gpml-matlab-v3.1-2010-09-27\\cov');\
addpath('C:\\wangyi\\software\\gpml-matlab-v3.1-2010-09-27\\doc');\
addpath('C:\\wangyi\\software\\gpml-matlab-v3.1-2010-09-27\\inf');\
addpath('C:\\wangyi\\software\\gpml-matlab-v3.1-2010-09-27\\lik');\
addpath('C:\\wangyi\\software\\gpml-matlab-v3.1-2010-09-27\\mean');\
addpath('C:\\wangyi\\software\\gpml-matlab-v3.1-2010-09-27\\util');\
addpath('C:\\wangyi\\software\\gpml-matlab-v3.1-2010-09-27\\glove');\
global HD;HD=1; global WS_PATH;WS_PATH = '%s\\trainingset'", WS_PATH);
			engEvalString(s_pMatlabEngine,strCmd);
		}
		return s_pMatlabEngine;
	}
	virtual ~CMatlabEngine()
	{
		delete s_pMatlabEngine;
	}
	static Engine* s_pMatlabEngine;
private:
	CMatlabEngine(){}
};

#include "GloveAnimation.h"
namespace MatlabUtil
{
	enum E_ABDUCTION_TYPE
	{
		E_THUMB_INDEX, E_INDEX_MID, E_MID_RING, E_RING_PINKY
	};
	void PlotCrossAbd(CRawClip clipRaw, char cMarkerType='+', char cMarkerColor='b', bool bNewFigure=false, bool bPlot3 = false);
	void PlotCrossAbdByDifference(CRawClip clipRaw, double fAbdReal=0, char cMarkerType='+', char cMarkerColor='b', bool bNewFigure = false, bool bPlot3 = false);
	
	void GriddataCrossAbd(CRawClip clipRaw);
	void GriddataCrossAbdByDifference(CRawClip clipRaw);

	void DelaunayCrossAbd(CRawClip clipRaw);
	void DelaunayCrossAbdByDifference(CRawClip clipRaw);

	void Test1();
	void Test2();

	double TDSearchCrossAbd(CRawClip clipRaw, CRawData dataTuple, std::vector<CRawData>& arSimplex, CRawData& barencentricCoord);
	double TDSearchCrossAbdByDifference(CRawClip clipRaw, CRawData dataTuple, std::vector<CRawData>& arSimplex, CRawData& barencentricCoord);

	void LoadPredictedMatFile(std::string strMatPath, std::vector<double>& arPredictedAbd);
	
	void PlotGlvClip(CGlvClip& clipGlv);
	void PlotRawClip(CRawClip& clipRaw);
	void PlotPair(CRawClip& clipSrc, int iIdxSrc, CRawClip& clipDest, int iIdxDest); 
	void ReTrainAll();
	void LoadTrained();
	//==========================================================================
	void Load_full(std::string strPath, bool bLeft = true);
	void Load_fitc(std::string strPath, bool bLeft = true);
	void Load_FK_full(std::string strPath, bool bLeft = true);
	void Load_FK_fitc(std::string strPath, bool bLeft = true);
	void Load_linear_go(std::string strPath, bool bLeft = true);
	void Load_Thumb_full(std::string strPath, bool bLeft = true);
	void Load_Thumb_bc(std::string strPath, bool bLeft = true);

	CRawFrame GPRCalibrate_full(CRawFrame& frmRaw, bool bLeft = true);
	CRawFrame GPRCalibrate_fitc(CRawFrame& frmRaw, bool bLeft = true);
	CRawFrame GPRCalibrate_FK_full(CRawFrame& frmRaw, bool bLeft = true);
	CRawFrame GPRCalibrate_FK_fitc(CRawFrame& frmRaw, bool bLeft = true);
	
	CRawFrame GPRCalibrate_linear(CRawFrame& frmRaw, bool bLeft = true);
	CRawFrame GPRCalibrate_Thumb_full(CRawFrame& frmRaw, bool bLeft = true);
	CRawFrame GPRCalibrate_Thumb_fitc(CRawFrame& frmRaw, bool bLeft = true);
	CRawFrame GPRCalibrate_fingerABD_full(CRawFrame& frmRaw, bool bLeft = true);
	CRawFrame GPRCalibrate_fingerFLEX_full(CRawFrame& frmRaw, bool bLeft = true);
	CRawFrame GPRCalibrate_fingerFLEX_fitc(CRawFrame& frmRaw, bool bLeft = true);
	CRawFrame GPRCalibrate_fingerABD_fitc(CRawFrame& frmRaw, bool bLeft = true);

	CRawClip GPRCalibrate_full(CRawClip& clipRaw, bool bLeft = true);
	CRawClip GPRCalibrate_fitc(CRawClip& clipRaw, bool bLeft = true);
	CRawClip GPRCalibrate_FK_full(CRawClip& clipRaw, bool bLeft = true);
	CRawClip GPRCalibrate_FK_fitc(CRawClip& clipRaw, bool bLeft = true);

	CRawClip GPRCalibrate_linear(CRawClip& clipRaw, bool bLeft = true);
	CRawClip GPRCalibrate_Thumb_full(CRawClip& clipRaw, bool bLeft = true);
	CRawClip GPRCalibrate_Thumb_fitc(CRawClip& clipRaw, bool bLeft = true);
	CRawClip GPRCalibrate_fingerABD_full(CRawClip& clipRaw, bool bLeft = true);	
	CRawClip GPRCalibrate_fingerABD_fitc(CRawClip& clipRaw, bool bLeft = true);
	CRawClip GPRCalibrate_fingerFLEX_full(CRawClip& clipRaw, bool bLeft = true);
	CRawClip GPRCalibrate_fingerFLEX_fitc(CRawClip& clipRaw, bool bLeft = true);


	
	CRawClip GPRCalibrate_Thumb_bc(CRawClip& clipRaw, bool bLeft = true);
	CRawFrame GPRCalibrate_Thumb_bc(CRawFrame& frmRaw, bool bLeft = true);

	CGloveCalibration LinearRegressCalibrate(CGlvFrame frmGlvFlat, CGlvFrame frmGlvSpread, CGlvFrame frmGlvFist, CGlvFrame frmGlvExtBend,
		CGlvFrame frmRealFlat, CGlvFrame frmRealSpread, CGlvFrame frmRealFist, CGlvFrame frmRealExtBend, bool bLeft = true);

	//calibrate clip range
	CRawClip GPRCalibrate_FK_full(CRawClip& clipRaw, int iBegIdx, int iEndIdx, bool bLeft = true);

	CRawClip MultilinearRegress(CRawClip clipTrainingTarget, CRawClip clipTrainingInput, CRawClip clipInput, int iDOFIndex);
};