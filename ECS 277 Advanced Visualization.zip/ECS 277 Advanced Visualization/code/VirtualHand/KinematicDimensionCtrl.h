#pragma once

class CHandSkeletonKin;
// CKinematicDimensionCtrl dialog

class CKinematicDimensionCtrl : public CDialog
{
	DECLARE_DYNAMIC(CKinematicDimensionCtrl)

public:
	CKinematicDimensionCtrl(bool bLeft=true, CWnd* pParent = NULL);   // standard constructor
	virtual ~CKinematicDimensionCtrl();
	virtual BOOL OnInitDialog();
	CHandSkeletonKin* m_pHandSkeleton;
	bool m_bLeft;
	void UpdateUIToHandDim();
	void UpdateHandDimToUI();

// Dialog Data
	enum { IDD = IDD_CTRL_KINEMATIC_DIMENSION };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonSaveKinDim();
	afx_msg void OnBnClickedButtonLoadKimDim();
	afx_msg void OnEnChangeEditTl0();
	afx_msg void OnEnChangeEditTl1();
	afx_msg void OnEnChangeEditTl2();
	afx_msg void OnEnChangeEditTl3();
	afx_msg void OnEnChangeEditTl4();
	afx_msg void OnEnChangeEditIl0();
	afx_msg void OnEnChangeEditIl1();
	afx_msg void OnEnChangeEditIl2();
	afx_msg void OnEnChangeEditIl3();
	afx_msg void OnEnChangeEditMl0();
	afx_msg void OnEnChangeEditMl1();
	afx_msg void OnEnChangeEditMl2();
	afx_msg void OnEnChangeEditMl3();
	afx_msg void OnEnChangeEditRl0();
	afx_msg void OnEnChangeEditRl1();
	afx_msg void OnEnChangeEditRl2();
	afx_msg void OnEnChangeEditRl3();
	afx_msg void OnEnChangeEditPl0();
	afx_msg void OnEnChangeEditPl1();
	afx_msg void OnEnChangeEditPl2();
	afx_msg void OnEnChangeEditPl3();
};
