#pragma once
#include <fstream>
#include <ctime>
#include <string>
#include <vector>
#include "GloveCalibration.h"
using namespace std;

enum GLV_MOCAP_HANDNESS
{
	LEFT_HAND = 0, 
	RIGHT_HAND, 
	BOTH_HANDS
};

class CGloveMocapMgr
{
public:
	static CGloveMocapMgr* GetGloveMgr(GLV_MOCAP_HANDNESS eHandness);
	static CGloveMocapMgr* s_pGloveMocapMgrLeft;
	static CGloveMocapMgr* s_pGloveMocapMgrRight;
private:
	CGloveMocapMgr();
	CGloveMocapMgr(string strPath);
	CGloveMocapMgr(CGloveMocapMgr&);
public:
	//connection
	void Connect();
	void ConnectLeft();
	void ConnectRight();	
	bool IsConnected();
	
	//calibration
	void WriteStandardBaseCalibration();
	void SetStandardBaseCalibration();
	void WriteBaseCalibration();	
	void SetBaseGain(int iJointIdx, float fGain);
	float GetBaseGain(int iJointIdx);
	void SetBaseOffset(int iJointIdx, float fOffset);
	float GetBaseOffset(int iJointIdx);
	void SetAdjustGain(int iJointIdx, float fGain);
	float GetAdjustGain(int iJointIdx);
	void SetAdjustOffset(int iJointIdx, float fOffset);
	float GetAdjustOffset(int iJointIdx);

	//data
	void RecordData();
	void RecordSensorData();
	void RecordAdjustedDataLinear();

	std::vector<	float> RetrieveAdjustedDataLinear();
	std::vector<float> RetrieveSensorData();
	std::vector<float> RetrieveRawData();
	string EndRecord();

	void SetName(string strPath);
	void SetHandness(bool bRightHand);
private:
	
	void RecordTxt();
	//test only
	void ProcessXml();
	double m_dBaseTime;
	ofstream m_foutSensorData;
	ofstream m_foutAdjustedDataLinear;

	clock_t m_tStart;
	clock_t m_tEnd;
	string m_strPath;
	bool m_bRightHand;
	bool m_bConnected;
	int m_iOnes;

	//CGloveCalibration m_baseCalibration;//the calibration that will actually be written into glove
	//CGloveCalibration m_adjustCalibration;//the local adjustment
public:
	CGloveCalibration* m_pCalib;
};
