#pragma once

#include "GloveAnimation.h"
#include "BvhAnimation.h"

class CGloveMergeDlg : public CDialog
{
	DECLARE_DYNAMIC(CGloveMergeDlg)

public:
	CGloveMergeDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGloveMergeDlg();

// Dialog Data
	enum { IDD = IDD_GLOVEMERGE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonBswSrcRight();
	afx_msg void OnBnClickedButtonBwsDest();
	afx_msg void OnBnClickedButtonBswSrcLeft();
	afx_msg void OnBnClickedButtonBwsBvhBase();
	afx_msg void OnBnClickedButtonMerge();	
	afx_msg void OnBnClickedButtonMapping();

public:
	void UpdateMergeAndCustomize();

	CGlvClip m_filerGloveLeft;
	CGlvClip m_filerGloveRight;
	CBvhClip m_filerBvh;

	CString m_strInputPath;
	CString m_strOutputPath;

	CGloveBvhRetarget m_glvRetarget;
	CGloveBvhInsert m_glvInsert;
	afx_msg void OnBnClickedCheckInsert();
	afx_msg void OnBnClickedButtonInsert();
	afx_msg void OnEnChangeEditOffsetRight();
	afx_msg void OnBnClickedButtonFastIntegrate();
};
