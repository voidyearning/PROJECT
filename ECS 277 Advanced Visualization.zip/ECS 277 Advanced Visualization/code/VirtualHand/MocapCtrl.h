#pragma once

class CGloveMocapMgr;
// CMocapCtrl dialog

class CMocapCtrl : public CDialog
{
	DECLARE_DYNAMIC(CMocapCtrl)

public:
	CMocapCtrl(CWnd* pParent = NULL);   // standard constructor
	virtual ~CMocapCtrl();
	virtual BOOL OnInitDialog();
	CGloveMocapMgr* m_pGlvMgrLeft;
	CGloveMocapMgr* m_pGlvMgrRight;
	int m_iFreq_ms;
	int m_iHandness;

// Dialog Data
	enum { IDD = IDD_CTRL_MOCAP };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonMocapHomeDir();
	afx_msg void OnBnClickedRadioMocapBothHands();
	afx_msg void OnBnClickedRadioMocapLeftHand();
	afx_msg void OnBnClickedRadioMocapRightHand();
	afx_msg void OnCbnSelchangeComboMocapFreq();
	afx_msg void OnBnClickedButtonMocapStart();
	afx_msg void OnBnClickedButtonMocapStop();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
