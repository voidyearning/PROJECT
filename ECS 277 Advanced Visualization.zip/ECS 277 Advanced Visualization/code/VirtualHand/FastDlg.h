#pragma once
#include "fast.h"


// CFastDlg dialog

class CFastDlg : public CDialog
{
	DECLARE_DYNAMIC(CFastDlg)

public:
	CFastDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CFastDlg();
	CFastCal m_fastCal;
	virtual BOOL OnInitDialog();

// Dialog Data
	enum { IDD = IDD_GLOVE_FAST_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonBrowseBasePath();
	afx_msg void OnBnClickedButtonGenerateGroundTruth();
	afx_msg void OnBnClickedButtonFastCalibrate();
	afx_msg void OnBnClickedButtonBrowseRawPath();
	afx_msg void OnBnClickedButtonFastBatchCalibrate();
	afx_msg void OnBnClickedButtonFastBatchBvh();
	afx_msg void OnBnClickedButtonFastGlvToRaw();
	afx_msg void OnBnClickedButtonGenerateGroundTruthIk();
	afx_msg void OnBnClickedButtonExtractIk();
	afx_msg void OnBnClickedButtonFastTrainIk();
	afx_msg void OnBnClickedButtonFastCheckIkInput();
	afx_msg void OnBnClickedButtonGenerateGroundTruthIkFitc();
	afx_msg void OnBnClickedButtonExtractIkFitc();
	afx_msg void OnBnClickedButtonFastTrainIkFitc();
	afx_msg void OnBnClickedButtonFastCheckIkInputFitc();
	afx_msg void OnBnClickedButtonFastLoadHandSize();
	afx_msg void OnBnClickedButtonWriteGo();
	afx_msg void OnBnClickedButtonExtractFlexFull();
	afx_msg void OnBnClickedButtonExtractFlexFitc();
	afx_msg void OnBnClickedButtonFastTrainFlexFull();
	afx_msg void OnBnClickedButtonFastTrainFlexFitc();
	afx_msg void OnBnClickedButtonGenerate2flexFitc();
	afx_msg void OnBnClickedButtonGenerate2flexFull();
	afx_msg void OnBnClickedButtonExtractAbdFull();
	afx_msg void OnBnClickedButtonExtractAbdFitc();
	afx_msg void OnBnClickedButtonFastTrainAbdFull();
	afx_msg void OnBnClickedButtonFastTrainAbdFitc();
	afx_msg void OnBnClickedButtonGenerate3abdFull();
	afx_msg void OnBnClickedButtonGenerate3abdFitc();
	afx_msg void OnBnClickedCheckFastLeft();
	afx_msg void OnBnClickedButtonXfastCalibrate();
	afx_msg void OnBnClickedButtonGenerate4ikFull();
	afx_msg void OnBnClickedButtonGenerate4ikFitc();
};
