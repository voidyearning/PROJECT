#pragma once

#include "GloveAnimation.h"
// CGloveEditDlg dialog
#include "ckinematic\CKinematicHand.h"


class CGloveEditDlg : public CDialog
{
	DECLARE_DYNAMIC(CGloveEditDlg)

public:
	CGloveEditDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGloveEditDlg();

// Dialog Data
	enum { IDD = IDD_GLOVEEDIT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	void UpdataDOFActiveFromUI(CKinematicHand& hand);

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeEditSrc();
	afx_msg void OnCbnSelchangeComboDestType();
	afx_msg void OnBnClickedButtonBswSrc();
	afx_msg void OnEnChangeEditDest();
	afx_msg void OnBnClickedButtonBwsDest();
	afx_msg void OnBnClickedButtonConvert();

public:
	void Init();
	CLIP_TYPE GetClipTypeFromExt(CString strExt);

	//CGlvClip m_filerGlove;
	CBaseClip* m_pClip;
	CLIP_TYPE m_typeDest;
	afx_msg void OnBnClickedCheckOriginal();
	afx_msg void OnBnClickedButtonIkSample();
	afx_msg void OnBnClickedCheckConcatenatedJ();
	afx_msg void OnBnClickedCheckSmoothByFk();
	afx_msg void OnBnClickedCheckContinousIk();
	afx_msg void OnEnChangeEditRatioToFinger();
	afx_msg void OnBnClickedButtonBswThumbIndex();
	afx_msg void OnBnClickedButtonBswThumbMid();
	afx_msg void OnBnClickedButtonBswThumbRing();
	afx_msg void OnBnClickedButtonBswThumbPinky();
	afx_msg void OnBnClickedButtonBswThumbAllDest();
	afx_msg void OnBnClickedButtonMergeToIkclip();
	afx_msg void OnBnClickedButtonCloseIkClip();
	afx_msg void OnBnClickedButtonExtractSubclip();
	afx_msg void OnBnClickedButtonTiIkAccuracy();
	afx_msg void OnBnClickedButtonTmIkAccuracy();
	afx_msg void OnBnClickedButtonTrIkAccuracy();
	afx_msg void OnBnClickedButtonTpIkAccuracy();
	afx_msg void OnBnClickedButtonBswGlvFlatPath();
	afx_msg void OnBnClickedButtonBswRealFlatPath();
	afx_msg void OnBnClickedButtonBswGlvSpreadPath();
	afx_msg void OnBnClickedButtonBswRealSpreadPath();
	afx_msg void OnBnClickedButtonBswGlvFistPath();
	afx_msg void OnBnClickedButtonBswRealFistPath();
	afx_msg void OnBnClickedButtonBswGlvExtbendPath();
	afx_msg void OnBnClickedButtonBswRealExtbendPath();
	afx_msg void OnBnClickedButtonBswLinearCalibrationPath();
	afx_msg void OnBnClickedButtonLinearCalibrate();
	afx_msg void OnBnClickedButtonTestEvTransform();
	afx_msg void OnBnClickedButtonEvTransform();
	afx_msg void OnBnClickedButtonExportMarkersRaw();
	afx_msg void OnBnClickedButtonExportMarkersRawtime();
	afx_msg void OnBnClickedButtonResampleFromRawtime();
	afx_msg void OnBnClickedButton1();
};
