#pragma once
#include "GloveMocapMgr.h"
#include "WokaoWnd.h"
// CGloveMocapDlg dialog
enum GLV_MOCAP_FREQ
{
	FREQ_30 = 0,
	FREQ_45,
	FREQ_60,
	FREQ_90,
	FREQ_120,
	FREQ_OTHERS
};

enum GLV_MOCAP_FILE
{
	FILE_TXT = 0,
	FILE_XML
};

#define TIMER_EVENT_ID	1

class CGloveMocapDlg : public CDialog
{
	DECLARE_DYNAMIC(CGloveMocapDlg)

public:
	CGloveMocapDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGloveMocapDlg();

	CWokaoWnd* m_pWokao;

// Dialog Data
	enum { IDD = IDD_GLOVEMOCAP_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()	
public:
	afx_msg void OnBnClickedBtnBrw();
	afx_msg void OnCbnSelchangeComboFreq();
	afx_msg void OnCbnSelchangeComboFiler();
	afx_msg void OnBnClickedBtnStart();
	afx_msg void OnBnClickedBtnStop();

private:
	GLV_MOCAP_FREQ m_eMocapFreq;
	GLV_MOCAP_FILE m_eMocapFile;//not used
	GLV_MOCAP_HANDNESS m_eMocapHandness;

	CGloveMocapMgr* m_pGlvMgrLeft;
	CGloveMocapMgr* m_pGlvMgrRight;
	void SetPath(CString strName);
	void Init();
	CString UpdatePath();
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	int GetTimerInterval(UINT_PTR nIDEvent);
	afx_msg void OnEnChangeEditFile();
	afx_msg void OnTcnSelchangeTab1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnEnChangeEditName();
	afx_msg void OnBnClickedRadioLeft();
	afx_msg void OnBnClickedRadioRight();
	afx_msg void OnBnClickedRadioBoth();
	afx_msg void OnBnClickedButtonRecordPose();
	afx_msg void OnBnClickedButtonStandardData();
	afx_msg void OnBnClickedButtonDetectStaticGap();
	afx_msg void OnBnClickedButtonToData();
};
