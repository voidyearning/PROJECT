#include "stdafx.h"
#include "PtTrajRenderer.h"
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glaux.h>
#include <gl/glut.h>


CPtTrajRenderer::CPtTrajRenderer()
{
	m_color = CKinematicPoint(255, 255, 255);
	m_bDiscrete = true;
	m_fRenderSize = 1;
	m_bShow = false;
	
	m_iRenderBegIdx = m_iRenderEndIdx = -1;
}
void CPtTrajRenderer::Render()
{
	if(!m_bShow || (m_iRenderBegIdx == -1 && m_iRenderEndIdx == -1))
		return;

	glPointSize(m_fRenderSize);	
	glColor3f(m_color.m_fX,  m_color.m_fY,  m_color.m_fZ);

	int iRenderBegIdx = m_iRenderBegIdx;
	int iRenderEndIdx = m_iRenderEndIdx;
	if(m_iRenderBegIdx < m_traj.m_iBegIdx)
		iRenderBegIdx = m_traj.m_iBegIdx;
	if(m_iRenderEndIdx > m_traj.m_iEndIdx)
		iRenderEndIdx = m_traj.m_iEndIdx;

	for(int i = iRenderBegIdx; i <= iRenderEndIdx;  ++i)
	{
		CPtTrajFrame frm = m_traj.m_arFrame[i-m_traj.m_iBegIdx];
		glPushMatrix();
		glRotated(frm.m_fWristAbd, 0.0, 1.0, 0.0);
		glRotated(frm.m_fWristFlex, 0.0, 0.0, 1.0);
		glBegin(GL_POINTS);
		glVertex3f(frm.m_pos.m_fX, frm.m_pos.m_fY, frm.m_pos.m_fZ);		
		glEnd();
		glPopMatrix();
	}
}
