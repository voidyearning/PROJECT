// KinematicDimensionCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "KinematicDimensionCtrl.h"
#include "GloveSkeleton.h"


// CKinematicDimensionCtrl dialog

IMPLEMENT_DYNAMIC(CKinematicDimensionCtrl, CDialog)

CKinematicDimensionCtrl::CKinematicDimensionCtrl(bool bLeft, CWnd* pParent /*=NULL*/)
	: CDialog(CKinematicDimensionCtrl::IDD, pParent)
{
	m_bLeft = bLeft;
}

CKinematicDimensionCtrl::~CKinematicDimensionCtrl()
{
}

void CKinematicDimensionCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}
BOOL CKinematicDimensionCtrl::OnInitDialog()
{
	UpdateHandDimToUI();
	return CDialog::OnInitDialog();
}
void CKinematicDimensionCtrl::UpdateUIToHandDim()
{
	if(m_pHandSkeleton == NULL || m_pHandSkeleton->m_pHand == NULL)
		return;

	CKinematicPoint ptCur;
	CString strText;
	//thumb
	//root
	//abd
	GetDlgItem(IDC_EDIT_TL_0)->GetWindowText(strText);
	if(m_bLeft)
		ptCur = CKinematicPoint(0, 0, _wtof(strText.GetBuffer()));
	else
		ptCur = CKinematicPoint(0, 0, - _wtof(strText.GetBuffer()));
	m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[1]->m_posLocalCoord = ptCur;
	//virtual
	GetDlgItem(IDC_EDIT_TL_1)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[2]->m_posLocalCoord = ptCur;
	//flex ij
	GetDlgItem(IDC_EDIT_TL_2)->GetWindowText(strText);	
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[3]->m_posLocalCoord = ptCur;
	//flex dij
	GetDlgItem(IDC_EDIT_TL_3)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[4]->m_posLocalCoord = ptCur;
	//end
	GetDlgItem(IDC_EDIT_TL_4)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[5]->m_posLocalCoord = ptCur;
	
	//index
	//root
	//prox
	GetDlgItem(IDC_EDIT_IL_0)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[1]->m_arJoint[1]->m_posLocalCoord = ptCur;
	//pij
	GetDlgItem(IDC_EDIT_IL_1)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[1]->m_arJoint[2]->m_posLocalCoord = ptCur;
	//dij
	GetDlgItem(IDC_EDIT_IL_2)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[1]->m_arJoint[3]->m_posLocalCoord = ptCur;
	//end
	GetDlgItem(IDC_EDIT_IL_3)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[1]->m_arJoint[4]->m_posLocalCoord = ptCur;

	//middle
	//root
	//prox
	GetDlgItem(IDC_EDIT_ML_0)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[2]->m_arJoint[1]->m_posLocalCoord = ptCur;
	//pij
	GetDlgItem(IDC_EDIT_ML_1)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[2]->m_arJoint[2]->m_posLocalCoord = ptCur;
	//dij
	GetDlgItem(IDC_EDIT_ML_2)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[2]->m_arJoint[3]->m_posLocalCoord = ptCur;
	//end
	GetDlgItem(IDC_EDIT_ML_3)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[2]->m_arJoint[4]->m_posLocalCoord = ptCur;
	
	//ring
	//root
	//prox
	GetDlgItem(IDC_EDIT_RL_0)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[3]->m_arJoint[1]->m_posLocalCoord = ptCur;
	//pij
	GetDlgItem(IDC_EDIT_RL_1)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[3]->m_arJoint[2]->m_posLocalCoord = ptCur;
	//dij
	GetDlgItem(IDC_EDIT_RL_2)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[3]->m_arJoint[3]->m_posLocalCoord = ptCur;
	//end
	GetDlgItem(IDC_EDIT_RL_3)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[3]->m_arJoint[4]->m_posLocalCoord = ptCur;
	
	//pinky
	//root
	//prox
	GetDlgItem(IDC_EDIT_PL_0)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[4]->m_arJoint[1]->m_posLocalCoord = ptCur;
	//pij
	GetDlgItem(IDC_EDIT_PL_1)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[4]->m_arJoint[2]->m_posLocalCoord = ptCur;
	//dij
	GetDlgItem(IDC_EDIT_PL_2)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[4]->m_arJoint[3]->m_posLocalCoord = ptCur;
	//end
	GetDlgItem(IDC_EDIT_RL_3)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[4]->m_arJoint[4]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->PopulateGlobalPosAndAxis();	
}
void CKinematicDimensionCtrl::UpdateHandDimToUI()
{
	if(m_pHandSkeleton == NULL || m_pHandSkeleton->m_pHand == NULL)
		return;

	CKinematicPoint ptCur;
	CString strText;
	//thumb
	//root
	//abd
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[1]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_TL_0)->SetWindowText(strText);
	//virtual
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[2]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_TL_1)->SetWindowText(strText);
	//flex ij
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[3]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_TL_2)->SetWindowText(strText);
	//flex dij
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[4]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_TL_3)->SetWindowText(strText);
	//end
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[5]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_TL_4)->SetWindowText(strText);

	//index
	//root
	//prox
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[1]->m_arJoint[1]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_IL_0)->SetWindowText(strText);
	//pij
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[1]->m_arJoint[2]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_IL_1)->SetWindowText(strText);
	//dij
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[1]->m_arJoint[3]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_IL_2)->SetWindowText(strText);
	//end
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[1]->m_arJoint[4]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_IL_3)->SetWindowText(strText);

	//middle
	//root
	//prox
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[2]->m_arJoint[1]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_ML_0)->SetWindowText(strText);
	//pij
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[2]->m_arJoint[2]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_ML_1)->SetWindowText(strText);
	//dij
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[2]->m_arJoint[3]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_ML_2)->SetWindowText(strText);
	//end
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[2]->m_arJoint[4]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_ML_3)->SetWindowText(strText);

	//ring
	//root
	//prox
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[3]->m_arJoint[1]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_RL_0)->SetWindowText(strText);
	//pij
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[3]->m_arJoint[2]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_RL_1)->SetWindowText(strText);
	//dij
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[3]->m_arJoint[3]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_RL_2)->SetWindowText(strText);
	//end
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[3]->m_arJoint[4]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_RL_3)->SetWindowText(strText);
	
	//pinky
	//root
	//prox
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[4]->m_arJoint[1]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_PL_0)->SetWindowText(strText);
	//pij
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[4]->m_arJoint[2]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_PL_1)->SetWindowText(strText);
	//dij
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[4]->m_arJoint[3]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_PL_2)->SetWindowText(strText);
	//end
	ptCur = m_pHandSkeleton->m_pHand->m_arChain[4]->m_arJoint[4]->m_posLocalCoord;
	strText.Format(L"%f", ptCur.GetEuclideanLength());
	GetDlgItem(IDC_EDIT_RL_3)->SetWindowText(strText);
}


BEGIN_MESSAGE_MAP(CKinematicDimensionCtrl, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_KIN_DIM, &CKinematicDimensionCtrl::OnBnClickedButtonSaveKinDim)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_KIM_DIM, &CKinematicDimensionCtrl::OnBnClickedButtonLoadKimDim)
	ON_EN_CHANGE(IDC_EDIT_TL_0, &CKinematicDimensionCtrl::OnEnChangeEditTl0)
	ON_EN_CHANGE(IDC_EDIT_TL_1, &CKinematicDimensionCtrl::OnEnChangeEditTl1)
	ON_EN_CHANGE(IDC_EDIT_TL_2, &CKinematicDimensionCtrl::OnEnChangeEditTl2)
	ON_EN_CHANGE(IDC_EDIT_TL_3, &CKinematicDimensionCtrl::OnEnChangeEditTl3)
	ON_EN_CHANGE(IDC_EDIT_TL_4, &CKinematicDimensionCtrl::OnEnChangeEditTl4)
	ON_EN_CHANGE(IDC_EDIT_IL_0, &CKinematicDimensionCtrl::OnEnChangeEditIl0)
	ON_EN_CHANGE(IDC_EDIT_IL_1, &CKinematicDimensionCtrl::OnEnChangeEditIl1)
	ON_EN_CHANGE(IDC_EDIT_IL_2, &CKinematicDimensionCtrl::OnEnChangeEditIl2)
	ON_EN_CHANGE(IDC_EDIT_IL_3, &CKinematicDimensionCtrl::OnEnChangeEditIl3)
	ON_EN_CHANGE(IDC_EDIT_ML_0, &CKinematicDimensionCtrl::OnEnChangeEditMl0)
	ON_EN_CHANGE(IDC_EDIT_ML_1, &CKinematicDimensionCtrl::OnEnChangeEditMl1)
	ON_EN_CHANGE(IDC_EDIT_ML_2, &CKinematicDimensionCtrl::OnEnChangeEditMl2)
	ON_EN_CHANGE(IDC_EDIT_ML_3, &CKinematicDimensionCtrl::OnEnChangeEditMl3)
	ON_EN_CHANGE(IDC_EDIT_RL_0, &CKinematicDimensionCtrl::OnEnChangeEditRl0)
	ON_EN_CHANGE(IDC_EDIT_RL_1, &CKinematicDimensionCtrl::OnEnChangeEditRl1)
	ON_EN_CHANGE(IDC_EDIT_RL_2, &CKinematicDimensionCtrl::OnEnChangeEditRl2)
	ON_EN_CHANGE(IDC_EDIT_RL_3, &CKinematicDimensionCtrl::OnEnChangeEditRl3)
	ON_EN_CHANGE(IDC_EDIT_PL_0, &CKinematicDimensionCtrl::OnEnChangeEditPl0)
	ON_EN_CHANGE(IDC_EDIT_PL_1, &CKinematicDimensionCtrl::OnEnChangeEditPl1)
	ON_EN_CHANGE(IDC_EDIT_PL_2, &CKinematicDimensionCtrl::OnEnChangeEditPl2)
	ON_EN_CHANGE(IDC_EDIT_PL_3, &CKinematicDimensionCtrl::OnEnChangeEditPl3)
END_MESSAGE_MAP()


// CKinematicDimensionCtrl message handlers

void CKinematicDimensionCtrl::OnBnClickedButtonSaveKinDim()
{
	CFileDialog dlgFile(FALSE, L"Glove Handsize File(*.gsz)|*.gsz", NULL, 4|2, L"Glove Handsize File(*.gsz)|*.gsz||");
	if(IDOK == dlgFile.DoModal())
	{
		if(m_pHandSkeleton)
			m_pHandSkeleton->SaveSizeToFile(dlgFile.GetPathName());
	}
}

void CKinematicDimensionCtrl::OnBnClickedButtonLoadKimDim()
{
	CFileDialog dlgFile(FALSE, L"Glove Handsize File(*.gsz)|*.gsz", NULL, 4|2, L"Glove Handsize File(*.gsz)|*.gsz||");
	if(IDOK == dlgFile.DoModal())
	{
		if(m_pHandSkeleton)
			m_pHandSkeleton->LoadSizeFromFile(dlgFile.GetPathName());
	}
}

void CKinematicDimensionCtrl::OnEnChangeEditTl0()
{
	CString strText;
	CKinematicPoint ptCur;
	GetDlgItem(IDC_EDIT_TL_0)->GetWindowText(strText);
	if(m_bLeft)
		ptCur = CKinematicPoint(0, 0, _wtof(strText.GetBuffer()));
	else
		ptCur = CKinematicPoint(0, 0, - _wtof(strText.GetBuffer()));
	m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[1]->m_posLocalCoord = ptCur;
	m_pHandSkeleton->m_pHand->m_arChain[0]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditTl1()
{
	CString strText;
	CKinematicPoint ptCur;
	
	//virtual
	GetDlgItem(IDC_EDIT_TL_1)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[2]->m_posLocalCoord = ptCur;
	m_pHandSkeleton->m_pHand->m_arChain[0]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditTl2()
{	
	CString strText;
	CKinematicPoint ptCur;	
	//flex ij
	GetDlgItem(IDC_EDIT_TL_2)->GetWindowText(strText);	
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[3]->m_posLocalCoord = ptCur;
}

void CKinematicDimensionCtrl::OnEnChangeEditTl3()
{	
	CString strText;
	CKinematicPoint ptCur;	
	//flex dij
	GetDlgItem(IDC_EDIT_TL_3)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[4]->m_posLocalCoord = ptCur;
}

void CKinematicDimensionCtrl::OnEnChangeEditTl4()
{
	CString strText;
	CKinematicPoint ptCur;	
	//end
	GetDlgItem(IDC_EDIT_TL_4)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[0]->m_arJoint[5]->m_posLocalCoord = ptCur;
}

void CKinematicDimensionCtrl::OnEnChangeEditIl0()
{
	CString strText;
	CKinematicPoint ptCur;
		//prox
	GetDlgItem(IDC_EDIT_IL_0)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[1]->m_arJoint[1]->m_posLocalCoord = ptCur;
	
	m_pHandSkeleton->m_pHand->m_arChain[1]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditIl1()
{
	CString strText;
	CKinematicPoint ptCur;
	//pij
	GetDlgItem(IDC_EDIT_IL_1)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[1]->m_arJoint[2]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[1]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditIl2()
{
	CString strText;
	CKinematicPoint ptCur;
	//dij
	GetDlgItem(IDC_EDIT_IL_2)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[1]->m_arJoint[3]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[1]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditIl3()
{
	CString strText;
	CKinematicPoint ptCur;
	//end
	GetDlgItem(IDC_EDIT_IL_3)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[1]->m_arJoint[4]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[1]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditMl0()
{
	CString strText;
	CKinematicPoint ptCur;
	//prox
	GetDlgItem(IDC_EDIT_ML_0)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[2]->m_arJoint[1]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[2]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditMl1()
{
	CString strText;
	CKinematicPoint ptCur;
	//pij
	GetDlgItem(IDC_EDIT_ML_1)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[2]->m_arJoint[2]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[2]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditMl2()
{
	CString strText;
	CKinematicPoint ptCur;
	//dij
	GetDlgItem(IDC_EDIT_ML_2)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[2]->m_arJoint[3]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[2]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditMl3()
{
	CString strText;
	CKinematicPoint ptCur;
	//end
	GetDlgItem(IDC_EDIT_ML_3)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[2]->m_arJoint[4]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[2]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditRl0()
{
	CString strText;
	CKinematicPoint ptCur;
	//prox
	GetDlgItem(IDC_EDIT_RL_0)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[3]->m_arJoint[1]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[3]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditRl1()
{
	CString strText;
	CKinematicPoint ptCur;
	//pij
	GetDlgItem(IDC_EDIT_RL_1)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[3]->m_arJoint[2]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[3]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditRl2()
{
	CString strText;
	CKinematicPoint ptCur;
	//dij
	GetDlgItem(IDC_EDIT_RL_2)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[3]->m_arJoint[3]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[3]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditRl3()
{
	CString strText;
	CKinematicPoint ptCur;
	//end
	GetDlgItem(IDC_EDIT_RL_3)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[3]->m_arJoint[4]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[3]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditPl0()
{
	CString strText;
	CKinematicPoint ptCur;

	//prox
	GetDlgItem(IDC_EDIT_PL_0)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[4]->m_arJoint[1]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[4]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditPl1()
{
	CString strText;
	CKinematicPoint ptCur;
	//pij
	GetDlgItem(IDC_EDIT_PL_1)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[4]->m_arJoint[2]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[4]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditPl2()
{
	CString strText;
	CKinematicPoint ptCur;
	//dij
	GetDlgItem(IDC_EDIT_PL_2)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[4]->m_arJoint[3]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[4]->PopulateGlobalPosAndAxis();
}

void CKinematicDimensionCtrl::OnEnChangeEditPl3()
{
	CString strText;
	CKinematicPoint ptCur;
	//end
	GetDlgItem(IDC_EDIT_RL_3)->GetWindowText(strText);
	ptCur = CKinematicPoint(- _wtof(strText.GetBuffer()), 0, 0);
	m_pHandSkeleton->m_pHand->m_arChain[4]->m_arJoint[4]->m_posLocalCoord = ptCur;

	m_pHandSkeleton->m_pHand->m_arChain[4]->PopulateGlobalPosAndAxis();
}
