// VirtualHandDlg.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "VirtualHandDlg.h"

#include "MatlabUtil.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CVirtualHandDlg dialog




CVirtualHandDlg::CVirtualHandDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVirtualHandDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CVirtualHandDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CVirtualHandDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB_GLV, &CVirtualHandDlg::OnTcnSelchangeTabGlv)
	ON_BN_CLICKED(IDC_BUTTON_TEST_KIN, &CVirtualHandDlg::OnBnClickedButtonTestKin)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_FULL, &CVirtualHandDlg::OnBnClickedButtonLoadFull)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_FITC, &CVirtualHandDlg::OnBnClickedButtonLoadFitc)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_FINGERABD_FULL, &CVirtualHandDlg::OnBnClickedButtonLoadFingerabdFull)
	ON_BN_CLICKED(IDC_BUTTON_SELECT_BASE_PATH, &CVirtualHandDlg::OnBnClickedButtonSelectBasePath)
	ON_BN_CLICKED(IDC_BUTTON2, &CVirtualHandDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_LINEAR_GO, &CVirtualHandDlg::OnBnClickedButtonLoadLinearGo)
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()


// CVirtualHandDlg message handlers
BOOL CVirtualHandDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	CTabCtrl* pTab=(CTabCtrl*)GetDlgItem(IDC_TAB_GLV); 
	/*pTab->InsertItem(0, L"Glove capture"); 
	pTab->InsertItem(1, L"Whole body merge");
	pTab->InsertItem(2, L"Glove resampling");
	pTab->InsertItem(3, L"Glove display");
	pTab->InsertItem(4, L"Glove calibration");
	pTab->InsertItem(5, L"Glove sampling");*/
	pTab->InsertItem(0, L"MorphCube");

	m_dlgMocap.Create(IDD_GLOVEMOCAP_DIALOG, pTab);
	m_dlgMerge.Create(IDD_GLOVEMERGE_DIALOG, pTab);
	m_dlgEdit.Create(IDD_GLOVEEDIT_DIALOG, pTab);
	m_dlgPlay.Create(IDD_GLOVEPLAY_DIALOG, pTab);
	m_dlgCalib.Create(IDD_GLOVECALIB_DIALOG, pTab);
	m_dlgSampling.Create(IDD_DIALOG_SAMPLING, pTab);
	//m_dlgFast.Create(IDD_GLOVE_FAST_DIALOG, pTab);
	m_dlgECS277.Create(IDD_DIALOG_ECS277, pTab);

	CRect rs;
	pTab->GetClientRect(&rs);

	rs.top+=30;
	rs.bottom-=30;
	rs.left+=1;
	rs.right-=2;

	m_dlgMocap.MoveWindow(&rs);	
	m_dlgMerge.MoveWindow(&rs);
	m_dlgEdit.MoveWindow(&rs);
	m_dlgPlay.MoveWindow(&rs);
	m_dlgCalib.MoveWindow(&rs);
	m_dlgSampling.MoveWindow(&rs);
	//m_dlgFast.MoveWindow(&rs);
	m_dlgECS277.MoveWindow(&rs);

	m_dlgMocap.ShowWindow(false);
	m_dlgMerge.ShowWindow(false);
	m_dlgEdit.ShowWindow(false);
	m_dlgPlay.ShowWindow(false);
	m_dlgCalib.ShowWindow(false);
	m_dlgSampling.ShowWindow(false);
	//m_dlgFast.ShowWindow(true);
	m_dlgECS277.ShowWindow(true);
    //pTab->SetCurSel(6);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CVirtualHandDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CVirtualHandDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CVirtualHandDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CVirtualHandDlg::OnTcnSelchangeTabGlv(NMHDR *pNMHDR, LRESULT *pResult)
{
	CTabCtrl* pTab=(CTabCtrl*)GetDlgItem(IDC_TAB_GLV);
	int iSel = pTab->GetCurSel();
    switch (iSel)
	{
	case 0:
			m_dlgMocap.ShowWindow(true);
			m_dlgMerge.ShowWindow(false);
	        m_dlgEdit.ShowWindow(false);
			m_dlgPlay.ShowWindow(false);
			m_dlgCalib.ShowWindow(false);
			m_dlgSampling.ShowWindow(false);
			//m_dlgFast.ShowWindow(false);
			m_dlgECS277.ShowWindow(false);
			break;
	case 1:
			m_dlgMocap.ShowWindow(false);
			m_dlgMerge.ShowWindow(true);
	        m_dlgEdit.ShowWindow(false);
			m_dlgPlay.ShowWindow(false);
			m_dlgCalib.ShowWindow(false);
			m_dlgSampling.ShowWindow(false);
			//m_dlgFast.ShowWindow(false);
			m_dlgECS277.ShowWindow(false);
			break;
	case 2:		
			m_dlgMocap.ShowWindow(false);
			m_dlgMerge.ShowWindow(false);
	        m_dlgEdit.ShowWindow(true);
			m_dlgPlay.ShowWindow(false);
			m_dlgCalib.ShowWindow(false);
			m_dlgSampling.ShowWindow(false);
			//m_dlgFast.ShowWindow(false);
			m_dlgECS277.ShowWindow(false);
			break;
	case 3:
			m_dlgMocap.ShowWindow(false);
			m_dlgMerge.ShowWindow(false);
	        m_dlgEdit.ShowWindow(false);
			m_dlgPlay.ShowWindow(true);
			m_dlgCalib.ShowWindow(false);
			m_dlgSampling.ShowWindow(false);
			//m_dlgFast.ShowWindow(false);
			m_dlgECS277.ShowWindow(false);
			::SetFocus(m_dlgPlay.m_wndOpenGL.m_hWnd);
			break;
	case 4:
			m_dlgMocap.ShowWindow(false);
			m_dlgMerge.ShowWindow(false);
	        m_dlgEdit.ShowWindow(false);
			m_dlgPlay.ShowWindow(false);
			m_dlgCalib.ShowWindow(true);
			m_dlgSampling.ShowWindow(false);
			//m_dlgFast.ShowWindow(false);
			m_dlgECS277.ShowWindow(false);
			::SetFocus(m_dlgCalib.m_wndOpenGLMainLeft.m_hWnd);
			break;
	case 5:
			m_dlgMocap.ShowWindow(false);
			m_dlgMerge.ShowWindow(false);
	        m_dlgEdit.ShowWindow(false);
			m_dlgPlay.ShowWindow(false);
			m_dlgCalib.ShowWindow(false);
			m_dlgSampling.ShowWindow(true);
			//m_dlgFast.ShowWindow(false);
			m_dlgECS277.ShowWindow(false);
			break;
	case 6:
			m_dlgMocap.ShowWindow(false);
			m_dlgMerge.ShowWindow(false);
	        m_dlgEdit.ShowWindow(false);
			m_dlgPlay.ShowWindow(false);
			m_dlgCalib.ShowWindow(false);
			m_dlgSampling.ShowWindow(false);
			//m_dlgFast.ShowWindow(true);
			m_dlgECS277.ShowWindow(true);
			break;
	}

	*pResult = 0;
}
#include "CKinematic\IKSolverDlg.h"
#include "MocapMainDialog.h"
void CVirtualHandDlg::OnBnClickedButtonTestKin()
{
	CMocapMainDialog mocapDlg;
	mocapDlg.DoModal();
	return;
	CKinematicHand* pHand = NULL;
	/*
	if(m_dlgCalib.m_eAdjustHandness == LEFT_HAND) 
		pHand = m_dlgCalib.m_pHandLeft->m_pHand;
	else 
		pHand = m_dlgCalib.m_pHandRight->m_pHand;*/
	pHand = m_dlgPlay.m_pHandRenderer->m_pHand->m_pHand;
	CIKSolverDlg2 dlg(pHand);
	dlg.DoModal();
	m_dlgCalib.Invalidate(1);
	string strBvhHeader = pHand->GetBvhHeader();
	strBvhHeader.append("0 0 ");
	strBvhHeader.append(pHand->GetBvhData());
	::MessageBoxA(NULL, strBvhHeader.c_str(), "bvh header", MB_OK);
}


void CVirtualHandDlg::OnBnClickedButtonLoadFull()
{
	MatlabUtil::Load_full(m_strLoadPath, true);
	MatlabUtil::Load_full(m_strLoadPath, false);
}

void CVirtualHandDlg::OnBnClickedButtonLoadFitc()
{
	MatlabUtil::Load_fitc(m_strLoadPath, true);
	MatlabUtil::Load_fitc(m_strLoadPath, false);
}

void CVirtualHandDlg::OnBnClickedButtonLoadFingerabdFull()
{
	MatlabUtil::Load_FK_full(m_strLoadPath, true);
	MatlabUtil::Load_FK_full(m_strLoadPath, false);
}
#include "GloveUtil.h"
void CVirtualHandDlg::OnBnClickedButtonSelectBasePath()
{
		CString strPath = GloveUtil::ShowFolderDlg(L"Base Path");
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_BASE_PATH); 
		pEdit->SetWindowText(strPath);
		strPath = strPath.Trim();
		m_strLoadPath = GloveUtil::ToChar(strPath);
}

void CVirtualHandDlg::OnBnClickedButton2()
{
	//GloveUtil::CalculateFKError();

	//GloveUtil::constructStaticPoseForPerception(L"E:\\research\\hand motion perception\\data\\raw\\pose\\orchid.raw", L"E:\\research\\hand motion perception\\data\\raw\\motion\\orchid.raw");
	GloveUtil::UseHandPose(L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\fist.raw",
		L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\wristExtracted.raw",
		L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\wfist.raw");

	GloveUtil::UseHandPose(L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\flat.raw",
		L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\wristExtracted.raw",
		L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\wflat.raw");

	GloveUtil::UseHandPose(L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\spread.raw",
		L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\wristExtracted.raw",
		L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\wspread.raw");

	GloveUtil::UseHandPose(L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\rest.raw",
		L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\wristExtracted.raw",
		L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\wrest.raw");

	GloveUtil::UseHandPose(L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\touching.raw",
		L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\wristExtracted.raw",
		L"E:\\research\\HandMotionPerception\\data\\raw\\pose\\wtouching.raw");
}

void CVirtualHandDlg::OnBnClickedButtonLoadLinearGo()
{
	MatlabUtil::Load_linear_go(m_strLoadPath, true);
	MatlabUtil::Load_linear_go(m_strLoadPath, false);
}

void CVirtualHandDlg::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: Add your message handler code here and/or call default

	CDialog::OnKeyDown(nChar, nRepCnt, nFlags);
}

BOOL CVirtualHandDlg::PreTranslateMessage(MSG* pMsg)
{
	return m_dlgECS277.PreTranslateMessage(pMsg);
}
