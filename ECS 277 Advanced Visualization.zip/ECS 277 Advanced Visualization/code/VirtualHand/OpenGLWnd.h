#pragma once
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glaux.h>
#include <gl/glut.h>
#include "GloveRenderer.h"
#include "PtTrajRenderer.h"


class CSampleOpenGLRenderer : public COpenGLRenderer
{
public:
	virtual void Render();
};

#define		DOUBLE_Z_DEPTH	100000
#define     DATA_SIZE	20


class COpenGLWnd : public CWnd
{
public:
	COpenGLWnd();
	virtual ~COpenGLWnd();
	virtual void OnDraw(CDC* pDC); 

	int MySetPixelFormat(HDC hdc);
	void DrawColorBox();
	void DrawCoordinate();

	void SetRender(COpenGLRenderer* pRenderer);
	COpenGLRenderer* m_pRenderer;
	std::vector<CPtTrajRenderer*> m_arTrajRenderer;

public:
	bool m_bShowHand;
	bool m_bLightOn;
	double m_dLightPosX;
	double m_dLightPosY;
	double m_dLightPosZ;

	bool m_bShowOrigin;
	CPoint m_ptLBtnDown;
	CPoint m_ptRBtnDown;
	CPoint m_ptMBtnDown;

	int m_iXWndSize;
	int m_iYWndSize;
    int m_iXmin;
	int m_iXmax;
	int m_iYmin;
	int m_iYmax;
	int m_iZmin;
	int m_iZmax;
	int m_iZoomStep;	
    int m_iDisplayList;

    double m_dXOffset;
	double m_dYOffset;
	double m_dOffsetStep;

	double m_dXAngle;
	double m_dYAngle;
	double m_dZAngle;
	double m_dAngleStep;
	double m_dAspectRatio;

	HDC m_hDC ;
	HGLRC m_hGLRC;
	HPALETTE m_hPalette ;

	BOOL SetupPixelFormat();
	BOOL InitializeOpenGL();   
	void SetLogicalPalette();
	void Minify();
	void Amplify();	
	void Maxify();
	void IncreaseXAngle();
	void DecreaseXAngle();
	void IncreaseYAngle();
	void DecreaseYAngle();
	void IncreaseZAngle();
	void DecreaseZAngle();
	void NormalizeAngle();
	void NormalizeScope();
	void Centralize();
	void DeCentralize();
	void GetScope();
	void Leftward();
	void Rightward();
	void Upward();
	void Downward() ;
	void RatializeScope( int cx , int cy );
	void OnDrawGL();
	void SetViewFront();
	void SetViewLeft();
	void SetViewTop();

public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();	
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);	
	afx_msg void OnRButtonDown( UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp( UINT nFlags, CPoint point);
	afx_msg void OnMButtonDown( UINT nFlags, CPoint point);
	afx_msg void OnMButtonUp( UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel( UINT nFlags, short zDelta, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};