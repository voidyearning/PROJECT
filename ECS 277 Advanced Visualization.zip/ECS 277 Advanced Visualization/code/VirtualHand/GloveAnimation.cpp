#include "stdafx.h"
#include "GloveAnimation.h"
#include <fstream>
#include "math.h"
#include "GloveUtil.h"
using namespace GloveUtil;

/*********************************************************************************************************************************
raw data

/*********************************************************************************************************************************
glove data
*********************************************************************************************************************************/
int CGlvStructre::GetDataSize()
{
	return 23;
}
CGlvFrame::CGlvFrame()
{
}
CGlvFrame::CGlvFrame(const std::vector<float>& arData)
{
	m_arData.clear();
	for(int i = 0; i < arData.size(); ++i)
		m_arData.push_back(arData[i]);
}
bool CGlvFrame::operator == (const CGlvFrame& frame)
{
	if(m_arData.size() != frame.m_arData.size())
		return false;
	for(int i = 0; i < m_arData.size(); ++i)
	{
		if(m_arData[i] != frame.m_arData[i])
			return false;
	}
	return true;
}
//raw is in degree, glv is in radian
CGlvFrame CGlvFrame::GetEmptyFrame()
{
	CGlvFrame emptyFrame;
	for(int i = 0; i < 23; ++i)
		emptyFrame.m_arData.push_back(0);
	emptyFrame.m_fTime = 0;
	return emptyFrame;
}
void CGlvFrame::LoadFromFile(std::string strPath)
{
	LoadFromFileRadian(strPath);
}
void CGlvFrame::LoadFromFileRadian(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	m_arData.clear();
	while(fin.good())
	{
		char buf[1024] = {0};
		fin.getline(buf, sizeof(buf));
		CString strLine(buf);
		if(strLine.Find(L"frame") == 0)
		{
			//time
			int iTime = strLine.Find(L"time ");
			iTime += 5;
			CString strTime = strLine.Mid(iTime);
			m_fTime = _wtof(strTime.GetBuffer());

			//data
			buf[1023] = 0;
			fin.getline(buf, sizeof(buf));
			CString strData(buf);
			int iStart = 0, iEnd = strData.Find(L" ");
			int iCount = 0;
			while(iEnd > iStart)
			{
				CString strOneData = strData.Mid(iStart, iEnd - iStart);
				strOneData.Trim();
				float fData = _wtof(strOneData);
				m_arData.push_back(fData);
				iStart = iEnd + 1;
				iEnd = strData.Find(L" ", iStart);
			}
		}
	}
}
void CGlvFrame::LoadFromFileAngle(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	m_arData.clear();
	while(fin.good())
	{
		char buf[1024] = {0};
		fin.getline(buf, sizeof(buf));
		CString strLine(buf);
		if(strLine.Find(L"frame") == 0)
		{
			//time
			int iTime = strLine.Find(L"time ");
			iTime += 5;
			CString strTime = strLine.Mid(iTime);
			m_fTime = _wtof(strTime.GetBuffer());

			//data
			buf[1023] = 0;
			fin.getline(buf, sizeof(buf));
			CString strData(buf);
			int iStart = 0, iEnd = strData.Find(L" ");
			int iCount = 0;
			while(iEnd > iStart)
			{
				CString strOneData = strData.Mid(iStart, iEnd - iStart);
				strOneData.Trim();
				float fData = GloveUtil::DegreeToRadian(_wtof(strOneData));
				m_arData.push_back(fData);
				iStart = iEnd + 1;
				iEnd = strData.Find(L" ", iStart);
			}
		}
	}
}
void CGlvFrame::SaveToFile(std::string strPath)
{
	SaveToFileRadian(strPath);
}
void CGlvFrame::SaveToFileRadian(std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	fout << "frame" << 0 << " time " << 0 <<"\n";
	for(int i = 0; i < m_arData.size(); ++i)
	{
		fout << m_arData[i] << " ";
	}
	fout << "\n";
	fout.flush();
	fout.close();
}
void CGlvFrame::SaveToFileAngle(std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	fout << "frame" << 0 << " time " << 0 <<"\n";
	for(int i = 0; i < m_arData.size(); ++i)
	{
		fout << GloveUtil::RadianToDegree(m_arData[i]) << " ";
	}
	fout << "\n";
	fout.flush();
	fout.close();
}
void CGlvFrame::ZeroWristRotations()
{
	if(m_arData.size() < 23)
		return;

	m_arData[CGlvStructre::glv_wristPitch] = 0;
	m_arData[CGlvStructre::glv_wristYaw] = 0;
}

void CGlvFrame::ToRadian()
{
	for(int i = 0; i < m_arData.size(); ++i)
	{
		float fData = m_arData[i];
		float fDataRadian = GloveUtil::DegreeToRadian(fData);
		m_arData[i] = fDataRadian;
	}
}
void CGlvFrame::ToDegree()
{
	for(int i = 0; i < m_arData.size(); ++i)
	{
		float fData = m_arData[i];
		float fDataDegree = GloveUtil::RadianToDegree(fData);
		m_arData[i] = fDataDegree;
	}
}

/*deprecated*/ char* CGlvFrame::ToBvh()
{
	/*bvh order                         - glove data
	0: hand:Z							0			
	1: hand:Y							0
	
	2: ProxPhalanx:Yrotation1			glv_thumbAbduction = 3		
	3: ProxPhalanx:Zrotation1			glv_thumbTMJ = 0;        thumb roll
	4: ProxPhalanx:Xrotation1			glv_thumbTMJ = 0;        thumb roll
	5: MidPhalanx:Zrotation1			glv_thumbMPJ = 1         inner 
	6: DistPhalanx:Zrotation1			glv_thumbIJ = 2          outer

	7: ProxPhalanx:Yrotation2			glv_indexAbduction = 7
	8: ProxPhalanx:Zrotation2			glv_indexMPJ = 4
	9: MidPhalanx:Zrotation2			glv_indexPIJ = 5
	10: DistPhalanx:Zrotation2			glv_indexDIJ = 6

	11: ProxPhalanx:Yrotation3			glv_middleAbudction = 11	
	12:ProxPhalanx:Zrotation3			glv_middleMPJ = 8
	13:MidPhalanx:Zrotation3			glv_middlePIJ = 9
	14:DistPhalanx:Zrotation3			glv_middleDIJ = 10

	15:ProxPhalanx:Yrotation4			glv_ringAbduction = 15
	16:ProxPhalanx:Zrotation4			glv_ringMPJ = 12
	17:MidPhalanx:Zrotation4			glv_ringPIJ = 13
	18:DistPhalanx:Zrotation4			glv_ringDIJ = 14

	19:ProxPhalanx:Yrotation5			glv_pinkieAbduction = 19
	20:ProxPhalanx:Zrotation5			glv_pinkieMPJ = 16
	21:MidPhalanx:Zrotation5			glv_pinkiePIJ = 17
	22:DistPhalanx:Zrotation5			glv_pinkieDIJ = 18*/

	CString strBvh = L"";
	strBvh.Format(L"%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f",
		0.0, 0.0,
		RadianToDegree(m_arData[CGlvStructre::glv_thumbAbduction]), RadianToDegree(m_arData[CGlvStructre::glv_thumbTMJ]), RadianToDegree(m_arData[CGlvStructre::glv_thumbTMJ]), RadianToDegree(m_arData[CGlvStructre::glv_thumbMPJ]), RadianToDegree(m_arData[CGlvStructre::glv_thumbIJ]), 
		RadianToDegree(m_arData[CGlvStructre::glv_indexAbduction]), RadianToDegree(m_arData[CGlvStructre::glv_indexMPJ]), RadianToDegree(m_arData[CGlvStructre::glv_indexPIJ]), RadianToDegree(m_arData[CGlvStructre::glv_indexDIJ]),
		RadianToDegree(m_arData[CGlvStructre::glv_middleAbudction]), RadianToDegree(m_arData[CGlvStructre::glv_middleMPJ]), RadianToDegree(m_arData[CGlvStructre::glv_indexPIJ]), RadianToDegree(m_arData[CGlvStructre::glv_indexDIJ]),
		RadianToDegree(m_arData[CGlvStructre::glv_ringAbduction]), RadianToDegree(m_arData[CGlvStructre::glv_ringMPJ]), RadianToDegree(m_arData[CGlvStructre::glv_ringPIJ]), RadianToDegree(m_arData[CGlvStructre::glv_ringDIJ]),
		RadianToDegree(m_arData[CGlvStructre::glv_pinkieAbduction]), RadianToDegree(m_arData[CGlvStructre::glv_pinkieMPJ]), RadianToDegree(m_arData[CGlvStructre::glv_pinkiePIJ]), RadianToDegree(m_arData[CGlvStructre::glv_pinkieDIJ]));
	return GloveUtil::ToChar(strBvh);
}
/*deprecated*/ char* CGlvStructre::GetDataNameAt(int idxData)
{
	switch(idxData)
	{
	case 0: return "thumbTMJ";
	case 1: return "thumbMPJ";
	case 2: return "thumbIJ";
	case 3: return "thumbAbduction";
	case 4: return "indexMPJ";
	case 5: return "indexPIJ";
	case 6: return "indexDIJ";
	case 7: return "indexAbduction";
	case 8: return "middleMPJ";
	case 9: return "middlePIJ";
	case 10: return "middleDIJ";
	case 11: return "middleAbudction";
	case 12: return "ringMPJ";
	case 13: return "ringPIJ";
	case 14: return "ringDIJ";
	case 15: return "ringAbduction";
	case 16: return "pinkieMPJ";
	case 17: return "pinkiePIJ";
	case 18: return "pinkieDIJ";
	case 19: return "pinkieAbduction";
	case 20: return "palmArch";
	case 21: return "wristPitch";
	case 22: return "wristYaw";
	}
	return "";
}
CGlvClip::CGlvClip()
{
	m_arFrame.clear();
	m_fBaseTime = 0;
	m_fIntervalTime = 0;
}
CBaseFrame* CGlvClip::GetFrameAt(int iFrmIdx)
{
	return (CBaseFrame*)(&m_arFrame[iFrmIdx]);
}

void CGlvClip::SetFrameAt(int iFrmIdx, CBaseFrame* pFrame)
{
	m_arFrame[iFrmIdx] = *(CGlvFrame*)pFrame;
}
int CGlvClip::GetFrameCount()
{
	return m_arFrame.size();
}
void CGlvClip::SaveToFile(std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	for(int i = 0; i < m_arFrame.size(); ++ i)
	{
		CGlvFrame frame = m_arFrame[i];
		fout << "frame" << i << " time " << frame.m_fTime << std::endl;
	
		for(int i = 0; i < frame.m_arData.size(); ++i)
			fout << frame.m_arData[i] << " ";
		fout << std::endl;
	}
	fout.flush();
	fout.close();
}
void CGlvClip::LoadFromFile(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	if(!fin.good())
		return;

	m_arFrame.clear();
	int iFrameCount = 0;
	while(fin.good())
	{
		char buf[1024] = {0};
		fin.getline(buf, sizeof(buf));
		CString strLine(buf);

		CGlvFrame frame;
		if(strLine.Find(L"frame") == 0)
		{
			int iTime = strLine.Find(L"time ");
			iTime += 5;
			CString strTime = strLine.Mid(iTime);
			frame.m_fTime = _wtof(strTime.GetBuffer());

			if(iFrameCount == 0)
				m_fBaseTime = frame.m_fTime;
			if(iFrameCount == 1)
				m_fIntervalTime = frame.m_fTime - m_fBaseTime;

			iFrameCount++;

			buf[1023] = 0;
			fin.getline(buf, sizeof(buf));
			CString strData(buf);
			int iStart = 0, iEnd = strData.Find(L" ");
			int iCount = 0;
			while(iEnd > iStart)
			{
				CString strOneData = strData.Mid(iStart, iEnd - iStart);
				strOneData.Trim();
				float fData = _wtof(strOneData);
				frame.m_arData.push_back(fData);
				iStart = iEnd + 1;
				iEnd = strData.Find(L" ", iStart);
			}
			if(frame.m_arData.size() !=0)
				m_arFrame.push_back(frame);
		}
	}
}
std::vector<float> CGlvClip::GetTimeArray()
{
	std::vector<float> arTime;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		float fTime = m_arFrame[i].m_fTime;
		arTime.push_back(fTime);
	}
	return arTime;
}
void CGlvClip::Resample(float fNewIntervalTime)
{
	if(fNewIntervalTime == m_fIntervalTime ||
		fNewIntervalTime <= 0)
		return;

	std::vector<CGlvFrame> arFrame;
	float fDuration= m_arFrame.size() * m_fIntervalTime;
	int iFrameCount = 0;
	float fCurrentTime = m_fBaseTime;
	while(fCurrentTime <= m_fBaseTime + fDuration)
	{
		CGlvFrame frame = GetFrameAt(fCurrentTime);
		arFrame.push_back(frame);
		
		fCurrentTime = fCurrentTime + m_fIntervalTime;
		iFrameCount++;
	}
	m_fIntervalTime = fNewIntervalTime;
	m_arFrame = arFrame;
}
void CGlvClip::SaveToBvh(std::string strPath)
{
	float fInterval = m_fIntervalTime;
	if(fInterval <=0)
		fInterval = 0.0469999;

	std::ofstream fout(strPath.c_str());
	fout << IDS_BVH_STRUCTURE;
	fout << "MOTION" << std::endl;
	fout << "Frame Time: " << fInterval << std::endl;
	
	int iFrameCount = 0;
	float fCurrentTime = m_fBaseTime;
	float fDuration = fInterval * m_arFrame.size();
	while(fCurrentTime <= m_fBaseTime + fDuration)
	{
		fCurrentTime = fCurrentTime + fInterval;
		iFrameCount ++;
	}	
	fout << "Frames: " << iFrameCount << std::endl;	
	
	iFrameCount = 0;
	fCurrentTime = m_fBaseTime;
	while(fCurrentTime <= fDuration + m_fBaseTime)
	{
		CGlvFrame frame = GetFrameAt(fCurrentTime);
		char* pBvhString = frame.ToBvh();
		fout << pBvhString;
		fout << std::endl;
		delete pBvhString;
		
		fCurrentTime = fCurrentTime + fInterval;
		iFrameCount++;
	}
	fout.flush();
	fout.close();
}
CGlvFrame CGlvClip::GetFrameAt(float time)
{
	CGlvFrame emptyFrame = CGlvFrame::GetEmptyFrame();
	emptyFrame.m_fTime = time;

	if(m_arFrame.size() == 0)
		return emptyFrame; 

	int iBeg = 0;
	for(int i = 0; i < m_arFrame.size(); ++ i)
	{
		CGlvFrame frame = m_arFrame[i];

		if((i == 0 && time < frame.m_fTime)||
			(i == m_arFrame.size() -1 && time > frame.m_fTime))
			return emptyFrame;

		if(time > frame.m_fTime)
			iBeg = i;
	}

	CGlvFrame frameBeg = m_arFrame[iBeg];
	CGlvFrame frameEnd = m_arFrame[iBeg + 1];

	CGlvFrame frame = InterpolateLinear(frameBeg, frameEnd, time);
	return frame;
}
#define TIME_SMALL  0.0001
CGlvFrame CGlvClip::InterpolateLinear(CGlvFrame frameBeg, CGlvFrame frameEnd, float curTime)
{
	if(fabs(curTime-frameBeg.m_fTime) < TIME_SMALL)
		return frameBeg;
	if(fabs(curTime - frameEnd.m_fTime) < TIME_SMALL)
		return frameEnd;

	float fRatio = (curTime - frameBeg.m_fTime) / (frameEnd.m_fTime - frameBeg.m_fTime);

	CGlvFrame frame;
	frame.m_fTime = curTime;

	for(int i = 0; i < frameBeg.m_arData.size(); ++i)
	{
		float data = (1 - fRatio) * frameBeg.m_arData[i] + fRatio * frameEnd.m_arData[i];
		frame.m_arData.push_back(data);
	}
	return frame;
}

CGlvFrame CGlvClip::GetAveragePose()
{
	CGlvFrame frmAvePose;
	if(m_arFrame.size() <= 0)
		return frmAvePose;
	
	frmAvePose = CGlvFrame::GetEmptyFrame();
	for(int f = 0; f < m_arFrame.size(); ++f)
	{
		CGlvFrame frmCur = m_arFrame[f];
		for(int d = 0; d < frmCur.m_arData.size(); ++d)
			frmAvePose.m_arData[d] += frmCur.m_arData[d];
	}
	for(int d = 0; d < frmAvePose.m_arData.size(); ++d)
		frmAvePose.m_arData[d] = frmAvePose.m_arData[d] / m_arFrame.size();
	
	return frmAvePose;
}
CBaseClip* CGlvClip::GetSubClip(int iBegIdx, int iEndIdx)
{
	CGlvClip* pResultClip = new CGlvClip();
	for(int i = iBegIdx; i < iEndIdx; ++i)
	{
		CGlvFrame frmSub = m_arFrame[i];
		pResultClip->m_arFrame.push_back(frmSub);
	}
	return (CBaseClip*)pResultClip;
}
void CGlvClip::ZeroWristRotations()
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CGlvFrame frmGlv = m_arFrame[i];
		frmGlv.ZeroWristRotations();
		m_arFrame[i] = frmGlv;
	}
}

void CGlvClip::ToRadian()
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CGlvFrame frmGlv = m_arFrame[i];
		frmGlv.ToRadian();
		m_arFrame[i] = frmGlv;
	}
}
void CGlvClip::ToDegree()
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CGlvFrame frmGlv = m_arFrame[i];
		frmGlv.ToDegree();
		m_arFrame[i] = frmGlv;
	}
}
STATIC_GAPS CGlvClip::FindUnchaningData(int iConsecutiveThreshold)
{
	STATIC_GAPS gaps; 
	int iGapBeg = 0,  iGapEnd = 0;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CGlvFrame frmGapBeg = m_arFrame[iGapBeg];
		CGlvFrame frmGlv = m_arFrame[i];
		if(frmGapBeg == frmGlv)
			iGapEnd = i;
		else
		{
			if(iGapEnd - iGapBeg + 1>= iConsecutiveThreshold)
			{
				STATIC_GAP gap;
				gap.first = iGapBeg;
				gap.second = iGapEnd;
				gaps.push_back(gap);
			}
			iGapBeg = i;
			iGapEnd = i;
		}
		
	}
	return gaps;
}

void CGlvClip::ToGlvData(std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CGlvFrame frmGlv = m_arFrame[i];
		if(i >= 321 && i <= 466)
			frmGlv = m_arFrame[321];
		if(i>=349 && i<=466)
			continue;

		for(int j = 0; j < frmGlv.m_arData.size(); ++j)
		{
			if(j == CGlvStructre::glv_indexDIJ ||
				j == CGlvStructre::glv_middleDIJ ||
				j == CGlvStructre::glv_middleAbudction ||
				j == CGlvStructre::glv_ringDIJ ||
				j == CGlvStructre::glv_pinkieDIJ)
				continue;

			float fData = frmGlv.m_arData[j];
			if(i == 467)
				fData = 0.55 * (m_arFrame[465].m_arData[j] + m_arFrame[468].m_arData[j]);
			fout <<fData * 180.0 / 3.1415926;
			if(j == frmGlv.m_arData.size() -1)
				fout << std::endl;
			else 
				fout << " ";
		}
	}
	fout.flush();
	fout.close();
}

/*********************************************************************************************************************************
bvh data
*********************************************************************************************************************************/
//hierachy and total frames
//no detailed frame data

