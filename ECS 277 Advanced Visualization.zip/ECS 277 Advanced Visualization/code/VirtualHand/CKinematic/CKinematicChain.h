#pragma once
#include "..\MatlabUtil.h"
#include "..\RawAnimation.h"
#include <vector>
using namespace std;



class CKinematicPoint
{
public:
	float m_fX;
	float m_fY;
	float m_fZ;
	
	CKinematicPoint(const CKinematicPoint& kPt);
	CKinematicPoint();
	CKinematicPoint(float x, float y, float z);
	CKinematicPoint(char* strPos);
	CKinematicPoint(wchar_t* strPos);
	CKinematicPoint& operator=(const CKinematicPoint& kPt);
	void operator+=(const CKinematicPoint& kPt);
	void operator-=(const CKinematicPoint& kPt);
	void operator*=(const float k);
	void operator /=(const float k);
	CKinematicPoint operator*(const float k);
	CKinematicPoint operator+(const CKinematicPoint& kPt);
	virtual ~CKinematicPoint();
	float GetEuclideanLength();
	std::string ToString();
	void Normalize();
	float DistanceTo(CKinematicPoint& kPt);
};
typedef CKinematicPoint CKinematicPos;
typedef CKinematicPoint CKinematicVec3D;
class CKinematicJoint;
class CKinematicChain;

class CKinematicDOF
{
public:
	//member
	CKinematicJoint* m_pParentJoint;
	CKinematicVec3D m_vecLocalAxis;
	CKinematicVec3D m_vecGlobalAxis;	
	float m_dLocalRotationAngle;//degree
	int m_iID;
	//constaints
	float m_dWeight;/*0-no impact, 1-free*/
	CKinematicVec3D m_vecConstraints;/*alpha, min, max*/
	float m_fVariance;//degree
	bool m_bActive;//false to be rigid

	//static method
	static CKinematicDOF* CloneNew(const CKinematicDOF& kDOF, CKinematicJoint* pParentJoint=NULL);
	
	//method
	CKinematicDOF();
	CKinematicDOF(float dLocalRotationAngle, CKinematicVec3D vecLocalAxis);
	CKinematicDOF(float dLocalRotationAngle, CKinematicVec3D vecLocalAxis, CKinematicVec3D vecGlobalAxis);
	CKinematicDOF(float dLocalRotationAngle, CKinematicVec3D vecLocalAxis, CKinematicVec3D vecGlobalAxis, int iID);
	CKinematicDOF(float dLocalRotationAngle, CKinematicVec3D vecLocalAxis, int iID);
	CKinematicDOF(float dLocalRotationAngle, CKinematicVec3D vecLocalAxis, int iID, float dWeight, CKinematicVec3D vecConstraints);
	CKinematicDOF(float dLocalRotationAngle, CKinematicVec3D vecLocalAxis, int iID, float dWeight, CKinematicVec3D vecConstraints, float fVariance);
	CKinematicDOF(const CKinematicDOF& kDOF);
	string GetBvhChannelInfo();
	virtual ~CKinematicDOF();
	inline bool IsViolateConstraints();
};

class CKinematicJoint
{
public:
	//member
	CKinematicChain* m_pParentChain;
	vector<CKinematicDOF*> m_arDOF;	
	CKinematicPos m_posLocalCoord;
	CKinematicPos m_posGlobalCoord;
	string m_strName;
	int m_iID;

	//static method
	static CKinematicJoint* CloneNew(const CKinematicJoint& kJoint, CKinematicChain* pParentChain=NULL);

	//method
	CKinematicJoint();
	CKinematicJoint(CKinematicPos posLocalCoord);
	CKinematicJoint(CKinematicPos posLocalCoord, CKinematicPos posGlobalCoord);
	CKinematicJoint(CKinematicPos posLocalCoord, CKinematicPos posGlobalCoord, int iID);
	CKinematicJoint(CKinematicPos posLocalCoord, int iID);
	CKinematicJoint(const CKinematicJoint& kJoint);
	virtual ~CKinematicJoint();

	void AddDOF(CKinematicDOF* pDOF);
	int GetActiveDOFNum();
	string GetBvhChannelInfo();
	string GetBvhOffsetInfo();

	string GetBvhOffsetInfoConsistentWithBody(bool bLeft);
	string GetBvhChannelInfoConsistentWithBody();
};

class CKinematicChain
{
public:
	CKinematicPos m_posGoal;
	CKinematicPos m_posRoot;
	vector<CKinematicJoint*> m_arJoint;
	int m_iID;
	
	static CKinematicChain* CloneNew(const CKinematicChain& kChain);
	CKinematicChain();
	CKinematicChain(CKinematicPos posRoot);
	CKinematicChain(CKinematicPos posRoot, int iID);
	CKinematicChain(const CKinematicChain& kChain);
	virtual ~CKinematicChain();

	void AddJoint(CKinematicJoint* pJoint);
	void AddDOF(CKinematicDOF* pDOF, int iIDJoint);
	CKinematicJoint* GetJointByID(int iJointID);
	CKinematicDOF* GetDOFByID(int iDOFID);
	CKinematicDOF* GetDOFByID(int iJointID, int iDOFID);

	void PopulateGlobalPosAndAxis();
	void SolveToReach(CKinematicPos posGoal);
	void SolveToReachWithWeightConstraints(CKinematicPos posGoal);
	void SolveToReachWithRangeConstraints(CKinematicPos posGoal);
	void SolveToReachWithCombinedConstraints(CKinematicPos posGoal);
	void SolveToReachWithCombinedConstraintsDLS(CKinematicPos posGoal);
	void	SolveToReachWithCombinedConstraintsDLSFromPalm(CKinematicPos posGoal);
	void SolveToReachWithCombinedConstraints_thumb(CKinematicPos posGoal, float fA, float fB);

	void IKSolver_stablized(CKinematicPos posGoal, float fTolerance, std::vector<float> arWeight);

	void SolveToReachWithCombinedConstraintsDLS_thumb_activeOnly(CKinematicPos posGoal);
	void SolveToReachWithForClipByConJ(CRawClip& inputClipRadian, CRawClip& outputClipRadian, std::vector<CKinematicPos>& arGoal, std::vector<float>& arGain, std::vector<float>& arOffset, std::vector<int>& arFree);

	double GetPosProbability(CKinematicPos posEnd);
	double GetPosProbabilityFromPalm(CKinematicPos posEnd);

	void VisualizeMatlab();
	int GetJointNum();
	int GetDOFNum();
	CKinematicDOF* GetDOFAt(int iDOF);	
	void SetDOFAt(int iDOF, CKinematicDOF* pDOF);

	int GetActiveDOFNum();

	inline CKinematicPos GetGlobalEndEffectorPos() {return m_arJoint[m_arJoint.size()-1]->m_posGlobalCoord;}
	CKinematicPos GetLocalPosOfDOFAt(int iDOF);
	void SetGlobalPosOfDOFAt(int iDOF, CKinematicPos posGlobal);
	void Render();
	void RenderGlobalPos();
	void RenderLocalRotation();
	float GetEndDistanceToGoal();
	string GetBvhHeader(string strNamePrefix="", int iStartIdx=0, string strTab=""); 
	string GetBvhHeaderConsistentWithBody(bool bLeft, string strNamePrefix="", int iStartIdx=0, string strTab="");
	string GetBvhData();
	bool IsFailedIK();
	float GetChainLength();
};