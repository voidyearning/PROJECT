// IKSolverDlg.cpp : implementation file
//

#include "stdafx.h"
#include "..\Resource.h"
#include "IKSolverDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


CIKSolverRenderer::CIKSolverRenderer(CIKSolverDlg2* pDlg)
{
	m_pDlg = pDlg;
}
void CIKSolverRenderer::Render()
{
	CKinematicHandRenderer* pHandRenderer = m_pDlg->m_pHandRenderer;
	if(pHandRenderer)
		pHandRenderer->Render();
}

#include "TreeListContainer.h"

CIKSolverDlg2::CIKSolverDlg2(CKinematicHand* pHand, CWnd* pParent) 
: CDialog(CIKSolverDlg2::IDD, pParent)
{
	m_pHand = pHand;
}
void CIKSolverDlg2::BuildTreeForPalmRigidHand()
{
	//create tree handle
	RECT rcTree;
	GetDlgItem(IDC_STATIC_TREE)->GetClientRect(&rcTree);
	TREELIST_HANDLE hTreeListHandle = TreeListCreate(GetModuleHandle(NULL), GetDlgItem(IDC_STATIC_TREE)->m_hWnd, &rcTree, TREELIST_DRAW_EDGE | TREELIST_ANCHOR_RIGHT, &ValidateTreeEditRequestForPalmRigidHand);

	//add column
	TreeListAddColumn(hTreeListHandle, "Kinematic Name",   200);
	TreeListAddColumn(hTreeListHandle, "Local Rotation",   100);
	TreeListAddColumn(hTreeListHandle, "Global Position", 200);	
	TreeListAddColumn(hTreeListHandle, "Goal Position", TREELIST_LAST_COLUMN);

	//add tree item
	m_arHandle.clear();
	m_arHandle.push_back(hTreeListHandle);
	//thumb
	CKinematicChain* pChainThumb = m_pHand->m_arChain[0];
	NODE_HANDLE hThumbChain = TreeListAddItemForPalmRigidHand(hTreeListHandle, NULL, (void*)1, "Thumb", NULL, NULL, pChainThumb);
	NODE_HANDLE hThumbDOFX = TreeListAddItemForPalmRigidHand(hTreeListHandle, hThumbChain, (void*)2, "Roll-X", pChainThumb->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hThumbDOFY = TreeListAddItemForPalmRigidHand(hTreeListHandle, hThumbChain, (void*)3,  "Abduct-Y", pChainThumb->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hThumbDOFZ1 = TreeListAddItemForPalmRigidHand(hTreeListHandle, hThumbChain, (void*)4, "Flex-Z-Mid", pChainThumb->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hThumbDOFZ2 = TreeListAddItemForPalmRigidHand(hTreeListHandle, hThumbChain, (void*)5, "Flex-Z-Distal", pChainThumb->m_arJoint[3]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hThumbEnd = TreeListAddItemForPalmRigidHand(hTreeListHandle, hThumbChain, (void*)6, "End Effector", NULL, pChainThumb->m_arJoint[pChainThumb->m_arJoint.size()-1], NULL);

	m_arHandle.push_back(hThumbChain);
	m_arHandle.push_back(hThumbDOFX);
	m_arHandle.push_back(hThumbDOFY);
	m_arHandle.push_back(hThumbDOFZ1);
	m_arHandle.push_back(hThumbDOFZ2);
	m_arHandle.push_back(hThumbEnd);

	//index
	CKinematicChain* pChainIndex = m_pHand->m_arChain[1];
	NODE_HANDLE hIndexChain = TreeListAddItemForPalmRigidHand(hTreeListHandle, NULL, (void*)7, "Index", NULL, NULL, pChainIndex);
	NODE_HANDLE hIndexAbduct = TreeListAddItemForPalmRigidHand(hTreeListHandle, hIndexChain, (void*)8, "Abuct-Y", pChainIndex->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hIndexFlexProximal = TreeListAddItemForPalmRigidHand(hTreeListHandle, hIndexChain, (void*)9, "FLEX-Z-Proximal", pChainIndex->m_arJoint[0]->m_arDOF[1], NULL, NULL);
	NODE_HANDLE hIndexFlexMid = TreeListAddItemForPalmRigidHand(hTreeListHandle, hIndexChain, (void*)10, "FLEX-Z-Mid", pChainIndex->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hIndexFlexDistal = TreeListAddItemForPalmRigidHand(hTreeListHandle, hIndexChain, (void*)11, "FLEX-Z-Distal", pChainIndex->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hIndexEnd = TreeListAddItemForPalmRigidHand(hTreeListHandle, hIndexChain, (void*)12, "End Effector", NULL, pChainIndex->m_arJoint[pChainIndex->m_arJoint.size()-1], NULL);
	m_arHandle.push_back(hIndexChain);
	m_arHandle.push_back(hIndexAbduct);
	m_arHandle.push_back(hIndexFlexProximal);
	m_arHandle.push_back(hIndexFlexMid);
	m_arHandle.push_back(hIndexFlexDistal);
	m_arHandle.push_back(hIndexEnd);
	
	//mid
	CKinematicChain* pChainMid = m_pHand->m_arChain[2];
	NODE_HANDLE hMidChain = TreeListAddItemForPalmRigidHand(hTreeListHandle, NULL, (void*)13, "Mid", NULL, NULL, pChainMid);
	NODE_HANDLE hMidAbduct = TreeListAddItemForPalmRigidHand(hTreeListHandle, hMidChain, (void*)14, "Abduct-Y", pChainMid->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hMidFlexProximal = TreeListAddItemForPalmRigidHand(hTreeListHandle, hMidChain, (void*)15, "FLEX-Z-Proximal", pChainMid->m_arJoint[0]->m_arDOF[1], NULL, NULL);
	NODE_HANDLE hMidFlexMid = TreeListAddItemForPalmRigidHand(hTreeListHandle, hMidChain, (void*)16, "FLEX-Z-Mid", pChainMid->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hMidFlexDistal = TreeListAddItemForPalmRigidHand(hTreeListHandle, hMidChain, (void*)17, "FLEX-Z-Distal", pChainMid->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hMidEnd = TreeListAddItemForPalmRigidHand(hTreeListHandle, hMidChain, (void*)18, "End Effector", NULL, pChainMid->m_arJoint[pChainMid->m_arJoint.size()-1], NULL);
	m_arHandle.push_back(hMidChain);
	m_arHandle.push_back(hMidAbduct);
	m_arHandle.push_back(hMidFlexProximal);
	m_arHandle.push_back(hMidFlexMid);
	m_arHandle.push_back(hMidFlexDistal);
	m_arHandle.push_back(hMidEnd);
	
	//ring
	CKinematicChain* pChainRing = m_pHand->m_arChain[3];
	NODE_HANDLE hRingChain = TreeListAddItemForPalmRigidHand(hTreeListHandle, NULL, (void*)19, "Ring", NULL, NULL, pChainRing);
	NODE_HANDLE hRingAbduct = TreeListAddItemForPalmRigidHand(hTreeListHandle, hRingChain, (void*)20, "Abduct-Y", pChainRing->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hRingFlexProximal = TreeListAddItemForPalmRigidHand(hTreeListHandle, hRingChain, (void*)21, "FLEX-Z-Proximal", pChainRing->m_arJoint[0]->m_arDOF[1], NULL, NULL);
	NODE_HANDLE hRingFlexMid = TreeListAddItemForPalmRigidHand(hTreeListHandle, hRingChain, (void*)22, "FLEX-Z-Mid", pChainRing->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hRingFlexDistal = TreeListAddItemForPalmRigidHand(hTreeListHandle, hRingChain, (void*)23, "FLEX-Z-Distal", pChainRing->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hRingEnd = TreeListAddItemForPalmRigidHand(hTreeListHandle, hRingChain, (void*)24, "End Effector", NULL, pChainRing->m_arJoint[pChainRing->m_arJoint.size()-1], NULL);
	m_arHandle.push_back(hRingChain);
	m_arHandle.push_back(hRingAbduct);
	m_arHandle.push_back(hRingFlexProximal);
	m_arHandle.push_back(hRingFlexMid);
	m_arHandle.push_back(hRingFlexDistal);
	m_arHandle.push_back(hRingEnd);
	
	//pinky
	CKinematicChain* pChainPinky = m_pHand->m_arChain[4];
	NODE_HANDLE hPinkyChain = TreeListAddItemForPalmRigidHand(hTreeListHandle, NULL, (void*)25, "Pinky", NULL, NULL, pChainPinky);
	NODE_HANDLE hPinkyAbduct = TreeListAddItemForPalmRigidHand(hTreeListHandle, hPinkyChain, (void*)26, "Abduct-Y", pChainPinky->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hPinkyFlexProximal = TreeListAddItemForPalmRigidHand(hTreeListHandle, hPinkyChain, (void*)27, "FLEX-Z-Proximal", pChainPinky->m_arJoint[0]->m_arDOF[1], NULL, NULL);
	NODE_HANDLE hPinkyFlexMid = TreeListAddItemForPalmRigidHand(hTreeListHandle, hPinkyChain, (void*)28, "FLEX-Z-Mid", pChainPinky->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hPinkyFlexDistal = TreeListAddItemForPalmRigidHand(hTreeListHandle, hPinkyChain, (void*)29, "FLEX-Z-Distal", pChainPinky->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	NODE_HANDLE hPinkyEnd = TreeListAddItemForPalmRigidHand(hTreeListHandle, hPinkyChain, (void*)30, "End Effector", NULL, pChainPinky->m_arJoint[pChainPinky->m_arJoint.size()-1], NULL);
	m_arHandle.push_back(hPinkyChain);
	m_arHandle.push_back(hPinkyAbduct);
	m_arHandle.push_back(hPinkyFlexProximal);
	m_arHandle.push_back(hPinkyFlexMid);
	m_arHandle.push_back(hPinkyFlexDistal);
	m_arHandle.push_back(hPinkyEnd);	            
}
void CIKSolverDlg2::BuildTreeForKinematicHand()
{	
	//create tree handle
	RECT rcTree;
	GetDlgItem(IDC_STATIC_TREE)->GetClientRect(&rcTree);
	TREELIST_HANDLE hTreeListHandle = TreeListCreate(GetModuleHandle(NULL), GetDlgItem(IDC_STATIC_TREE)->m_hWnd, &rcTree, TREELIST_DRAW_EDGE | TREELIST_ANCHOR_RIGHT, &ValidateTreeEditRequestForKinematicHand);

	//add column
	TreeListAddColumn(hTreeListHandle, "Kinematic Name",   200);
	TreeListAddColumn(hTreeListHandle, "Local Rotation",   80);
	TreeListAddColumn(hTreeListHandle, "Global Position", 180);	
	TreeListAddColumn(hTreeListHandle, "Weight", 60);
	TreeListAddColumn(hTreeListHandle, "Constraints", 200);
	TreeListAddColumn(hTreeListHandle, "Goal Position", TREELIST_LAST_COLUMN);

	//add tree item
	int iID = 0;
	m_arHandle.clear();
	m_arHandle.push_back(hTreeListHandle);
	//thumb
	CKinematicChain* pChainThumb = m_pHand->m_arChain[0];
	NODE_HANDLE hThumbChain = TreeListAddItemForKinematicHand(hTreeListHandle, NULL, (void*)++iID, "Thumb", NULL, NULL, pChainThumb);//1
	NODE_HANDLE hThumbDOFX = TreeListAddItemForKinematicHand(hTreeListHandle, hThumbChain, (void*)++iID, "Roll-X", pChainThumb->m_arJoint[0]->m_arDOF[0], NULL, NULL);//2,3,4
	NODE_HANDLE hThumbDOFY = TreeListAddItemForKinematicHand(hTreeListHandle, hThumbChain, (void*)(iID=iID+3),  "Abduct-Y", pChainThumb->m_arJoint[1]->m_arDOF[0], NULL, NULL);//5,6,7
	NODE_HANDLE hThumbDOFXTWIST = TreeListAddItemForKinematicHand(hTreeListHandle, hThumbChain, (void*)(iID=iID+3), "Virtual-Twist", pChainThumb->m_arJoint[2]->m_arDOF[0],NULL, NULL);//8,9,10
	NODE_HANDLE hThumbDOFZ1 = TreeListAddItemForKinematicHand(hTreeListHandle, hThumbChain, (void*)(iID=iID+3), "Mid-Flex-Z", pChainThumb->m_arJoint[3]->m_arDOF[0], NULL, NULL);//11,12,13
	NODE_HANDLE hThumbDOFZ2 = TreeListAddItemForKinematicHand(hTreeListHandle, hThumbChain, (void*)(iID=iID+3), "Distal-Flex-Z", pChainThumb->m_arJoint[4]->m_arDOF[0], NULL, NULL);//14,15,16
	NODE_HANDLE hThumbEnd = TreeListAddItemForKinematicHand(hTreeListHandle, hThumbChain, (void*)(iID=iID+3), "End Effector", NULL, pChainThumb->m_arJoint[pChainThumb->m_arJoint.size()-1], NULL);//17
	m_arHandle.push_back(hThumbChain);
	m_arHandle.push_back(hThumbDOFX);
	m_arHandle.push_back(hThumbDOFY);
	m_arHandle.push_back(hThumbDOFXTWIST);
	m_arHandle.push_back(hThumbDOFZ1);
	m_arHandle.push_back(hThumbDOFZ2);
	m_arHandle.push_back(hThumbEnd);

	//index
	CKinematicChain* pChainIndex = m_pHand->m_arChain[1];
	NODE_HANDLE hIndexChain = TreeListAddItemForKinematicHand(hTreeListHandle, NULL, (void*)++iID, "Index", NULL, NULL, pChainIndex);//18
	NODE_HANDLE hIndexAbductPalm = TreeListAddItemForKinematicHand(hTreeListHandle, hIndexChain, (void*)++iID, "Palm-Abduct-Y", pChainIndex->m_arJoint[0]->m_arDOF[0], NULL, NULL);//19,20,21
	NODE_HANDLE hIndexFlexPalm = TreeListAddItemForKinematicHand(hTreeListHandle, hIndexChain, (void*)(iID=iID+3), "Palm-Flex-Z", pChainIndex->m_arJoint[0]->m_arDOF[1], NULL, NULL);//22,23,24
	NODE_HANDLE hIndexAbduct = TreeListAddItemForKinematicHand(hTreeListHandle, hIndexChain, (void*)(iID=iID+3), "Prox-Abuct-Y", pChainIndex->m_arJoint[1]->m_arDOF[0], NULL, NULL);//25,26,27
	NODE_HANDLE hIndexFlexProximal = TreeListAddItemForKinematicHand(hTreeListHandle, hIndexChain, (void*)(iID=iID+3), "Prox-Flex-Z", pChainIndex->m_arJoint[1]->m_arDOF[1], NULL, NULL);//28,29,30
	NODE_HANDLE hIndexFlexMid = TreeListAddItemForKinematicHand(hTreeListHandle, hIndexChain, (void*)(iID=iID+3), "Mid-Flex-Z", pChainIndex->m_arJoint[2]->m_arDOF[0], NULL, NULL);//31,32,33
	NODE_HANDLE hIndexFlexDistal = TreeListAddItemForKinematicHand(hTreeListHandle, hIndexChain, (void*)(iID=iID+3), "Distal-Flex-Z", pChainIndex->m_arJoint[3]->m_arDOF[0], NULL, NULL);//34,35,36
	NODE_HANDLE hIndexEnd = TreeListAddItemForKinematicHand(hTreeListHandle, hIndexChain, (void*)(iID=iID+3), "End Effector", NULL, pChainIndex->m_arJoint[pChainIndex->m_arJoint.size()-1], NULL);//37
	m_arHandle.push_back(hIndexChain);
	m_arHandle.push_back(hIndexAbductPalm);
	m_arHandle.push_back(hIndexFlexPalm);	
	m_arHandle.push_back(hIndexAbduct);
	m_arHandle.push_back(hIndexFlexProximal);
	m_arHandle.push_back(hIndexFlexMid);
	m_arHandle.push_back(hIndexFlexDistal);
	m_arHandle.push_back(hIndexEnd);
	
	//mid
	CKinematicChain* pChainMid = m_pHand->m_arChain[2];
	NODE_HANDLE hMidChain = TreeListAddItemForKinematicHand(hTreeListHandle, NULL, (void*)++iID, "Mid", NULL, NULL, pChainMid);//38
	NODE_HANDLE hMidAbductPalm = TreeListAddItemForKinematicHand(hTreeListHandle, hMidChain, (void*)++iID, "Palm-Abduct-Y", pChainMid->m_arJoint[0]->m_arDOF[0], NULL, NULL);//39,40,41
	NODE_HANDLE hMidFlexPalm = TreeListAddItemForKinematicHand(hTreeListHandle, hMidChain, (void*)(iID=iID+3), "Palm-Flex-Z", pChainMid->m_arJoint[0]->m_arDOF[1], NULL, NULL);//42,43,44	
	NODE_HANDLE hMidAbduct = TreeListAddItemForKinematicHand(hTreeListHandle, hMidChain, (void*)(iID=iID+3), "Prox-Abduct-Y", pChainMid->m_arJoint[1]->m_arDOF[0], NULL, NULL);//45,46,47
	NODE_HANDLE hMidFlexProximal = TreeListAddItemForKinematicHand(hTreeListHandle, hMidChain, (void*)(iID=iID+3), "Prox-Flex-Z", pChainMid->m_arJoint[1]->m_arDOF[1], NULL, NULL);//48,49,50
	NODE_HANDLE hMidFlexMid = TreeListAddItemForKinematicHand(hTreeListHandle, hMidChain, (void*)(iID=iID+3), "Mid-Flex-Z", pChainMid->m_arJoint[2]->m_arDOF[0], NULL, NULL);//51,52,53
	NODE_HANDLE hMidFlexDistal = TreeListAddItemForKinematicHand(hTreeListHandle, hMidChain, (void*)(iID=iID+3), "Distal-Flex-Z", pChainMid->m_arJoint[3]->m_arDOF[0], NULL, NULL);//54,55,56
	NODE_HANDLE hMidEnd = TreeListAddItemForKinematicHand(hTreeListHandle, hMidChain, (void*)(iID=iID+3), "End Effector", NULL, pChainMid->m_arJoint[pChainMid->m_arJoint.size()-1], NULL);//57
	m_arHandle.push_back(hMidChain);
	m_arHandle.push_back(hMidAbductPalm);
	m_arHandle.push_back(hMidFlexPalm);
	m_arHandle.push_back(hMidAbduct);
	m_arHandle.push_back(hMidFlexProximal);
	m_arHandle.push_back(hMidFlexMid);
	m_arHandle.push_back(hMidFlexDistal);
	m_arHandle.push_back(hMidEnd);
	
	//ring
	CKinematicChain* pChainRing = m_pHand->m_arChain[3];
	NODE_HANDLE hRingChain = TreeListAddItemForKinematicHand(hTreeListHandle, NULL, (void*)++iID, "Ring", NULL, NULL, pChainRing);//58
	NODE_HANDLE hRingAbductPalm = TreeListAddItemForKinematicHand(hTreeListHandle, hRingChain, (void*)++iID, "Palm-Abduct-Y", pChainRing->m_arJoint[0]->m_arDOF[0], NULL, NULL);//59,60,61
	NODE_HANDLE hRingFlexPalm = TreeListAddItemForKinematicHand(hTreeListHandle, hRingChain, (void*)(iID=iID+3), "Palm-Flex-Z", pChainRing->m_arJoint[0]->m_arDOF[1], NULL, NULL);//62,63,64
	NODE_HANDLE hRingAbduct = TreeListAddItemForKinematicHand(hTreeListHandle, hRingChain, (void*)(iID=iID+3), "Prox-Abduct-Y", pChainRing->m_arJoint[1]->m_arDOF[0], NULL, NULL);//65,66,67
	NODE_HANDLE hRingFlexProximal = TreeListAddItemForKinematicHand(hTreeListHandle, hRingChain, (void*)(iID=iID+3), "Prox-Flex-Z", pChainRing->m_arJoint[1]->m_arDOF[1], NULL, NULL);//68,69,70
	NODE_HANDLE hRingFlexMid = TreeListAddItemForKinematicHand(hTreeListHandle, hRingChain, (void*)(iID=iID+3), "Mid-Flex-Z", pChainRing->m_arJoint[2]->m_arDOF[0], NULL, NULL);//71,72,73
	NODE_HANDLE hRingFlexDistal = TreeListAddItemForKinematicHand(hTreeListHandle, hRingChain, (void*)(iID=iID+3), "Distal-Flex-Z", pChainRing->m_arJoint[3]->m_arDOF[0], NULL, NULL);//74,75,76
	NODE_HANDLE hRingEnd = TreeListAddItemForKinematicHand(hTreeListHandle, hRingChain, (void*)(iID=iID+3), "End Effector", NULL, pChainRing->m_arJoint[pChainRing->m_arJoint.size()-1], NULL);//77
	m_arHandle.push_back(hRingChain);
	m_arHandle.push_back(hRingAbductPalm);
	m_arHandle.push_back(hRingFlexPalm);
	m_arHandle.push_back(hRingAbduct);
	m_arHandle.push_back(hRingFlexProximal);
	m_arHandle.push_back(hRingFlexMid);
	m_arHandle.push_back(hRingFlexDistal);
	m_arHandle.push_back(hRingEnd);
	
	//pinky
	CKinematicChain* pChainPinky = m_pHand->m_arChain[4];
	NODE_HANDLE hPinkyChain = TreeListAddItemForKinematicHand(hTreeListHandle, NULL, (void*)++iID, "Pinky", NULL, NULL, pChainPinky);//78
	NODE_HANDLE hPinkyAbductPalm = TreeListAddItemForKinematicHand(hTreeListHandle, hPinkyChain, (void*)++iID, "Palm-Abduct-Y", pChainPinky->m_arJoint[0]->m_arDOF[0], NULL, NULL);//79,80,81
	NODE_HANDLE hPinkyFlexPalm = TreeListAddItemForKinematicHand(hTreeListHandle, hPinkyChain, (void*)(iID=iID+3), "Palm-Flex-Z", pChainPinky->m_arJoint[0]->m_arDOF[1], NULL, NULL);//82,83,84
	NODE_HANDLE hPinkyAbduct = TreeListAddItemForKinematicHand(hTreeListHandle, hPinkyChain, (void*)(iID=iID+3), "Prox-Abduct-Y", pChainPinky->m_arJoint[1]->m_arDOF[0], NULL, NULL);//85,86,87
	NODE_HANDLE hPinkyFlexProximal = TreeListAddItemForKinematicHand(hTreeListHandle, hPinkyChain, (void*)(iID=iID+3), "Prox-Flex-Z", pChainPinky->m_arJoint[1]->m_arDOF[1], NULL, NULL);//88,89,90
	NODE_HANDLE hPinkyFlexMid = TreeListAddItemForKinematicHand(hTreeListHandle, hPinkyChain, (void*)(iID=iID+3), "Mid-Flex-Z", pChainPinky->m_arJoint[2]->m_arDOF[0], NULL, NULL);//91,92,93
	NODE_HANDLE hPinkyFlexDistal = TreeListAddItemForKinematicHand(hTreeListHandle, hPinkyChain, (void*)(iID=iID+3), "Distal-Flex-Z", pChainPinky->m_arJoint[3]->m_arDOF[0], NULL, NULL);//94,95,96
	NODE_HANDLE hPinkyEnd = TreeListAddItemForKinematicHand(hTreeListHandle, hPinkyChain, (void*)(iID=iID+3), "End Effector", NULL, pChainPinky->m_arJoint[pChainPinky->m_arJoint.size()-1], NULL);//97
	m_arHandle.push_back(hPinkyChain);
	m_arHandle.push_back(hPinkyAbductPalm);
	m_arHandle.push_back(hPinkyFlexPalm);
	m_arHandle.push_back(hPinkyAbduct);
	m_arHandle.push_back(hPinkyFlexProximal);
	m_arHandle.push_back(hPinkyFlexMid);
	m_arHandle.push_back(hPinkyFlexDistal);
	m_arHandle.push_back(hPinkyEnd);	

}
CIKSolverDlg2* g_pDlg = NULL;
BOOL _stdcall CIKSolverDlg2::ValidateTreeEditRequestForPalmRigidHand(const TREELIST_HANDLE TreeListHandle,const void *pAnyPtr, const char *NewData,char *Override)
{
	int iID = (int)pAnyPtr;

	//set new goal
	if(iID == 1 || iID == 7 || iID == 13 || iID == 19 || iID == 25)
	{
		CKinematicPos posGoal = CKinematicPos((char*)NewData);
		switch(iID)
		{
		case 1: g_pDlg->m_pHand->m_arChain[0]->m_posGoal =posGoal; 
			g_pDlg->m_wndOpenGL.Invalidate(1); return TRUE;

		case 7: g_pDlg->m_pHand->m_arChain[1]->m_posGoal =posGoal; 
			g_pDlg->m_wndOpenGL.Invalidate(1); return TRUE;

		case 13: g_pDlg->m_pHand->m_arChain[2]->m_posGoal =posGoal; 
			g_pDlg->m_wndOpenGL.Invalidate(1); return TRUE;

		case 19: g_pDlg->m_pHand->m_arChain[3]->m_posGoal =posGoal; 
			g_pDlg->m_wndOpenGL.Invalidate(1); return TRUE;

		case 25: g_pDlg->m_pHand->m_arChain[4]->m_posGoal =posGoal; 
			g_pDlg->m_wndOpenGL.Invalidate(1); return TRUE;
		}
	}

	//set new rotation angle
	float dRotationAngle = atof(NewData);
	switch(iID)
	{
		//Thumb
	case 2: //"Roll-X"
		g_pDlg->m_pHand->m_arChain[0]->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(0); return TRUE;

	case 3: //"Abduct-Y"
		g_pDlg->m_pHand->m_arChain[0]->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(0); return TRUE;
		
	case 4: //"Flex-Z-Mid"
		g_pDlg->m_pHand->m_arChain[0]->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(0); return TRUE;

	case 5: //"Flex-Z-Distal"
		g_pDlg->m_pHand->m_arChain[0]->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle;
		g_pDlg->FKUpdate(0); return TRUE;

		//Index
	case 8: //"Abuct-Y"
		g_pDlg->m_pHand->m_arChain[1]->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(1); return TRUE;
		
	case 9: //"FLEX-Z-Proximal"
		g_pDlg->m_pHand->m_arChain[1]->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(1); return TRUE;

	case 10: //"FLEX-Z-Mid"
		g_pDlg->m_pHand->m_arChain[1]->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(1); return TRUE;
		
	case 11: //"FLEX-Z-Distal"
		g_pDlg->m_pHand->m_arChain[1]->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(1); return TRUE;

		//mid
	case 14: //"Abduct-Y"
		g_pDlg->m_pHand->m_arChain[2]->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(2); return TRUE;

	case 15: //"FLEX-Z-Proximal"
		g_pDlg->m_pHand->m_arChain[2]->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(2); return TRUE;

	case 16: //"FLEX-Z-Mid"
		g_pDlg->m_pHand->m_arChain[2]->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(2); return TRUE;
		
	case 17: //"FLEX-Z-Distal"
		g_pDlg->m_pHand->m_arChain[2]->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(2); return TRUE;

		//ring
	case 20: //"Abduct-Y"
		g_pDlg->m_pHand->m_arChain[3]->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(3); return TRUE;
		
	case 21: //"FLEX-Z-Proximal"
		g_pDlg->m_pHand->m_arChain[3]->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(3); return TRUE;
	
	case 22: //"FLEX-Z-Mid"
		g_pDlg->m_pHand->m_arChain[3]->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(3); return TRUE;

	case 23: //"FLEX-Z-Distal"
		g_pDlg->m_pHand->m_arChain[3]->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(3); return TRUE;

		//pinky
	case 26: //"Abduct-Y"
		g_pDlg->m_pHand->m_arChain[4]->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(4); return TRUE;
	
	case 27: //"FLEX-Z-Proximal"
		g_pDlg->m_pHand->m_arChain[4]->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = dRotationAngle;
		g_pDlg->FKUpdate(4); return TRUE;
		
	case 28: //"FLEX-Z-Mid"
		g_pDlg->m_pHand->m_arChain[4]->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(4); 	return TRUE;
		
	case 29: //"FLEX-Z-Distal"
		g_pDlg->m_pHand->m_arChain[4]->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(4); return TRUE;
	
	}

    return TRUE; // 'FALSE' Will prevent the edit request
}
BOOL _stdcall CIKSolverDlg2::ValidateTreeEditRequestForKinematicHand(const TREELIST_HANDLE TreeListHandle,const void *pAnyPtr, const char *NewData,char *Override)
{	
	int iID = (int)pAnyPtr;

	//set new goal
	CKinematicPos posTrio = CKinematicPos((char*)NewData);
	switch(iID)
	{
	case 1: g_pDlg->m_pHand->m_arChain[0]->m_posGoal =posTrio; 
			g_pDlg->m_wndOpenGL.Invalidate(1); return TRUE;

	case 18: g_pDlg->m_pHand->m_arChain[1]->m_posGoal =posTrio; 
			g_pDlg->m_wndOpenGL.Invalidate(1); return TRUE;

	case 38: g_pDlg->m_pHand->m_arChain[2]->m_posGoal =posTrio; 
			g_pDlg->m_wndOpenGL.Invalidate(1); return TRUE;

	case 58: g_pDlg->m_pHand->m_arChain[3]->m_posGoal =posTrio; 
			g_pDlg->m_wndOpenGL.Invalidate(1); return TRUE;

	case 78: g_pDlg->m_pHand->m_arChain[4]->m_posGoal =posTrio; 
			g_pDlg->m_wndOpenGL.Invalidate(1); return TRUE;
	}
	
	//set new constraint set
	switch(iID)
	{
		//thumb
	case 4: g_pDlg->m_pHand->m_arChain[0]->m_arJoint[0]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 7: g_pDlg->m_pHand->m_arChain[0]->m_arJoint[1]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 10: g_pDlg->m_pHand->m_arChain[0]->m_arJoint[2]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 13: g_pDlg->m_pHand->m_arChain[0]->m_arJoint[3]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 16: g_pDlg->m_pHand->m_arChain[0]->m_arJoint[4]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
		//index
	case 21: g_pDlg->m_pHand->m_arChain[1]->m_arJoint[0]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 24: g_pDlg->m_pHand->m_arChain[1]->m_arJoint[0]->m_arDOF[1]->m_vecConstraints = posTrio; return TRUE;
	case 27: g_pDlg->m_pHand->m_arChain[1]->m_arJoint[1]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 30: g_pDlg->m_pHand->m_arChain[1]->m_arJoint[1]->m_arDOF[1]->m_vecConstraints = posTrio; return TRUE;
	case 33: g_pDlg->m_pHand->m_arChain[1]->m_arJoint[2]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 36: g_pDlg->m_pHand->m_arChain[1]->m_arJoint[3]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
		//mid
	case 41: g_pDlg->m_pHand->m_arChain[2]->m_arJoint[0]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 44: g_pDlg->m_pHand->m_arChain[2]->m_arJoint[0]->m_arDOF[1]->m_vecConstraints = posTrio; return TRUE;
	case 47: g_pDlg->m_pHand->m_arChain[2]->m_arJoint[1]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 50: g_pDlg->m_pHand->m_arChain[2]->m_arJoint[1]->m_arDOF[1]->m_vecConstraints = posTrio; return TRUE;
	case 53: g_pDlg->m_pHand->m_arChain[2]->m_arJoint[2]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 56: g_pDlg->m_pHand->m_arChain[2]->m_arJoint[3]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
		//ring
	case 61: g_pDlg->m_pHand->m_arChain[3]->m_arJoint[0]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 64: g_pDlg->m_pHand->m_arChain[3]->m_arJoint[0]->m_arDOF[1]->m_vecConstraints = posTrio; return TRUE;
	case 67: g_pDlg->m_pHand->m_arChain[3]->m_arJoint[1]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 70: g_pDlg->m_pHand->m_arChain[3]->m_arJoint[1]->m_arDOF[1]->m_vecConstraints = posTrio; return TRUE;
	case 73: g_pDlg->m_pHand->m_arChain[3]->m_arJoint[2]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 76: g_pDlg->m_pHand->m_arChain[3]->m_arJoint[3]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
		//pinky
	case 81: g_pDlg->m_pHand->m_arChain[4]->m_arJoint[0]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 84: g_pDlg->m_pHand->m_arChain[4]->m_arJoint[0]->m_arDOF[1]->m_vecConstraints = posTrio; return TRUE;
	case 87: g_pDlg->m_pHand->m_arChain[4]->m_arJoint[1]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 90: g_pDlg->m_pHand->m_arChain[4]->m_arJoint[1]->m_arDOF[1]->m_vecConstraints = posTrio; return TRUE;
	case 93: g_pDlg->m_pHand->m_arChain[4]->m_arJoint[2]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	case 96: g_pDlg->m_pHand->m_arChain[4]->m_arJoint[3]->m_arDOF[0]->m_vecConstraints = posTrio; return TRUE;
	}
	//set new weight
	float dWeight = atof(NewData);
	switch(iID)
	{
		//thumb
	case 3: g_pDlg->m_pHand->m_arChain[0]->m_arJoint[0]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 6: g_pDlg->m_pHand->m_arChain[0]->m_arJoint[1]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 9: g_pDlg->m_pHand->m_arChain[0]->m_arJoint[2]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 12: g_pDlg->m_pHand->m_arChain[0]->m_arJoint[3]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 15: g_pDlg->m_pHand->m_arChain[0]->m_arJoint[4]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
		//index
	case 20: g_pDlg->m_pHand->m_arChain[1]->m_arJoint[0]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 23: g_pDlg->m_pHand->m_arChain[1]->m_arJoint[0]->m_arDOF[1]->m_dWeight = dWeight; return TRUE;
	case 26: g_pDlg->m_pHand->m_arChain[1]->m_arJoint[1]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 29: g_pDlg->m_pHand->m_arChain[1]->m_arJoint[1]->m_arDOF[1]->m_dWeight = dWeight; return TRUE;
	case 32: g_pDlg->m_pHand->m_arChain[1]->m_arJoint[2]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 35: g_pDlg->m_pHand->m_arChain[1]->m_arJoint[3]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
		//mid
	case 40: g_pDlg->m_pHand->m_arChain[2]->m_arJoint[0]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 43: g_pDlg->m_pHand->m_arChain[2]->m_arJoint[0]->m_arDOF[1]->m_dWeight = dWeight; return TRUE;
	case 46: g_pDlg->m_pHand->m_arChain[2]->m_arJoint[1]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 49: g_pDlg->m_pHand->m_arChain[2]->m_arJoint[1]->m_arDOF[1]->m_dWeight = dWeight; return TRUE;
	case 52: g_pDlg->m_pHand->m_arChain[2]->m_arJoint[2]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 55: g_pDlg->m_pHand->m_arChain[2]->m_arJoint[3]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
		//ring
	case 60: g_pDlg->m_pHand->m_arChain[3]->m_arJoint[0]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 63: g_pDlg->m_pHand->m_arChain[3]->m_arJoint[0]->m_arDOF[1]->m_dWeight = dWeight; return TRUE;
	case 66: g_pDlg->m_pHand->m_arChain[3]->m_arJoint[1]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 69: g_pDlg->m_pHand->m_arChain[3]->m_arJoint[1]->m_arDOF[1]->m_dWeight = dWeight; return TRUE;
	case 72: g_pDlg->m_pHand->m_arChain[3]->m_arJoint[2]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 75: g_pDlg->m_pHand->m_arChain[3]->m_arJoint[3]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
		//pinky
	case 80: g_pDlg->m_pHand->m_arChain[4]->m_arJoint[0]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 83: g_pDlg->m_pHand->m_arChain[4]->m_arJoint[0]->m_arDOF[1]->m_dWeight = dWeight; return TRUE;
	case 86: g_pDlg->m_pHand->m_arChain[4]->m_arJoint[1]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 89: g_pDlg->m_pHand->m_arChain[4]->m_arJoint[1]->m_arDOF[1]->m_dWeight = dWeight; return TRUE;
	case 92: g_pDlg->m_pHand->m_arChain[4]->m_arJoint[2]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	case 95: g_pDlg->m_pHand->m_arChain[4]->m_arJoint[3]->m_arDOF[0]->m_dWeight = dWeight; return TRUE;
	}

	//set new rotation angle
	float dRotationAngle = atof(NewData);
	switch(iID)
	{
		//Thumb
	case 2: //"Roll-X"
		g_pDlg->m_pHand->m_arChain[0]->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(0); return TRUE;
	case 5: //"Abduct-Y"
		g_pDlg->m_pHand->m_arChain[0]->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(0); return TRUE;	
	case 8://"virtual-twist"
		g_pDlg->m_pHand->m_arChain[0]->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle;
		g_pDlg->FKUpdate(0); return TRUE;
	case 11: //"Flex-Z-Mid"
		g_pDlg->m_pHand->m_arChain[0]->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(0); return TRUE;
	case 14: //"Flex-Z-Distal"
		g_pDlg->m_pHand->m_arChain[0]->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle;
		g_pDlg->FKUpdate(0); return TRUE;

		//Index
	case 19: /*abduct-palm*/
		g_pDlg->m_pHand->m_arChain[1]->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(1); return TRUE;		
	case 22: /*flex-palm*/
		g_pDlg->m_pHand->m_arChain[1]->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(1); return TRUE;		
	case 25: //"Abuct-Y"
		g_pDlg->m_pHand->m_arChain[1]->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(1); return TRUE;		
	case 28: //"FLEX-Z-Proximal"
		g_pDlg->m_pHand->m_arChain[1]->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(1); return TRUE;
	case 31: //"FLEX-Z-Mid"
		g_pDlg->m_pHand->m_arChain[1]->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(1); return TRUE;		
	case 34: //"FLEX-Z-Distal"
		g_pDlg->m_pHand->m_arChain[1]->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(1); return TRUE;

		//mid
	case 39:
		g_pDlg->m_pHand->m_arChain[2]->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(2); return TRUE;
	case 42:
		g_pDlg->m_pHand->m_arChain[2]->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(2); return TRUE;		
	case 45: //"Abduct-Y"
		g_pDlg->m_pHand->m_arChain[2]->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(2); return TRUE;
	case 48: //"FLEX-Z-Proximal"
		g_pDlg->m_pHand->m_arChain[2]->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(2); return TRUE;
	case 51: //"FLEX-Z-Mid"
		g_pDlg->m_pHand->m_arChain[2]->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(2); return TRUE;		
	case 54: //"FLEX-Z-Distal"
		g_pDlg->m_pHand->m_arChain[2]->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(2); return TRUE;

		//ring
	case 59:
		g_pDlg->m_pHand->m_arChain[3]->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(3); return TRUE;	
	case 62:
		g_pDlg->m_pHand->m_arChain[3]->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(3); return TRUE;	
	case 65: //"Abduct-Y"
		g_pDlg->m_pHand->m_arChain[3]->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(3); return TRUE;		
	case 68: //"FLEX-Z-Proximal"
		g_pDlg->m_pHand->m_arChain[3]->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(3); return TRUE;	
	case 71: //"FLEX-Z-Mid"
		g_pDlg->m_pHand->m_arChain[3]->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(3); return TRUE;
	case 74: //"FLEX-Z-Distal"
		g_pDlg->m_pHand->m_arChain[3]->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(3); return TRUE;

		//pinky
	case 79:
		g_pDlg->m_pHand->m_arChain[4]->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(4); return TRUE;
	case 82:
		g_pDlg->m_pHand->m_arChain[4]->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(4); return TRUE;
	case 85: //"Abduct-Y"
		g_pDlg->m_pHand->m_arChain[4]->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(4); return TRUE;	
	case 88: //"FLEX-Z-Proximal"
		g_pDlg->m_pHand->m_arChain[4]->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = dRotationAngle;
		g_pDlg->FKUpdate(4); return TRUE;		
	case 91: //"FLEX-Z-Mid"
		g_pDlg->m_pHand->m_arChain[4]->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(4); 	return TRUE;		
	case 94: //"FLEX-Z-Distal"
		g_pDlg->m_pHand->m_arChain[4]->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = dRotationAngle; 
		g_pDlg->FKUpdate(4); return TRUE;
	
	}

    return TRUE; // 'FALSE' Will prevent the edit request

}
NODE_HANDLE CIKSolverDlg2::TreeListAddItemForPalmRigidHand(TREELIST_HANDLE hListTreeHandle, NODE_HANDLE hParentHandle, void *pID, char* strName, CKinematicDOF* pDOF, CKinematicJoint* pJoint, CKinematicChain* pChain)
{
	char buffer[1024] = {0};
    TreeListNodeData arNodeItem[4]; //{KinematicName, LocalRotation, GlobalPosition, Goal Position}

    memset(&arNodeItem, 0, sizeof(arNodeItem));

    //KinematicName: Not editable, no back pointer
    strncpy(arNodeItem[0].Data, strName, TREELIST_MAX_STRING);
    arNodeItem[0].Editable = FALSE;
    arNodeItem[0].pExternalPtr = 0;

	//LocalRotation: Editable
	sprintf(buffer, "");
	if(pDOF != NULL)
		sprintf(buffer, "%.2f", pDOF->m_dLocalRotationAngle);
	strncpy(arNodeItem[1].Data, buffer, TREELIST_MAX_STRING);
    arNodeItem[1].Editable = TRUE;
	arNodeItem[1].AltertedTextColor = RGB(0,22,67);
	arNodeItem[1].BackgroundColor = COLOR_WHITE;
    arNodeItem[1].Colored = TRUE;
    arNodeItem[1].pExternalPtr = pID;

    //GlobalPosition: Not editable, no back pointer
	sprintf(buffer, "");
	if(pDOF != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pDOF->m_pParentJoint->m_posGlobalCoord.m_fX, pDOF->m_pParentJoint->m_posGlobalCoord.m_fY, pDOF->m_pParentJoint->m_posGlobalCoord.m_fZ);
	if(pJoint != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pJoint->m_posGlobalCoord.m_fX, pJoint->m_posGlobalCoord.m_fY, pJoint->m_posGlobalCoord.m_fZ);
    strncpy(arNodeItem[2].Data, buffer,TREELIST_MAX_STRING);
    arNodeItem[2].Editable = FALSE;
	arNodeItem[2].pExternalPtr = 0;

	//Goal Position: Editable
	sprintf(buffer, "");
	if(pChain != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pChain->m_posGoal.m_fX, pChain->m_posGoal.m_fY, pChain->m_posGoal.m_fZ);
	strncpy(arNodeItem[3].Data, buffer, TREELIST_MAX_STRING);
    arNodeItem[3].Editable = TRUE;
	arNodeItem[3].AltertedTextColor = RGB(0,22,67);
	arNodeItem[3].BackgroundColor = COLOR_WHITE;
    arNodeItem[3].Colored = TRUE;
    arNodeItem[3].pExternalPtr = pID;

    // Call the API to add the data to the tree and return the node handle
    return(TreeListAddNode(hListTreeHandle, hParentHandle,(TreeListNodeData*)(arNodeItem),4));
}

NODE_HANDLE CIKSolverDlg2::TreeListAddItemForKinematicHand(TREELIST_HANDLE hListTreeHandle, NODE_HANDLE hParentHandle, void *pID, char* strName, CKinematicDOF* pDOF, CKinematicJoint* pJoint, CKinematicChain* pChain)
{
	char buffer[1024] = {0};
    TreeListNodeData arNodeItem[6]; //{KinematicName, LocalRotation, GlobalPosition, Weight, Constraints, Goal Position}
    memset(&arNodeItem, 0, sizeof(arNodeItem));

    //KinematicName: Not editable, no back pointer
    strncpy(arNodeItem[0].Data, strName, TREELIST_MAX_STRING);
    arNodeItem[0].Editable = FALSE;
    arNodeItem[0].pExternalPtr = 0;

	//LocalRotation: Editable
	sprintf(buffer, "");
	if(pDOF != NULL)
		sprintf(buffer, "%.2f", pDOF->m_dLocalRotationAngle);
	strncpy(arNodeItem[1].Data, buffer, TREELIST_MAX_STRING);
    arNodeItem[1].Editable = TRUE;
	arNodeItem[1].AltertedTextColor = RGB(0,22,67);
	arNodeItem[1].BackgroundColor = COLOR_WHITE;
    arNodeItem[1].Colored = TRUE;
    arNodeItem[1].pExternalPtr = pID;

    //GlobalPosition: Not editable, no back pointer
	sprintf(buffer, "");
	if(pDOF != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pDOF->m_pParentJoint->m_posGlobalCoord.m_fX, pDOF->m_pParentJoint->m_posGlobalCoord.m_fY, pDOF->m_pParentJoint->m_posGlobalCoord.m_fZ);
	if(pJoint != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pJoint->m_posGlobalCoord.m_fX, pJoint->m_posGlobalCoord.m_fY, pJoint->m_posGlobalCoord.m_fZ);
    strncpy(arNodeItem[2].Data, buffer,TREELIST_MAX_STRING);
    arNodeItem[2].Editable = FALSE;
	arNodeItem[2].pExternalPtr = 0;

	//Weight
	sprintf(buffer, "");
	if(pDOF != NULL)
		sprintf(buffer, "%.2f", pDOF->m_dWeight);
	strncpy(arNodeItem[3].Data, buffer, TREELIST_MAX_STRING);
    arNodeItem[3].Editable = TRUE;
	arNodeItem[3].AltertedTextColor = RGB(0,22,67);
	arNodeItem[3].BackgroundColor = COLOR_WHITE;
    arNodeItem[3].Colored = TRUE;
    arNodeItem[3].pExternalPtr = (void*)(int(pID)+1);
	
	//Constraints
	sprintf(buffer, "");
	if(pDOF != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pDOF->m_vecConstraints.m_fX, pDOF->m_vecConstraints.m_fY, pDOF->m_vecConstraints.m_fZ);
	strncpy(arNodeItem[4].Data, buffer, TREELIST_MAX_STRING);
    arNodeItem[4].Editable = TRUE;
	arNodeItem[4].AltertedTextColor = RGB(0,22,67);
	arNodeItem[4].BackgroundColor = COLOR_WHITE;
    arNodeItem[4].Colored = TRUE;
    arNodeItem[4].pExternalPtr = (void*)(int(pID)+2);

	//Goal Position: Editable
	sprintf(buffer, "");
	if(pChain != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pChain->m_posGoal.m_fX, pChain->m_posGoal.m_fY, pChain->m_posGoal.m_fZ);
	strncpy(arNodeItem[5].Data, buffer, TREELIST_MAX_STRING);
    arNodeItem[5].Editable = TRUE;
	arNodeItem[5].AltertedTextColor = RGB(0,22,67);
	arNodeItem[5].BackgroundColor = COLOR_WHITE;
    arNodeItem[5].Colored = TRUE;
    arNodeItem[5].pExternalPtr = pID;

	

    // Call the API to add the data to the tree and return the node handle
    return(TreeListAddNode(hListTreeHandle, hParentHandle,(TreeListNodeData*)(arNodeItem),6));
}
void CIKSolverDlg2::SetFlatForPalmRigidHand()
{
	m_pHand->SetFlatPose();
	m_wndOpenGL.Invalidate(1);	
	TreeListInvalidateForPalmRigidHand();

}
void CIKSolverDlg2::SetFlatForKinematicHand()
{
	m_pHand->SetFlatPose();
	m_wndOpenGL.Invalidate(1);	
	TreeListInvalidateForKinematicHand();
}
void CIKSolverDlg2::SetFistForPalmRigidHand()
{
	m_pHand->SetFistPose();
	m_wndOpenGL.Invalidate(1);
	TreeListInvalidateForPalmRigidHand();
}

void CIKSolverDlg2::SetFistForKinematicHand()
{
	m_pHand->SetFistPose();
	m_wndOpenGL.Invalidate(1);
	TreeListInvalidateForKinematicHand();
}

void CIKSolverDlg2::SetSpreadForPalmRigidHand()
{	
	m_pHand->SetSpreadPose();
	m_wndOpenGL.Invalidate(1);	
	TreeListInvalidateForPalmRigidHand();
}
void CIKSolverDlg2::SetSpreadForKinematicHand()
{
	m_pHand->SetSpreadPose();
	m_wndOpenGL.Invalidate(1);	
	TreeListInvalidateForKinematicHand();
}
void CIKSolverDlg2::TreeListInvalidateForPalmRigidHand()
{
	CKinematicChain* pChainThumb = m_pHand->m_arChain[0];
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[1],"Thumb", NULL, NULL, pChainThumb);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[2], "Roll-X", pChainThumb->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[3], "Abduct-Y", pChainThumb->m_arJoint[1]->m_arDOF[0], NULL, NULL);	
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[4], "Flex-Z-Mid", pChainThumb->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[5], "Flex-Z-Distal", pChainThumb->m_arJoint[3]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[6], "End Effector", NULL, pChainThumb->m_arJoint[pChainThumb->m_arJoint.size()-1], NULL);

	//index
	CKinematicChain* pChainIndex = m_pHand->m_arChain[1];
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[7], "Index", NULL, NULL, pChainIndex);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[8], "Abuct-Y", pChainIndex->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[9], "FLEX-Z-Proximal", pChainIndex->m_arJoint[0]->m_arDOF[1], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[10], "FLEX-Z-Mid", pChainIndex->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[11], "FLEX-Z-Distal", pChainIndex->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[12], "End Effector", NULL, pChainIndex->m_arJoint[pChainIndex->m_arJoint.size()-1], NULL);
	
	//mid
	CKinematicChain* pChainMid = m_pHand->m_arChain[2];
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[13], "Mid", NULL, NULL, pChainMid);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[14], "Abduct-Y", pChainMid->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[15], "FLEX-Z-Proximal", pChainMid->m_arJoint[0]->m_arDOF[1], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[16], "FLEX-Z-Mid", pChainMid->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[17], "FLEX-Z-Distal", pChainMid->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[18], "End Effector", NULL, pChainMid->m_arJoint[pChainMid->m_arJoint.size()-1], NULL);
	
	//ring
	CKinematicChain* pChainRing = m_pHand->m_arChain[3];
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[19], "Ring", NULL, NULL, pChainRing);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[20], "Abduct-Y", pChainRing->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[21], "FLEX-Z-Proximal", pChainRing->m_arJoint[0]->m_arDOF[1], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[22], "FLEX-Z-Mid", pChainRing->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[23], "FLEX-Z-Distal", pChainRing->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[24], "End Effector", NULL, pChainRing->m_arJoint[pChainRing->m_arJoint.size()-1], NULL);
	
	//pinky
	CKinematicChain* pChainPinky = m_pHand->m_arChain[4];
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[25], "Pinky", NULL, NULL, pChainPinky);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[26], "Abduct-Y", pChainPinky->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[27], "FLEX-Z-Proximal", pChainPinky->m_arJoint[0]->m_arDOF[1], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[28], "FLEX-Z-Mid", pChainPinky->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[29], "FLEX-Z-Distal", pChainPinky->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForPalmRigidHand(m_arHandle[0], m_arHandle[30], "End Effector", NULL, pChainPinky->m_arJoint[pChainPinky->m_arJoint.size()-1], NULL);
}
void CIKSolverDlg2::TreeListInvalidateForKinematicHand()
{
	CKinematicChain* pChainThumb = m_pHand->m_arChain[0];
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[1],"Thumb", NULL, NULL, pChainThumb);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[2], "Roll-X", pChainThumb->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[3], "Abduct-Y", pChainThumb->m_arJoint[1]->m_arDOF[0], NULL, NULL);	
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[4], "Virtual-twist", pChainThumb->m_arJoint[2]->m_arDOF[0], NULL, NULL);	
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[5], "Flex-Z-Mid", pChainThumb->m_arJoint[3]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[6], "Flex-Z-Distal", pChainThumb->m_arJoint[4]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[7], "End Effector", NULL, pChainThumb->m_arJoint[pChainThumb->m_arJoint.size()-1], NULL);

	//index
	CKinematicChain* pChainIndex = m_pHand->m_arChain[1];
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[8], "Index", NULL, NULL, pChainIndex);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[9], "Palm-Abuct-Y", pChainIndex->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[10], "Palm-Flex-Z", pChainIndex->m_arJoint[0]->m_arDOF[1], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[11], "Prox-Abuct-Y", pChainIndex->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[12], "Prox-Flex-Z", pChainIndex->m_arJoint[1]->m_arDOF[1], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[13], "Mid-Flex-Z", pChainIndex->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[14], "Distal-Flex-Zl", pChainIndex->m_arJoint[3]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[15], "End Effector", NULL, pChainIndex->m_arJoint[pChainIndex->m_arJoint.size()-1], NULL);
	
	//mid
	CKinematicChain* pChainMid = m_pHand->m_arChain[2];
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[16], "Mid", NULL, NULL, pChainMid);	
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[17], "Palm-Abduct-Y", pChainMid->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[18], "Palm-Flex-Z", pChainMid->m_arJoint[0]->m_arDOF[1], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[19], "Prox-Abduct-Y", pChainMid->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[20], "Prox-Flex-Z", pChainMid->m_arJoint[1]->m_arDOF[1], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[21], "Mid-Flex-Z", pChainMid->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[22], "Distal-Flex-Z", pChainMid->m_arJoint[3]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[23], "End Effector", NULL, pChainMid->m_arJoint[pChainMid->m_arJoint.size()-1], NULL);
	
	//ring
	CKinematicChain* pChainRing = m_pHand->m_arChain[3];
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[24], "Ring", NULL, NULL, pChainRing);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[25], "Palm-Abduct-Y", pChainRing->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[26], "Palm-Flex-Z", pChainRing->m_arJoint[0]->m_arDOF[1], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[27], "Prox-Abduct-Y", pChainRing->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[28], "Prox-Flex-Z", pChainRing->m_arJoint[1]->m_arDOF[1], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[29], "Mid-Flex-Z", pChainRing->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[30], "Distal-Flex-Z", pChainRing->m_arJoint[3]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[31], "End Effector", NULL, pChainRing->m_arJoint[pChainRing->m_arJoint.size()-1], NULL);
	
	//pinky
	CKinematicChain* pChainPinky = m_pHand->m_arChain[4];
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[32], "Pinky", NULL, NULL, pChainPinky);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[33], "Palm-Abduct-Y", pChainPinky->m_arJoint[0]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[34], "Palm-Flex-Z", pChainPinky->m_arJoint[0]->m_arDOF[1], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[35], "Prox-Abduct-Y", pChainPinky->m_arJoint[1]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[36], "Prox-Flex-Z", pChainPinky->m_arJoint[1]->m_arDOF[1], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[37], "Mid-Flex-Z", pChainPinky->m_arJoint[2]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[38], "Distal-Flex-Z", pChainPinky->m_arJoint[3]->m_arDOF[0], NULL, NULL);
	TreeListUpdateItemForKinematicHand(m_arHandle[0], m_arHandle[39], "End Effector", NULL, pChainPinky->m_arJoint[pChainPinky->m_arJoint.size()-1], NULL);

}
void CIKSolverDlg2::TreeListUpdateItemForPalmRigidHand(TREELIST_HANDLE hListTreeHandle, NODE_HANDLE hNodeHandle, char* strName, CKinematicDOF* pDOF, CKinematicJoint* pJoint, CKinematicChain* pChain)
{
	char buffer[1024] = {0};
    TreeListNodeData arNodeItem[4]; //{KinematicName, LocalRotation, GlobalPosition, Goal Position}

    memset(&arNodeItem, 0, sizeof(arNodeItem));

    //KinematicName: Not editable, no back pointer
    strncpy(arNodeItem[0].Data, strName, TREELIST_MAX_STRING);

	//LocalRotation: Editable
	sprintf(buffer, "");
	if(pDOF != NULL)
		sprintf(buffer, "%.2f", pDOF->m_dLocalRotationAngle);
	strncpy(arNodeItem[1].Data, buffer, TREELIST_MAX_STRING);

    //GlobalPosition: Not editable, no back pointer
	sprintf(buffer, "");
	if(pDOF != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pDOF->m_pParentJoint->m_posGlobalCoord.m_fX, pDOF->m_pParentJoint->m_posGlobalCoord.m_fY, pDOF->m_pParentJoint->m_posGlobalCoord.m_fZ);
	if(pJoint != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pJoint->m_posGlobalCoord.m_fX, pJoint->m_posGlobalCoord.m_fY, pJoint->m_posGlobalCoord.m_fZ);
    strncpy(arNodeItem[2].Data, buffer,TREELIST_MAX_STRING);

	//Goal Position: Editable
	sprintf(buffer, "");
	if(pChain != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pChain->m_posGoal.m_fX, pChain->m_posGoal.m_fY, pChain->m_posGoal.m_fZ);
	strncpy(arNodeItem[3].Data, buffer, TREELIST_MAX_STRING);

    TreeListUpdateNode(hListTreeHandle, hNodeHandle, (TreeListNodeData*)(arNodeItem),4);
}
void CIKSolverDlg2::TreeListUpdateItemForKinematicHand(TREELIST_HANDLE hListTreeHandle, NODE_HANDLE hNodeHandle, char* strName, CKinematicDOF* pDOF, CKinematicJoint* pJoint, CKinematicChain* pChain)
{	
	char buffer[1024] = {0};
    TreeListNodeData arNodeItem[6]; //{KinematicName, LocalRotation, GlobalPosition, Weight, Constraints, Goal Position}

    memset(&arNodeItem, 0, sizeof(arNodeItem));

    //KinematicName: Not editable, no back pointer
    strncpy(arNodeItem[0].Data, strName, TREELIST_MAX_STRING);

	//LocalRotation: Editable
	sprintf(buffer, "");
	if(pDOF != NULL)
		sprintf(buffer, "%.2f", pDOF->m_dLocalRotationAngle);
	strncpy(arNodeItem[1].Data, buffer, TREELIST_MAX_STRING);

    //GlobalPosition: Not editable, no back pointer
	sprintf(buffer, "");
	if(pDOF != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pDOF->m_pParentJoint->m_posGlobalCoord.m_fX, pDOF->m_pParentJoint->m_posGlobalCoord.m_fY, pDOF->m_pParentJoint->m_posGlobalCoord.m_fZ);
	if(pJoint != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pJoint->m_posGlobalCoord.m_fX, pJoint->m_posGlobalCoord.m_fY, pJoint->m_posGlobalCoord.m_fZ);
    strncpy(arNodeItem[2].Data, buffer,TREELIST_MAX_STRING);

	//Weight
	sprintf(buffer, "");
	if(pDOF != NULL)
		sprintf(buffer, "%.2f", pDOF->m_dWeight);
	strncpy(arNodeItem[3].Data, buffer, TREELIST_MAX_STRING);
	
	//Constraints
	sprintf(buffer, "");
	if(pDOF != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pDOF->m_vecConstraints.m_fX, pDOF->m_vecConstraints.m_fY, pDOF->m_vecConstraints.m_fZ);
	strncpy(arNodeItem[4].Data, buffer, TREELIST_MAX_STRING);

	//Goal Position: Editable
	sprintf(buffer, "");
	if(pChain != NULL)
		sprintf(buffer, "(%.2f,%.2f,%.2f)", pChain->m_posGoal.m_fX, pChain->m_posGoal.m_fY, pChain->m_posGoal.m_fZ);
	strncpy(arNodeItem[5].Data, buffer, TREELIST_MAX_STRING);

    TreeListUpdateNode(hListTreeHandle, hNodeHandle, (TreeListNodeData*)(arNodeItem),6);
}

BOOL CIKSolverDlg2::OnInitDialog()
{
	g_pDlg = this;
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}



	//ShowWindow(SW_MAXIMIZE);

	//opengl wnd
	CRect rcOpenGL;
	::GetClientRect(GetDlgItem(IDC_STATIC_OPENGL)->m_hWnd, rcOpenGL);

	m_wndOpenGL.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcOpenGL, this, 0);   
	m_wndOpenGL.m_bLightOn = true;
	m_wndOpenGL.m_bShowOrigin = false;
	m_wndOpenGL.OnDraw(NULL);	

	//matlab
	//TestChain();
	m_pFingerChain = NULL;
	TestHand();

	//tree list
	//Container_BuildTreeLists(GetDlgItem(IDC_STATIC_TREE)->m_hWnd);
	BuildTreeForKinematicHand();
	m_eConstraints = eNone;
	((CButton*)GetDlgItem(IDC_RADIO_NO_CONSTRAINTS))->SetCheck(1);

	::SetFocus(m_wndOpenGL.m_hWnd);
	

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
void CIKSolverDlg2::TestHand()
{
	if(m_pHand == NULL)
	{
		m_pHand = new CKinematicHandLeft();
		m_pHand->ConstructHand();
	}
	m_pHand->PopulateGlobalPosAndAxis();
	m_pHandRenderer = new CKinematicHandRenderer(m_pHand);
	m_pHand->UpdateToKinematicData(m_arInitialKinData);
	
	m_pIKSolverRenderer = new CIKSolverRenderer(this);
	this->m_wndOpenGL.SetRender((COpenGLRenderer*)m_pIKSolverRenderer);
}
void CIKSolverDlg2::TestChain()
{
	//chain
	m_pFingerChain = new CKinematicChain((CKinematicPos(-1, -1, -1)));
	
	//joint
	CKinematicJoint* pFingerRoot = new CKinematicJoint(CKinematicPos(0, 0, 0));
	pFingerRoot->m_pParentChain = m_pFingerChain;
	CKinematicJoint* pFingerProximal = new CKinematicJoint(CKinematicPos(8.5, 0, 0));
	pFingerProximal->m_pParentChain = m_pFingerChain;
	CKinematicJoint* pFingerMid = new CKinematicJoint(CKinematicPos(4, 0, 0));
	pFingerMid->m_pParentChain = m_pFingerChain;	
	CKinematicJoint* pFingerDistal = new CKinematicJoint(CKinematicPos(2.8, 0, 0));
	pFingerDistal->m_pParentChain = m_pFingerChain;
	CKinematicJoint* pFingerEndEffector = new CKinematicJoint(CKinematicPos(2, 0, 0));
	pFingerEndEffector->m_pParentChain = m_pFingerChain;
	m_pFingerChain->m_arJoint.push_back(pFingerRoot);
	m_pFingerChain->m_arJoint.push_back(pFingerProximal);
	m_pFingerChain->m_arJoint.push_back(pFingerMid);
	m_pFingerChain->m_arJoint.push_back(pFingerDistal);
	m_pFingerChain->m_arJoint.push_back(pFingerEndEffector);

	//dof
	CKinematicDOF* pFingerPalmFlex = new CKinematicDOF(0, CKinematicVec3D(0, 0, 1));
	pFingerPalmFlex->m_pParentJoint = pFingerRoot;
	CKinematicDOF* pFingerPalmAbd = new CKinematicDOF(-15, CKinematicVec3D(0, 1, 0));	
	pFingerPalmAbd->m_pParentJoint = pFingerRoot;
	pFingerRoot->m_arDOF.push_back(pFingerPalmFlex);
	pFingerRoot->m_arDOF.push_back(pFingerPalmAbd);

	CKinematicDOF* pFingerProximalAbd = new CKinematicDOF(15, CKinematicVec3D(0, 1, 0));
	pFingerProximalAbd->m_pParentJoint = pFingerProximal;
	CKinematicDOF* pFingerProximalFlex = new CKinematicDOF(-30, CKinematicVec3D(0, 0, 1));
	pFingerProximalFlex->m_pParentJoint = pFingerProximal;
	pFingerProximal->m_arDOF.push_back(pFingerProximalAbd);
	pFingerProximal->m_arDOF.push_back(pFingerProximalFlex);

	CKinematicDOF* pFingerMidFlex = new CKinematicDOF(-15, CKinematicVec3D(0, 0, 1));
	pFingerMidFlex->m_pParentJoint = pFingerMid;
	pFingerMid->m_arDOF.push_back(pFingerMidFlex);

	CKinematicDOF* pFingerDistalFlex = new CKinematicDOF(-15, CKinematicVec3D(0, 0, 1));
	pFingerDistalFlex->m_pParentJoint = pFingerDistal;
	pFingerDistal->m_arDOF.push_back(pFingerDistalFlex);	

	//renderer
	m_pFingerChainRenderer = new CKinematicChainRenderer(m_pFingerChain);
	this->m_wndOpenGL.SetRender((COpenGLRenderer*)m_pFingerChainRenderer);
	
	m_pFingerChain->PopulateGlobalPosAndAxis();
	//pFingerChain->VisualizeInMatlab();
	//m_pFingerChain->SolveToReach(CKinematicPos(-1,-1,-1));
	//pFingerChain->VisualizeInMatlab();

}





void CIKSolverDlg2::FKUpdate(int iChainID)
{
	if(iChainID == -1)
	{
		for(int i = 0; i < m_pHand->m_arChain.size(); ++i)
		{
			m_pHand->m_arChain[i]->PopulateGlobalPosAndAxis();
		}
	}
	else 
	{
		m_pHand->m_arChain[iChainID]->PopulateGlobalPosAndAxis();
	}
	m_wndOpenGL.Invalidate(1);
	TreeListInvalidateForKinematicHand();
}

void CIKSolverDlg2::OnBnClickedButtonTestGoal()
{
	CKinematicPos posOffset(2, 2, -0.5);
	m_pHand->m_arChain[0]->m_posGoal += posOffset;
	m_pHand->m_arChain[1]->m_posGoal += posOffset;
	m_pHand->m_arChain[2]->m_posGoal += posOffset;
	m_pHand->m_arChain[3]->m_posGoal += posOffset;
	m_pHand->m_arChain[4]->m_posGoal += posOffset;
	m_wndOpenGL.Invalidate(1);
}

void CIKSolverDlg2::OnBnClickedButtonTestLoop()
{
	CKinematicPos posGoal(9, -5, 5);
	m_pHand->m_arChain[0]->m_posGoal = posGoal;
	m_pHand->m_arChain[1]->m_posGoal = posGoal;
	m_wndOpenGL.Invalidate(1);
}

void CIKSolverDlg2::OnBnClickedButtonTestFlat()
{
	SetFlatForKinematicHand();
}

void CIKSolverDlg2::OnBnClickedButtonTestFist()
{
	SetFistForKinematicHand();
}

void CIKSolverDlg2::OnBnClickedButtonTestSpread()
{
	SetSpreadForKinematicHand();
}
void CIKSolverDlg2::OnBnClickedButtonReset()
{
	if(m_pFingerChain != NULL)
	{
		CKinematicJoint* pJointRoot = m_pFingerChain->m_arJoint[0];
		CKinematicDOF* pFingerPalmFlex = pJointRoot->m_arDOF[0];
		pFingerPalmFlex->m_dLocalRotationAngle = 0;
		CKinematicDOF* pFingerPalmAbd = pJointRoot->m_arDOF[1];
		pFingerPalmAbd->m_dLocalRotationAngle = -15;

		CKinematicJoint* pJointProximal = m_pFingerChain->m_arJoint[1];
		CKinematicDOF* pFingerProximalAbd = pJointProximal->m_arDOF[0];
		pFingerProximalAbd->m_dLocalRotationAngle = 15;
		CKinematicDOF* pFingerProximalFlex = pJointProximal->m_arDOF[1];
		pFingerProximalFlex->m_dLocalRotationAngle = -30;

		CKinematicJoint* pJointMid = m_pFingerChain->m_arJoint[2];
		CKinematicDOF* pFingerMidFlex = pJointMid->m_arDOF[0];
		pFingerMidFlex->m_dLocalRotationAngle = -15;

		CKinematicJoint* pJointDistal = m_pFingerChain->m_arJoint[3];
		CKinematicDOF* pFingerDistalFlex = pJointDistal->m_arDOF[0];
		pFingerDistalFlex->m_dLocalRotationAngle = -15;	
		m_pFingerChain->PopulateGlobalPosAndAxis();
	}
	
	m_pHand->Reset();
	m_wndOpenGL.Invalidate(1);
	TreeListInvalidateForKinematicHand();
}
void CIKSolverDlg2::OnBnClickedButtonSolve()
{
	if(m_eConstraints == eNone)
	{
		m_pHand->m_arChain[0]->SolveToReach(m_pHand->m_arChain[0]->m_posGoal);
		m_pHand->m_arChain[1]->SolveToReach(m_pHand->m_arChain[1]->m_posGoal);
		m_pHand->m_arChain[2]->SolveToReach(m_pHand->m_arChain[2]->m_posGoal);
		m_pHand->m_arChain[3]->SolveToReach(m_pHand->m_arChain[3]->m_posGoal);
		m_pHand->m_arChain[4]->SolveToReach(m_pHand->m_arChain[4]->m_posGoal);
	}
	else if(m_eConstraints == eWeight)
	{
		m_pHand->m_arChain[0]->SolveToReachWithWeightConstraints(m_pHand->m_arChain[0]->m_posGoal);
		m_pHand->m_arChain[1]->SolveToReachWithWeightConstraints(m_pHand->m_arChain[1]->m_posGoal);
		m_pHand->m_arChain[2]->SolveToReachWithWeightConstraints(m_pHand->m_arChain[2]->m_posGoal);
		m_pHand->m_arChain[3]->SolveToReachWithWeightConstraints(m_pHand->m_arChain[3]->m_posGoal);
		m_pHand->m_arChain[4]->SolveToReachWithWeightConstraints(m_pHand->m_arChain[4]->m_posGoal);
	}
	else if(m_eConstraints == eRange)
	{
		m_pHand->m_arChain[0]->SolveToReachWithRangeConstraints(m_pHand->m_arChain[0]->m_posGoal);
		m_pHand->m_arChain[1]->SolveToReachWithRangeConstraints(m_pHand->m_arChain[1]->m_posGoal);
		m_pHand->m_arChain[2]->SolveToReachWithRangeConstraints(m_pHand->m_arChain[2]->m_posGoal);
		m_pHand->m_arChain[3]->SolveToReachWithRangeConstraints(m_pHand->m_arChain[3]->m_posGoal);
		m_pHand->m_arChain[4]->SolveToReachWithRangeConstraints(m_pHand->m_arChain[4]->m_posGoal);
	}
	else if(m_eConstraints == eCombined)
	{		
		m_pHand->m_arChain[0]->SolveToReachWithCombinedConstraints(m_pHand->m_arChain[0]->m_posGoal);
		m_pHand->m_arChain[1]->SolveToReachWithCombinedConstraints(m_pHand->m_arChain[1]->m_posGoal);
		m_pHand->m_arChain[2]->SolveToReachWithCombinedConstraints(m_pHand->m_arChain[2]->m_posGoal);
		m_pHand->m_arChain[3]->SolveToReachWithCombinedConstraints(m_pHand->m_arChain[3]->m_posGoal);
		m_pHand->m_arChain[4]->SolveToReachWithCombinedConstraints(m_pHand->m_arChain[4]->m_posGoal);
	}
	else if(m_eConstraints == eDLSConstrained)
	{
		//m_pHand->m_arChain[0]->SolveToReachWithCombinedConstraintsDLS(m_pHand->m_arChain[0]->m_posGoal);
		m_pHand->m_arChain[0]->SolveToReachWithCombinedConstraintsDLS_thumb_activeOnly(m_pHand->m_arChain[0]->m_posGoal);
		m_pHand->m_arChain[1]->SolveToReachWithCombinedConstraintsDLS(m_pHand->m_arChain[1]->m_posGoal);
		m_pHand->m_arChain[2]->SolveToReachWithCombinedConstraintsDLS(m_pHand->m_arChain[2]->m_posGoal);
		m_pHand->m_arChain[3]->SolveToReachWithCombinedConstraintsDLS(m_pHand->m_arChain[3]->m_posGoal);
		m_pHand->m_arChain[4]->SolveToReachWithCombinedConstraintsDLS(m_pHand->m_arChain[4]->m_posGoal);
	}
	else if(m_eConstraints == eDLSConstrainedFromPalm)
	{
		m_pHand->m_arChain[0]->SolveToReachWithCombinedConstraintsDLSFromPalm(m_pHand->m_arChain[0]->m_posGoal);
		m_pHand->m_arChain[1]->SolveToReachWithCombinedConstraintsDLSFromPalm(m_pHand->m_arChain[1]->m_posGoal);
		m_pHand->m_arChain[2]->SolveToReachWithCombinedConstraintsDLSFromPalm(m_pHand->m_arChain[2]->m_posGoal);
		m_pHand->m_arChain[3]->SolveToReachWithCombinedConstraintsDLSFromPalm(m_pHand->m_arChain[3]->m_posGoal);
		m_pHand->m_arChain[4]->SolveToReachWithCombinedConstraintsDLSFromPalm(m_pHand->m_arChain[4]->m_posGoal);
	}
	 m_wndOpenGL.Invalidate(1);
	 TreeListInvalidateForKinematicHand();
}
void CIKSolverDlg2::OnBnClickedButtonResetGoal()
{
	for(int i = 0; i < m_pHand->m_arChain.size(); ++i)
		m_pHand->m_arChain[i]->m_posGoal = m_pHand->m_arChain[i]->m_arJoint[m_pHand->m_arChain[i]->m_arJoint.size()-1]->m_posGlobalCoord;
	m_wndOpenGL.Invalidate(1);
	TreeListInvalidateForKinematicHand();
}

#include "ConstraintTestDlg.h"
void CIKSolverDlg2::OnBnClickedButtonConstraintTest()
{
	CConstraintTestDlg dlg;
	dlg.DoModal();
}

void CIKSolverDlg2::OnBnClickedRadioNoConstraints()
{
	m_eConstraints = eNone;
}

void CIKSolverDlg2::OnBnClickedRadioWeightConstraints()
{
	m_eConstraints = eWeight;
}

void CIKSolverDlg2::OnBnClickedRadioRangeConstraints()
{
	m_eConstraints = eRange;
}

void CIKSolverDlg2::OnBnClickedRadioCombinedConstraints()
{
	m_eConstraints = eCombined;
}


IMPLEMENT_DYNAMIC(CIKSolverDlg2, CDialog)

CIKSolverDlg2::CIKSolverDlg2(CWnd* pParent /*=NULL*/)
	: CDialog(CIKSolverDlg2::IDD, pParent)
{
	m_pHand = NULL;
}

CIKSolverDlg2::~CIKSolverDlg2()
{
}

void CIKSolverDlg2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CIKSolverDlg2, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_SOLVE, &CIKSolverDlg2::OnBnClickedButtonSolve)
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CIKSolverDlg2::OnBnClickedButtonReset)
	ON_BN_CLICKED(IDC_BUTTON_TEST_GOAL, &CIKSolverDlg2::OnBnClickedButtonTestGoal)
	ON_BN_CLICKED(IDC_BUTTON_TEST_LOOP, &CIKSolverDlg2::OnBnClickedButtonTestLoop)
	ON_BN_CLICKED(IDC_BUTTON_TEST_FLAT, &CIKSolverDlg2::OnBnClickedButtonTestFlat)
	ON_BN_CLICKED(IDC_BUTTON_TEST_FIST, &CIKSolverDlg2::OnBnClickedButtonTestFist)
	ON_BN_CLICKED(IDC_BUTTON_TEST_SPREAD, &CIKSolverDlg2::OnBnClickedButtonTestSpread)
	ON_BN_CLICKED(IDC_BUTTON_RESET_GOAL, &CIKSolverDlg2::OnBnClickedButtonResetGoal)
	ON_BN_CLICKED(IDC_BUTTON_CONSTRAINT_TEST, &CIKSolverDlg2::OnBnClickedButtonConstraintTest)
	ON_BN_CLICKED(IDC_RADIO_NO_CONSTRAINTS, &CIKSolverDlg2::OnBnClickedRadioNoConstraints)
	ON_BN_CLICKED(IDC_RADIO_WEIGHT_CONSTRAINTS, &CIKSolverDlg2::OnBnClickedRadioWeightConstraints)
	ON_BN_CLICKED(IDC_RADIO_RANGE_CONSTRAINTS, &CIKSolverDlg2::OnBnClickedRadioRangeConstraints)
	ON_BN_CLICKED(IDC_RADIO_COMBINED_CONSTRAINTS, &CIKSolverDlg2::OnBnClickedRadioCombinedConstraints)
	ON_BN_CLICKED(IDC_BUTTON_TOUCH, &CIKSolverDlg2::OnBnClickedButtonTouch)
	ON_BN_CLICKED(IDC_BUTTON_POPULATE, &CIKSolverDlg2::OnBnClickedButtonPopulate)
	ON_BN_CLICKED(IDCANCEL, &CIKSolverDlg2::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_TEST_POS_PROB, &CIKSolverDlg2::OnBnClickedTestPosProb)
	ON_BN_CLICKED(IDC_RADIO_DLS, &CIKSolverDlg2::OnBnClickedRadioDls)
	ON_BN_CLICKED(IDC_RADIO_DLS_FROM_PALM, &CIKSolverDlg2::OnBnClickedRadioDlsFromPalm)
	ON_STN_CLICKED(IDC_STATIC_OPENGL, &CIKSolverDlg2::OnStnClickedStaticOpengl)
END_MESSAGE_MAP()


// CIKSolverDlg2 message handlers


void CIKSolverDlg2::OnBnClickedButtonTouch()
{
	m_pHand->PleaseTouch(eThumbIndex);	
	TreeListInvalidateForKinematicHand();
	m_pHand->PopulateGlobalPosAndAxis();
	m_wndOpenGL.Invalidate(1);
}

void CIKSolverDlg2::OnBnClickedButtonPopulate()
{
	m_pHand->PopulateGlobalPosAndAxis();	
	TreeListInvalidateForKinematicHand();
	m_wndOpenGL.Invalidate(1);
}

void CIKSolverDlg2::OnBnClickedCancel()
{
	m_pHand->UpdateFromKinematicData(m_arInitialKinData);
	OnCancel();
}

void CIKSolverDlg2::OnBnClickedTestPosProb()
{
	CKinematicPos posEnd;
	double dProb = m_pHand->m_arChain[1]->GetPosProbability(posEnd);
}

void CIKSolverDlg2::OnBnClickedRadioDls()
{
	m_eConstraints = eDLSConstrained;
}

void CIKSolverDlg2::OnBnClickedRadioDlsFromPalm()
{	
	m_eConstraints = eDLSConstrainedFromPalm;
}

void CIKSolverDlg2::OnStnClickedStaticOpengl()
{
	// TODO: Add your control notification handler code here
}
