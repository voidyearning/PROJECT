#include "CKinematicHand.h"
#include <gl/glaux.h>
#include <gl/glut.h>
#include <fstream>
#include "..\RGBColor.h"
#include <math.h>

float RadianToDegree(float fRadian) 
{
	return fRadian * 180 / 3.1415926;
}
float DegreeToRadian(float fDegree) 
{
	return fDegree * 3.1415926 / 180;
}

CKinematicHand::CKinematicHand()
{
	m_sFlagActiveFinger = 0;
}
void CKinematicHand::SetActiveFlag(short sActiveFinger)
{
	m_sFlagActiveFinger |= sActiveFinger;
}
void CKinematicHand::UnsetActiveFlag(short sActiveFinger)
{
	m_sFlagActiveFinger &= ~sActiveFinger;
}
bool CKinematicHand::IsFingerActive(short sActiveFinger)
{
	if(sActiveFinger == 0)
	{
		if(m_sFlagActiveFinger == 0)
			return true;
		else
			return false;
	}

	short sResult = m_sFlagActiveFinger & sActiveFinger;

	if(sResult == 0)
			return false;

	return true;
}
//neg log representation
double CKinematicHand::GetActiveProbability(CKinematicPos posEnd)
{
	if(IsFingerActive(FLAG_ACTIVE_NONE))
		return 0;

	double fProb = 0;
	if(IsFingerActive(FLAG_ACTIVE_THUMB))
		fProb = fProb + m_arChain[0]->GetPosProbability(posEnd);
	if(IsFingerActive(FLAG_ACTIVE_INDEX))
		fProb = fProb + m_arChain[1]->GetPosProbability(posEnd);
	if(IsFingerActive(FLAG_ACTIVE_MID))
		fProb = fProb + m_arChain[2]->GetPosProbability(posEnd);
	if(IsFingerActive(FLAG_ACTIVE_RING))
		fProb = fProb + m_arChain[3]->GetPosProbability(posEnd);
	if(IsFingerActive(FLAG_ACTIVE_PINKY))
		fProb = fProb + m_arChain[4]->GetPosProbability(posEnd);

	return fProb;
}
int CKinematicHand::GetActiveChainCount()
{
	int iCount = 0;
	if(IsFingerActive(FLAG_ACTIVE_THUMB))
		iCount ++;
	if(IsFingerActive(FLAG_ACTIVE_INDEX))
		iCount ++;
	if(IsFingerActive(FLAG_ACTIVE_MID))
		iCount ++;
	if(IsFingerActive(FLAG_ACTIVE_RING))
		iCount ++;
	if(IsFingerActive(FLAG_ACTIVE_PINKY))
		iCount ++;
	return iCount;
}
void CKinematicHand::GetActiveChain(std::vector<CKinematicChain*>& arActiveChain)
{
	arActiveChain.clear();
	if(IsFingerActive(FLAG_ACTIVE_THUMB))
		arActiveChain.push_back(m_arChain[0]);
	if(IsFingerActive(FLAG_ACTIVE_INDEX))
		arActiveChain.push_back(m_arChain[1]);
	if(IsFingerActive(FLAG_ACTIVE_MID))
		arActiveChain.push_back(m_arChain[2]);
	if(IsFingerActive(FLAG_ACTIVE_RING))
		arActiveChain.push_back(m_arChain[3]);
	if(IsFingerActive(FLAG_ACTIVE_PINKY))
		arActiveChain.push_back(m_arChain[4]);
}
void CKinematicHand::GetActiveEndEffectorRange(CKinematicPoint& posMin, CKinematicPoint& posMax)
{
	PopulateGlobalPosAndAxis();
	if(IsFingerActive(FLAG_ACTIVE_THUMB))
	{
		CKinematicPoint posEnd = m_arChain[0]->GetGlobalEndEffectorPos();
		if(posEnd.m_fX < posMin.m_fX) posMin.m_fX = posEnd.m_fX;
		if(posEnd.m_fY < posMin.m_fY) posMin.m_fY = posEnd.m_fY;
		if(posEnd.m_fZ < posMin.m_fZ) posMin.m_fZ = posEnd.m_fZ;
		if(posEnd.m_fX > posMax.m_fX) posMax.m_fX = posEnd.m_fX;
		if(posEnd.m_fY > posMax.m_fY) posMax.m_fY = posEnd.m_fY;
		if(posEnd.m_fZ > posMax.m_fZ) posMax.m_fZ = posEnd.m_fZ;
	}
	if(IsFingerActive(FLAG_ACTIVE_INDEX))
	{
		CKinematicPoint posEnd = m_arChain[1]->GetGlobalEndEffectorPos();
		if(posEnd.m_fX < posMin.m_fX) posMin.m_fX = posEnd.m_fX;
		if(posEnd.m_fY < posMin.m_fY) posMin.m_fY = posEnd.m_fY;
		if(posEnd.m_fZ < posMin.m_fZ) posMin.m_fZ = posEnd.m_fZ;
		if(posEnd.m_fX > posMax.m_fX) posMax.m_fX = posEnd.m_fX;
		if(posEnd.m_fY > posMax.m_fY) posMax.m_fY = posEnd.m_fY;
		if(posEnd.m_fZ > posMax.m_fZ) posMax.m_fZ = posEnd.m_fZ;
	}
	if(IsFingerActive(FLAG_ACTIVE_MID))
	{
		CKinematicPoint posEnd = m_arChain[2]->GetGlobalEndEffectorPos();
		if(posEnd.m_fX < posMin.m_fX) posMin.m_fX = posEnd.m_fX;
		if(posEnd.m_fY < posMin.m_fY) posMin.m_fY = posEnd.m_fY;
		if(posEnd.m_fZ < posMin.m_fZ) posMin.m_fZ = posEnd.m_fZ;
		if(posEnd.m_fX > posMax.m_fX) posMax.m_fX = posEnd.m_fX;
		if(posEnd.m_fY > posMax.m_fY) posMax.m_fY = posEnd.m_fY;
		if(posEnd.m_fZ > posMax.m_fZ) posMax.m_fZ = posEnd.m_fZ;
	}
	if(IsFingerActive(FLAG_ACTIVE_RING))
	{
		CKinematicPoint posEnd = m_arChain[3]->GetGlobalEndEffectorPos();
		if(posEnd.m_fX < posMin.m_fX) posMin.m_fX = posEnd.m_fX;
		if(posEnd.m_fY < posMin.m_fY) posMin.m_fY = posEnd.m_fY;
		if(posEnd.m_fZ < posMin.m_fZ) posMin.m_fZ = posEnd.m_fZ;
		if(posEnd.m_fX > posMax.m_fX) posMax.m_fX = posEnd.m_fX;
		if(posEnd.m_fY > posMax.m_fY) posMax.m_fY = posEnd.m_fY;
		if(posEnd.m_fZ > posMax.m_fZ) posMax.m_fZ = posEnd.m_fZ;
	}
	if(IsFingerActive(FLAG_ACTIVE_PINKY))
	{
		CKinematicPoint posEnd = m_arChain[4]->GetGlobalEndEffectorPos();
		if(posEnd.m_fX < posMin.m_fX) posMin.m_fX = posEnd.m_fX;
		if(posEnd.m_fY < posMin.m_fY) posMin.m_fY = posEnd.m_fY;
		if(posEnd.m_fZ < posMin.m_fZ) posMin.m_fZ = posEnd.m_fZ;
		if(posEnd.m_fX > posMax.m_fX) posMax.m_fX = posEnd.m_fX;
		if(posEnd.m_fY > posMax.m_fY) posMax.m_fY = posEnd.m_fY;
		if(posEnd.m_fZ > posMax.m_fZ) posMax.m_fZ = posEnd.m_fZ;
	}
}
CKinematicChain* CKinematicHand::GetChain(enum CKinematicHand::HAND_CHAIN_ID eChainId)
{
	switch(eChainId)
	{
		case HAND_CHAIN_ID::E_CHAIN_THUMB: return m_arChain[0];
		case HAND_CHAIN_ID::E_CHAIN_INDEX: return m_arChain[1];
		case HAND_CHAIN_ID::E_CHAIN_MID: return m_arChain[2];
		case HAND_CHAIN_ID::E_CHAIN_RING: return m_arChain[3];
		case HAND_CHAIN_ID::E_CHAIN_PINKY: return m_arChain[4];
	}
	return NULL;
}
void CKinematicHand::MoveGoalToFingerTip()
{

	for(int i = 0; i < m_arChain.size(); ++i)
	{
		m_arChain[i]->PopulateGlobalPosAndAxis();
		m_arChain[i]->m_posGoal = m_arChain[i]->GetGlobalEndEffectorPos();
	}
}
void CKinematicHand::PopulateGlobalPosAndAxis()
{
	for(int i = 0; i < m_arChain.size(); ++i)
		m_arChain[i]->PopulateGlobalPosAndAxis();
}
void CKinematicHand::PleaseTouchAt(IK_FINGER_TOUCHING_TYPE eTouchingType, CKinematicPos posGoal)
{	
	CKinematicChain* pChainThumb = m_arChain[0];//thumb;
	CKinematicChain* pChainFinger = NULL;//the other finger;
	switch(eTouchingType)
	{
	case eThumbIndex: pChainFinger = m_arChain[1]; break;
	case eThumbMid: pChainFinger = m_arChain[2]; break;
	case eThumbRing: pChainFinger = m_arChain[3]; break;
	case eThumbPinky: pChainFinger = m_arChain[4]; break;
	}
	pChainThumb->PopulateGlobalPosAndAxis();
	pChainFinger->PopulateGlobalPosAndAxis();

	//reach
	//pChainThumb->SolveToReachWithCombinedConstraints_thumb(posGoal, m_fA, m_fB); //this is super slow, convergence problem 
	pChainThumb->SolveToReachWithCombinedConstraintsDLS(posGoal);
	//pChainFinger->SolveToReachWithCombinedConstraintsDLSFromPalm(posGoal);
}

void CKinematicHand::ik_thumb_reach(CKinematicPos posGoal, float fTolerance, std::vector<float> arWeight)
{
	CKinematicChain* pChainThumb = m_arChain[0];
	pChainThumb->PopulateGlobalPosAndAxis();
	pChainThumb->IKSolver_stablized(posGoal, fTolerance, arWeight); 
}
void CKinematicHand::PleaseTouchAt(CKinematicPos posGoal)
{	
	CKinematicChain* pChainThumb = m_arChain[0];//thumb;
	pChainThumb->PopulateGlobalPosAndAxis();
	//reach
	pChainThumb->SolveToReachWithCombinedConstraintsDLS_thumb_activeOnly(posGoal);
}
void CKinematicHand::PleaseTouch(IK_FINGER_TOUCHING_TYPE eTouchingType)
{
	CKinematicChain* pChainThumb = m_arChain[0];//thumb;
	CKinematicChain* pChainFinger = NULL;//the other finger;
	switch(eTouchingType)
	{
	case eThumbIndex: pChainFinger = m_arChain[1]; break;
	case eThumbMid: pChainFinger = m_arChain[2]; break;
	case eThumbRing: pChainFinger = m_arChain[3]; break;
	case eThumbPinky: pChainFinger = m_arChain[4]; break;
	}
	pChainThumb->PopulateGlobalPosAndAxis();
	pChainFinger->PopulateGlobalPosAndAxis();

	//calculate weighted goal pos
	CKinematicPos posThumbEnd = pChainThumb->GetGlobalEndEffectorPos();
	CKinematicPos posFingerEnd = pChainFinger->GetGlobalEndEffectorPos();
	//CKinematicPos posGoal(posThumbEnd.m_fX*0.1+posFingerEnd.m_fX*0.9, posThumbEnd.m_fY*0.1+posFingerEnd.m_fY*0.9, posThumbEnd.m_fZ*0.1+posFingerEnd.m_fZ*0.9);
	CKinematicPos posGoal(posFingerEnd.m_fX, posFingerEnd.m_fY, posFingerEnd.m_fZ);
	
	//reach
	//pChainThumb->SolveToReachWithCombinedConstraints_thumb(posGoal, m_fA, m_fB); //this is super slow, convergence problem 
	pChainThumb->SolveToReachWithCombinedConstraintsDLS_thumb_activeOnly(posGoal);
	//pChainFinger->SolveToReachWithCombinedConstraintsDLSFromPalm(posGoal);//keep finger still
}

void CKinematicHand::PleaseTouchClip(IK_FINGER_TOUCHING_TYPE eTouchingType, std::vector<float>& arGain, std::vector<float>& arOffset, CGlvClip& inputClip, CRawClip& outputClip)
{
	//data preparation
	std::vector<float> arThumbGain;
	std::vector<float> arThumbOffset;
	std::vector<int> arThumbFree;
	CKinematicChain* pChainThumb = m_arChain[0];

	arThumbGain.push_back(arGain[CGlvStructre::glv_thumbTMJ]);	
	arThumbGain.push_back(arGain[CGlvStructre::glv_thumbAbduction]);
	arThumbGain.push_back(1);
	arThumbGain.push_back(arGain[CGlvStructre::glv_thumbMPJ]);
	arThumbGain.push_back(arGain[CGlvStructre::glv_thumbIJ]);

	arThumbOffset.push_back(arOffset[CGlvStructre::glv_thumbTMJ]);	
	arThumbOffset.push_back(arOffset[CGlvStructre::glv_thumbAbduction]);
	arThumbOffset.push_back(0);
	arThumbOffset.push_back(arOffset[CGlvStructre::glv_thumbMPJ]);
	arThumbOffset.push_back(arOffset[CGlvStructre::glv_thumbIJ]);

	arThumbFree.push_back(0);
	arThumbFree.push_back(0);
	arThumbFree.push_back(1);
	arThumbFree.push_back(0);
	arThumbFree.push_back(0);

	//the other finger;
	std::vector<float> arFingerGain;
	std::vector<float> arFingerOffset;
	std::vector<int> arFingerFree;
	CKinematicChain* pChainFinger = NULL;
	int iBaseIdxGlv = -1, iBaseIdxKin = -1;
	switch(eTouchingType)
	{
	case eThumbIndex: 
		pChainFinger = m_arChain[1];
		iBaseIdxGlv = CGlvStructre::glv_indexMPJ; 
		iBaseIdxKin = 5; break;
	case eThumbMid: 
		pChainFinger = m_arChain[2]; 
		iBaseIdxGlv = CGlvStructre::glv_middleMPJ; 
		iBaseIdxKin = 11; break;
	case eThumbRing: 
		pChainFinger = m_arChain[3]; 
		iBaseIdxGlv = CGlvStructre::glv_ringMPJ; 
		iBaseIdxKin = 17; break;
	case eThumbPinky: 
		pChainFinger = m_arChain[4]; 
		iBaseIdxGlv = CGlvStructre::glv_pinkieMPJ; 
		iBaseIdxKin = 23; break;
	}

	arFingerGain.push_back(1);
	arFingerGain.push_back(1);	
	arFingerGain.push_back(arGain[iBaseIdxGlv+3]);
	arFingerGain.push_back(arGain[iBaseIdxGlv]);
	arFingerGain.push_back(arGain[iBaseIdxGlv+1]);
	arFingerGain.push_back(arGain[iBaseIdxGlv+2]);

	arFingerOffset.push_back(0);
	arFingerOffset.push_back(0);	
	arFingerOffset.push_back(arOffset[iBaseIdxGlv+3]);
	arFingerOffset.push_back(arOffset[iBaseIdxGlv]);
	arFingerOffset.push_back(arOffset[iBaseIdxGlv+1]);
	arFingerOffset.push_back(arOffset[iBaseIdxGlv+2]);

	arFingerFree.push_back(1);
	arFingerFree.push_back(1);
	arFingerFree.push_back(0);
	arFingerFree.push_back(0);
	arFingerFree.push_back(0);
	arFingerFree.push_back(0);

	//frame by frame, glvClip -> rawClip
	CRawClip inputRawClipThumbRadian;
	CRawClip inputRawClipFingerRadian;
	std::vector<CKinematicPos> arGoal;
	for(int i = 0; i < inputClip.GetFrameCount(); ++i)
	{
		CGlvFrame frmGlv = inputClip.m_arFrame[i];
		UpdateFromSensorData(frmGlv.m_arData);
		PopulateGlobalPosAndAxis();
		CRawFrame frmRawHandDegree;
		UpdateToKinematicData(frmRawHandDegree.m_arData);
		outputClip.m_arFrame.push_back(frmRawHandDegree);

		CRawFrame frmRawThumbRadian;
		frmRawThumbRadian.m_arData.push_back(DegreeToRadian(frmRawHandDegree.m_arData[0]));		
		frmRawThumbRadian.m_arData.push_back(DegreeToRadian(frmRawHandDegree.m_arData[1]));
		frmRawThumbRadian.m_arData.push_back(DegreeToRadian(frmRawHandDegree.m_arData[2]));
		frmRawThumbRadian.m_arData.push_back(DegreeToRadian(frmRawHandDegree.m_arData[3]));
		frmRawThumbRadian.m_arData.push_back(DegreeToRadian(frmRawHandDegree.m_arData[4]));
		inputRawClipThumbRadian.m_arFrame.push_back(frmRawThumbRadian);
				
		CRawFrame frmRawFingerRadian;
		frmRawFingerRadian.m_arData.push_back(DegreeToRadian(frmRawHandDegree.m_arData[iBaseIdxKin]));
		frmRawFingerRadian.m_arData.push_back(DegreeToRadian(frmRawHandDegree.m_arData[iBaseIdxKin+1]));
		frmRawFingerRadian.m_arData.push_back(DegreeToRadian(frmRawHandDegree.m_arData[iBaseIdxKin+2]));
		frmRawFingerRadian.m_arData.push_back(DegreeToRadian(frmRawHandDegree.m_arData[iBaseIdxKin+3]));
		frmRawFingerRadian.m_arData.push_back(DegreeToRadian(frmRawHandDegree.m_arData[iBaseIdxKin+4]));
		frmRawFingerRadian.m_arData.push_back(DegreeToRadian(frmRawHandDegree.m_arData[iBaseIdxKin+5]));
		inputRawClipFingerRadian.m_arFrame.push_back(frmRawFingerRadian);

		CKinematicPos posThumbEnd = pChainThumb->GetGlobalEndEffectorPos();
		CKinematicPos posFingerEnd = pChainFinger->GetGlobalEndEffectorPos();
		arGoal.push_back(posFingerEnd);
	}

	CRawClip outputRawClipThumbRadian, outputRawClipFingerRadian;
	pChainThumb->SolveToReachWithForClipByConJ(inputRawClipThumbRadian, outputRawClipThumbRadian, arGoal, arThumbGain, arThumbOffset, arThumbFree);
	pChainFinger->SolveToReachWithForClipByConJ(inputRawClipFingerRadian, outputRawClipFingerRadian, arGoal, arFingerGain, arFingerOffset, arFingerFree);

	//update outputRawClipThumb, outputRawClipFinger to outputHand clip
	for(int i = 0; i < outputClip.m_arFrame.size(); ++i)
	{
		CRawFrame frmRawHandDegree = outputClip.m_arFrame[i];
		CRawFrame frmRawThumbRadian = outputRawClipThumbRadian.m_arFrame[i];		
		CRawFrame frmRawFingerRadian = outputRawClipFingerRadian.m_arFrame[i];

		frmRawHandDegree.m_arData[0] = RadianToDegree(frmRawThumbRadian.m_arData[0]);
		frmRawHandDegree.m_arData[1] = RadianToDegree(frmRawThumbRadian.m_arData[1]);
		frmRawHandDegree.m_arData[2] = RadianToDegree(frmRawThumbRadian.m_arData[2]);
		frmRawHandDegree.m_arData[3] = RadianToDegree(frmRawThumbRadian.m_arData[3]);
		frmRawHandDegree.m_arData[4] = RadianToDegree(frmRawThumbRadian.m_arData[4]);

		frmRawHandDegree.m_arData[iBaseIdxKin] = RadianToDegree(frmRawFingerRadian.m_arData[0]);
		frmRawHandDegree.m_arData[iBaseIdxKin+1] = RadianToDegree(frmRawFingerRadian.m_arData[1]);
		frmRawHandDegree.m_arData[iBaseIdxKin+2] = RadianToDegree(frmRawFingerRadian.m_arData[2]);
		frmRawHandDegree.m_arData[iBaseIdxKin+3] = RadianToDegree(frmRawFingerRadian.m_arData[3]);
		frmRawHandDegree.m_arData[iBaseIdxKin+4] = RadianToDegree(frmRawFingerRadian.m_arData[4]);
		frmRawHandDegree.m_arData[iBaseIdxKin+5] = RadianToDegree(frmRawFingerRadian.m_arData[5]);
		outputClip.m_arFrame[i] = frmRawHandDegree;
	}
}
void CKinematicHand::UpdateFromKinematicData(const std::vector<float>& arKinData)
{
	int iDataIndex = 0;
	for(int c=0; c < m_arChain.size(); ++c)
	{
		CKinematicChain* pChain = m_arChain[c];
		for(int j=0; j < pChain->m_arJoint.size(); ++j)
		{
			CKinematicJoint* pJoint = pChain->m_arJoint[j];
			for(int d = 0; d < pJoint->m_arDOF.size(); ++ d)
			{
				CKinematicDOF* pDOF = pJoint->m_arDOF[d];
				pDOF->m_dLocalRotationAngle = arKinData[iDataIndex];
				iDataIndex ++;
			}
		}
	}
}
void CKinematicHand::UpdateToKinematicData(std::vector<float>& arKinData)
{
	arKinData.clear();
	for(int c=0; c < m_arChain.size(); ++c)
	{
		CKinematicChain* pChain = m_arChain[c];
		for(int j=0; j < pChain->m_arJoint.size(); ++j)
		{
			CKinematicJoint* pJoint = pChain->m_arJoint[j];
			for(int d = 0; d < pJoint->m_arDOF.size(); ++ d)
			{
				CKinematicDOF* pDOF = pJoint->m_arDOF[d];
				arKinData.push_back(pDOF->m_dLocalRotationAngle);
			}
		}
	}
}
void CKinematicHand::UpdateFingerFromKinematicData(enum HAND_CHAIN_ID eChainId, const std::vector<float>& arKinData)
{
	int iStartIdx, iEndIdx;
	CKinematicChain* pChain = NULL;
	switch(eChainId)
	{
	case HAND_CHAIN_ID::E_CHAIN_THUMB: iStartIdx = 0; iEndIdx = 4; pChain = m_arChain[0];
		break;
	case HAND_CHAIN_ID::E_CHAIN_INDEX: iStartIdx = 5; iEndIdx = 10; pChain = m_arChain[1];
		break;
	case HAND_CHAIN_ID::E_CHAIN_MID: iStartIdx = 11; iEndIdx = 16; pChain = m_arChain[2];
		break;
	case HAND_CHAIN_ID::E_CHAIN_RING: iStartIdx = 17; iEndIdx = 22; pChain = m_arChain[3];
		break;
	case HAND_CHAIN_ID::E_CHAIN_PINKY: iStartIdx = 23; iEndIdx = 28; pChain = m_arChain[4];
		break;
	}
	assert(pChain->GetDOFNum() == iEndIdx-iStartIdx+1);
	int iDOFCount = 0;
	for(int j = 0; j < pChain->m_arJoint.size(); ++j)
	{
		CKinematicJoint* pJoint = pChain->m_arJoint[j];
		for(int d = 0; d < pJoint->m_arDOF.size(); ++d)
		{
			CKinematicDOF* pDOF = pJoint->m_arDOF[d];
			pDOF->m_dLocalRotationAngle = arKinData[iStartIdx + iDOFCount];
			iDOFCount ++;			
		}
	}
	assert(iStartIdx + iDOFCount - 1 == iEndIdx);
}
void CKinematicHand::UpdateFingerToKinematicData(enum HAND_CHAIN_ID eChainId, std::vector<float>& arKinData)
{
	assert(arKinData.size()!=0);
	int iStartIdx, iEndIdx;
	CKinematicChain* pChain = NULL;
	switch(eChainId)
	{
	case HAND_CHAIN_ID::E_CHAIN_THUMB: iStartIdx = 0; iEndIdx = 4; pChain = m_arChain[0];
		break;
	case HAND_CHAIN_ID::E_CHAIN_INDEX: iStartIdx = 5; iEndIdx = 10; pChain = m_arChain[1];
		break;
	case HAND_CHAIN_ID::E_CHAIN_MID: iStartIdx = 11; iEndIdx = 16; pChain = m_arChain[2];
		break;
	case HAND_CHAIN_ID::E_CHAIN_RING: iStartIdx = 17; iEndIdx = 22; pChain = m_arChain[3];
		break;
	case HAND_CHAIN_ID::E_CHAIN_PINKY: iStartIdx = 23; iEndIdx = 28; pChain = m_arChain[4];
		break;
	}
	assert(pChain->GetDOFNum() == iEndIdx-iStartIdx+1);
	int iDOFCount = 0;
	for(int j = 0; j < pChain->m_arJoint.size(); ++j)
	{
		CKinematicJoint* pJoint = pChain->m_arJoint[j];
		for(int d = 0; d < pJoint->m_arDOF.size(); ++d)
		{
			CKinematicDOF* pDOF = pJoint->m_arDOF[d];
			arKinData[iStartIdx + iDOFCount] = pDOF->m_dLocalRotationAngle;
			iDOFCount ++;			
		}
	}
	assert(iStartIdx + iDOFCount == iEndIdx);
}


string CKinematicHand::GetBvhHeader()
{
	string strBvhHeader;	
	string strTab = "";

	//root
	strBvhHeader = "HIERARCHY\r\n";
	strBvhHeader.append("ROOT Hand\r\n");
	strBvhHeader.append("{\r\n");	
	strTab = strTab + "\t";
	strBvhHeader.append(strTab + "OFFSET 0 0 0\r\n");
	strBvhHeader.append(strTab + "CHANNELS 2 Yrotation Zrotation\r\n");

	//thumb
	CKinematicChain* pChainThumb = m_arChain[0];
	string strThumb = pChainThumb->GetBvhHeader("Thumb", 0/*0 is root*/, strTab);
	strBvhHeader.append(strThumb);

	//index 
	CKinematicChain* pChainIndex = m_arChain[1];
	string strIndex = pChainIndex->GetBvhHeader("Index", 0, strTab);
	strBvhHeader.append(strIndex);

	//mid
	CKinematicChain* pChainMid = m_arChain[2];
	string strMid = pChainMid->GetBvhHeader("Middle", 0, strTab);
	strBvhHeader.append(strMid);

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	string strRing = pChainRing->GetBvhHeader("Ring", 0, strTab);
	strBvhHeader.append(strRing);

	//pinky
	CKinematicChain* pChainPinky = m_arChain[4];
	string strPinky = pChainPinky->GetBvhHeader("Pinky", 0, strTab);
	strBvhHeader.append(strPinky);

	//end of hand
	strBvhHeader.append("}\r\n");
	return strBvhHeader;
}
string CKinematicHand::GetBvhHeaderConsistentWithBody()
{
	string strBvhHeader;	
	string strTab = "\t\t\t\t\t\t\t";

	//handness
	string strHandness = "Left";
	bool bLeft = true;
	if(dynamic_cast<CKinematicHandRight*>(this) != NULL)//left hand
	{
		strHandness = "Right";
		bLeft = false;
	}

	/*root - no need, to concatinate with body
	strBvhHeader = "HIERARCHY\r\n";
	strBvhHeader.append("ROOT Hand\r\n");
	strBvhHeader.append("{\r\n");	
	strTab = strTab + "\t";
	strBvhHeader.append(strTab + "OFFSET 0 0 0\r\n");
	strBvhHeader.append(strTab + "CHANNELS 2 Yrotation Zrotation\r\n");
	*/

	//thumb
	CKinematicChain* pChainThumb = m_arChain[0];
	string strPrefix = strHandness;
	strPrefix.append("Thumb");
	string strThumb = pChainThumb->GetBvhHeaderConsistentWithBody(bLeft, strPrefix, 0/*0 is root*/, strTab);
	strBvhHeader.append(strThumb);

	//index 
	CKinematicChain* pChainIndex = m_arChain[1];
	strPrefix = strHandness;
	strPrefix.append("Index");
	string strIndex = pChainIndex->GetBvhHeaderConsistentWithBody(bLeft, strPrefix, 0, strTab);
	strBvhHeader.append(strIndex);

	//mid
	CKinematicChain* pChainMid = m_arChain[2];
	strPrefix = strHandness;
	strPrefix.append("Middle");
	string strMid = pChainMid->GetBvhHeaderConsistentWithBody(bLeft, strPrefix, 0, strTab);
	strBvhHeader.append(strMid);

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	strPrefix = strHandness;
	strPrefix.append("Ring");
	string strRing = pChainRing->GetBvhHeaderConsistentWithBody(bLeft, strPrefix, 0, strTab);
	strBvhHeader.append(strRing);

	//pinky
	CKinematicChain* pChainPinky = m_arChain[4];
	strPrefix = strHandness;
	strPrefix.append("Pinky");
	string strPinky = pChainPinky->GetBvhHeaderConsistentWithBody(bLeft, strPrefix, 0, strTab);
	strBvhHeader.append(strPinky);

	//end of hand
	//strBvhHeader.append("}\r\n");
	return strBvhHeader;
}

string CKinematicHand::GetBvhData()
{
	string strBvhData = "";
	for(int i = 0; i < m_arChain.size(); ++i)
		strBvhData.append(m_arChain[i]->GetBvhData());
	return strBvhData;
}

void CKinematicHand::ExportTrajectory(CRawClip clipRaw, int iTrjIndex, std::string strPath)
{
	std::ofstream fout(strPath.c_str());

	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = clipRaw.m_arFrame[i]; 
		UpdateFromKinematicData(frmRaw.m_arData);
		PopulateGlobalPosAndAxis();
		CKinematicJoint* pJoint = GetJoint((CKinematicHand::HAND_JOINT_ID)iTrjIndex);
		fout << pJoint->m_posGlobalCoord.m_fX << "\t"
			<< pJoint->m_posGlobalCoord.m_fY << "\t"
			<< pJoint->m_posGlobalCoord.m_fZ << endl;
	}

	fout.flush();
	fout.close();
}

void CKinematicHand::ExportTipDistance(CRawClip clipRaw, IK_FINGER_TOUCHING_TYPE eTouchingType, std::string strPath)
{
	std::ofstream fout(strPath.c_str());

	CKinematicChain* pChainThumb = m_arChain[0];
	CKinematicChain* pChainFinger = NULL;
	switch(eTouchingType)
	{
	case IK_FINGER_TOUCHING_TYPE::eThumbIndex: pChainFinger = m_arChain[1]; break;
	case IK_FINGER_TOUCHING_TYPE::eThumbMid: pChainFinger = m_arChain[2]; break;
	case IK_FINGER_TOUCHING_TYPE::eThumbRing: pChainFinger = m_arChain[3]; break;
	case IK_FINGER_TOUCHING_TYPE::eThumbPinky: pChainFinger = m_arChain[4]; break;
	}

	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = clipRaw.m_arFrame[i]; 
		UpdateFromKinematicData(frmRaw.m_arData);
		PopulateGlobalPosAndAxis();
		
		CKinematicPos posThumbTip = pChainThumb->GetGlobalEndEffectorPos();
		CKinematicPos posFingerTip = pChainFinger->GetGlobalEndEffectorPos();
		float dist = (posThumbTip.m_fX - posFingerTip.m_fX) * (posThumbTip.m_fX - posFingerTip.m_fX)
			+ (posThumbTip.m_fY - posFingerTip.m_fY) * (posThumbTip.m_fY - posFingerTip.m_fY)
			+ (posThumbTip.m_fZ - posFingerTip.m_fZ) * (posThumbTip.m_fZ - posFingerTip.m_fZ);
		dist = sqrt(dist);

		fout << dist << endl;
	}

	fout.flush();
	fout.close();
}
//=========================================================================================
//kinematic hand
CKinematicHandLeft::CKinematicHandLeft()
{
	m_fA = 0.25;
	m_fB = -0.375;
}
void CKinematicHandLeft::ConstructHand()
{
	for(int i = 0; i < m_arChain.size(); ++i)
		delete m_arChain[i];
	m_arChain.clear();

	//thumb=================================================================
	CKinematicChain* pChainThumb = new CKinematicChain(CKinematicPos(0, 0, 0), E_CHAIN_THUMB);
	
	CKinematicJoint* pJointThumbRoot = new CKinematicJoint(CKinematicPos(0, 0, 0), E_JOINT_THUMB_ROOT);
	pJointThumbRoot->AddDOF(new CKinematicDOF(-30, CKinematicVec3D(1,0,0), E_DOF_ROLL_X, 0.5, CKinematicVec3D(0, -90, 10), 1));
	pChainThumb->AddJoint(pJointThumbRoot);

	CKinematicJoint* pJointThumbAbduct = new CKinematicJoint(CKinematicPos(0, 0, 2.5), E_JOINT_THUMB_ABDUCT);
	pJointThumbAbduct->AddDOF(new CKinematicDOF(15, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 0.5, CKinematicVec3D(0.1, 0, 90), 6));
	pChainThumb->AddJoint(pJointThumbAbduct);

	//virtual twist - in the middle
	CKinematicJoint* pJointThumbVirtualTwist = new CKinematicJoint(CKinematicPos(-2.25, 0, 0), E_JOINT_THUMB_VIRTUAL_TWIST);
	pJointThumbVirtualTwist->AddDOF(new CKinematicDOF(m_fA*(-30)+m_fB*(15), CKinematicVec3D(1,0,0), E_DOF_ROLL_X, 0.5, CKinematicVec3D(0.1, -90, 0), 6));
	pChainThumb->AddJoint(pJointThumbVirtualTwist);

	CKinematicJoint* pJointThumbMid = new CKinematicJoint(CKinematicPos(-2.25, 0, 0), E_JOINT_THUMB_FLEX_1);
	pJointThumbMid->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 0.5, CKinematicVec3D(0.1, -80,  5), 3));
	pChainThumb->AddJoint(pJointThumbMid);

	CKinematicJoint* pJointThumbDistal = new CKinematicJoint(CKinematicPos(-3.6, 0, 0), E_JOINT_THUMB_FLEX_2);
	pJointThumbDistal->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 0.5, CKinematicVec3D(0.1, -100, 10), 3));
	pChainThumb->AddJoint(pJointThumbDistal);

	CKinematicJoint* pJointThumbEnd = new CKinematicJoint(CKinematicPos(-3, 0, 0), E_JOINT_THUMB_END);
	pChainThumb->AddJoint(pJointThumbEnd);

	//index==================================================================
	CKinematicChain* pChainIndex = new CKinematicChain(CKinematicPos(0,0,0), E_CHAIN_INDEX);
	//in palm
	CKinematicJoint* pJointIndexPalm = new CKinematicJoint(CKinematicPos(0,0,0), E_JOINT_INDEX_PALM);
	pJointIndexPalm->AddDOF(new CKinematicDOF(15, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 0.1, CKinematicVec3D(1, 15, 15), 1));//in palm abd
	pJointIndexPalm->AddDOF(new CKinematicDOF(0, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 0.1, CKinematicVec3D(1, 0, 0), 1));//in palm flex, not change to much as rigid
	pChainIndex->AddJoint(pJointIndexPalm);
	//proximal
	CKinematicJoint* pJointIndexProximal = new CKinematicJoint(CKinematicPos(-7.2,0,0), E_JOINT_INDEX_PROXIMAL);
	pJointIndexProximal->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 0.1, CKinematicVec3D(0.1, -20, 0), 6));
	pJointIndexProximal->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 0.1, CKinematicVec3D(0.1, -100, 10), 3));
	pChainIndex->AddJoint(pJointIndexProximal);
	//mid
	CKinematicJoint* pJointIndexMid = new CKinematicJoint(CKinematicPos(-4.5,0,0), E_JOINT_INDEX_MID);
	pJointIndexMid->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1),E_DOF_FLEX_Z, 0.1, CKinematicVec3D(0.1, -100, 5), 3));
	pChainIndex->AddJoint(pJointIndexMid);
	//distal
	CKinematicJoint* pJointIndexDistal = new CKinematicJoint(CKinematicPos(-2.6,0,0), E_JOINT_INDEX_DISTAL);
	pJointIndexDistal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z, 0.1, CKinematicVec3D(0.1, -90, 0), 3));
	pChainIndex->AddJoint(pJointIndexDistal);
	//end
	CKinematicJoint* pJointIndexEnd = new CKinematicJoint(CKinematicPos(-2.2,0,0),E_JOINT_INDEX_END);
	pChainIndex->AddJoint(pJointIndexEnd);

	//mid===================================================================
	CKinematicChain* pChainMid = new CKinematicChain(CKinematicPos(0,0,0),E_CHAIN_MID);
	//in palm
	CKinematicJoint* pJointMidPalm = new CKinematicJoint(CKinematicPos(0,0,0),E_JOINT_MID_PALM);
	pJointMidPalm->AddDOF(new CKinematicDOF(0, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 0.1, CKinematicVec3D(0.1, 0, 0), 1));//in palm abd
	pJointMidPalm->AddDOF(new CKinematicDOF(0, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 0.1, CKinematicVec3D(0.1, 0, 0), 1));//in palm flex
	pChainMid->AddJoint(pJointMidPalm);
	//proximal
	CKinematicJoint* pJointMidProximal = new CKinematicJoint(CKinematicPos(-6.6, 0,0),E_JOINT_MID_PROXIMAL);
	pJointMidProximal->AddDOF(new CKinematicDOF(0, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 0.1, CKinematicVec3D(0.1, 0, 0), 3));
	pJointMidProximal->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 0.1, CKinematicVec3D(0.1, -100, 10), 3));
	pChainMid->AddJoint(pJointMidProximal);
	//mid
	CKinematicJoint* pJointMidMid = new CKinematicJoint(CKinematicPos(-5,0,0),E_JOINT_MID_MID);
	pJointMidMid->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 0.1, CKinematicVec3D(0.1, -100, 5), 3));
	pChainMid->AddJoint(pJointMidMid);
	//distal
	CKinematicJoint* pJointMidDistal = new CKinematicJoint(CKinematicPos(-2.9,0,0),E_JOINT_MID_DISTAL);
	pJointMidDistal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z, 0.1, CKinematicVec3D(0.1, -90, 0), 3));
	pChainMid->AddJoint(pJointMidDistal);
	//end
	CKinematicJoint* pJointMidEnd = new CKinematicJoint(CKinematicPos(-2.4,0,0), E_JOINT_MID_END);
	pChainMid->AddJoint(pJointMidEnd);

	//ring====================================================================
	CKinematicChain* pChainRing = new CKinematicChain(CKinematicPos(0,0,0), E_CHAIN_RING);
	//in palm
	CKinematicJoint* pJointRingPalm = new CKinematicJoint(CKinematicPos(0,0,0), E_JOINT_RING_PALM);
	pJointRingPalm->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 0.1, CKinematicVec3D(1, -15, -15), 1));
	pJointRingPalm->AddDOF(new CKinematicDOF(0,CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 0.1, CKinematicVec3D(1, 0, 0), 1));
	pChainRing->AddJoint(pJointRingPalm);
	//proximal
	CKinematicJoint* pJointRingProximal = new CKinematicJoint(CKinematicPos(-6.4,0,0), E_JOINT_RING_PROXIMAL);
	pJointRingProximal->AddDOF(new CKinematicDOF(15,CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 1, CKinematicVec3D(1, 0, 15), 3));
	pJointRingProximal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 1, CKinematicVec3D(1, -100, 10), 3));
	pChainRing->AddJoint(pJointRingProximal);
	//mid
	CKinematicJoint* pJointRingMid = new CKinematicJoint(CKinematicPos(-5,0,0), E_JOINT_RING_MID);
	pJointRingMid->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z,1, CKinematicVec3D(1, -100, 5), 3));
	pChainRing->AddJoint(pJointRingMid);
	//distal
	CKinematicJoint* pJointRingDistal = new CKinematicJoint(CKinematicPos(-2.7,0,0),E_JOINT_RING_DISTAL);
	pJointRingDistal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z, 1, CKinematicVec3D(1, -90, 0), 3));
	pChainRing->AddJoint(pJointRingDistal);
	//end
	CKinematicJoint* pJointRingEnd = new CKinematicJoint(CKinematicPos(-2.3,0,0),E_JOINT_RING_END);
	pChainRing->AddJoint(pJointRingEnd);

	//pinky====================================================================
	//proximal
	CKinematicChain* pChainPinky = new CKinematicChain(CKinematicPos(0,0,0), E_CHAIN_PINKY);
	//palm
	CKinematicJoint* pJointPinkyPalm = new CKinematicJoint(CKinematicPos(0,0,0),E_JOINT_PINKY_PALM);
	pJointPinkyPalm->AddDOF(new CKinematicDOF(-30,CKinematicVec3D(0,1,0),E_DOF_ABDUCT_Y, 0.1, CKinematicVec3D(1, -30, -30), 1));
	pJointPinkyPalm->AddDOF(new CKinematicDOF(0,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z, 0.1, CKinematicVec3D(1, 0, 0), 1));
	pChainPinky->AddJoint(pJointPinkyPalm);
	//proximal
	CKinematicJoint* pJointPinkyProximal = new CKinematicJoint(CKinematicPos(-6.5,0,0),E_JOINT_PINKY_PROXIMAL);
	pJointPinkyProximal->AddDOF(new CKinematicDOF(30,CKinematicVec3D(0,1,0),E_DOF_ABDUCT_Y, 1, CKinematicVec3D(1, -10, 30), 3));
	pJointPinkyProximal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z, 1, CKinematicVec3D(1, -100, 20), 3));
	pChainPinky->AddJoint(pJointPinkyProximal);
	//mid
	CKinematicJoint* pJointPinkyMid = new CKinematicJoint(CKinematicPos(-3.6,0,0),E_JOINT_PINKY_MID);
	pJointPinkyMid->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z,1, CKinematicVec3D(1, -100, 10), 3));
	pChainPinky->AddJoint(pJointPinkyMid);
	//distal
	CKinematicJoint* pJointPinkyDistal = new CKinematicJoint(CKinematicPos(-2.1,0,0),E_JOINT_PINKY_DISTAL);
	pJointPinkyDistal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z,1, CKinematicVec3D(1, -100, 20), 3));
	pChainPinky->AddJoint(pJointPinkyDistal);
	//end
	CKinematicJoint* pJointPinkyEnd = new CKinematicJoint(CKinematicPos(-2.2,0,0),E_JOINT_PINKY_END);
	pChainPinky->AddJoint(pJointPinkyEnd);

	//populate global info ============================================================
	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();

	//initialize goal ================================================================
	pChainThumb->m_posGoal = pChainThumb->m_arJoint[pChainThumb->m_arJoint.size()-1]->m_posGlobalCoord;
	pChainIndex->m_posGoal = pChainIndex->m_arJoint[pChainIndex->m_arJoint.size()-1]->m_posGlobalCoord;
	pChainMid->m_posGoal = pChainMid->m_arJoint[pChainMid->m_arJoint.size()-1]->m_posGlobalCoord;
	pChainRing->m_posGoal = pChainRing->m_arJoint[pChainRing->m_arJoint.size()-1]->m_posGlobalCoord;
	pChainPinky->m_posGoal = pChainPinky->m_arJoint[pChainPinky->m_arJoint.size()-1]->m_posGlobalCoord;

	//add to vector ================================================================
	m_arChain.push_back(pChainThumb);
	m_arChain.push_back(pChainIndex);
	m_arChain.push_back(pChainMid);
	m_arChain.push_back(pChainRing);
	m_arChain.push_back(pChainPinky);
}
void CKinematicHandLeft::DestructHand()
{
	for(int i = 0; i < m_arChain.size(); ++i)
		delete m_arChain[i];
	m_arChain.clear();
}
void CKinematicHandLeft::Reset()
{	
	SetDefaultPose();
}
/*
void CHandSkeleton::LoadSizeFromFile(CString strPath)
{
	std::ifstream fin(strPath);

	//palm
	char buf[1024] = {0};
	fin.getline(buf, sizeof(buf));
	CString strLine(buf);
	int iBeg = 0, iEnd = strLine.Find(L",", iBeg);
	CString strToThumb = strLine.Mid(iBeg, iEnd-iBeg);
	m_fToThumb = _wtof(strToThumb.GetBuffer());
	
	iBeg = iEnd+1, iEnd = strLine.Find(L",", iBeg);
	CString strToIndex = strLine.Mid(iBeg, iEnd-iBeg);
	m_fToIndex = _wtof(strToIndex.GetBuffer());

	iBeg = iEnd+1, iEnd = strLine.Find(L",", iBeg);
	CString strToMiddle = strLine.Mid(iBeg, iEnd-iBeg);
	m_fToMiddle = _wtof(strToMiddle.GetBuffer());

	iBeg = iEnd+1, iEnd = strLine.Find(L",", iBeg);
	CString strToRing = strLine.Mid(iBeg, iEnd-iBeg);
	m_fToRing = _wtof(strToRing.GetBuffer());

	iBeg = iEnd+1, iEnd = strLine.GetLength();
	CString strToPinky = strLine.Mid(iBeg, iEnd-iBeg);
	m_fToPinky = _wtof(strToPinky.GetBuffer());
	
	//finger
	for(int i = 0; i < 5; ++ i)
	{
		buf[1023] = '\0';
		fin.getline(buf, sizeof(buf));
		strLine = CString(buf);

		CFingerSkeleton* pSkelFinger = NULL;
		switch(i)
		{
		case 0: pSkelFinger = m_pSkelThumb; break;
		case 1: pSkelFinger = m_pSkelIndex; break;
		case 2: pSkelFinger = m_pSkelMiddle; break;
		case 3: pSkelFinger = m_pSkelRing; break;
		case 4: pSkelFinger = m_pSkelPinky; break;
		}

		iBeg = 0;
		for(int j = 0; j < 3; ++ j)
		{
			iEnd = strLine.Find(L",", iBeg);
			if(iEnd == -1)
				iEnd = strLine.GetLength();
			CString strLen = strLine.Mid(iBeg, iEnd - iBeg);
			switch(j)
			{
			case 0: pSkelFinger->m_fEndLen = _wtof(strLen.GetBuffer()); break;
			case 1: pSkelFinger->m_fMidLen = _wtof(strLen.GetBuffer()); break;
			case 2: pSkelFinger->m_fTipLen = _wtof(strLen.GetBuffer()); break;
			}
			iBeg = iEnd + 1;
		}
	}
}
*/
void CKinematicHandLeft::LoadHandSize(string strPath)
{	
	std::ifstream fin(strPath.c_str());

	//thumb
	char bufThumb[600] = {0};
	fin.getline(bufThumb, sizeof(bufThumb));
	string strLine(bufThumb);
	int iBeg = 0, iEnd = strLine.find(",", iBeg);
	string strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[0]->m_arJoint[1]->m_posLocalCoord = CKinematicPoint(0,0,atof(strLen.c_str()));

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[0]->m_arJoint[2]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[0]->m_arJoint[3]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[0]->m_arJoint[4]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1;
	strLen = strLine.substr(iBeg);
	m_arChain[0]->m_arJoint[5]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	//index
	char bufIndex[600] = {0};
	fin.getline(bufIndex, sizeof(bufIndex));
	strLine = string(bufIndex);
	iBeg = 0, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[1]->m_arJoint[1]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[1]->m_arJoint[2]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[1]->m_arJoint[3]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);
		
	iBeg = iEnd+1;
	strLen = strLine.substr(iBeg);
	m_arChain[1]->m_arJoint[4]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);
	
	//middle
	char bufMiddle[600] = {0};
	fin.getline(bufMiddle, sizeof(bufMiddle));
	strLine = string(bufMiddle);
	iBeg = 0, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[2]->m_arJoint[1]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[2]->m_arJoint[2]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[2]->m_arJoint[3]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1;
	strLen = strLine.substr(iBeg);
	m_arChain[2]->m_arJoint[4]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);
	
	//ring
	char bufRing[600] = {0};
	fin.getline(bufRing, sizeof(bufRing));
	strLine = string(bufRing);
	iBeg = 0, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[3]->m_arJoint[1]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[3]->m_arJoint[2]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[3]->m_arJoint[3]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1;
	strLen = strLine.substr(iBeg);
	m_arChain[3]->m_arJoint[4]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);
	
	//pinky
	char bufPinky[600] = {0};
	fin.getline(bufPinky, sizeof(bufRing));
	strLine = string(bufPinky);
	iBeg = 0, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[4]->m_arJoint[1]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[4]->m_arJoint[2]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[4]->m_arJoint[3]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1;
	strLen = strLine.substr(iBeg);
	m_arChain[4]->m_arJoint[4]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	PopulateGlobalPosAndAxis();
}
void CKinematicHandLeft::SaveHandSize(string strPath)
{
	std::ofstream fout(strPath.c_str());	
	//thumb
	fout << m_arChain[0]->m_arJoint[1]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[0]->m_arJoint[2]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[0]->m_arJoint[3]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[0]->m_arJoint[4]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[0]->m_arJoint[5]->m_posLocalCoord.GetEuclideanLength() << std::endl;
	//index
	fout << m_arChain[1]->m_arJoint[1]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[1]->m_arJoint[2]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[1]->m_arJoint[3]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[1]->m_arJoint[4]->m_posLocalCoord.GetEuclideanLength() << std::endl;
	//middle
	fout << m_arChain[2]->m_arJoint[1]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[2]->m_arJoint[2]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[2]->m_arJoint[3]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[2]->m_arJoint[4]->m_posLocalCoord.GetEuclideanLength() << std::endl;
	//ring
	fout << m_arChain[3]->m_arJoint[1]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[3]->m_arJoint[2]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[3]->m_arJoint[3]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[3]->m_arJoint[4]->m_posLocalCoord.GetEuclideanLength() << std::endl;
	//pinky
	fout << m_arChain[4]->m_arJoint[1]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[4]->m_arJoint[2]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[4]->m_arJoint[3]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[4]->m_arJoint[4]->m_posLocalCoord.GetEuclideanLength() << std::endl;
	fout.flush();
}
void CKinematicHandLeft::LoadHandPose(string strPath)
{}
void CKinematicHandLeft::Render()
{	
	//lighting always
	GLfloat light_position[] = {60, 60, 60, 0.0};	
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	//finger
	glColor3ub(RGB_THUMB);
	m_arChain[0]->Render();
	glColor3ub(RGB_INDEX);
	m_arChain[1]->Render();
	glColor3ub(RGB_MIDDLE);
	m_arChain[2]->Render();
	glColor3ub(RGB_RING);
	m_arChain[3]->Render();
	glColor3ub(RGB_PINKY);
	m_arChain[4]->Render();

	//palm polygon
	glColor3f(1.0f, 0.8f, 0.7f);
	glBegin(GL_POLYGON);
	glVertex3f(m_arChain[0]->m_posRoot.m_fX,m_arChain[0]->m_posRoot.m_fY, m_arChain[0]->m_posRoot.m_fZ);
	CKinematicPos posFirst = m_arChain[0]->m_posRoot;
	CKinematicPos posMid = m_arChain[3]->m_arJoint[1]->m_posGlobalCoord;
	CKinematicPos posLast = m_arChain[4]->m_arJoint[1]->m_posGlobalCoord;
	for(int i = 0; i < m_arChain.size(); ++i)
	{
		CKinematicChain* pChain = m_arChain[i];
		if(pChain == NULL)
			continue;			
		
		glVertex3f(pChain->m_arJoint[1]->m_posGlobalCoord.m_fX, pChain->m_arJoint[1]->m_posGlobalCoord.m_fY, pChain->m_arJoint[1]->m_posGlobalCoord.m_fZ);
		if(i==0)
			glVertex3f(pChain->m_arJoint[3]->m_posGlobalCoord.m_fX, pChain->m_arJoint[3]->m_posGlobalCoord.m_fY, pChain->m_arJoint[3]->m_posGlobalCoord.m_fZ);
		
	}
	glVertex3f(posFirst.m_fX+posLast.m_fX-posMid.m_fX, posFirst.m_fY+posLast.m_fY-posMid.m_fY, posFirst.m_fZ+posLast.m_fZ-posMid.m_fZ);
	glEnd();
}
CKinematicJoint* CKinematicHandLeft::GetJoint(enum HAND_JOINT_ID id)
{
	switch(id)
	{
	case E_JOINT_THUMB_ROOT: return m_arChain[0]->m_arJoint[0];
	case E_JOINT_THUMB_ABDUCT: return m_arChain[0]->m_arJoint[1];
	case E_JOINT_THUMB_VIRTUAL_TWIST: return m_arChain[0]->m_arJoint[2];
	case E_JOINT_THUMB_FLEX_1: return m_arChain[0]->m_arJoint[3];
	case E_JOINT_THUMB_FLEX_2: return m_arChain[0]->m_arJoint[4];
	case E_JOINT_THUMB_END: return m_arChain[0]->m_arJoint[5];

	case 	E_JOINT_INDEX_PALM: return m_arChain[1]->m_arJoint[0];
	case E_JOINT_INDEX_PROXIMAL: return m_arChain[1]->m_arJoint[1];
	case E_JOINT_INDEX_MID: return m_arChain[1]->m_arJoint[2];
	case E_JOINT_INDEX_DISTAL: return m_arChain[1]->m_arJoint[3];
	case E_JOINT_INDEX_END: return m_arChain[1]->m_arJoint[4];

	case E_JOINT_MID_PALM: return m_arChain[2]->m_arJoint[0];
	case E_JOINT_MID_PROXIMAL: return m_arChain[2]->m_arJoint[1];
	case E_JOINT_MID_MID: return m_arChain[2]->m_arJoint[2];
	case E_JOINT_MID_DISTAL: return m_arChain[2]->m_arJoint[3];
	case E_JOINT_MID_END: return m_arChain[2]->m_arJoint[4];

	case E_JOINT_RING_PALM: return m_arChain[3]->m_arJoint[0];
	case E_JOINT_RING_PROXIMAL: return m_arChain[3]->m_arJoint[1];
	case E_JOINT_RING_MID: return m_arChain[3]->m_arJoint[2];
	case E_JOINT_RING_DISTAL: return m_arChain[3]->m_arJoint[3];
	case E_JOINT_RING_END: return m_arChain[3]->m_arJoint[4];

	case E_JOINT_PINKY_PALM: return m_arChain[4]->m_arJoint[0];
	case E_JOINT_PINKY_PROXIMAL: return m_arChain[4]->m_arJoint[1];
	case E_JOINT_PINKY_MID: return m_arChain[4]->m_arJoint[2];
	case E_JOINT_PINKY_DISTAL: return m_arChain[4]->m_arJoint[3];
	case E_JOINT_PINKY_END: return m_arChain[4]->m_arJoint[4];
	}
	return NULL;
}
CKinematicDOF* CKinematicHandLeft::GetDOF(enum HAND_JOINT_ID, enum HAND_DOF_ID)
{
	return NULL;
}
void CKinematicHandLeft::SetDefaultPose()
{	
	//thumb
	CKinematicChain* pChainThumb =m_arChain[0];
	/*palm*/pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -30;
	/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*virtual-twist*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = m_fA*(-30)+m_fB*(15);
	/*flex1*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flex2*/pChainThumb->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	//index
	CKinematicChain* pChainIndex =m_arChain[1];
	/*palm abd*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*palm flex*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexProx*/pChainIndex->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	/*flexMid*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexDist*/pChainIndex->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	//mid
	CKinematicChain* pChainMid = m_arChain[2];	
	/*palm abd*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*palm flex*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;	
	/*abd*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainMid->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	/*flexMid*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexDist*/pChainMid->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	/*palm abd*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*palm flex*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;		
	/*abd*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*flexProx*/pChainRing->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	/*flexMid*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexDist*/pChainRing->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	//pinky
	CKinematicChain* pChainPinky =m_arChain[4];	
	/*palm abd*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -30;
	/*palm flex*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;		
	/*abd*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 30;
	/*flexProx*/pChainPinky->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	/*flexMid*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexDist*/pChainPinky->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();
}
void CKinematicHandLeft::SetFlatPose()
{	
	//thumb
	CKinematicChain* pChainThumb = m_arChain[0];
	/*roll*/	pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*virtual*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flex1*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flex2*/pChainThumb->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//index
	CKinematicChain* pChainIndex = m_arChain[1];
	/*abdPalm*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*flexPalm*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexProx*/pChainIndex->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainIndex->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//mid
	CKinematicChain* pChainMid = m_arChain[2];	
    /*abdPalm*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexPalm*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainMid->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainMid->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	/*abdPalm*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexPalm*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*flexProx*/pChainRing->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainRing->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//pinky
	CKinematicChain* pChainPinky = m_arChain[4];	
	/*abdPalm*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -30;
	/*flexPalm*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 30;
	/*flexProx*/pChainPinky->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainPinky->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();

}
void CKinematicHandLeft::SetFistPose()
{	
	//thumb
	CKinematicChain* pChainThumb = m_arChain[0];
	/*roll*/	pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -60;
	/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 30;
	/*virtual*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = m_fA*(-60)+m_fB*(30);
	/*flex1*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -45;
	/*flex2*/pChainThumb->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	//index
	CKinematicChain* pChainIndex = m_arChain[1];
	/*abdPalm*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*flexPalm*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexProx*/pChainIndex->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -100;
	/*flexMid*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -90;
	/*flexDist*/pChainIndex->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	//mid
	CKinematicChain* pChainMid = m_arChain[2];	
	/*abdPalm*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexPalm*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainMid->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -100;
	/*flexMid*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -90;
	/*flexDist*/pChainMid->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	/*abdPalm*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexPalm*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*flexProx*/pChainRing->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -100;
	/*flexMid*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -90;
	/*flexDist*/pChainRing->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	//pinky
	CKinematicChain* pChainPinky = m_arChain[4];	
	/*abdPalm*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -30;
	/*flexPalm*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 30;
	/*flexProx*/pChainPinky->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -100;
	/*flexMid*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -90;
	/*flexDist*/pChainPinky->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();
}
void CKinematicHandLeft::SetSpreadPose()
{	
	//thumb
	CKinematicChain* pChainThumb = m_arChain[0];
	/*roll*/pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 70;
	/*virtual*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = m_fB*(70);
	/*flex1*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flex2*/pChainThumb->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//index
	CKinematicChain* pChainIndex = m_arChain[1];
	/*abdPalm*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*flexPalm*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainIndex->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainIndex->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//mid
	CKinematicChain* pChainMid = m_arChain[2];	
	/*abdPalm*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexPalm*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainMid->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainMid->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	/*abdPalm*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexPalm*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainRing->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainRing->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//pinky
	CKinematicChain* pChainPinky = m_arChain[4];	
	/*abdPalm*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -30;
	/*flexPalm*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -10;
	/*flexProx*/pChainPinky->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainPinky->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();
}
//sensor is jiajiao, kinematic is kjiao
//that is: jiajiao (index 15, 0) = kjiao (index 0, -15) + palm_abd_kjiao (15)
//->     : kjiao = jiajiao - palm_abd_kjiao
//zhuyi:  jiajiao rengran you zhengfu de
void CKinematicHandLeft::UpdateFingerFromSensorData(enum HAND_CHAIN_ID eChainId, const std::vector<float>& arSensorData)
{
	static const int glv_thumbTMJ = 0;
	static const int glv_thumbMPJ = 1;
	static const int glv_thumbIJ = 2;
	static const int glv_thumbAbduction = 3;
	static const int glv_indexMPJ = 4;
	static const int glv_indexPIJ = 5;
	static const int glv_indexDIJ = 6;
	static const int glv_indexAbduction = 7;
	static const int glv_middleMPJ = 8;
	static const int glv_middlePIJ = 9;
	static const int glv_middleDIJ = 10;
	static const int glv_middleAbudction = 11;
	static const int glv_ringMPJ = 12;
	static const int glv_ringPIJ = 13;
	static const int glv_ringDIJ = 14;
	static const int glv_ringAbduction = 15;
	static const int glv_pinkieMPJ = 16;
	static const int glv_pinkiePIJ = 17;
	static const int glv_pinkieDIJ = 18;
	static const int glv_pinkieAbduction = 19;
	static const int glv_palmArch = 20;
	static const int glv_wristPitch = 21;
	static const int glv_wristYaw = 22;
	/*static const int glv_palmArch = 20;
	static const int glv_wristPitch = 21;
	static const int glv_wristYaw = 22;*/

	std::vector<float> arSensorDegreeData;
	for(int i = 0; i < arSensorData.size(); ++i)
		arSensorDegreeData.push_back(RadianToDegree(arSensorData[i]));

	if(eChainId ==  HAND_CHAIN_ID::E_CHAIN_THUMB)
	{
			//thumb
			CKinematicChain* pChainThumb =m_arChain[0];
			/*palm*/pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_thumbTMJ];
			/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_thumbAbduction];
			/*virtual-twist*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = m_fA*pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle+m_fB*pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle;
			/*flex1*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_thumbMPJ];
			/*flex2*/pChainThumb->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_thumbIJ];
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_INDEX)
	{
			//index
			CKinematicChain* pChainIndex =m_arChain[1];
			/*palm abd*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 15;
			/*palm flex*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
			/*abd*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_indexAbduction] - pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle;
			/*flexProx*/pChainIndex->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = arSensorDegreeData[glv_indexMPJ];
			/*flexMid*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_indexPIJ];
			/*flexDist*/pChainIndex->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_indexDIJ];
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_MID)
	{
		//mid
		CKinematicChain* pChainMid = m_arChain[2];	
		//wangyy TODO: fix with palm arch
		/*palm abd*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
		/*palm flex*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;	
		/*abd*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;//arSensorDegreeData[glv_middleAbudction];
		/*flexProx*/pChainMid->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = arSensorDegreeData[glv_middleMPJ];
		/*flexMid*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_middlePIJ];
		/*flexDist*/pChainMid->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_middleDIJ];
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_RING)
	{
		//ring
		CKinematicChain* pChainRing = m_arChain[3];
		//wangyy TODO: fix with palm arch
		/*palm abd*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -15;
		/*palm flex*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;		
		/*abd*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_ringAbduction] - pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle;
		/*flexProx*/pChainRing->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = arSensorDegreeData[glv_ringMPJ];
		/*flexMid*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_ringPIJ];
		/*flexDist*/pChainRing->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_ringDIJ];
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_PINKY)
	{
		//pinky
		CKinematicChain* pChainPinky =m_arChain[4];	
		//wangyy TODO: fix with palm arch
		/*palm abd*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -30;
		/*palm flex*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;		
		/*abd*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_pinkieAbduction] - pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle;
		/*flexProx*/pChainPinky->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = arSensorDegreeData[glv_pinkieMPJ];
		/*flexMid*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_pinkiePIJ];
		/*flexDist*/pChainPinky->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_pinkieDIJ];
	}
}
void CKinematicHandLeft::UpdateFingerToSensorData(enum HAND_CHAIN_ID eChainId, std::vector<float>& arSensorData)
{
	static const int glv_thumbTMJ = 0;
	static const int glv_thumbMPJ = 1;
	static const int glv_thumbIJ = 2;
	static const int glv_thumbAbduction = 3;
	static const int glv_indexMPJ = 4;
	static const int glv_indexPIJ = 5;
	static const int glv_indexDIJ = 6;
	static const int glv_indexAbduction = 7;
	static const int glv_middleMPJ = 8;
	static const int glv_middlePIJ = 9;
	static const int glv_middleDIJ = 10;
	static const int glv_middleAbudction = 11;
	static const int glv_ringMPJ = 12;
	static const int glv_ringPIJ = 13;
	static const int glv_ringDIJ = 14;
	static const int glv_ringAbduction = 15;
	static const int glv_pinkieMPJ = 16;
	static const int glv_pinkiePIJ = 17;
	static const int glv_pinkieDIJ = 18;
	static const int glv_pinkieAbduction = 19;
	static const int glv_palmArch = 20;
	static const int glv_wristPitch = 21;
	static const int glv_wristYaw = 22;

	if(eChainId == HAND_CHAIN_ID::E_CHAIN_THUMB)
	{
		//thumb
		CKinematicChain* pChainThumb =m_arChain[0];
		/*palm*/arSensorData[glv_thumbTMJ] = DegreeToRadian(pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle);
		/*abd*/arSensorData[glv_thumbAbduction] = DegreeToRadian(pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flex1*/arSensorData[glv_thumbMPJ] =DegreeToRadian( pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flex2*/arSensorData[glv_thumbIJ] = DegreeToRadian(pChainThumb->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle);
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_INDEX)
	{
		//index
		CKinematicChain* pChainIndex =m_arChain[1];
		/*abd*/arSensorData[glv_indexAbduction] = DegreeToRadian(pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle + pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexProx*/arSensorData[glv_indexMPJ] = DegreeToRadian(pChainIndex->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle);
		/*flexMid*/arSensorData[glv_indexPIJ] = DegreeToRadian(pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexDist*/arSensorData[glv_indexDIJ] = DegreeToRadian(pChainIndex->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle);
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_MID)
	{
		//mid
		CKinematicChain* pChainMid = m_arChain[2];
		/*abd*/arSensorData[glv_middleAbudction] = 0;
		/*flexProx*/arSensorData[glv_middleMPJ] = DegreeToRadian(pChainMid->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle);
		/*flexMid*/arSensorData[glv_middlePIJ] = DegreeToRadian(pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexDist*/arSensorData[glv_middleDIJ] = DegreeToRadian(pChainMid->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle);
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_RING)
	{
		//ring
		CKinematicChain* pChainRing = m_arChain[3];		
		/*abd*/arSensorData[glv_ringAbduction] = DegreeToRadian(pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle + pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexProx*/arSensorData[glv_ringMPJ] = DegreeToRadian(pChainRing->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle);
		/*flexMid*/arSensorData[glv_ringPIJ] = DegreeToRadian(pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexDist*/arSensorData[glv_ringDIJ] = DegreeToRadian(pChainRing->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle);
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_PINKY)
	{
		//pinky
		CKinematicChain* pChainPinky =m_arChain[4];		
		/*abd*/arSensorData[glv_pinkieAbduction] = DegreeToRadian(pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle + pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexProx*/arSensorData[glv_pinkieMPJ] = DegreeToRadian(pChainPinky->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle);
		/*flexMid*/arSensorData[glv_pinkiePIJ] = DegreeToRadian(pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexDist*/arSensorData[glv_pinkieDIJ] = DegreeToRadian(pChainPinky->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle);
	}
}
void CKinematicHandLeft::UpdateFromSensorData(const std::vector<float>& arSensorData)
{	
	UpdateFingerFromSensorData(HAND_CHAIN_ID::E_CHAIN_THUMB, arSensorData);
	UpdateFingerFromSensorData(HAND_CHAIN_ID::E_CHAIN_INDEX, arSensorData);
	UpdateFingerFromSensorData(HAND_CHAIN_ID::E_CHAIN_MID, arSensorData);
	UpdateFingerFromSensorData(HAND_CHAIN_ID::E_CHAIN_RING, arSensorData);
	UpdateFingerFromSensorData(HAND_CHAIN_ID::E_CHAIN_PINKY, arSensorData);
}


void CKinematicHandLeft::UpdateToSensorData(std::vector<float>& arSensorData)
{
	UpdateFingerToSensorData(HAND_CHAIN_ID::E_CHAIN_THUMB, arSensorData);
	UpdateFingerToSensorData(HAND_CHAIN_ID::E_CHAIN_INDEX, arSensorData);
	UpdateFingerToSensorData(HAND_CHAIN_ID::E_CHAIN_MID, arSensorData);
	UpdateFingerToSensorData(HAND_CHAIN_ID::E_CHAIN_RING, arSensorData);
	UpdateFingerToSensorData(HAND_CHAIN_ID::E_CHAIN_PINKY, arSensorData);
}
//=========================================================================================
//right hand
CKinematicHandRight::CKinematicHandRight()
{
	m_fA = 0.25;
	m_fB = -0.375;
}
void CKinematicHandRight::ConstructHand()
{
	for(int i = 0; i < m_arChain.size(); ++i)
		delete m_arChain[i];
	m_arChain.clear();

	//thumb=================================================================
	CKinematicChain* pChainThumb = new CKinematicChain(CKinematicPos(0, 0, 0), E_CHAIN_THUMB);
	
	CKinematicJoint* pJointThumbRoot = new CKinematicJoint(CKinematicPos(0, 0, 0), E_JOINT_THUMB_ROOT);
	pJointThumbRoot->AddDOF(new CKinematicDOF(30, CKinematicVec3D(1,0,0), E_DOF_ROLL_X, 1, CKinematicVec3D(1, -10, 90), 1));
	pChainThumb->AddJoint(pJointThumbRoot);

	CKinematicJoint* pJointThumbAbduct = new CKinematicJoint(CKinematicPos(0, 0, -2.5), E_JOINT_THUMB_ABDUCT);
	pJointThumbAbduct->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 1, CKinematicVec3D(1, -90, 0), 6));
	pChainThumb->AddJoint(pJointThumbAbduct);

	//virtual twist - in the middle
	CKinematicJoint* pJointThumbVirtualTwist = new CKinematicJoint(CKinematicPos(-2.25, 0, 0), E_JOINT_THUMB_VIRTUAL_TWIST);
	pJointThumbVirtualTwist->AddDOF(new CKinematicDOF(m_fA*30+m_fB*(-15), CKinematicVec3D(1,0,0), E_DOF_ROLL_X, 1, CKinematicVec3D(1, 0, 90), 6));
	pChainThumb->AddJoint(pJointThumbVirtualTwist);

	CKinematicJoint* pJointThumbMid = new CKinematicJoint(CKinematicPos(-2.25, 0, 0), E_JOINT_THUMB_FLEX_1);
	pJointThumbMid->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 1, CKinematicVec3D(1, -80,  5), 3));
	pChainThumb->AddJoint(pJointThumbMid);

	CKinematicJoint* pJointThumbDistal = new CKinematicJoint(CKinematicPos(-3.6, 0, 0), E_JOINT_THUMB_FLEX_2);
	pJointThumbDistal->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 1, CKinematicVec3D(1, -100, 10), 3));
	pChainThumb->AddJoint(pJointThumbDistal);

	CKinematicJoint* pJointThumbEnd = new CKinematicJoint(CKinematicPos(-3, 0, 0), E_JOINT_THUMB_END);
	pChainThumb->AddJoint(pJointThumbEnd);

	//index==================================================================
	CKinematicChain* pChainIndex = new CKinematicChain(CKinematicPos(0,0,0), E_CHAIN_INDEX);
	//in palm
	CKinematicJoint* pJointIndexPalm = new CKinematicJoint(CKinematicPos(0,0,0), E_JOINT_INDEX_PALM);
	pJointIndexPalm->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 0, CKinematicVec3D(1, -15, -15), 1));//in palm abd
	pJointIndexPalm->AddDOF(new CKinematicDOF(0, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 0, CKinematicVec3D(1, 0, 0), 1));//in palm flex, not change to much as rigid
	pChainIndex->AddJoint(pJointIndexPalm);
	//proximal
	CKinematicJoint* pJointIndexProximal = new CKinematicJoint(CKinematicPos(-7.2,0,0), E_JOINT_INDEX_PROXIMAL);
	pJointIndexProximal->AddDOF(new CKinematicDOF(15, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 0.1, CKinematicVec3D(0.1, 0, 20), 3));
	pJointIndexProximal->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 0.1, CKinematicVec3D(0.1, -100, 10), 3));
	pChainIndex->AddJoint(pJointIndexProximal);
	//mid
	CKinematicJoint* pJointIndexMid = new CKinematicJoint(CKinematicPos(-4.5,0,0), E_JOINT_INDEX_MID);
	pJointIndexMid->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1),E_DOF_FLEX_Z, 0.1, CKinematicVec3D(0.1, -100, 5), 3));
	pChainIndex->AddJoint(pJointIndexMid);
	//distal
	CKinematicJoint* pJointIndexDistal = new CKinematicJoint(CKinematicPos(-2.6,0,0), E_JOINT_INDEX_DISTAL);
	pJointIndexDistal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z, 0.1, CKinematicVec3D(0.1, -90, 0), 3));
	pChainIndex->AddJoint(pJointIndexDistal);
	//end
	CKinematicJoint* pJointIndexEnd = new CKinematicJoint(CKinematicPos(-2.2,0,0),E_JOINT_INDEX_END);
	pChainIndex->AddJoint(pJointIndexEnd);

	//mid===================================================================
	CKinematicChain* pChainMid = new CKinematicChain(CKinematicPos(0,0,0),E_CHAIN_MID);
	//in palm
	CKinematicJoint* pJointMidPalm = new CKinematicJoint(CKinematicPos(0,0,0),E_JOINT_MID_PALM);
	pJointMidPalm->AddDOF(new CKinematicDOF(0, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 0.1, CKinematicVec3D(1, 0, 0), 1));//in palm abd
	pJointMidPalm->AddDOF(new CKinematicDOF(0, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 0.1, CKinematicVec3D(1, 0, 0), 1));//in palm flex
	pChainMid->AddJoint(pJointMidPalm);
	//proximal
	CKinematicJoint* pJointMidProximal = new CKinematicJoint(CKinematicPos(-6.6, 0,0),E_JOINT_MID_PROXIMAL);
	pJointMidProximal->AddDOF(new CKinematicDOF(0, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 1, CKinematicVec3D(1, 0, 0), 3));
	pJointMidProximal->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 1, CKinematicVec3D(1, -100, 10), 3));
	pChainMid->AddJoint(pJointMidProximal);
	//mid
	CKinematicJoint* pJointMidMid = new CKinematicJoint(CKinematicPos(-5,0,0),E_JOINT_MID_MID);
	pJointMidMid->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 1, CKinematicVec3D(1, -100, 5), 3));
	pChainMid->AddJoint(pJointMidMid);
	//distal
	CKinematicJoint* pJointMidDistal = new CKinematicJoint(CKinematicPos(-2.9,0,0),E_JOINT_MID_DISTAL);
	pJointMidDistal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z, 1, CKinematicVec3D(1, -90, 0), 3));
	pChainMid->AddJoint(pJointMidDistal);
	//end
	CKinematicJoint* pJointMidEnd = new CKinematicJoint(CKinematicPos(-2.4,0,0), E_JOINT_MID_END);
	pChainMid->AddJoint(pJointMidEnd);

	//ring====================================================================
	CKinematicChain* pChainRing = new CKinematicChain(CKinematicPos(0,0,0), E_CHAIN_RING);
	//in palm
	CKinematicJoint* pJointRingPalm = new CKinematicJoint(CKinematicPos(0,0,0), E_JOINT_RING_PALM);
	pJointRingPalm->AddDOF(new CKinematicDOF(15,CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 0.1, CKinematicVec3D(1, 15, 15), 1));
	pJointRingPalm->AddDOF(new CKinematicDOF(0,CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 0.1, CKinematicVec3D(1, 0, 0), 1));
	pChainRing->AddJoint(pJointRingPalm);
	//proximal
	CKinematicJoint* pJointRingProximal = new CKinematicJoint(CKinematicPos(-6.4,0,0), E_JOINT_RING_PROXIMAL);
	pJointRingProximal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y, 1, CKinematicVec3D(1, -15, 0), 3));
	pJointRingProximal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1), E_DOF_FLEX_Z, 1, CKinematicVec3D(1, -100, 10), 3));
	pChainRing->AddJoint(pJointRingProximal);
	//mid
	CKinematicJoint* pJointRingMid = new CKinematicJoint(CKinematicPos(-5,0,0), E_JOINT_RING_MID);
	pJointRingMid->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z,1, CKinematicVec3D(1, -100, 5), 3));
	pChainRing->AddJoint(pJointRingMid);
	//distal
	CKinematicJoint* pJointRingDistal = new CKinematicJoint(CKinematicPos(-2.7,0,0),E_JOINT_RING_DISTAL);
	pJointRingDistal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z, 1, CKinematicVec3D(1, -90, 0), 3));
	pChainRing->AddJoint(pJointRingDistal);
	//end
	CKinematicJoint* pJointRingEnd = new CKinematicJoint(CKinematicPos(-2.3,0,0),E_JOINT_RING_END);
	pChainRing->AddJoint(pJointRingEnd);

	//pinky====================================================================
	//proximal
	CKinematicChain* pChainPinky = new CKinematicChain(CKinematicPos(0,0,0), E_CHAIN_PINKY);
	//palm
	CKinematicJoint* pJointPinkyPalm = new CKinematicJoint(CKinematicPos(0,0,0),E_JOINT_PINKY_PALM);
	pJointPinkyPalm->AddDOF(new CKinematicDOF(30,CKinematicVec3D(0,1,0),E_DOF_ABDUCT_Y, 0.1, CKinematicVec3D(1, 30, 30), 1));
	pJointPinkyPalm->AddDOF(new CKinematicDOF(0,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z, 0.1, CKinematicVec3D(1, 0, 0), 1));
	pChainPinky->AddJoint(pJointPinkyPalm);

	//proximal
	CKinematicJoint* pJointPinkyProximal = new CKinematicJoint(CKinematicPos(-6.5,0,0),E_JOINT_PINKY_PROXIMAL);
	pJointPinkyProximal->AddDOF(new CKinematicDOF(-30,CKinematicVec3D(0,1,0),E_DOF_ABDUCT_Y, 1, CKinematicVec3D(1, -30, 10), 3));
	pJointPinkyProximal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z, 1, CKinematicVec3D(1, -100, 20), 3));
	pChainPinky->AddJoint(pJointPinkyProximal);
	//mid
	CKinematicJoint* pJointPinkyMid = new CKinematicJoint(CKinematicPos(-3.6,0,0),E_JOINT_PINKY_MID);
	pJointPinkyMid->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z,1, CKinematicVec3D(1, -100, 0), 3));
	pChainPinky->AddJoint(pJointPinkyMid);
	//distal
	CKinematicJoint* pJointPinkyDistal = new CKinematicJoint(CKinematicPos(-2.1,0,0),E_JOINT_PINKY_DISTAL);
	pJointPinkyDistal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z,1, CKinematicVec3D(1, -100, 0), 3));
	pChainPinky->AddJoint(pJointPinkyDistal);
	//end
	CKinematicJoint* pJointPinkyEnd = new CKinematicJoint(CKinematicPos(-2.2,0,0),E_JOINT_PINKY_END);
	pChainPinky->AddJoint(pJointPinkyEnd);

	//populate global info ============================================================
	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();

	//initialize goal ================================================================
	pChainThumb->m_posGoal = pChainThumb->m_arJoint[pChainThumb->m_arJoint.size()-1]->m_posGlobalCoord;
	pChainIndex->m_posGoal = pChainIndex->m_arJoint[pChainIndex->m_arJoint.size()-1]->m_posGlobalCoord;
	pChainMid->m_posGoal = pChainMid->m_arJoint[pChainMid->m_arJoint.size()-1]->m_posGlobalCoord;
	pChainRing->m_posGoal = pChainRing->m_arJoint[pChainRing->m_arJoint.size()-1]->m_posGlobalCoord;
	pChainPinky->m_posGoal = pChainPinky->m_arJoint[pChainPinky->m_arJoint.size()-1]->m_posGlobalCoord;

	//add to vector ================================================================
	m_arChain.push_back(pChainThumb);
	m_arChain.push_back(pChainIndex);
	m_arChain.push_back(pChainMid);
	m_arChain.push_back(pChainRing);
	m_arChain.push_back(pChainPinky);
}
void CKinematicHandRight::DestructHand()
{
	for(int i = 0; i < m_arChain.size(); ++i)
		delete m_arChain[i];
	m_arChain.clear();
}
void CKinematicHandRight::Reset()
{	
	SetDefaultPose();
}
void CKinematicHandRight::LoadHandSize(string strPath)
{
	std::ifstream fin(strPath.c_str());

	//thumb
	char bufThumb[600] = {0};
	fin.getline(bufThumb, sizeof(bufThumb));
	string strLine(bufThumb);
	int iBeg = 0, iEnd = strLine.find(",", iBeg);
	string strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[0]->m_arJoint[1]->m_posLocalCoord = CKinematicPoint(0,0,- atof(strLen.c_str()));

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[0]->m_arJoint[2]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[0]->m_arJoint[3]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[0]->m_arJoint[4]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1;
	strLen = strLine.substr(iBeg);
	m_arChain[0]->m_arJoint[5]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	//index
	char bufIndex[600] = {0};
	fin.getline(bufIndex, sizeof(bufIndex));
	strLine = string(bufIndex);
	iBeg = 0, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[1]->m_arJoint[1]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[1]->m_arJoint[2]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[1]->m_arJoint[3]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1;
	strLen = strLine.substr(iBeg);
	m_arChain[1]->m_arJoint[4]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);
	
	//middle
	char bufMiddle[600] = {0};
	fin.getline(bufMiddle, sizeof(bufMiddle));
	strLine = string(bufMiddle);
	iBeg = 0, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[2]->m_arJoint[1]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[2]->m_arJoint[2]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[2]->m_arJoint[3]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1;
	strLen = strLine.substr(iBeg);
	m_arChain[2]->m_arJoint[4]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	//ring
	char bufRing[600] = {0};
	fin.getline(bufRing, sizeof(bufRing));
	strLine = string(bufRing);
	iBeg = 0, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[3]->m_arJoint[1]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[3]->m_arJoint[2]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[3]->m_arJoint[3]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1;
	strLen = strLine.substr(iBeg);
	m_arChain[3]->m_arJoint[4]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);
	
	//pinky
	char bufPinky[600] = {0};
	fin.getline(bufPinky, sizeof(bufRing));
	strLine = string(bufPinky);
	iBeg = 0, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[4]->m_arJoint[1]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[4]->m_arJoint[2]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1, iEnd = strLine.find(",", iBeg);
	strLen = strLine.substr(iBeg, iEnd-iBeg);
	m_arChain[4]->m_arJoint[3]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	iBeg = iEnd+1;
	strLen = strLine.substr(iBeg);
	m_arChain[4]->m_arJoint[4]->m_posLocalCoord = CKinematicPoint(- atof(strLen.c_str()),0,0);

	PopulateGlobalPosAndAxis();
}
void CKinematicHandRight::SaveHandSize(string strPath)
{
	std::ofstream fout(strPath.c_str());	
	//thumb
	fout << m_arChain[0]->m_arJoint[1]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[0]->m_arJoint[2]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[0]->m_arJoint[3]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[0]->m_arJoint[4]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[0]->m_arJoint[5]->m_posLocalCoord.GetEuclideanLength() << std::endl;
	//index
	fout << m_arChain[1]->m_arJoint[1]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[1]->m_arJoint[2]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[1]->m_arJoint[3]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[1]->m_arJoint[4]->m_posLocalCoord.GetEuclideanLength() << std::endl;
	//middle
	fout << m_arChain[2]->m_arJoint[1]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[2]->m_arJoint[2]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[2]->m_arJoint[3]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[2]->m_arJoint[4]->m_posLocalCoord.GetEuclideanLength() << std::endl;
	//ring
	fout << m_arChain[3]->m_arJoint[1]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[3]->m_arJoint[2]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[3]->m_arJoint[3]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[3]->m_arJoint[4]->m_posLocalCoord.GetEuclideanLength() << std::endl;
	//pinky
	fout << m_arChain[4]->m_arJoint[1]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[4]->m_arJoint[2]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[4]->m_arJoint[3]->m_posLocalCoord.GetEuclideanLength() << ",";
	fout << m_arChain[4]->m_arJoint[4]->m_posLocalCoord.GetEuclideanLength() << std::endl;
	fout.flush();
}
void CKinematicHandRight::LoadHandPose(string strPath)
{}
void CKinematicHandRight::Render()
{	
	//finger
	glColor3f(1.0f, 0.0f, 0.0f);
	m_arChain[0]->Render();
	glColor3f(1.0f, 1.0f, 0.0f);
	m_arChain[1]->Render();
	glColor3f(0.0f, 0.0f, 1.0f);
	m_arChain[2]->Render();
	glColor3f(0.0f, 1.0f, 0.0f);
	m_arChain[3]->Render();
	glColor3f(1.0f, 0.0f, 1.0f);
	m_arChain[4]->Render();

	//palm polygon
	glColor3f(1.0f, 0.8f, 0.7f);
	glBegin(GL_POLYGON);
	glVertex3f(m_arChain[0]->m_posRoot.m_fX,m_arChain[0]->m_posRoot.m_fY, m_arChain[0]->m_posRoot.m_fZ);
	CKinematicPos posFirst = m_arChain[0]->m_posRoot;
	CKinematicPos posMid = m_arChain[3]->m_arJoint[1]->m_posGlobalCoord;
	CKinematicPos posLast = m_arChain[4]->m_arJoint[1]->m_posGlobalCoord;
	for(int i = 0; i < m_arChain.size(); ++i)
	{
		CKinematicChain* pChain = m_arChain[i];
		if(pChain == NULL)
			continue;			
		
		glVertex3f(pChain->m_arJoint[1]->m_posGlobalCoord.m_fX, pChain->m_arJoint[1]->m_posGlobalCoord.m_fY, pChain->m_arJoint[1]->m_posGlobalCoord.m_fZ);
		if(i==0)
			glVertex3f(pChain->m_arJoint[3]->m_posGlobalCoord.m_fX, pChain->m_arJoint[3]->m_posGlobalCoord.m_fY, pChain->m_arJoint[3]->m_posGlobalCoord.m_fZ);
		
	}
	glVertex3f(posFirst.m_fX+posLast.m_fX-posMid.m_fX, posFirst.m_fY+posLast.m_fY-posMid.m_fY, posFirst.m_fZ+posLast.m_fZ-posMid.m_fZ);
	glEnd();
}
CKinematicJoint* CKinematicHandRight::GetJoint(enum HAND_JOINT_ID)
{
	return NULL;
}
CKinematicDOF* CKinematicHandRight::GetDOF(enum HAND_JOINT_ID, enum HAND_DOF_ID)
{
	return NULL;
}
void CKinematicHandRight::SetDefaultPose()
{	
	//thumb
	CKinematicChain* pChainThumb =m_arChain[0];
	/*palm*/pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle =30;
	/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*virtual-twist*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = m_fA*30+m_fB*(-15);
	/*flex1*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flex2*/pChainThumb->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	//index
	CKinematicChain* pChainIndex =m_arChain[1];
	/*palm abd*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*palm flex*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*flexProx*/pChainIndex->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	/*flexMid*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexDist*/pChainIndex->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	//mid
	CKinematicChain* pChainMid = m_arChain[2];	
	/*palm abd*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*palm flex*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;	
	/*abd*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainMid->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	/*flexMid*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexDist*/pChainMid->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	/*palm abd*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*palm flex*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;		
	/*abd*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexProx*/pChainRing->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	/*flexMid*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexDist*/pChainRing->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	//pinky
	CKinematicChain* pChainPinky =m_arChain[4];	
	/*palm abd*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 30;
	/*palm flex*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;		
	/*abd*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -30;
	/*flexProx*/pChainPinky->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	/*flexMid*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexDist*/pChainPinky->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();
}
void CKinematicHandRight::SetFlatPose()
{//thumb
	CKinematicChain* pChainThumb = m_arChain[0];
	/*roll*/	pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*virtual*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flex1*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flex2*/pChainThumb->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//index
	CKinematicChain* pChainIndex = m_arChain[1];
	/*abdPalm*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexPalm*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*flexProx*/pChainIndex->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainIndex->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//mid
	CKinematicChain* pChainMid = m_arChain[2];	
    /*abdPalm*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexPalm*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainMid->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainMid->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	/*abdPalm*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*flexPalm*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexProx*/pChainRing->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainRing->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//pinky
	CKinematicChain* pChainPinky = m_arChain[4];	
	/*abdPalm*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 30;
	/*flexPalm*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -30;
	/*flexProx*/pChainPinky->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainPinky->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();
}
void CKinematicHandRight::SetFistPose()
{	
	//thumb
	CKinematicChain* pChainThumb = m_arChain[0];
	/*roll*/pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 60;
	/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -30;
	/*virtual*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = m_fA*60+m_fB*(-30);
	/*flex1*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -45;
	/*flex2*/pChainThumb->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	//index
	CKinematicChain* pChainIndex = m_arChain[1];
	/*abdPalm*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexPalm*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*flexProx*/pChainIndex->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -100;
	/*flexMid*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -90;
	/*flexDist*/pChainIndex->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	//mid
	CKinematicChain* pChainMid = m_arChain[2];	
	/*abdPalm*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexPalm*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainMid->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -100;
	/*flexMid*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -90;
	/*flexDist*/pChainMid->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	/*abdPalm*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*flexPalm*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexProx*/pChainRing->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -100;
	/*flexMid*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -90;
	/*flexDist*/pChainRing->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	//pinky
	CKinematicChain* pChainPinky = m_arChain[4];	
	/*abdPalm*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 30;
	/*flexPalm*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -30;
	/*flexProx*/pChainPinky->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -100;
	/*flexMid*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -90;
	/*flexDist*/pChainPinky->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();
}
void CKinematicHandRight::SetSpreadPose()
{	
	//thumb
	CKinematicChain* pChainThumb = m_arChain[0];
	/*roll*/pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -70;
	/*virtual*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = m_fB*(-70);
	/*flex1*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flex2*/pChainThumb->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//index
	CKinematicChain* pChainIndex = m_arChain[1];
	/*abdPalm*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexPalm*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainIndex->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainIndex->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//mid
	CKinematicChain* pChainMid = m_arChain[2];	
	/*abdPalm*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexPalm*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainMid->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainMid->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	/*abdPalm*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*flexPalm*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainRing->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainRing->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//pinky
	CKinematicChain* pChainPinky = m_arChain[4];	
	/*abdPalm*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 30;
	/*flexPalm*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*abd*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 10;
	/*flexProx*/pChainPinky->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainPinky->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();
}
void CKinematicHandRight::UpdateFingerFromSensorData(enum HAND_CHAIN_ID eChainId, const std::vector<float>& arSensorData) 
{
	std::vector<float> arSensorDegreeData;
	for(int i = 0; i < arSensorData.size(); ++i)
		arSensorDegreeData.push_back(RadianToDegree(arSensorData[i]));

	static const int glv_thumbTMJ = 0;
	static const int glv_thumbMPJ = 1;
	static const int glv_thumbIJ = 2;
	static const int glv_thumbAbduction = 3;
	static const int glv_indexMPJ = 4;
	static const int glv_indexPIJ = 5;
	static const int glv_indexDIJ = 6;
	static const int glv_indexAbduction = 7;
	static const int glv_middleMPJ = 8;
	static const int glv_middlePIJ = 9;
	static const int glv_middleDIJ = 10;
	static const int glv_middleAbudction = 11;
	static const int glv_ringMPJ = 12;
	static const int glv_ringPIJ = 13;
	static const int glv_ringDIJ = 14;
	static const int glv_ringAbduction = 15;
	static const int glv_pinkieMPJ = 16;
	static const int glv_pinkiePIJ = 17;
	static const int glv_pinkieDIJ = 18;
	static const int glv_pinkieAbduction = 19;
	static const int glv_palmArch = 20;
	static const int glv_wristPitch = 21;
	static const int glv_wristYaw = 22;
	/*static const int glv_palmArch = 20;
	static const int glv_wristPitch = 21;
	static const int glv_wristYaw = 22;*/

	if(eChainId == HAND_CHAIN_ID::E_CHAIN_THUMB)
	{
		//thumb
		CKinematicChain* pChainThumb =m_arChain[0];
		/*palm*/pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -arSensorDegreeData[glv_thumbTMJ];
		/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_thumbAbduction];
		/*virtual-twist*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = m_fA*pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle+m_fB*pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle;
		/*flex1*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_thumbMPJ];
		/*flex2*/pChainThumb->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_thumbIJ];
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_INDEX)
	{
		//index
		CKinematicChain* pChainIndex =m_arChain[1];
		/*palm abd*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -15;
		/*palm flex*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
		/*abd*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_indexAbduction] - pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle;
		/*flexProx*/pChainIndex->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = arSensorDegreeData[glv_indexMPJ];
		/*flexMid*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_indexPIJ];
		/*flexDist*/pChainIndex->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_indexDIJ];
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_MID)
	{
		//mid
		CKinematicChain* pChainMid = m_arChain[2];	
		/*palm abd*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
		/*palm flex*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;	
		/*abd*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;//arData[glv_middleAbudction];
		/*flexProx*/pChainMid->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = arSensorDegreeData[glv_middleMPJ];
		/*flexMid*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_middlePIJ];
		/*flexDist*/pChainMid->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_middleDIJ];
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_RING)
	{
		//ring
		CKinematicChain* pChainRing = m_arChain[3];
		/*palm abd*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 15;
		/*palm flex*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;		
		/*abd*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_ringAbduction] - pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle;
		/*flexProx*/pChainRing->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = arSensorDegreeData[glv_ringMPJ];
		/*flexMid*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_ringPIJ];
		/*flexDist*/pChainRing->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_ringDIJ];
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_PINKY)
	{
		//pinky
		CKinematicChain* pChainPinky =m_arChain[4];	
		/*palm abd*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 30;
		/*palm flex*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;		
		/*abd*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_pinkieAbduction] - pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle;
		/*flexProx*/pChainPinky->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = arSensorDegreeData[glv_pinkieMPJ];
		/*flexMid*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_pinkiePIJ];
		/*flexDist*/pChainPinky->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = arSensorDegreeData[glv_pinkieDIJ];
	}

}
void CKinematicHandRight::UpdateFromSensorData(const std::vector<float>& arSensorData)
{		
	UpdateFingerFromSensorData(HAND_CHAIN_ID::E_CHAIN_THUMB, arSensorData);
	UpdateFingerFromSensorData(HAND_CHAIN_ID::E_CHAIN_INDEX, arSensorData);
	UpdateFingerFromSensorData(HAND_CHAIN_ID::E_CHAIN_MID, arSensorData);
	UpdateFingerFromSensorData(HAND_CHAIN_ID::E_CHAIN_RING, arSensorData);
	UpdateFingerFromSensorData(HAND_CHAIN_ID::E_CHAIN_PINKY, arSensorData);
}
void CKinematicHandRight::UpdateFingerToSensorData(enum HAND_CHAIN_ID eChainId, std::vector<float>& arSensorData)
{
	static const int glv_thumbTMJ = 0;
	static const int glv_thumbMPJ = 1;
	static const int glv_thumbIJ = 2;
	static const int glv_thumbAbduction = 3;
	static const int glv_indexMPJ = 4;
	static const int glv_indexPIJ = 5;
	static const int glv_indexDIJ = 6;
	static const int glv_indexAbduction = 7;
	static const int glv_middleMPJ = 8;
	static const int glv_middlePIJ = 9;
	static const int glv_middleDIJ = 10;
	static const int glv_middleAbudction = 11;
	static const int glv_ringMPJ = 12;
	static const int glv_ringPIJ = 13;
	static const int glv_ringDIJ = 14;
	static const int glv_ringAbduction = 15;
	static const int glv_pinkieMPJ = 16;
	static const int glv_pinkiePIJ = 17;
	static const int glv_pinkieDIJ = 18;
	static const int glv_pinkieAbduction = 19;
	static const int glv_palmArch = 20;
	static const int glv_wristPitch = 21;
	static const int glv_wristYaw = 22;

	if(eChainId == HAND_CHAIN_ID::E_CHAIN_THUMB)
	{
		//thumb
		CKinematicChain* pChainThumb =m_arChain[0];
		/*palm*/arSensorData[glv_thumbTMJ] = DegreeToRadian(- pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle);
		/*abd*/arSensorData[glv_thumbAbduction] = DegreeToRadian(pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flex1*/arSensorData[glv_thumbMPJ] = DegreeToRadian(pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flex2*/arSensorData[glv_thumbIJ] = DegreeToRadian(pChainThumb->m_arJoint[4]->m_arDOF[0]->m_dLocalRotationAngle);
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_INDEX)
	{
		//index
		CKinematicChain* pChainIndex =m_arChain[1];
		/*abd*/arSensorData[glv_indexAbduction] = DegreeToRadian(pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle + pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexProx*/arSensorData[glv_indexMPJ] = DegreeToRadian(pChainIndex->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle);
		/*flexMid*/arSensorData[glv_indexPIJ] = DegreeToRadian(pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexDist*/arSensorData[glv_indexDIJ] = DegreeToRadian(pChainIndex->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle);
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_MID)
	{
		//mid
		CKinematicChain* pChainMid = m_arChain[2];
		/*abd*/arSensorData[glv_middleAbudction] = 0;
		/*flexProx*/arSensorData[glv_middleMPJ] =DegreeToRadian( pChainMid->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle);
		/*flexMid*/arSensorData[glv_middlePIJ] = DegreeToRadian(pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexDist*/arSensorData[glv_middleDIJ] = DegreeToRadian(pChainMid->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle);
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_RING)
	{
		//ring
		CKinematicChain* pChainRing = m_arChain[3];		
		/*abd*/arSensorData[glv_ringAbduction] = DegreeToRadian(pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle + pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexProx*/arSensorData[glv_ringMPJ] = DegreeToRadian(pChainRing->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle);
		/*flexMid*/arSensorData[glv_ringPIJ] = DegreeToRadian(pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexDist*/arSensorData[glv_ringDIJ] = DegreeToRadian(pChainRing->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle);
	}
	if(eChainId == HAND_CHAIN_ID::E_CHAIN_PINKY)
	{
		//pinky
		CKinematicChain* pChainPinky =m_arChain[4];		
		/*abd*/arSensorData[glv_pinkieAbduction] = DegreeToRadian(pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle + pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexProx*/arSensorData[glv_pinkieMPJ] = DegreeToRadian(pChainPinky->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle);
		/*flexMid*/arSensorData[glv_pinkiePIJ] = DegreeToRadian(pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle);
		/*flexDist*/arSensorData[glv_pinkieDIJ] = DegreeToRadian(pChainPinky->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle);
	}
}
void CKinematicHandRight::UpdateToSensorData(std::vector<float>& arSensorData)
{
	UpdateFingerToSensorData(HAND_CHAIN_ID::E_CHAIN_THUMB, arSensorData);
	UpdateFingerToSensorData(HAND_CHAIN_ID::E_CHAIN_INDEX, arSensorData);
	UpdateFingerToSensorData(HAND_CHAIN_ID::E_CHAIN_MID, arSensorData);
	UpdateFingerToSensorData(HAND_CHAIN_ID::E_CHAIN_RING, arSensorData);
	UpdateFingerToSensorData(HAND_CHAIN_ID::E_CHAIN_PINKY, arSensorData);	
}
