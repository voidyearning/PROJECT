// ConstraintTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ConstraintTestDlg.h"
#include "..\Resource.h"


// CConstraintTestDlg dialog

IMPLEMENT_DYNAMIC(CConstraintTestDlg, CDialog)

CConstraintTestDlg::CConstraintTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConstraintTestDlg::IDD, pParent)
{

}

CConstraintTestDlg::~CConstraintTestDlg()
{
}

void CConstraintTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CConstraintTestDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CConstraintTestDlg::OnBnClickedButtonReset)
	ON_BN_CLICKED(IDC_BUTTON_REACH_GOAL, &CConstraintTestDlg::OnBnClickedButtonReachGoal)
	ON_EN_CHANGE(IDC_EDIT_GOAL, &CConstraintTestDlg::OnEnChangeEditGoal)
	ON_EN_CHANGE(IDC_EDIT_FLEX_DISTAL_W, &CConstraintTestDlg::OnEnChangeEditFlexDistalW)
	ON_EN_CHANGE(IDC_EDIT_FLEX_MID_W, &CConstraintTestDlg::OnEnChangeEditFlexMidW)
	ON_EN_CHANGE(IDC_EDIT_FLEX_PROX_W, &CConstraintTestDlg::OnEnChangeEditFlexProxW)
	ON_EN_CHANGE(IDC_EDIT_ABD_PROX_W, &CConstraintTestDlg::OnEnChangeEditAbdProxW)
	ON_EN_CHANGE(IDC_EDIT_ABD_ROOT_W, &CConstraintTestDlg::OnEnChangeEditAbdRootW)
	ON_EN_CHANGE(IDC_EDIT_FLEX_ROOT_W, &CConstraintTestDlg::OnEnChangeEditFlexRootW)
	ON_EN_CHANGE(IDC_EDIT_FLEX_ROOT_C, &CConstraintTestDlg::OnEnChangeEditFlexRootC)
	ON_EN_CHANGE(IDC_EDIT_ABD_ROOT_C, &CConstraintTestDlg::OnEnChangeEditAbdRootC)
	ON_EN_CHANGE(IDC_EDIT_ABD_PROX_C, &CConstraintTestDlg::OnEnChangeEditAbdProxC)
	ON_EN_CHANGE(IDC_EDIT_FLEX_PROX_C, &CConstraintTestDlg::OnEnChangeEditFlexProxC)
	ON_EN_CHANGE(IDC_EDIT_FLEX_MID_C, &CConstraintTestDlg::OnEnChangeEditFlexMidC)
	ON_EN_CHANGE(IDC_EDIT_FLEX_DISTAL_C, &CConstraintTestDlg::OnEnChangeEditFlexDistalC)
END_MESSAGE_MAP()

BOOL CConstraintTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	//opengl wnd
	CRect rcOpenGLNoConstraints;
	::GetClientRect(GetDlgItem(IDC_STATIC_NO_CONSTRAINTS)->m_hWnd, rcOpenGLNoConstraints);
	m_wndOpenGLNoConstraints.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcOpenGLNoConstraints, this, 0);   
	m_wndOpenGLNoConstraints.m_bLightOn = true;
	m_wndOpenGLNoConstraints.m_bShowOrigin = true;

	CRect rcOpenGLWeightConstraints;
	::GetClientRect(GetDlgItem(IDC_STATIC_WEIGHT_CONSTRAINTS)->m_hWnd, rcOpenGLWeightConstraints);
	rcOpenGLWeightConstraints.OffsetRect(rcOpenGLNoConstraints.right, 0);
	m_wndOpenGLWeightConstraints.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcOpenGLWeightConstraints, this, 0);   
	m_wndOpenGLWeightConstraints.m_bLightOn = true;
	m_wndOpenGLWeightConstraints.m_bShowOrigin = true;

	CRect rcOpenGLRangeConstraints;
	::GetClientRect(GetDlgItem(IDC_STATIC_RANGE_CONSTRAINTS)->m_hWnd, rcOpenGLRangeConstraints);
	rcOpenGLRangeConstraints.OffsetRect(0, rcOpenGLNoConstraints.bottom);
	m_wndOpenGLRangeConstraints.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcOpenGLRangeConstraints, this, 0);   
	m_wndOpenGLRangeConstraints.m_bLightOn = true;
	m_wndOpenGLRangeConstraints.m_bShowOrigin = true;

	CreateChain();

	//initial value of constraints
	GetDlgItem(IDC_EDIT_GOAL)->SetWindowTextW(L"(9, -5, 5)");
	
	GetDlgItem(IDC_EDIT_FLEX_ROOT_W)->SetWindowTextW(L"0.1");
	GetDlgItem(IDC_EDIT_FLEX_ROOT_C)->SetWindowTextW(L"(1,-15,-15)");

	GetDlgItem(IDC_EDIT_ABD_ROOT_W)->SetWindowTextW(L"0.1");	
	GetDlgItem(IDC_EDIT_ABD_ROOT_C)->SetWindowTextW(L"(1,0,0)");

	GetDlgItem(IDC_EDIT_ABD_PROX_W)->SetWindowTextW(L"1");
	GetDlgItem(IDC_EDIT_ABD_PROX_C)->SetWindowTextW(L"(1,0,20)");

	GetDlgItem(IDC_EDIT_FLEX_PROX_W)->SetWindowTextW(L"1");
	GetDlgItem(IDC_EDIT_FLEX_PROX_C)->SetWindowTextW(L"(1,-100,10)");

	GetDlgItem(IDC_EDIT_FLEX_MID_W)->SetWindowTextW(L"1");
	GetDlgItem(IDC_EDIT_FLEX_MID_C)->SetWindowTextW(L"(1,-100,5)");

	GetDlgItem(IDC_EDIT_FLEX_DISTAL_W)->SetWindowTextW(L"1");
	GetDlgItem(IDC_EDIT_FLEX_DISTAL_C)->SetWindowTextW(L"(1,-90,0)");

	return TRUE;  // return TRUE  unless you set the focus to a control
}
void CConstraintTestDlg::CreateChain()
{
	m_pChainNoConstraints = new CKinematicChain((CKinematicPos(0, 0, 0)));
		
	//joint
	CKinematicJoint* pFingerRoot = new CKinematicJoint(CKinematicPos(0, 0, 0));
	pFingerRoot->m_pParentChain = m_pChainNoConstraints;
	CKinematicJoint* pFingerProximal = new CKinematicJoint(CKinematicPos(7.2, 0, 0));
	pFingerProximal->m_pParentChain = m_pChainNoConstraints;
	CKinematicJoint* pFingerMid = new CKinematicJoint(CKinematicPos(4.5, 0, 0));
	pFingerMid->m_pParentChain = m_pChainNoConstraints;	
	CKinematicJoint* pFingerDistal = new CKinematicJoint(CKinematicPos(2.6, 0, 0));
	pFingerDistal->m_pParentChain = m_pChainNoConstraints;
	CKinematicJoint* pFingerEndEffector = new CKinematicJoint(CKinematicPos(2.2, 0, 0));
	pFingerEndEffector->m_pParentChain = m_pChainNoConstraints;
	m_pChainNoConstraints->m_arJoint.push_back(pFingerRoot);
	m_pChainNoConstraints->m_arJoint.push_back(pFingerProximal);
	m_pChainNoConstraints->m_arJoint.push_back(pFingerMid);
	m_pChainNoConstraints->m_arJoint.push_back(pFingerDistal);
	m_pChainNoConstraints->m_arJoint.push_back(pFingerEndEffector);

	//dof palm
	CKinematicDOF* pFingerPalmAbd = new CKinematicDOF(-15, CKinematicVec3D(0, 1, 0));	
	pFingerPalmAbd->m_pParentJoint = pFingerRoot;
	CKinematicDOF* pFingerPalmFlex = new CKinematicDOF(0, CKinematicVec3D(0, 0, 1));
	pFingerPalmFlex->m_pParentJoint = pFingerRoot;
	pFingerRoot->m_arDOF.push_back(pFingerPalmAbd);
	pFingerRoot->m_arDOF.push_back(pFingerPalmFlex);
	
	CKinematicDOF* pFingerProximalAbd = new CKinematicDOF(15, CKinematicVec3D(0, 1, 0));
	pFingerProximalAbd->m_pParentJoint = pFingerProximal;
	CKinematicDOF* pFingerProximalFlex = new CKinematicDOF(-15, CKinematicVec3D(0, 0, 1));
	pFingerProximalFlex->m_pParentJoint = pFingerProximal;
	pFingerProximal->m_arDOF.push_back(pFingerProximalAbd);
	pFingerProximal->m_arDOF.push_back(pFingerProximalFlex);

	CKinematicDOF* pFingerMidFlex = new CKinematicDOF(-15, CKinematicVec3D(0, 0, 1));
	pFingerMidFlex->m_pParentJoint = pFingerMid;
	pFingerMid->m_arDOF.push_back(pFingerMidFlex);

	CKinematicDOF* pFingerDistalFlex = new CKinematicDOF(-15, CKinematicVec3D(0, 0, 1));
	pFingerDistalFlex->m_pParentJoint = pFingerDistal;
	pFingerDistal->m_arDOF.push_back(pFingerDistalFlex);	

	//renderer
	m_pChainRendererNoConstraints = new CKinematicChainRenderer(m_pChainNoConstraints);
	this->m_wndOpenGLNoConstraints.SetRender((COpenGLRenderer*)m_pChainRendererNoConstraints);
	
	m_pChainNoConstraints->PopulateGlobalPosAndAxis();

	m_pChainWeightConstraints = CKinematicChain::CloneNew(*m_pChainNoConstraints);
	m_pChainRendererWeightConstraints = new CKinematicChainRenderer(m_pChainWeightConstraints);
	this->m_wndOpenGLWeightConstraints.SetRender((COpenGLRenderer*)m_pChainRendererWeightConstraints);

	m_pChainRangeConstraints = CKinematicChain::CloneNew(*m_pChainNoConstraints);
	m_pChainRendererRangeConstraints = new CKinematicChainRenderer(m_pChainRangeConstraints);
	this->m_wndOpenGLRangeConstraints.SetRender((COpenGLRenderer*)m_pChainRendererRangeConstraints);
}
void CConstraintTestDlg::ResetChain(CKinematicChain* pChain)
{
	//root
	pChain->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	pChain->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	//proximal
	pChain->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	pChain->m_arJoint[1]->m_arDOF[1]->m_dLocalRotationAngle = -30;
	//mid
	pChain->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	//distal
	pChain->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	pChain->PopulateGlobalPosAndAxis();
}
// CConstraintTestDlg message handlers

void CConstraintTestDlg::OnBnClickedButtonReset()
{
	ResetChain(m_pChainNoConstraints);
	ResetChain(m_pChainWeightConstraints);
	ResetChain(m_pChainRangeConstraints);

	m_wndOpenGLNoConstraints.Invalidate(1);
	m_wndOpenGLWeightConstraints.Invalidate(1);
	m_wndOpenGLRangeConstraints.Invalidate(1);
}

void CConstraintTestDlg::OnBnClickedButtonReachGoal()
{
	m_pChainNoConstraints->SolveToReach(m_posGoal);
	m_pChainWeightConstraints->SolveToReachWithWeightConstraints(m_posGoal);
	m_pChainRangeConstraints->SolveToReachWithRangeConstraints(m_posGoal);

	m_wndOpenGLNoConstraints.Invalidate(1);
	m_wndOpenGLWeightConstraints.Invalidate(1);
	m_wndOpenGLRangeConstraints.Invalidate(1);
}

void CConstraintTestDlg::OnEnChangeEditGoal()
{
	CString strGoal;
	GetDlgItem(IDC_EDIT_GOAL)->GetWindowText(strGoal);
	m_posGoal = CKinematicPos(strGoal.GetBuffer());

	m_pChainNoConstraints->m_posGoal = m_posGoal;
	m_pChainWeightConstraints->m_posGoal = m_posGoal;
	m_pChainRangeConstraints->m_posGoal = m_posGoal;

	m_wndOpenGLNoConstraints.Invalidate(1);
	m_wndOpenGLWeightConstraints.Invalidate(1);
	m_wndOpenGLRangeConstraints.Invalidate(1);
}


void CConstraintTestDlg::OnEnChangeEditFlexDistalW()
{
	CString strW;
	GetDlgItem(IDC_EDIT_FLEX_DISTAL_W)->GetWindowText(strW);
	m_pChainWeightConstraints->m_arJoint[3]->m_arDOF[0]->m_dWeight = _wtof(strW.GetBuffer());
}

void CConstraintTestDlg::OnEnChangeEditFlexMidW()
{
	CString strW;
	GetDlgItem(IDC_EDIT_FLEX_MID_W)->GetWindowText(strW);
	m_pChainWeightConstraints->m_arJoint[2]->m_arDOF[0]->m_dWeight = _wtof(strW.GetBuffer());
}

void CConstraintTestDlg::OnEnChangeEditFlexProxW()
{
	CString strW;
	GetDlgItem(IDC_EDIT_FLEX_PROX_W)->GetWindowText(strW);
	m_pChainWeightConstraints->m_arJoint[1]->m_arDOF[0]->m_dWeight = _wtof(strW.GetBuffer());
}

void CConstraintTestDlg::OnEnChangeEditAbdProxW()
{
	CString strW;
	GetDlgItem(IDC_EDIT_ABD_PROX_W)->GetWindowText(strW);
	m_pChainWeightConstraints->m_arJoint[1]->m_arDOF[1]->m_dWeight = _wtof(strW.GetBuffer());
}

void CConstraintTestDlg::OnEnChangeEditAbdRootW()
{
	CString strW;
	GetDlgItem(IDC_EDIT_ABD_ROOT_W)->GetWindowText(strW);
	m_pChainWeightConstraints->m_arJoint[0]->m_arDOF[1]->m_dWeight = _wtof(strW.GetBuffer());
}

void CConstraintTestDlg::OnEnChangeEditFlexRootW()
{
	CString strW;
	GetDlgItem(IDC_EDIT_FLEX_ROOT_W)->GetWindowText(strW);
	m_pChainWeightConstraints->m_arJoint[0]->m_arDOF[0]->m_dWeight = _wtof(strW.GetBuffer());
}

void CConstraintTestDlg::OnEnChangeEditFlexRootC()
{	
	CString strConstraints;
	GetDlgItem(IDC_EDIT_FLEX_ROOT_C)->GetWindowText(strConstraints);
	m_pChainRangeConstraints->m_arJoint[0]->m_arDOF[0]->m_vecConstraints = CKinematicVec3D(strConstraints.GetBuffer());
}

void CConstraintTestDlg::OnEnChangeEditAbdRootC()
{
	CString strConstraints;
	GetDlgItem(IDC_EDIT_ABD_ROOT_C)->GetWindowText(strConstraints);
	m_pChainRangeConstraints->m_arJoint[0]->m_arDOF[1]->m_vecConstraints = CKinematicVec3D(strConstraints.GetBuffer());
}

void CConstraintTestDlg::OnEnChangeEditAbdProxC()
{
	CString strConstraints;
	GetDlgItem(IDC_EDIT_ABD_PROX_C)->GetWindowText(strConstraints);
	m_pChainRangeConstraints->m_arJoint[1]->m_arDOF[0]->m_vecConstraints = CKinematicVec3D(strConstraints.GetBuffer());
}

void CConstraintTestDlg::OnEnChangeEditFlexProxC()
{
	CString strConstraints;
	GetDlgItem(IDC_EDIT_FLEX_PROX_C)->GetWindowText(strConstraints);
	m_pChainRangeConstraints->m_arJoint[1]->m_arDOF[1]->m_vecConstraints = CKinematicVec3D(strConstraints.GetBuffer());
}

void CConstraintTestDlg::OnEnChangeEditFlexMidC()
{
	CString strConstraints;
	GetDlgItem(IDC_EDIT_FLEX_MID_C)->GetWindowText(strConstraints);
	m_pChainRangeConstraints->m_arJoint[2]->m_arDOF[0]->m_vecConstraints = CKinematicVec3D(strConstraints.GetBuffer());
}

void CConstraintTestDlg::OnEnChangeEditFlexDistalC()
{
	CString strConstraints;
	GetDlgItem(IDC_EDIT_FLEX_DISTAL_C)->GetWindowText(strConstraints);
	m_pChainRangeConstraints->m_arJoint[3]->m_arDOF[0]->m_vecConstraints = CKinematicVec3D(strConstraints.GetBuffer());
}
