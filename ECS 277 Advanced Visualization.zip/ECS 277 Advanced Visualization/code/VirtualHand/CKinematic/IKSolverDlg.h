// IKSolverDlg.h : header file
//

#pragma once
#include "..\OpenGLWnd.h"
#include "TreeList.h"
#include "..\Resource.h"
#include "CKinematicChain.h"
#include "CRenderer.h"
#include "CKinematicHand.h"
#include <vector>

class CIKSolverDlg2;
class CIKSolverRenderer : public COpenGLRenderer
{
public:
	CIKSolverDlg2* m_pDlg;
	CKinematicPos m_posGoalActive;

	CIKSolverRenderer(CIKSolverDlg2* pDlg);
	virtual void Render();
};
#pragma once


// CIKSolverDlg2 dialog

class CIKSolverDlg2 : public CDialog
{
	DECLARE_DYNAMIC(CIKSolverDlg2)

public:
	CIKSolverDlg2(CWnd* pParent = NULL);   // standard constructor
	CIKSolverDlg2(CKinematicHand* pHand, CWnd* pParent = NULL);
	virtual ~CIKSolverDlg2();

// Dialog Data
	enum { IDD = IDD_IKSOLVER_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

	public:
	COpenGLWnd m_wndOpenGL;
	CKinematicChain* m_pFingerChain;
	CKinematicChainRenderer* m_pFingerChainRenderer;
	CKinematicHand* m_pHand;
	CKinematicHandRenderer* m_pHandRenderer;
	CIKSolverRenderer* m_pIKSolverRenderer;
	std::vector<float> m_arInitialKinData;

	std::vector<NODE_HANDLE> m_arHandle;
	//hand with rigid palm
	void BuildTreeForPalmRigidHand();
	static BOOL _stdcall ValidateTreeEditRequestForPalmRigidHand(const TREELIST_HANDLE TreeListHandle,const void *pAnyPtr, const char *NewData,char *Override);
	static NODE_HANDLE TreeListAddItemForPalmRigidHand(TREELIST_HANDLE hListTreeHandle, NODE_HANDLE hParentHandle, void *pID, char* strName, CKinematicDOF* pDOF, CKinematicJoint* pJoint, CKinematicChain* pChain);
	void SetFlatForPalmRigidHand();
	void SetFistForPalmRigidHand();
	void SetSpreadForPalmRigidHand();
	void TreeListInvalidateForPalmRigidHand();
	void TreeListUpdateItemForPalmRigidHand(TREELIST_HANDLE hListTreeHandle, NODE_HANDLE hNodeHandle, char* strName, CKinematicDOF* pDOF, CKinematicJoint* pJoint, CKinematicChain* pChain);

	//kinematic hand
	void BuildTreeForKinematicHand();
	static BOOL _stdcall ValidateTreeEditRequestForKinematicHand(const TREELIST_HANDLE TreeListHandle,const void *pAnyPtr, const char *NewData,char *Override);
	static NODE_HANDLE TreeListAddItemForKinematicHand(TREELIST_HANDLE hListTreeHandle, NODE_HANDLE hParentHandle, void *pID, char* strName, CKinematicDOF* pDOF, CKinematicJoint* pJoint, CKinematicChain* pChain);
	void SetFlatForKinematicHand();
	void SetFistForKinematicHand();
	void SetSpreadForKinematicHand();
	void TreeListInvalidateForKinematicHand();
	void TreeListUpdateItemForKinematicHand(TREELIST_HANDLE hListTreeHandle, NODE_HANDLE hNodeHandle, char* strName, CKinematicDOF* pDOF, CKinematicJoint* pJoint, CKinematicChain* pChain);
	
	//
	void TestChain();
	void TestHand();
	void FKUpdate(int iChainID = -1);

	//
	enum KINEMATIC_CONSTRAINTS{eNone, eWeight, eRange, eCombined, eDLSConstrained, eDLSConstrainedFromPalm} m_eConstraints;

	afx_msg void OnBnClickedButtonSolve();
	afx_msg void OnBnClickedButtonReset();
	afx_msg void OnBnClickedButtonTestGoal();
	afx_msg void OnBnClickedButtonTestLoop();
	afx_msg void OnBnClickedButtonTestFlat();
	afx_msg void OnBnClickedButtonTestFist();
	afx_msg void OnBnClickedButtonTestSpread();
	afx_msg void OnBnClickedButtonResetGoal();
	afx_msg void OnBnClickedButtonConstraintTest();
	afx_msg void OnBnClickedRadioNoConstraints();
	afx_msg void OnBnClickedRadioWeightConstraints();
	afx_msg void OnBnClickedRadioRangeConstraints();
	afx_msg void OnBnClickedRadioCombinedConstraints();
	afx_msg void OnBnClickedButtonTouch();
	afx_msg void OnBnClickedButtonPopulate();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedTestPosProb();
	afx_msg void OnBnClickedRadioDls();
	afx_msg void OnBnClickedRadioDlsFromPalm();
	afx_msg void OnStnClickedStaticOpengl();
};
