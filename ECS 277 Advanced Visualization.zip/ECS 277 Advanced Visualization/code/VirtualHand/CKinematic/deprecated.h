#include "CKinematicHand.h"
class CKinematicHandRigidPalmLeft : public CKinematicHand
{
public:
	CKinematicHandRigidPalmLeft();
	
	virtual void ConstructHand();
	virtual void DestructHand();
	virtual void Reset();

	virtual void LoadHandSize(string strPath);
	virtual void LoadHandPose(string strPath);
	virtual void Render();

	virtual CKinematicChain* GetChain(enum HAND_CHAIN_ID);
	virtual CKinematicJoint* GetJoint(enum HAND_JOINT_ID);
	virtual CKinematicDOF* GetDOF(enum HAND_JOINT_ID, enum HAND_DOF_ID);
	
	void SetDefaultPose();
	void SetFlatPose();
	void SetFistPose();
	void SetSpreadPose();
};

class CKinematicHandRigidPalmRight : public CKinematicHand
{

};

