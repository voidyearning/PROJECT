#pragma once
#include <vector>
#include "BaseAnimation.h"

class CGloveBvhRetarget;
class CGloveBvhInsert;

enum CLIP_TYPE
{
	GLV = 0, 
	BVH,
	KIN
};
class CGlvStructre
{	
public:
	static const int glv_thumbTMJ = 0;
	static const int glv_thumbMPJ = 1;
	static const int glv_thumbIJ = 2;
	static const int glv_thumbAbduction = 3;
	static const int glv_indexMPJ = 4;
	static const int glv_indexPIJ = 5;
	static const int glv_indexDIJ = 6;
	static const int glv_indexAbduction = 7;
	static const int glv_middleMPJ = 8;
	static const int glv_middlePIJ = 9;
	static const int glv_middleDIJ = 10;
	static const int glv_middleAbudction = 11;
	static const int glv_ringMPJ = 12;
	static const int glv_ringPIJ = 13;
	static const int glv_ringDIJ = 14;
	static const int glv_ringAbduction = 15;
	static const int glv_pinkieMPJ = 16;
	static const int glv_pinkiePIJ = 17;
	static const int glv_pinkieDIJ = 18;
	static const int glv_pinkieAbduction = 19;
	static const int glv_palmArch = 20;
	static const int glv_wristPitch = 21;
	static const int glv_wristYaw = 22;

	int GetDataSize();
	char* GetDataNameAt(int idxData);
};
class CGlvFrame : public CBaseFrame
{
public:
	CGlvFrame();
	CGlvFrame(const std::vector<float>& arData);
	bool operator == (const CGlvFrame& frame);

	static CGlvFrame GetEmptyFrame();	
	void LoadFromFile(std::string strPath);
	void SaveToFile(std::string strPath);

	void LoadFromFileRadian(std::string strPath);
	void LoadFromFileAngle(std::string strPath);	
	void SaveToFileRadian(std::string strPath);
	void SaveToFileAngle(std::string strPath);

	void ZeroWristRotations();

	void ToRadian();
	void ToDegree();

	char* ToBvh();
public:
	float m_fTime;
};

class CGlvClip : public CBaseClip
{
public:
	CGlvClip();
	virtual CGlvFrame GetAveragePose();

	void SaveToFile(std::string strPath);
	void LoadFromFile(std::string strPath);	
	int GetFrameCount();
	CBaseFrame* GetFrameAt(int iFrmIdx);
	void SetFrameAt(int iFrmIdx, CBaseFrame*);
	CGlvFrame GetFrameAt(float time);

	void Resample(float fNewIntervalTime);	
	CGlvFrame InterpolateLinear(CGlvFrame frameBeg, CGlvFrame frameEnd, float curTime);

	void SaveToBvh(std::string strOutputFile);
	
	std::vector<CGlvFrame> m_arFrame;
	float m_fBaseTime;//time are in seconds
	float m_fIntervalTime; 

	virtual CBaseClip* GetSubClip(int iBegIdx, int iEndIdx);
	void ZeroWristRotations();
	void ToRadian();
	void ToDegree();
	void ToGlvData(std::string strPath);

	std::vector<float> GetTimeArray();

	//testing
	virtual STATIC_GAPS FindUnchaningData(int iConsecutiveThreshold = 3);
};



