// WokaoWnd.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "WokaoWnd.h"


// CWokaoWnd dialog

IMPLEMENT_DYNAMIC(CWokaoWnd, CWnd)

CWokaoWnd::CWokaoWnd(CWnd* pParent /*=NULL*/)
: CDialog()
{

}

CWokaoWnd::~CWokaoWnd()
{
}

BEGIN_MESSAGE_MAP(CWokaoWnd, CDialog)
	ON_BN_CLICKED(IDCANCEL, &CWokaoWnd::OnBnClickedCancel)
END_MESSAGE_MAP()


// CWokaoWnd message handlers

void CWokaoWnd::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
}
