#pragma once
#include "GloveMocapMgr.h"
#include "OpenGLWnd.h"
#include "resource.h"
#include "GloveRenderer.h"
#include "GloveCalibration.h"
#include "GloveAnimation.h"
#include "GloveSkeleton.h"

// CGloveCalibDlg dialog
enum E_CALIB_MODE
{
	e_uncalibrated_raw = 0, 
	e_linear_calib_vc,
	e_linear_calib_matlab,
	e_gpr_calib_fitc_matlab
};

#define TIMER_EVENT_ID3	3
class CGloveCalibDlg : public CDialog
{
public:
	CGloveCalibDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGloveCalibDlg();	
	virtual BOOL OnInitDialog();
	void WriteCalibrationToMgr(CGloveCalibration calibration);	
	void InitGainAndOffsetUI();
	void UpdateEditsFromCalibration();
	void UpdateCalibrationFromEdits(int iIndex, CString strValue, bool bGain);

public:
	COpenGLWnd m_wndOpenGLMainLeft;
	COpenGLWnd m_wndOpenGLMainRight;
	COpenGLWnd m_wndOpenGLCap;
	COpenGLWnd m_wndOpenGLReal;

	COpenGLHandRendererKin* m_pHandRendererLeft;
	COpenGLHandRendererKin* m_pHandRendererRight;
	COpenGLHandRendererKin* m_pHandRendererCap;
	COpenGLHandRendererKin* m_pHandRendererReal;

	//KinematicHand
	CHandSkeletonKin* m_pHandLeft;
	CHandSkeletonKin* m_pHandRight;

	CGloveMocapMgr* m_pGlvMgrLeft;
	CGloveMocapMgr* m_pGlvMgrRight;

	GLV_MOCAP_HANDNESS m_eAdjustHandness;
	CGloveCalibration* m_pGlvCalib;

	CGlvFrame m_frmCap1;
	CGlvFrame m_frmCap2;
	CGlvFrame m_frmReal1;
	CGlvFrame m_frmReal2;

	std::vector<CEdit*> m_arGainEdit;
	std::vector<CEdit*> m_arOffsetEdit;
	std::vector<CStatic*> m_arInfoStatic;
	bool m_bShowRadian;

	E_CALIB_MODE m_eCalibMode;

// Dialog Data
	enum { IDD = IDD_GLOVECALIB_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedConnect();
	afx_msg void OnBnClickedBtnDisconnect();
	afx_msg void OnBnClickedRadioRighthand();
	afx_msg void OnBnClickedRadioLefthand();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonReset();
	afx_msg void OnBnClickedButtonCap1();
	afx_msg void OnBnClickedButtonReal1();
	afx_msg void OnBnClickedButtonCap2();
	afx_msg void OnBnClickedButtonReal2();
	afx_msg void OnBnClickedButtonAutocalib();
	afx_msg void OnEnChangeEditThumbTmjG();
	afx_msg void OnEnChangeEditThumbTmjO();
	afx_msg void OnEnChangeEditThumbMpjG();
	afx_msg void OnEnChangeEditThumbMpjO();
	afx_msg void OnEnChangeEditThumbIjG();
	afx_msg void OnEnChangeEditThumbIjO();
	afx_msg void OnEnChangeEditThumbAbdG();
	afx_msg void OnEnChangeEditThumbAbdO();
	afx_msg void OnEnChangeEditIndexMpjG();
	afx_msg void OnEnChangeEditIndexMpjO();
	afx_msg void OnEnChangeEditIndexPijG();
	afx_msg void OnEnChangeEditIndexPijO();
	afx_msg void OnEnChangeEditIndexDijG();
	afx_msg void OnEnChangeEditIndexDijO();
	afx_msg void OnEnChangeEditIndexAbdG();
	afx_msg void OnEnChangeEditIndexAbdO();
	afx_msg void OnEnChangeEditMiddleMpjG();
	afx_msg void OnEnChangeEditMiddleMpjO();
	afx_msg void OnEnChangeEditMiddlePijG();
	afx_msg void OnEnChangeEditMiddlePijO();
	afx_msg void OnEnChangeEditMiddleDijG();
	afx_msg void OnEnChangeEditMiddleDijO();
	afx_msg void OnEnChangeEditMiddleAbdG();
	afx_msg void OnEnChangeEditMiddleAbdO();
	afx_msg void OnEnChangeEditRingMpjG();
	afx_msg void OnEnChangeEditRingMpjO();
	afx_msg void OnEnChangeEditRingPijG();
	afx_msg void OnEnChangeEditRingPijO();
	afx_msg void OnEnChangeEditRingDijG();
	afx_msg void OnEnChangeEditRingDijO();
	afx_msg void OnEnChangeEditRingAbdG();
	afx_msg void OnEnChangeEditRingAbdO();
	afx_msg void OnEnChangeEditPinkyMpjG();
	afx_msg void OnEnChangeEditPinkyMpjO();
	afx_msg void OnEnChangeEditPinkyPijG();
	afx_msg void OnEnChangeEditPinkyPijO();
	afx_msg void OnEnChangeEditPinkyDijG();
	afx_msg void OnEnChangeEditPinkyDijO();
	afx_msg void OnEnChangeEditPinkyAbdG();
	afx_msg void OnEnChangeEditPinkyAbdO();
	afx_msg void OnStnClickedStaticMainLeft();
	afx_msg void OnStnClickedStaticMainRight();
	afx_msg void OnStnClickedStaticCap();
	afx_msg void OnStnClickedStaticReal();
	afx_msg void OnBnClickedButtonLoadCalib();
	afx_msg void OnBnClickedButtonSaveCalib();
	afx_msg void OnBnClickedButtonLoadHandsize();
	afx_msg void OnBnClickedButtonSaveHandsize();
	afx_msg void OnEnChangeEditPalmArcG();
	afx_msg void OnEnChangeEditPalmArcO();
	afx_msg void OnEnChangeEditPalmFlexG();
	afx_msg void OnEnChangeEditPalmFlexO();
	afx_msg void OnEnChangeEditPalmAbdG();
	afx_msg void OnEnChangeEditPalmAbdO();
	afx_msg void OnBnClickedRadioRadian();
	afx_msg void OnBnClickedRadioDegree();
	afx_msg void OnBnClickedButtonKinProp();
	afx_msg void OnBnClickedButtonLinearHp2Tr();
	afx_msg void OnBnClickedRadioUncalibRaw();
	afx_msg void OnBnClickedRadioLinearCalibVc();
	afx_msg void OnBnClickedRadioLinearCalibMatlab();
	afx_msg void OnBnClickedRadioGprCalibFitcMatlab2();
};
