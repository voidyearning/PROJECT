#include "stdafx.h"
#include "OpenGLWnd.h"
#include "GlovePlayDlg.h"
#include "GloveUtil.h"
#include "PtTrajAnimation.h"
#include "IKAnimation.h"

extern bool g_bHand;
extern bool g_bX;
extern bool g_bY;
extern bool g_bZ;


CGlovePlayDlg::CGlovePlayDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGlovePlayDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);	
	m_pMaxProbTrajRenderer = new CPtTrajRenderer();
	m_pCOMTrajRenderer = new CPtTrajRenderer();
	m_pHandRenderer = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_wndOpenGL.m_arTrajRenderer.push_back(m_pMaxProbTrajRenderer);
	m_wndOpenGL.m_arTrajRenderer.push_back(m_pCOMTrajRenderer);
	m_bCalibrateClip = false;
}
CGlovePlayDlg::~CGlovePlayDlg()
{
	if(m_pHandRenderer)
	{
		delete m_pHandRenderer->m_pHand;
		delete m_pHandRenderer;
	}
	delete m_pMaxProbTrajRenderer;
	delete m_pCOMTrajRenderer;
	for(int i = 0; i < m_arEndEffectorTrajRenderer.size(); ++i)
		delete m_arEndEffectorTrajRenderer[i];
}

void CGlovePlayDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CGlovePlayDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_TIMER()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CHECK_SHOW_ORIGIN, &CGlovePlayDlg::OnBnClickedCheckShowOrigin)
	ON_BN_CLICKED(IDC_CHECK_WIREFRAME, &CGlovePlayDlg::OnBnClickedCheckWireframe)
	ON_BN_CLICKED(IDC_BUTTON_SIZEFILE, &CGlovePlayDlg::OnBnClickedButtonSizefile)
	ON_BN_CLICKED(IDC_BUTTON_MOTIONFILE, &CGlovePlayDlg::OnBnClickedButtonMotionfile)
	ON_BN_CLICKED(IDC_CHECK_LIGHTING, &CGlovePlayDlg::OnBnClickedCheckLighting)
	ON_BN_CLICKED(IDC_RADIO_FRONT, &CGlovePlayDlg::OnBnClickedRadioFront)
	ON_BN_CLICKED(IDC_RADIO_LEFT, &CGlovePlayDlg::OnBnClickedRadioLeft)
	ON_BN_CLICKED(IDC_RADIO_TOP, &CGlovePlayDlg::OnBnClickedRadioTop)
	ON_BN_CLICKED(IDC_BUTTON_PLAY, &CGlovePlayDlg::OnBnClickedButtonPlay)
	ON_BN_CLICKED(IDC_BUTTON_BEGINNING, &CGlovePlayDlg::OnBnClickedButtonBeginning)
	ON_BN_CLICKED(IDC_BUTTON_BACKWARD, &CGlovePlayDlg::OnBnClickedButtonBackward)
	ON_BN_CLICKED(IDC_BUTTON_STOP, &CGlovePlayDlg::OnBnClickedButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_FORWARD, &CGlovePlayDlg::OnBnClickedButtonForward)
	ON_BN_CLICKED(IDC_BUTTON_ENDING, &CGlovePlayDlg::OnBnClickedButtonEnding)
	ON_EN_CHANGE(IDC_EDIT_FRAME, &CGlovePlayDlg::OnEnChangeEditFrame)
	ON_BN_CLICKED(IDC_CHECK_ORIGINAL_FPS, &CGlovePlayDlg::OnBnClickedCheckOriginalFps)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_FRAME, &CGlovePlayDlg::OnBnClickedButtonLoadFrame)
	ON_BN_CLICKED(IDC_RADIO_LEFTHAND, &CGlovePlayDlg::OnBnClickedRadioLefthand)
	ON_BN_CLICKED(IDC_RADIO_RIGHTHAND, &CGlovePlayDlg::OnBnClickedRadioRighthand)
	ON_BN_CLICKED(IDC_BUTTON_PLAY_TOUCH, &CGlovePlayDlg::OnBnClickedButtonPlayTouch)
	ON_BN_CLICKED(IDC_BUTTON_VIEW_AVE, &CGlovePlayDlg::OnBnClickedButtonViewAve)
	ON_BN_CLICKED(IDC_BUTTON_CUR_FRAME, &CGlovePlayDlg::OnBnClickedButtonCurFrame)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_MOTION, &CGlovePlayDlg::OnBnClickedButtonSaveMotion)
	ON_BN_CLICKED(IDC_CHECK_ACTIVE_THUMB, &CGlovePlayDlg::OnBnClickedCheckActiveThumb)
	ON_BN_CLICKED(IDC_CHECK_ACTIVE_INDEX, &CGlovePlayDlg::OnBnClickedCheckActiveIndex)
	ON_BN_CLICKED(IDC_CHECK_ACTIVE_MID, &CGlovePlayDlg::OnBnClickedCheckActiveMid)
	ON_BN_CLICKED(IDC_CHECK_ACTIVE_RING, &CGlovePlayDlg::OnBnClickedCheckActiveRing)
	ON_BN_CLICKED(IDC_CHECK_ACTIVE_PINKY, &CGlovePlayDlg::OnBnClickedCheckActivePinky)
	ON_BN_CLICKED(IDC_CHECK_SHOW_PROB, &CGlovePlayDlg::OnBnClickedCheckShowProb)
	ON_EN_CHANGE(IDC_EDIT_PROB_VALVE_MIN, &CGlovePlayDlg::OnEnChangeEditProbValveMin)
	ON_BN_CLICKED(IDC_CHECK_SHOW_HAND, &CGlovePlayDlg::OnBnClickedCheckShowHand)
	ON_EN_CHANGE(IDC_EDIT_RANGE_STEP_SIZE, &CGlovePlayDlg::OnEnChangeEditRangeStepSize)
	ON_BN_CLICKED(IDC_BUTTON_RECAL_PROB, &CGlovePlayDlg::OnBnClickedButtonRecalProb)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_PROB_FRAME, &CGlovePlayDlg::OnBnClickedButtonLoadProbFrame)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_PROB_FRAME, &CGlovePlayDlg::OnBnClickedButtonSaveProbFrame)
	ON_EN_CHANGE(IDC_EDIT_PROB_VALVE_MAX, &CGlovePlayDlg::OnEnChangeEditProbValveMax)
	ON_EN_CHANGE(IDC_EDIT_RENDER_RANGE_MIN, &CGlovePlayDlg::OnEnChangeEditRenderRangeMin)
	ON_EN_CHANGE(IDC_EDIT_RENDER_RANGE_MAX, &CGlovePlayDlg::OnEnChangeEditRenderRangeMax)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_PROB_SIZE, &CGlovePlayDlg::OnNMCustomdrawSliderProbSize)
	ON_BN_CLICKED(IDC_CHECK_RENDER_ORIGINAL_CALCULATED, &CGlovePlayDlg::OnBnClickedCheckRenderOriginalCalculated)
	ON_EN_CHANGE(IDC_EDIT_RENDER_VALVE, &CGlovePlayDlg::OnEnChangeEditRenderValve)
	ON_BN_CLICKED(IDC_CHECK_SHOW_END_TRAJ, &CGlovePlayDlg::OnBnClickedCheckShowEndTraj)
	ON_BN_CLICKED(IDC_CHECK_SHOW_MAX_PROB_TRAJ, &CGlovePlayDlg::OnBnClickedCheckShowMaxProbTraj)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_END_TRAJ_SIZE, &CGlovePlayDlg::OnNMCustomdrawSliderEndTrajSize)
	ON_EN_CHANGE(IDC_EDIT_COLOR_END_TRAJ, &CGlovePlayDlg::OnEnChangeEditColorEndTraj)
	ON_EN_CHANGE(IDC_EDIT_COLOR_MAX_PROB_TRAJ, &CGlovePlayDlg::OnEnChangeEditColorMaxProbTraj)
	ON_BN_CLICKED(IDC_CHECK_DISCRETE_END_TRAJ, &CGlovePlayDlg::OnBnClickedCheckDiscreteEndTraj)
	ON_BN_CLICKED(IDC_CHECK_DISCRETE_MAX_PROB_TRAJ, &CGlovePlayDlg::OnBnClickedCheckDiscreteMaxProbTraj)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_MAX_PROB_TRAJ_SIZE, &CGlovePlayDlg::OnNMCustomdrawSliderMaxProbTrajSize)
	ON_BN_CLICKED(IDC_BUTTON_RECAL_END_TRAJ, &CGlovePlayDlg::OnBnClickedButtonRecalEndTraj)
	ON_BN_CLICKED(IDC_BUTTON_RECAL_MAX_RPOB_TRAJ, &CGlovePlayDlg::OnBnClickedButtonRecalMaxRpobTraj)
	ON_EN_CHANGE(IDC_EDIT_TRAJ_BEG_IDX, &CGlovePlayDlg::OnEnChangeEditTrajBegIdx)
	ON_EN_CHANGE(IDC_EDIT_TRAJ_END_IDX, &CGlovePlayDlg::OnEnChangeEditTrajEndIdx)
	ON_BN_CLICKED(IDC_CHECK_SHOW_COM_TRAJ, &CGlovePlayDlg::OnBnClickedCheckShowComTraj)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_COM_TRAJ_SIZE, &CGlovePlayDlg::OnNMCustomdrawSliderComTrajSize)
	ON_EN_CHANGE(IDC_EDIT_COLOR_COM_TRAJ, &CGlovePlayDlg::OnEnChangeEditColorComTraj)
	ON_BN_CLICKED(IDC_CHECK_DISCRETE_COM_TRAJ, &CGlovePlayDlg::OnBnClickedCheckDiscreteComTraj)
	ON_BN_CLICKED(IDC_BUTTON_RECAL_COM_TRAJ, &CGlovePlayDlg::OnBnClickedButtonRecalComTraj)
	ON_EN_CHANGE(IDC_EDIT_LIGHT_POS, &CGlovePlayDlg::OnEnChangeEditLightPos)
	ON_EN_CHANGE(IDC_EDIT_THUMB_COLOR, &CGlovePlayDlg::OnEnChangeEditThumbColor)
	ON_EN_CHANGE(IDC_EDIT_INDEX_COLOR, &CGlovePlayDlg::OnEnChangeEditIndexColor)
	ON_EN_CHANGE(IDC_EDIT_MID_COLOR, &CGlovePlayDlg::OnEnChangeEditMidColor)
	ON_EN_CHANGE(IDC_EDIT_RING_COLOR, &CGlovePlayDlg::OnEnChangeEditRingColor)
	ON_EN_CHANGE(IDC_EDIT_PINKY_COLOR, &CGlovePlayDlg::OnEnChangeEditPinkyColor)
	ON_BN_CLICKED(IDC_BUTTON_CALIBRATE_FK_INDEPENDENT, &CGlovePlayDlg::OnBnClickedButtonCalibrateFkIndependent)
	ON_BN_CLICKED(IDC_CHECK_CALIBRATE_CLIP, &CGlovePlayDlg::OnBnClickedCheckCalibrateClip)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_POSE, &CGlovePlayDlg::OnBnClickedButtonSavePose)
	ON_BN_CLICKED(IDC_BUTTON_CALIBRATE_FK_FULL, &CGlovePlayDlg::OnBnClickedButtonCalibrateFkFull)
	ON_BN_CLICKED(IDC_BUTTON_CALIBRATE_FK_FITC, &CGlovePlayDlg::OnBnClickedButtonCalibrateFkFitc)
	ON_BN_CLICKED(IDC_BUTTON_CALIBRATE_FITC, &CGlovePlayDlg::OnBnClickedButtonCalibrateFitc)
	ON_BN_CLICKED(IDC_BUTTON_CALIBRATE_FULL, &CGlovePlayDlg::OnBnClickedButtonCalibrateFull)
	ON_BN_CLICKED(IDC_CHECK_THUMB_ROLL_ACTIVE, &CGlovePlayDlg::OnBnClickedCheckThumbRollActive)
	ON_BN_CLICKED(IDC_CHECK_THUMB_ABD_ACTIVE, &CGlovePlayDlg::OnBnClickedCheckThumbAbdActive)
	ON_BN_CLICKED(IDC_CHECK_THUMB_VIRTUAL_ACTIVE, &CGlovePlayDlg::OnBnClickedCheckThumbVirtualActive)
	ON_BN_CLICKED(IDC_CHECK_THUMB_INNER_FLEX_ACTIVE, &CGlovePlayDlg::OnBnClickedCheckThumbInnerFlexActive)
	ON_BN_CLICKED(IDC_CHECK_THUMB_DIST_FLEX_ACTIVE, &CGlovePlayDlg::OnBnClickedCheckThumbDistFlexActive)
	ON_BN_CLICKED(IDC_BUTTON_CALIBRATE_THUMB_FULL, &CGlovePlayDlg::OnBnClickedButtonCalibrateThumbFull)
	ON_BN_CLICKED(IDC_BUTTON_WATCH_DATA_REDUNDANT, &CGlovePlayDlg::OnBnClickedButtonWatchDataRedundant)
	ON_BN_CLICKED(IDC_BUTTON_REFRESH, &CGlovePlayDlg::OnBnClickedButtonRefresh)
	ON_BN_CLICKED(IDC_BUTTON_WATCH_DATA_NON_REDUNDANT, &CGlovePlayDlg::OnBnClickedButtonWatchDataNonRedundant)
	ON_BN_CLICKED(IDC_BUTTON_WATCH_ORDERED_BY_THUMB, &CGlovePlayDlg::OnBnClickedButtonWatchOrderedByThumb)
	ON_BN_CLICKED(IDC_BUTTON_CALIBRATE_FINGERABD_FULL, &CGlovePlayDlg::OnBnClickedButtonCalibrateFingerabdFull)
	ON_BN_CLICKED(IDC_BUTTON_FIND_CLOSE_INPUT, &CGlovePlayDlg::OnBnClickedButtonFindCloseInput)
	ON_BN_CLICKED(IDC_BUTTON_THUMB_COPY_PREV, &CGlovePlayDlg::OnBnClickedButtonThumbCopyPrev)
	ON_BN_CLICKED(IDC_BUTTON_NORMALIZE_WRIST, &CGlovePlayDlg::OnBnClickedButtonNormalizeWrist)
	ON_BN_CLICKED(IDC_BUTTON_ADD_OFFSET, &CGlovePlayDlg::OnBnClickedButtonAddOffset)
	ON_BN_CLICKED(IDC_BUTTON_COPY_THUMB_FROM, &CGlovePlayDlg::OnBnClickedButtonCopyThumbFrom)
	ON_BN_CLICKED(IDC_BUTTON_SUPPRESS_OVERBEND, &CGlovePlayDlg::OnBnClickedButtonSuppressOverbend)
	ON_BN_CLICKED(IDC_BUTTON_ITP, &CGlovePlayDlg::OnBnClickedButtonItp)
	ON_BN_CLICKED(IDC_BUTTON_MUL_COEF, &CGlovePlayDlg::OnBnClickedButtonMulCoef)
	ON_BN_CLICKED(IDC_CHECK_2Radian, &CGlovePlayDlg::OnBnClickedCheck2radian)
	ON_BN_CLICKED(IDC_BUTTON_EXPORT_TRJ, &CGlovePlayDlg::OnBnClickedButtonExportTrj)
	ON_BN_CLICKED(IDC_BUTTON_EXPORT_ROT, &CGlovePlayDlg::OnBnClickedButtonExportRot)
	ON_BN_CLICKED(IDC_BUTTON_EXPORT_FINGERTIP_DISTANCE, &CGlovePlayDlg::OnBnClickedButtonExportFingertipDistance)
	ON_BN_CLICKED(IDC_BUTTON_EXPORT_BVH, &CGlovePlayDlg::OnBnClickedButtonExportBvh)
	ON_BN_CLICKED(IDC_BUTTON_IMPORT_FRAMES_FROM, &CGlovePlayDlg::OnBnClickedButtonImportFramesFrom)
	ON_BN_CLICKED(IDC_BUTTON_CALIBRATE_FINGERFLEX_FULL, &CGlovePlayDlg::OnBnClickedButtonCalibrateFingerflexFull)
	ON_BN_CLICKED(IDC_BUTTON_CALIBRATE_FULL_SIMPLE, &CGlovePlayDlg::OnBnClickedButtonCalibrateFullSimple)
	ON_BN_CLICKED(IDC_BUTTON_CALIBRATE_FITC_SIMPLE, &CGlovePlayDlg::OnBnClickedButtonCalibrateFitcSimple)
	ON_BN_CLICKED(IDC_BUTTON_RESCALE, &CGlovePlayDlg::OnBnClickedButtonRescale)
	ON_BN_CLICKED(IDC_BUTTON_COPY_FROM, &CGlovePlayDlg::OnBnClickedButtonCopyFrom)
	ON_WM_KEYDOWN()
	END_MESSAGE_MAP()

BOOL CGlovePlayDlg::OnInitDialog()
{
	m_bPaused = true;
	m_bFPSOriginal = true;
	m_fFPS = 0;
	m_iCurFrameIdx = 0;
	CButton* pCheck = (CButton*)GetDlgItem(IDC_CHECK_SHOW_ORIGIN);
	pCheck->SetCheck(1);
	pCheck = (CButton*)GetDlgItem(IDC_CHECK_WIREFRAME);
	pCheck->SetCheck(1);
	pCheck = (CButton*)GetDlgItem(IDC_CHECK_LIGHTING);
	pCheck->SetCheck(1);

	GetDlgItem(IDC_EDIT_LIGHT_POS)->SetWindowText(L"(100, 100, 100)");
	GetDlgItem(IDC_BUTTON_BEGINNING)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_BACKWARD)->EnableWindow(FALSE);	
	GetDlgItem(IDC_BUTTON_PLAY)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_STOP)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_FORWARD)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_ENDING)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_FRAME)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_PLAY_FPS)->EnableWindow(FALSE);
	((CButton*)GetDlgItem(IDC_CHECK_SHOW_HAND))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_CHECK_ORIGINAL_FPS))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_CHECK_RENDER_ORIGINAL_CALCULATED))->SetCheck(1);
	GetDlgItem(IDC_CHECK_ORIGINAL_FPS)->EnableWindow(FALSE);
	CSliderCtrl* pSlider = (CSliderCtrl*)GetDlgItem(IDC_SLIDER_PROB_SIZE);
	pSlider->SetRange(0, 10);
	pSlider->SetPos(1);

	CString strPos;
	strPos.Format(L"(%.1f,%.1f,%.1f)", m_pHandRenderer->m_probRenderer.m_ptRenderRangeMin.m_fX, m_pHandRenderer->m_probRenderer.m_ptRenderRangeMin.m_fY, m_pHandRenderer->m_probRenderer.m_ptRenderRangeMin.m_fZ);
	GetDlgItem(IDC_EDIT_RENDER_RANGE_MIN)->SetWindowText(strPos);
	strPos.Format(L"(%.1f,%.1f,%.1f)", m_pHandRenderer->m_probRenderer.m_ptRenderRangeMax.m_fX, m_pHandRenderer->m_probRenderer.m_ptRenderRangeMax.m_fY, m_pHandRenderer->m_probRenderer.m_ptRenderRangeMax.m_fZ);
	GetDlgItem(IDC_EDIT_RENDER_RANGE_MAX)->SetWindowText(strPos);
	strPos.Format(L"(%.1f,%.1f,%.1f)", m_pHandRenderer->m_probRenderer.m_ptRenderRangeStep.m_fX, m_pHandRenderer->m_probRenderer.m_ptRenderRangeStep.m_fY, m_pHandRenderer->m_probRenderer.m_ptRenderRangeStep.m_fZ);
	GetDlgItem(IDC_EDIT_RANGE_STEP_SIZE)->SetWindowText(strPos);

	CString strValveRed;
	strValveRed.Format(L"%f", m_pHandRenderer->m_probRenderer.m_fProbColorMapRed);
	GetDlgItem(IDC_EDIT_PROB_VALVE_MIN)->SetWindowText(strValveRed);
	CString strValveBlue;
	strValveBlue.Format(L"%f", m_pHandRenderer->m_probRenderer.m_fProbColorMapBlue);
	GetDlgItem(IDC_EDIT_PROB_VALVE_MAX)->SetWindowText(strValveBlue);
	CString strRenderValve;
	strRenderValve.Format(L"%f", m_pHandRenderer->m_probRenderer.m_fRenderValve);
	GetDlgItem(IDC_EDIT_RENDER_VALVE)->SetWindowText(strRenderValve);

	//traj renderer
	((CButton*)GetDlgItem(IDC_CHECK_SHOW_END_TRAJ))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_CHECK_SHOW_MAX_PROB_TRAJ))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_CHECK_SHOW_COM_TRAJ))->SetCheck(0);

	pSlider = (CSliderCtrl*)GetDlgItem(IDC_SLIDER_END_TRAJ_SIZE);
	pSlider->SetRange(0, 10);
	pSlider->SetPos(1);
	pSlider = (CSliderCtrl*)GetDlgItem(IDC_SLIDER_MAX_PROB_TRAJ_SIZE);
	pSlider->SetRange(0, 10);
	pSlider->SetPos(1);
	pSlider = (CSliderCtrl*)GetDlgItem(IDC_SLIDER_COM_TRAJ_SIZE);
	pSlider->SetRange(0, 10);
	pSlider->SetPos(1);

	((CButton*)GetDlgItem(IDC_CHECK_DISCRETE_END_TRAJ))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_CHECK_DISCRETE_MAX_PROB_TRAJ))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_CHECK_DISCRETE_COM_TRAJ))->SetCheck(1);

	GetDlgItem(IDC_EDIT_COLOR_END_TRAJ)->SetWindowTextW(L"(255,255,255)");
	GetDlgItem(IDC_EDIT_COLOR_MAX_PROB_TRAJ)->SetWindowTextW(L"(255,0,0)");
	GetDlgItem(IDC_EDIT_COLOR_COM_TRAJ)->SetWindowTextW(L"(255,255,255)");

	GetDlgItem(IDC_EDIT_TRAJ_BEG_IDX)->SetWindowText(L"1");
	GetDlgItem(IDC_EDIT_TRAJ_END_IDX)->SetWindowText(L"100");

	CRect rect;
	::GetClientRect(GetDlgItem(IDC_STATIC_SIZE)->m_hWnd, rect);
	rect.InflateRect(-7,-7);

	m_wndOpenGL.Create(NULL,
						NULL,
						WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE,						       
						rect,  
						this,  
						0);  
	m_wndOpenGL.m_bShowOrigin = true;
	m_wndOpenGL.SetRender((COpenGLRenderer*)m_pHandRenderer);
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.OnDraw(NULL);

	//handness
	((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_RADIO_RIGHTHAND))->SetCheck(0);
	m_pHandRenderer->m_pHand->m_bRightHand = false;

	//must after creation of m_wndOpenGL
	GetDlgItem(IDC_EDIT_THUMB_COLOR)->SetWindowText(CString(m_pHandRenderer->m_clrThumb.ToString().c_str()));
	GetDlgItem(IDC_EDIT_INDEX_COLOR)->SetWindowText(CString(m_pHandRenderer->m_clrIndex.ToString().c_str()));
	GetDlgItem(IDC_EDIT_MID_COLOR)->SetWindowText(CString(m_pHandRenderer->m_clrMid.ToString().c_str()));
	GetDlgItem(IDC_EDIT_RING_COLOR)->SetWindowText(CString(m_pHandRenderer->m_clrRing.ToString().c_str()));
	GetDlgItem(IDC_EDIT_PINKY_COLOR)->SetWindowText(CString(m_pHandRenderer->m_clrPinky.ToString().c_str()));

	//dof active	
	((CButton*)GetDlgItem(IDC_CHECK_THUMB_ROLL_ACTIVE))->SetCheck(m_pHandRenderer->m_pHand->m_pHand->m_arChain[0]->GetDOFAt(0)->m_bActive);
	((CButton*)GetDlgItem(IDC_CHECK_THUMB_ABD_ACTIVE))->SetCheck(m_pHandRenderer->m_pHand->m_pHand->m_arChain[0]->GetDOFAt(1)->m_bActive);
	((CButton*)GetDlgItem(IDC_CHECK_THUMB_VIRTUAL_ACTIVE))->SetCheck(m_pHandRenderer->m_pHand->m_pHand->m_arChain[0]->GetDOFAt(2)->m_bActive);
	((CButton*)GetDlgItem(IDC_CHECK_THUMB_INNER_FLEX_ACTIVE))->SetCheck(m_pHandRenderer->m_pHand->m_pHand->m_arChain[0]->GetDOFAt(3)->m_bActive);
	((CButton*)GetDlgItem(IDC_CHECK_THUMB_DIST_FLEX_ACTIVE))->SetCheck(m_pHandRenderer->m_pHand->m_pHand->m_arChain[0]->GetDOFAt(4)->m_bActive);

	m_pClip = NULL;

	return TRUE;
}

void CGlovePlayDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}
HCURSOR CGlovePlayDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
void CGlovePlayDlg::OnEnChangeEditLightPos()
{
	CString strLightPos;
	GetDlgItem(IDC_EDIT_LIGHT_POS)->GetWindowText(strLightPos);
	CKinematicPoint ptLightPos(strLightPos.GetBuffer());
	m_wndOpenGL.m_dLightPosX = ptLightPos.m_fX;
	m_wndOpenGL.m_dLightPosY = ptLightPos.m_fY;
	m_wndOpenGL.m_dLightPosZ = ptLightPos.m_fZ;
	m_wndOpenGL.OnDraw(NULL);
}
void CGlovePlayDlg::OnBnClickedCheckShowOrigin()
{
	CButton* pCheck = (CButton*)GetDlgItem(IDC_CHECK_SHOW_ORIGIN);
	int iShowOrigin = pCheck->GetCheck();
	if(iShowOrigin != 0)
		m_wndOpenGL.m_bShowOrigin = true;
	else
		m_wndOpenGL.m_bShowOrigin = false;
	   
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnBnClickedCheckWireframe()
{
	CButton* pCheck = (CButton*)GetDlgItem(IDC_CHECK_WIREFRAME);
	bool bWireframe = pCheck->GetCheck()!= 0 ? true : false;
	m_pHandRenderer->SetWireframe(bWireframe);
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnBnClickedButtonSizefile()
{
	CFileDialog dlgFile(TRUE, L"Glove Handsize File(*.gsz)|*.gsz", NULL, 4|2, L"Glove Handsize File(*.gsz)|*.gsz||");
	if(IDOK == dlgFile.DoModal())
	{
		m_pHandRenderer->m_pHand->LoadSizeFromFile(dlgFile.GetPathName());
		m_wndOpenGL.OnDraw(NULL);
	}
	else
	{
		CRawClip* pClipRaw = dynamic_cast<CRawClip*>(m_pClip);
		if(pClipRaw == NULL)
			return;

		bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->GetCheck();
		pClipRaw->ReinforceRelation(bLeft);
	}
}

void CGlovePlayDlg::OnBnClickedButtonMotionfile()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv||");
	if(IDOK == dlgFile.DoModal())
	{
		if(m_pClip) 
			delete m_pClip;
		CString strFile = dlgFile.GetFileName();
		if(strFile.Find(L".glv")!=-1)
			m_pClip = new CGlvClip();
		else
			m_pClip = new CRawClip();

		m_pClip->LoadFromFile(GloveUtil::ToChar(strFile));
		GetDlgItem(IDC_BUTTON_PLAY)->EnableWindow(TRUE);
	}
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnTimer(UINT_PTR nIDEvent)
{
	KillTimer(TIMER_EVENT_ID2);
	if(m_bPaused)
		return;
	
	PlayCurFrame();

	if(m_iCurFrameIdx + 1 < m_pClip->GetFrameCount())
	{
		m_iCurFrameIdx ++;
		CString strCurFrame = L"";
		strCurFrame.Format(L"%d", m_iCurFrameIdx);
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FRAME);
		pEdit->EnableWindow(TRUE);
		pEdit->SetWindowText(strCurFrame);
		SetTimer(TIMER_EVENT_ID2, 30, NULL);//TODO: should be 30ms, for testing
	}
}

void CGlovePlayDlg::OnBnClickedCheckLighting()
{	
	CButton* pCheck = (CButton*)GetDlgItem(IDC_CHECK_LIGHTING);
	m_wndOpenGL.m_bLightOn = pCheck->GetCheck()!= 0 ? true : false;	
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnBnClickedRadioFront()
{
	CButton* pCheck = (CButton*)GetDlgItem(IDC_RADIO_FRONT);
	if(pCheck->GetCheck() != 0)
		m_wndOpenGL.SetViewFront();
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnBnClickedRadioLeft()
{
	CButton* pCheck = (CButton*)GetDlgItem(IDC_RADIO_LEFT);
	if(pCheck->GetCheck() != 0)
		m_wndOpenGL.SetViewLeft();
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnBnClickedRadioTop()
{
	CButton* pCheck = (CButton*)GetDlgItem(IDC_RADIO_TOP);
	if(pCheck->GetCheck() != 0)
		m_wndOpenGL.SetViewTop();
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnBnClickedButtonPlay()
{
	//GetDlgItem(IDC_BUTTON_PLAY)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_BEGINNING)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUTTON_BACKWARD)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUTTON_STOP)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUTTON_FORWARD)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUTTON_ENDING)->EnableWindow(TRUE);
	GetDlgItem(IDC_EDIT_PLAY_FPS)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_ORIGINAL_FPS)->EnableWindow(TRUE);

	m_bPaused = false;		
	SetTimer(TIMER_EVENT_ID2, 100, NULL);
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnBnClickedButtonStop()
{
	KillTimer(TIMER_EVENT_ID2);
	m_bPaused = true;
}

void CGlovePlayDlg::OnBnClickedButtonBeginning()
{
	KillTimer(TIMER_EVENT_ID2);
	m_bPaused = true;
	m_iCurFrameIdx = 0;
	UpdateCurFrame();
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnBnClickedButtonBackward()
{
	KillTimer(TIMER_EVENT_ID2);	
	m_bPaused = true;
	m_iCurFrameIdx = max(0, m_iCurFrameIdx - 1);	
	UpdateCurFrame();
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}


void CGlovePlayDlg::OnBnClickedButtonForward()
{
	KillTimer(TIMER_EVENT_ID2);
	m_bPaused = true;
	m_iCurFrameIdx = min(m_pClip->GetFrameCount()-1, m_iCurFrameIdx + 1);
	UpdateCurFrame();
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnBnClickedButtonEnding()
{
	KillTimer(TIMER_EVENT_ID2);
	m_bPaused = true;
	m_iCurFrameIdx = m_pClip->GetFrameCount() -1;
	UpdateCurFrame();
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnEnChangeEditFrame()
{
	CString strCurFrame = L"";
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FRAME);
	pEdit->GetWindowText(strCurFrame);
	int iCurFrame = _wtoi(strCurFrame);
	if(iCurFrame != m_iCurFrameIdx)
	{
		m_iCurFrameIdx = iCurFrame;
		UpdateCurFrame();
	}
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}
void CGlovePlayDlg::UpdateCurFrame()
{
	CString strCurFrame = L"";
	strCurFrame.Format(L"%d", m_iCurFrameIdx);
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FRAME);
	pEdit->EnableWindow(TRUE);
	pEdit->SetWindowText(strCurFrame);

	PlayCurFrame();
}


void CGlovePlayDlg::PlayCurFrame()
{
	if(m_pClip == NULL)//no clip to play
		return;

	if(m_iCurFrameIdx < m_pClip->GetFrameCount() && m_iCurFrameIdx >=0)
	{
		CBaseFrame* pFrame = m_pClip->GetFrameAt(m_iCurFrameIdx);
		m_pHandRenderer->m_pHand->UpdateFromFrame(pFrame);
		m_wndOpenGL.OnDraw(NULL);

		//to display it
		CString strInfo = L"";
		for(int i = 0; i < pFrame->m_arData.size(); ++i)
		{
			char cData[20];
			float fData = ((CButton*)GetDlgItem(IDC_CHECK_2Radian))->GetCheck() ?
				GloveUtil::RadianToDegree(pFrame->m_arData[i]) : pFrame->m_arData[i];
			sprintf(cData, "%.2f", fData);
			CString strData(cData);
			strInfo = strInfo + strData + L"\t";
			if((i+1)%10==0)
				strInfo = strInfo + L"\r\n";
		}
		GetDlgItem(IDC_EDIT_FRAMEINFO)->SetWindowTextW(strInfo);
	}
}
void CGlovePlayDlg::OnBnClickedCheckOriginalFps()
{
	CButton* pCheck = (CButton*)GetDlgItem(IDC_CHECK_ORIGINAL_FPS);
	if(pCheck->GetCheck() != 0)
		GetDlgItem(IDC_EDIT_PLAY_FPS)->EnableWindow(FALSE);
	else
		GetDlgItem(IDC_EDIT_PLAY_FPS)->EnableWindow(TRUE);
}

void CGlovePlayDlg::OnBnClickedButtonLoadFrame()
{
	CFileDialog dlgFile(TRUE, L"Glove Frame File(*.gfm)|*.gfm", NULL, 4|2, L"Glove Frame File(*.gfm)|*.gfm||");
	if(IDOK == dlgFile.DoModal())
	{
		CGlvFrame frame;
		frame.LoadFromFileAngle(GloveUtil::ToChar(dlgFile.GetFileName()));		
		m_pHandRenderer->m_pHand->UpdateFromSensorData(frame.m_arData);
		m_wndOpenGL.OnDraw(NULL);
	}
}

void CGlovePlayDlg::OnBnClickedRadioLefthand()
{
	m_pHandRenderer->m_pHand->InitMotionLeft();
	m_pHandRenderer->m_pHand->m_bRightHand = false;
	
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedRadioRighthand()
{
	m_pHandRenderer->m_pHand->InitMotionRight();
	m_pHandRenderer->m_pHand->m_bRightHand = true;
	
	m_wndOpenGL.OnDraw(NULL);
}
#include "CKinematic\IKSolverDlg.h"
void CGlovePlayDlg::OnBnClickedButtonPlayTouch()
{
	CString strBeg, strEnd, strFinger;
	GetDlgItem(IDC_EDIT_ITP_BEG)->GetWindowText(strBeg);
	GetDlgItem(IDC_EDIT_ITP_END)->GetWindowText(strEnd);
	int iBeg = _wtoi(strBeg.GetBuffer());
	int iEnd = _wtoi(strEnd.GetBuffer());

	for(int i = iBeg; i <= iEnd; ++i)
	{
		CRawFrame frmRaw = ((CRawClip*)m_pClip)->m_arFrame[i];
		m_pHandRenderer->m_pHand->m_pHand->UpdateFromKinematicData(frmRaw.m_arData);

		CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_INDEX);
		if(pBut->GetCheck())
			m_pHandRenderer->m_pHand->m_pHand->PleaseTouch(IK_FINGER_TOUCHING_TYPE::eThumbIndex);

		pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_MID);
		if(pBut->GetCheck())
			m_pHandRenderer->m_pHand->m_pHand->PleaseTouch(IK_FINGER_TOUCHING_TYPE::eThumbMid);

		pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_RING);
		if(pBut->GetCheck())
			m_pHandRenderer->m_pHand->m_pHand->PleaseTouch(IK_FINGER_TOUCHING_TYPE::eThumbRing);

		pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_PINKY);
		if(pBut->GetCheck())
			m_pHandRenderer->m_pHand->m_pHand->PleaseTouch(IK_FINGER_TOUCHING_TYPE::eThumbPinky);

		m_pHandRenderer->m_pHand->UpdateToFrame(&frmRaw);
		((CRawClip*)m_pClip)->m_arFrame[i] = frmRaw;
	}

	//CBaseFrame* pFrame = m_pClip->GetFrameAt(m_iCurFrameIdx);
	//m_pHandRenderer->m_pHand->UpdateToFrame(pFrame);
	//m_pClip->SetFrameAt(m_iCurFrameIdx, pFrame);
	Invalidate(1);
}


void CGlovePlayDlg::OnBnClickedButtonViewAve()
{
	CRawClip* pRawClip = dynamic_cast<CRawClip*>(m_pClip);
	if(pRawClip)
	{
		CRawFrame frmRawAve = pRawClip->GetAveragePose();
		m_pHandRenderer->m_pHand->UpdateFromKinematicData(frmRawAve.m_arData);
		m_wndOpenGL.OnDraw(NULL);
		return;
	}

	CGlvClip* pGlvClip = dynamic_cast<CGlvClip*>(m_pClip);
	if(pGlvClip)
	{
		CGlvFrame frmGlvAve = pGlvClip->GetAveragePose();
		m_pHandRenderer->m_pHand->UpdateFromSensorData(frmGlvAve.m_arData);
		m_wndOpenGL.OnDraw(NULL);
		return;
	}

	/*CBvhClip* pBvhClip = dynamic_cast<CBvhClip*>(m_pClip);
	if(pBvhClip)
	{
		CBvhFrame frmBvhAve = pBvhClip->GetAveragePose();
		m_pHandRenderer->m_pHand->UpdateFromData(frmGlvAve);
		m_wndOpenGL.OnDraw(NULL);
		return;
	}*/	
}


void CGlovePlayDlg::OnBnClickedButtonCurFrame()
{	
	CKinematicHand* pHand = NULL;
	pHand = m_pHandRenderer->m_pHand->m_pHand;
	pHand->MoveGoalToFingerTip();
	CIKSolverDlg2 dlg(pHand);
	if(dlg.DoModal() == IDOK)
	{
		CBaseFrame* pFrame = m_pClip->GetFrameAt(m_iCurFrameIdx);
		m_pHandRenderer->m_pHand->UpdateToFrame(pFrame);
		m_pClip->SetFrameAt(m_iCurFrameIdx, pFrame);
	}
	Invalidate(1);
}

void CGlovePlayDlg::OnBnClickedButtonSaveMotion()
{
	CFileDialog dlgFile(FALSE, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv||");
	if(IDOK == dlgFile.DoModal())
	{
		CString strFile = dlgFile.GetFileName();
		m_pClip->SaveToFile(GloveUtil::ToChar(strFile));
	}
	::SetFocus(m_wndOpenGL.m_hWnd);
}
void CGlovePlayDlg::OnBnClickedButtonSavePose()
{
	//CFileDialog dlgFile(FALSE, L"Glove Frame File(*.gfm)|*.gfm", NULL, 4|2, L"Glove Frame File(*.gfm)|*.gfm||");
	CFileDialog dlgFile(FALSE, L"Raw Kinematic File(*.raw)|*.raw|Glove Frame File(*.gfm)|*.gfm", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw|Glove Frame File(*.gfm)|*.gfm||");
	
	if(IDOK != dlgFile.DoModal())
		return;

	CString strFileName = dlgFile.GetFileName();
	if(strFileName.Find(L".raw")!=-1)
	{
		CRawFrame frmRaw = CRawFrame::GetEmptyFrame();
		m_pHandRenderer->m_pHand->UpdateToKinematicData(frmRaw.m_arData);
		frmRaw.SaveToFile(GloveUtil::ToChar(strFileName));
	}
	else if(strFileName.Find(L".gfm")!=-1)
	{
		CGlvFrame frmGlv = CGlvFrame::GetEmptyFrame();
		m_pHandRenderer->m_pHand->UpdateToSensorData(frmGlv.m_arData);
		frmGlv.SaveToFileAngle(GloveUtil::ToChar(strFileName));
	}
	m_wndOpenGL.OnDraw(NULL);
	::SetFocus(m_wndOpenGL.m_hWnd);
}

void CGlovePlayDlg::OnBnClickedCheckActiveThumb()
{
	CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_THUMB);
	if(pBut->GetCheck())
		m_pHandRenderer->m_pHand->SetActiveFlag(FLAG_ACTIVE_THUMB);
	else
		m_pHandRenderer->m_pHand->UnsetActiveFlag(FLAG_ACTIVE_THUMB);
}

void CGlovePlayDlg::OnBnClickedCheckActiveIndex()
{	
	CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_INDEX);
	if(pBut->GetCheck())
		m_pHandRenderer->m_pHand->SetActiveFlag(FLAG_ACTIVE_INDEX);
	else
		m_pHandRenderer->m_pHand->UnsetActiveFlag(FLAG_ACTIVE_INDEX);
}

void CGlovePlayDlg::OnBnClickedCheckActiveMid()
{
	CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_MID);
	if(pBut->GetCheck())
		m_pHandRenderer->m_pHand->SetActiveFlag(FLAG_ACTIVE_MID);
	else
		m_pHandRenderer->m_pHand->UnsetActiveFlag(FLAG_ACTIVE_MID);
}

void CGlovePlayDlg::OnBnClickedCheckActiveRing()
{
	CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_RING);
	if(pBut->GetCheck())
		m_pHandRenderer->m_pHand->SetActiveFlag(FLAG_ACTIVE_RING);
	else
		m_pHandRenderer->m_pHand->UnsetActiveFlag(FLAG_ACTIVE_RING);
}

void CGlovePlayDlg::OnBnClickedCheckActivePinky()
{
	CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_PINKY);
	if(pBut->GetCheck())
		m_pHandRenderer->m_pHand->SetActiveFlag(FLAG_ACTIVE_PINKY);
	else
		m_pHandRenderer->m_pHand->UnsetActiveFlag(FLAG_ACTIVE_PINKY);
}

void CGlovePlayDlg::OnBnClickedCheckShowProb()
{	
	CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_SHOW_PROB);
	if(pBut->GetCheck())
		m_pHandRenderer->m_bShowProb = true;
	else
		m_pHandRenderer->m_bShowProb = false;

	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnEnChangeEditProbValveMin()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_PROB_VALVE_MIN);
	CString strProbValveMin;
	pEdit->GetWindowTextW(strProbValveMin);
	m_pHandRenderer->m_probRenderer.m_fProbColorMapRed = _wtof(strProbValveMin.GetBuffer());
	m_wndOpenGL.OnDraw(NULL);
}


void CGlovePlayDlg::OnEnChangeEditProbValveMax()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_PROB_VALVE_MAX);
	CString strProbValveMax;
	pEdit->GetWindowTextW(strProbValveMax);
	m_pHandRenderer->m_probRenderer.m_fProbColorMapBlue = _wtof(strProbValveMax.GetBuffer());
	m_wndOpenGL.OnDraw(NULL);
}


void CGlovePlayDlg::OnBnClickedCheckShowHand()
{
	CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_SHOW_HAND);
	if(pBut->GetCheck())
		m_pHandRenderer->m_bShowHand = true;
	else
		m_pHandRenderer->m_bShowHand = false;
	m_wndOpenGL.OnDraw(NULL);
}
//render step size
void CGlovePlayDlg::OnEnChangeEditRangeStepSize()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_RANGE_STEP_SIZE);
	CString strStepsize;
	pEdit->GetWindowTextW(strStepsize);
	CKinematicPoint ptStepSize = CKinematicPoint(strStepsize.GetBuffer());
	if(ptStepSize.m_fX == 0) ptStepSize.m_fX = 1;
	if(ptStepSize.m_fY == 0) ptStepSize.m_fY = 1;
	if(ptStepSize.m_fZ == 0) ptStepSize.m_fZ = 1;
	m_pHandRenderer->m_probRenderer.m_ptRenderRangeStep = ptStepSize;
	m_wndOpenGL.OnDraw(NULL);
}
void CGlovePlayDlg::OnEnChangeEditRenderRangeMin()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_RENDER_RANGE_MIN);
	CString strRenderRangeMin;
	pEdit->GetWindowTextW(strRenderRangeMin);
	CKinematicPoint ptRenderRangeMin = CKinematicPoint(strRenderRangeMin.GetBuffer());
	m_pHandRenderer->m_probRenderer.m_ptRenderRangeMin = ptRenderRangeMin;
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnEnChangeEditRenderRangeMax()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_RENDER_RANGE_MAX);
	CString strRenderRangeMax;
	pEdit->GetWindowTextW(strRenderRangeMax);
	CKinematicPoint ptRenderRangeMax = CKinematicPoint(strRenderRangeMax.GetBuffer());
	m_pHandRenderer->m_probRenderer.m_ptRenderRangeMax = ptRenderRangeMax;
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedButtonRecalProb()
{
	m_pHandRenderer->m_probRenderer.m_probFrame.PopulateProbData_byRange(m_pHandRenderer->m_probRenderer.m_ptRenderRangeMin,
		m_pHandRenderer->m_probRenderer.m_ptRenderRangeMax, m_pHandRenderer->m_probRenderer.m_ptRenderRangeStep);
	GetDlgItem(IDC_STATIC_MAX_PROB)->SetWindowText(CString(m_pHandRenderer->m_probRenderer.m_probFrame.m_maxProbData.ToString().c_str()));
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedButtonLoadProbFrame()
{
	CFileDialog dlgFile(TRUE, L"Prob Frame File(*.txt)|*.txt", NULL, 4|2, L"Prob Frame File(*.txt)|*.txt||");
	
	if(IDOK == dlgFile.DoModal())
	{
		m_pHandRenderer->m_probRenderer.m_probFrame.LoadFromFile(GloveUtil::ToChar(dlgFile.GetPathName()));
		GetDlgItem(IDC_STATIC_MAX_PROB)->SetWindowText(CString(m_pHandRenderer->m_probRenderer.m_probFrame.m_maxProbData.ToString().c_str()));
	}
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedButtonSaveProbFrame()
{
	CFileDialog dlgFile(FALSE, L"Prob Frame File(*.txt)|*.txt", NULL, 4|2, L"Prob Frame File(*.txt)|*.txt||");
	
	if(IDOK == dlgFile.DoModal())
		m_pHandRenderer->m_probRenderer.m_probFrame.SaveToFile(GloveUtil::ToChar(dlgFile.GetPathName()));
}


void CGlovePlayDlg::OnNMCustomdrawSliderProbSize(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);

	CSliderCtrl* pSlider = (CSliderCtrl*)GetDlgItem(IDC_SLIDER_PROB_SIZE);
	int iPos = pSlider->GetPos();
	m_pHandRenderer->m_probRenderer.m_fRenderSize = iPos;
	m_wndOpenGL.OnDraw(NULL);
	*pResult = 0;
}

void CGlovePlayDlg::OnBnClickedCheckRenderOriginalCalculated()
{
	CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_RENDER_ORIGINAL_CALCULATED);
	m_pHandRenderer->m_probRenderer.m_bRenderOriginal = pBut->GetCheck();
}

void CGlovePlayDlg::OnEnChangeEditRenderValve()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_RENDER_VALVE);
	CString strRenderValve;
	pEdit->GetWindowTextW(strRenderValve);
	m_pHandRenderer->m_probRenderer.m_fRenderValve = _wtof(strRenderValve);
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedCheckShowEndTraj()
{
	bool bShow = ((CButton*)GetDlgItem(IDC_CHECK_SHOW_END_TRAJ))->GetCheck();
	for(int i = 0; i < m_arEndEffectorTrajRenderer.size(); ++i)
		m_arEndEffectorTrajRenderer[i]->m_bShow = bShow;
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedCheckShowMaxProbTraj()
{
	m_pMaxProbTrajRenderer->m_bShow = ((CButton*)GetDlgItem(IDC_CHECK_SHOW_MAX_PROB_TRAJ))->GetCheck();
	m_wndOpenGL.OnDraw(NULL);
}
void CGlovePlayDlg::OnBnClickedCheckShowComTraj()
{
	m_pCOMTrajRenderer->m_bShow = ((CButton*)GetDlgItem(IDC_CHECK_SHOW_COM_TRAJ))->GetCheck();
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnNMCustomdrawSliderEndTrajSize(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	CSliderCtrl* pSlider = (CSliderCtrl*)GetDlgItem(IDC_SLIDER_END_TRAJ_SIZE);
	int iPos = pSlider->GetPos();
	for(int i = 0; i < m_arEndEffectorTrajRenderer.size(); ++i)
		m_arEndEffectorTrajRenderer[i]->m_fRenderSize = iPos;
	m_wndOpenGL.OnDraw(NULL);
	*pResult = 0;
}

void CGlovePlayDlg::OnNMCustomdrawSliderMaxProbTrajSize(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	CSliderCtrl* pSlider = (CSliderCtrl*)GetDlgItem(IDC_SLIDER_MAX_PROB_TRAJ_SIZE);
	int iPos = pSlider->GetPos();
	m_pMaxProbTrajRenderer->m_fRenderSize = iPos;
	m_wndOpenGL.OnDraw(NULL);	
	*pResult = 0;
}
void CGlovePlayDlg::OnNMCustomdrawSliderComTrajSize(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	CSliderCtrl* pSlider = (CSliderCtrl*)GetDlgItem(IDC_SLIDER_COM_TRAJ_SIZE);
	int iPos = pSlider->GetPos();
	m_pCOMTrajRenderer->m_fRenderSize = iPos;
	m_wndOpenGL.OnDraw(NULL);	
	*pResult = 0;
}

void CGlovePlayDlg::OnEnChangeEditColorEndTraj()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_COLOR_END_TRAJ);
	CString strEndTrajColor;
	pEdit->GetWindowTextW(strEndTrajColor);
	CKinematicPoint ptEndTrajColor = CKinematicPoint(strEndTrajColor.GetBuffer());
	for(int i = 0; i < m_arEndEffectorTrajRenderer.size(); ++i)
		m_arEndEffectorTrajRenderer[i]->m_color = ptEndTrajColor;
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnEnChangeEditColorMaxProbTraj()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_COLOR_MAX_PROB_TRAJ);
	CString strMaxProbTrajColor;
	pEdit->GetWindowTextW(strMaxProbTrajColor);
	CKinematicPoint ptMaxProbTrajColor = CKinematicPoint(strMaxProbTrajColor.GetBuffer());
	m_pMaxProbTrajRenderer->m_color = ptMaxProbTrajColor;
	m_wndOpenGL.OnDraw(NULL);
}
void CGlovePlayDlg::OnEnChangeEditColorComTraj()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_COLOR_COM_TRAJ);
	CString strCOMTrajColor;
	pEdit->GetWindowTextW(strCOMTrajColor);
	CKinematicPoint ptCOMTrajColor = CKinematicPoint(strCOMTrajColor.GetBuffer());
	m_pCOMTrajRenderer->m_color = ptCOMTrajColor;
	m_wndOpenGL.OnDraw(NULL);
}


void CGlovePlayDlg::OnBnClickedCheckDiscreteEndTraj()
{
	bool bDiscrete = ((CButton*)GetDlgItem(IDC_CHECK_DISCRETE_END_TRAJ))->GetCheck();
	for(int i = 0; i < m_arEndEffectorTrajRenderer.size(); ++i)
		m_arEndEffectorTrajRenderer[i]->m_bDiscrete = bDiscrete;
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedCheckDiscreteMaxProbTraj()
{
	m_pMaxProbTrajRenderer->m_bDiscrete = ((CButton*)GetDlgItem(IDC_CHECK_DISCRETE_MAX_PROB_TRAJ))->GetCheck();
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedCheckDiscreteComTraj()
{
	m_pCOMTrajRenderer->m_bDiscrete = ((CButton*)GetDlgItem(IDC_CHECK_DISCRETE_COM_TRAJ))->GetCheck();
	m_wndOpenGL.OnDraw(NULL);
}
void CGlovePlayDlg::OnEnChangeEditTrajBegIdx()
{
	CString strBegIdx;
	GetDlgItem(IDC_EDIT_TRAJ_BEG_IDX)->GetWindowTextW(strBegIdx);
	int iBegIdx = _wtoi(strBegIdx.GetBuffer());
	m_pMaxProbTrajRenderer->m_iRenderBegIdx = iBegIdx;
	m_pCOMTrajRenderer->m_iRenderBegIdx = iBegIdx;
	for(int i = 0; i < m_arEndEffectorTrajRenderer.size(); ++i)
		m_arEndEffectorTrajRenderer[i]->m_iRenderBegIdx = iBegIdx;
}
void CGlovePlayDlg::OnEnChangeEditTrajEndIdx()
{
	CString strEndIdx;
	GetDlgItem(IDC_EDIT_TRAJ_END_IDX)->GetWindowTextW(strEndIdx);
	int iEndIdx = _wtoi(strEndIdx.GetBuffer());
	m_pMaxProbTrajRenderer->m_iRenderEndIdx = iEndIdx;
	m_pCOMTrajRenderer->m_iRenderEndIdx = iEndIdx;	
	for(int i = 0; i < m_arEndEffectorTrajRenderer.size(); ++i)
		m_arEndEffectorTrajRenderer[i]->m_iRenderEndIdx = iEndIdx;
}
void CGlovePlayDlg::OnBnClickedButtonRecalEndTraj()
{
	CString strBegIdx, strEndIdx;
	GetDlgItem(IDC_EDIT_TRAJ_BEG_IDX)->GetWindowText(strBegIdx);
	GetDlgItem(IDC_EDIT_TRAJ_END_IDX)->GetWindowText(strEndIdx);
	int iBegIdx = _wtoi(strBegIdx.GetBuffer());
	int iEndIdx = _wtoi(strEndIdx.GetBuffer());
	bool bDiscrete = ((CButton*)GetDlgItem(IDC_CHECK_DISCRETE_END_TRAJ))->GetCheck();
	bool bShow = ((CButton*)GetDlgItem(IDC_CHECK_SHOW_END_TRAJ))->GetCheck();
	CString strColor;
	GetDlgItem(IDC_EDIT_COLOR_END_TRAJ)->GetWindowText(strColor);
	CKinematicPoint ptColor(strColor.GetBuffer());
	CSliderCtrl* pSlider = (CSliderCtrl*)GetDlgItem(IDC_SLIDER_END_TRAJ_SIZE);
	float fRenderSize = pSlider->GetPos();

	for(int i = 0; i < m_arEndEffectorTrajRenderer.size(); ++i)
		delete m_arEndEffectorTrajRenderer[i];
	m_arEndEffectorTrajRenderer.clear();
	while(m_wndOpenGL.m_arTrajRenderer.size() > 2)
		m_wndOpenGL.m_arTrajRenderer.pop_back();

	CPtTrajClip clipTraj(m_pHandRenderer->m_pHand);
	std::vector<CPtTrajClip> arActiveTraj = clipTraj.GetActiveEndEffectorTrajClip(m_pClip, iBegIdx, iEndIdx);	
	for(int i = 0; i < arActiveTraj.size(); ++i)
	{
		CPtTrajRenderer* pTrajRenderer = new CPtTrajRenderer();
		pTrajRenderer->m_bDiscrete = bDiscrete;
		pTrajRenderer->m_bShow = bShow;
		pTrajRenderer->m_color = ptColor;
		pTrajRenderer->m_fRenderSize = fRenderSize;
		pTrajRenderer->m_iRenderBegIdx = iBegIdx;
		pTrajRenderer->m_iRenderEndIdx = iEndIdx; 
		pTrajRenderer->m_traj = arActiveTraj[i];
		m_arEndEffectorTrajRenderer.push_back(pTrajRenderer);
		m_wndOpenGL.m_arTrajRenderer.push_back(pTrajRenderer);
	}
}
void CGlovePlayDlg::OnBnClickedButtonRecalMaxRpobTraj()
{
	CString strBegIdx, strEndIdx;
	GetDlgItem(IDC_EDIT_TRAJ_BEG_IDX)->GetWindowText(strBegIdx);
	GetDlgItem(IDC_EDIT_TRAJ_END_IDX)->GetWindowText(strEndIdx);
	int iBegIdx = _wtoi(strBegIdx.GetBuffer());
	int iEndIdx = _wtoi(strEndIdx.GetBuffer());

	CPtTrajClip clipMaxProbTraj(m_pHandRenderer->m_pHand);
	clipMaxProbTraj.PopulateActiveMaxProbTrajClip_approx(m_pClip, iBegIdx, iEndIdx);
	m_pMaxProbTrajRenderer->m_traj = clipMaxProbTraj;
}
void CGlovePlayDlg::OnBnClickedButtonRecalComTraj()
{
	CString strBegIdx, strEndIdx;
	GetDlgItem(IDC_EDIT_TRAJ_BEG_IDX)->GetWindowText(strBegIdx);
	GetDlgItem(IDC_EDIT_TRAJ_END_IDX)->GetWindowText(strEndIdx);
	int iBegIdx = _wtoi(strBegIdx.GetBuffer());
	int iEndIdx = _wtoi(strEndIdx.GetBuffer());

	CPtTrajClip clipCOMTraj(m_pHandRenderer->m_pHand);
	clipCOMTraj.PopulateActiveCOMTrajClip(m_pClip, iBegIdx, iEndIdx);
	m_pCOMTrajRenderer->m_traj = clipCOMTraj;
}












void CGlovePlayDlg::OnEnChangeEditThumbColor()
{
	CString strColor;
	GetDlgItem(IDC_EDIT_THUMB_COLOR)->GetWindowText(strColor);
	CKinematicPoint ptColor(strColor.GetBuffer());
	m_pHandRenderer->m_clrThumb = ptColor;
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnEnChangeEditIndexColor()
{
	CString strColor;
	GetDlgItem(IDC_EDIT_INDEX_COLOR)->GetWindowText(strColor);
	CKinematicPoint ptColor(strColor.GetBuffer());
	m_pHandRenderer->m_clrIndex = ptColor;
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnEnChangeEditMidColor()
{
	CString strColor;
	GetDlgItem(IDC_EDIT_MID_COLOR)->GetWindowText(strColor);
	CKinematicPoint ptColor(strColor.GetBuffer());
	m_pHandRenderer->m_clrMid = ptColor;
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnEnChangeEditRingColor()
{
	CString strColor;
	GetDlgItem(IDC_EDIT_RING_COLOR)->GetWindowText(strColor);
	CKinematicPoint ptColor(strColor.GetBuffer());
	m_pHandRenderer->m_clrRing = ptColor;
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnEnChangeEditPinkyColor()
{
	CString strColor;
	GetDlgItem(IDC_EDIT_PINKY_COLOR)->GetWindowText(strColor);
	CKinematicPoint ptColor(strColor.GetBuffer());
	m_pHandRenderer->m_clrPinky = ptColor;
	m_wndOpenGL.Invalidate();
}


//calibration related
void CGlovePlayDlg::OnBnClickedCheckCalibrateClip()
{
	CButton* pButton = (CButton*)GetDlgItem(IDC_CHECK_CALIBRATE_CLIP);
	if(pButton->GetCheck())
		m_bCalibrateClip = true;
	else
		m_bCalibrateClip = false;
}
void CGlovePlayDlg::OnBnClickedButtonCalibrateFkIndependent()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->GetCheck();
	if(!m_bCalibrateClip)
	{
		CRawFrame frmRaw;
		m_pHandRenderer->m_pHand->UpdateToFrame(&frmRaw);
		CRawFrame frmCalibrated = MatlabUtil::GPRCalibrate_linear(frmRaw, bLeft);
		m_pHandRenderer->m_pHand->UpdateFromFrame(&frmCalibrated);
	}
	else
	{
		CRawClip* pRawClip = dynamic_cast<CRawClip*>(m_pClip);
		if(NULL == pRawClip)
			return;
		
		*pRawClip = MatlabUtil::GPRCalibrate_linear(*pRawClip, bLeft);
	}
	m_wndOpenGL.OnDraw(NULL);
}



void CGlovePlayDlg::OnBnClickedButtonCalibrateFkFull()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->GetCheck();
	if(!m_bCalibrateClip)
	{
		CRawFrame frmRaw;
		m_pHandRenderer->m_pHand->UpdateToFrame(&frmRaw);
		CRawFrame frmCalibrated = MatlabUtil::GPRCalibrate_FK_full(frmRaw, bLeft);
		m_pHandRenderer->m_pHand->UpdateFromFrame(&frmCalibrated);
	}
	else
	{
		CRawClip* pRawClip = dynamic_cast<CRawClip*>(m_pClip);
		if(NULL == pRawClip)
			return;
		
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_CALIB_RANGE);
		CString strCalibRange;
		pEdit->GetWindowText(strCalibRange);
		CKinematicPoint ptRange(strCalibRange.GetBuffer());
		*pRawClip = MatlabUtil::GPRCalibrate_FK_full(*pRawClip, ptRange.m_fX, ptRange.m_fY, bLeft);
	}
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedButtonCalibrateFkFitc()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->GetCheck();
	if(!m_bCalibrateClip)
	{
		CRawFrame frmRaw;
		m_pHandRenderer->m_pHand->UpdateToFrame(&frmRaw);
		CRawFrame frmCalibrated = MatlabUtil::GPRCalibrate_FK_fitc(frmRaw, bLeft);
		m_pHandRenderer->m_pHand->UpdateFromFrame(&frmCalibrated);
	}
	else
	{
		CRawClip* pRawClip = dynamic_cast<CRawClip*>(m_pClip);
		if(NULL == pRawClip)
			return;
		
		*pRawClip = MatlabUtil::GPRCalibrate_FK_fitc(*pRawClip, bLeft);
	}
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedButtonCalibrateFitc()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->GetCheck();
	if(!m_bCalibrateClip)
	{
		CRawFrame frmRaw;
		m_pHandRenderer->m_pHand->UpdateToFrame(&frmRaw);
		CRawFrame frmCalibrated = MatlabUtil::GPRCalibrate_fitc(frmRaw, bLeft);
		m_pHandRenderer->m_pHand->UpdateFromFrame(&frmCalibrated);
	}
	else
	{
		CRawClip* pRawClip = dynamic_cast<CRawClip*>(m_pClip);
		if(NULL == pRawClip)
			return;
		
		*pRawClip = MatlabUtil::GPRCalibrate_fitc(*pRawClip, bLeft);
	}
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedButtonCalibrateFull()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->GetCheck();
	if(!m_bCalibrateClip)
	{
		CRawFrame frmRaw;
		m_pHandRenderer->m_pHand->UpdateToFrame(&frmRaw);
		CRawFrame frmCalibrated = MatlabUtil::GPRCalibrate_full(frmRaw, bLeft);
		m_pHandRenderer->m_pHand->UpdateFromFrame(&frmCalibrated);
	}
	else
	{
		CRawClip* pRawClip = dynamic_cast<CRawClip*>(m_pClip);
		if(NULL == pRawClip)
			return;
		
		*pRawClip = MatlabUtil::GPRCalibrate_full(*pRawClip, bLeft);
	}
	m_wndOpenGL.OnDraw(NULL);
}


void CGlovePlayDlg::OnBnClickedButtonCalibrateFullSimple()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->GetCheck();
	if(!m_bCalibrateClip)
	{
		CRawFrame frmRaw;
		m_pHandRenderer->m_pHand->UpdateToFrame(&frmRaw);
		CRawFrame frmCalibrated = MatlabUtil::GPRCalibrate_fingerFLEX_full(frmRaw, bLeft);
		frmCalibrated = MatlabUtil::GPRCalibrate_fingerABD_full(frmCalibrated, bLeft);
		frmCalibrated = MatlabUtil::GPRCalibrate_Thumb_full(frmCalibrated, bLeft);
		m_pHandRenderer->m_pHand->UpdateFromFrame(&frmCalibrated);
	}
	else
	{
		CRawClip* pRawClip = dynamic_cast<CRawClip*>(m_pClip);
		if(NULL == pRawClip)
			return;
		
		*pRawClip = MatlabUtil::GPRCalibrate_fingerFLEX_full(*pRawClip, bLeft);
		*pRawClip = MatlabUtil::GPRCalibrate_fingerABD_full(*pRawClip, bLeft);
		*pRawClip = MatlabUtil::GPRCalibrate_Thumb_full(*pRawClip, bLeft);
	}
	m_wndOpenGL.OnDraw(NULL);
}
void CGlovePlayDlg::OnBnClickedButtonCalibrateFitcSimple()
{
		bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->GetCheck();
	if(!m_bCalibrateClip)
	{
		CRawFrame frmRaw;
		m_pHandRenderer->m_pHand->UpdateToFrame(&frmRaw);
		CRawFrame frmCalibrated = MatlabUtil::GPRCalibrate_fingerFLEX_fitc(frmRaw, bLeft);
		frmCalibrated = MatlabUtil::GPRCalibrate_fingerABD_fitc(frmCalibrated, bLeft);
		frmCalibrated = MatlabUtil::GPRCalibrate_Thumb_fitc(frmCalibrated, bLeft);
		m_pHandRenderer->m_pHand->UpdateFromFrame(&frmCalibrated);
	}
	else
	{
		CRawClip* pRawClip = dynamic_cast<CRawClip*>(m_pClip);
		if(NULL == pRawClip)
			return;
		
		*pRawClip = MatlabUtil::GPRCalibrate_fingerFLEX_fitc(*pRawClip, bLeft);
		*pRawClip = MatlabUtil::GPRCalibrate_fingerABD_fitc(*pRawClip, bLeft);
		*pRawClip = MatlabUtil::GPRCalibrate_Thumb_fitc(*pRawClip, bLeft);
	}
	m_wndOpenGL.OnDraw(NULL);
}
void CGlovePlayDlg::OnBnClickedButtonCalibrateThumbFull()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->GetCheck();
	if(!m_bCalibrateClip)
	{
		CRawFrame frmRaw;
		m_pHandRenderer->m_pHand->UpdateToFrame(&frmRaw);
		CRawFrame frmCalibrated = MatlabUtil::GPRCalibrate_Thumb_full(frmRaw, bLeft);
		m_pHandRenderer->m_pHand->UpdateFromFrame(&frmCalibrated);
	}
	else
	{
		CRawClip* pRawClip = dynamic_cast<CRawClip*>(m_pClip);
		if(NULL == pRawClip)
			return;
		
		*pRawClip = MatlabUtil::GPRCalibrate_Thumb_full(*pRawClip, bLeft);
	}
	m_wndOpenGL.OnDraw(NULL);
}
void CGlovePlayDlg::OnBnClickedButtonCalibrateFingerflexFull()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->GetCheck();
	if(!m_bCalibrateClip)
	{
		CRawFrame frmRaw;
		m_pHandRenderer->m_pHand->UpdateToFrame(&frmRaw);
		CRawFrame frmCalibrated = MatlabUtil::GPRCalibrate_fingerFLEX_full(frmRaw, bLeft);
		m_pHandRenderer->m_pHand->UpdateFromFrame(&frmCalibrated);
	}
	else
	{
		CRawClip* pRawClip = dynamic_cast<CRawClip*>(m_pClip);
		if(NULL == pRawClip)
			return;
		
		*pRawClip = MatlabUtil::GPRCalibrate_fingerFLEX_full(*pRawClip, bLeft);
	}
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedButtonCalibrateFingerabdFull()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->GetCheck();
	if(!m_bCalibrateClip)
	{
		CRawFrame frmRaw;
		m_pHandRenderer->m_pHand->UpdateToFrame(&frmRaw);
		CRawFrame frmCalibrated = MatlabUtil::GPRCalibrate_fingerABD_full(frmRaw, bLeft);
		m_pHandRenderer->m_pHand->UpdateFromFrame(&frmCalibrated);
	}
	else
	{
		CRawClip* pRawClip = dynamic_cast<CRawClip*>(m_pClip);
		if(NULL == pRawClip)
			return;
		
		*pRawClip = MatlabUtil::GPRCalibrate_fingerABD_full(*pRawClip, bLeft);
	}
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedCheckThumbRollActive()
{
	m_pHandRenderer->m_pHand->m_pHand->m_arChain[0]->GetDOFAt(0)->m_bActive = 
		((CButton*)GetDlgItem(IDC_CHECK_THUMB_ROLL_ACTIVE))->GetCheck();
}

void CGlovePlayDlg::OnBnClickedCheckThumbAbdActive()
{
	m_pHandRenderer->m_pHand->m_pHand->m_arChain[0]->GetDOFAt(1)->m_bActive = 
		((CButton*)GetDlgItem(IDC_CHECK_THUMB_ABD_ACTIVE))->GetCheck();
}

void CGlovePlayDlg::OnBnClickedCheckThumbVirtualActive()
{
	m_pHandRenderer->m_pHand->m_pHand->m_arChain[0]->GetDOFAt(2)->m_bActive = 
		((CButton*)GetDlgItem(IDC_CHECK_THUMB_VIRTUAL_ACTIVE))->GetCheck();
}

void CGlovePlayDlg::OnBnClickedCheckThumbInnerFlexActive()
{
	m_pHandRenderer->m_pHand->m_pHand->m_arChain[0]->GetDOFAt(3)->m_bActive = 
		((CButton*)GetDlgItem(IDC_CHECK_THUMB_INNER_FLEX_ACTIVE))->GetCheck();
}

void CGlovePlayDlg::OnBnClickedCheckThumbDistFlexActive()
{
	m_pHandRenderer->m_pHand->m_pHand->m_arChain[0]->GetDOFAt(4)->m_bActive = 
		((CButton*)GetDlgItem(IDC_CHECK_THUMB_DIST_FLEX_ACTIVE))->GetCheck();
}



void CGlovePlayDlg::OnBnClickedButtonWatchDataRedundant()
{
	CIKClip clipIK = CIKClip::NewFromRawClip(*((CRawClip*)m_pClip), IK_FINGER_TOUCHING_TYPE::eThumbIndex);
	clipIK = clipIK.GetAllDataRedundantClip();
	CRawClip clipRaw = clipIK.GetRawClip();
	delete m_pClip;
	m_pClip = new CRawClip(clipRaw);
}

void CGlovePlayDlg::OnBnClickedButtonRefresh()
{
	RefreshPlay();	
}
void CGlovePlayDlg::RefreshPlay()
{
	PlayCurFrame();
	m_wndOpenGL.OnDraw(NULL);
}

void CGlovePlayDlg::OnBnClickedButtonWatchDataNonRedundant()
{
	CIKClip clipIK = CIKClip::NewFromRawClip(*((CRawClip*)m_pClip), IK_FINGER_TOUCHING_TYPE::eThumbIndex);
	clipIK = clipIK.GetNoDataRedundantClip();
	CRawClip clipRaw = clipIK.GetRawClip();
	delete m_pClip;
	m_pClip = new CRawClip(clipRaw);
}

void CGlovePlayDlg::OnBnClickedButtonWatchOrderedByThumb()
{
	int iIdx = m_iCurFrameIdx;
	CIKClip clipIK = CIKClip::NewFromRawClip(*((CRawClip*)m_pClip), IK_FINGER_TOUCHING_TYPE::eThumbIndex);
	if(iIdx<0) 
		iIdx = 0;
	if(iIdx > clipIK.m_arFrame.size())
		iIdx = clipIK.m_arFrame.size() -1;

	CRawFrame frmRaw;
	if(m_pClip)
		frmRaw = ((CRawClip*)m_pClip)->m_arFrame[iIdx];

	CIKFrame frmIK(frmRaw, 0, 0, 0);
	clipIK = clipIK.GetReorderedClipByThumb(frmIK);
	CRawClip clipRaw = clipIK.GetRawClip();
	delete m_pClip;
	m_pClip = new CRawClip(clipRaw);
}




void CGlovePlayDlg::OnBnClickedButtonFindCloseInput()
{
	CRawFrame frmRaw;
	if(m_pClip)
		frmRaw = ((CRawClip*)m_pClip)->m_arFrame[m_iCurFrameIdx];

	CRawClip clipAllSnr;
	clipAllSnr.LoadFromFile("C:\\wangyi\\research\\glove\\VirtualHandCalib\\sp2_raw\\ik\\unclosed\\all_snr_l.raw");

	float fDistMin = 100000;
	int iIdxMin = -1;
	for(int i = 0; i < 250; ++i)
	{
		CRawFrame frmAllSnr= clipAllSnr.m_arFrame[i];
		float fDist = (frmAllSnr.m_arData[0] - frmRaw.m_arData[0]) * (frmAllSnr.m_arData[0] - frmRaw.m_arData[0]);
		fDist += (frmAllSnr.m_arData[1] - frmRaw.m_arData[1]) * (frmAllSnr.m_arData[1] - frmRaw.m_arData[1]);
		fDist += (frmAllSnr.m_arData[3] - frmRaw.m_arData[3]) * (frmAllSnr.m_arData[3] - frmRaw.m_arData[3]);
		fDist += (frmAllSnr.m_arData[4] - frmRaw.m_arData[4]) * (frmAllSnr.m_arData[4] - frmRaw.m_arData[4]);

		fDist += (frmAllSnr.m_arData[8] - frmRaw.m_arData[8]) * (frmAllSnr.m_arData[8] - frmRaw.m_arData[8]);
		fDist += (frmAllSnr.m_arData[14] - frmRaw.m_arData[14]) * (frmAllSnr.m_arData[14] - frmRaw.m_arData[14]);
		fDist += (frmAllSnr.m_arData[20] - frmRaw.m_arData[20]) * (frmAllSnr.m_arData[20] - frmRaw.m_arData[20]);
		fDist += (frmAllSnr.m_arData[26] - frmRaw.m_arData[26]) * (frmAllSnr.m_arData[26] - frmRaw.m_arData[26]);
		fDist = sqrt(fDist);


		if(fDist < fDistMin)
		{
			fDistMin = fDist;
			iIdxMin = i;
		}
	}
	CString strInfo;
	strInfo.Format(L"frame: %d, distance: %f", iIdxMin, fDistMin);
	::MessageBox(NULL, strInfo, L"Frame", MB_OK);

}

void CGlovePlayDlg::OnBnClickedButtonThumbCopyPrev()
{
	int iThumbIdx;
	CString strThumbIdx;
	GetDlgItem(IDC_EDIT_THUMB_COPY_IDX)->GetWindowText(strThumbIdx);
	iThumbIdx = _wtoi(strThumbIdx.GetBuffer());
	if(strThumbIdx.IsEmpty())
		iThumbIdx = m_iCurFrameIdx - 1;

	if(iThumbIdx >= m_pClip->GetFrameCount() || 
		iThumbIdx < 0)
		return;

	CRawClip* pClipRaw = dynamic_cast<CRawClip*>(m_pClip);
	if(pClipRaw == NULL)
		return;

	CRawFrame frmThumbIdx = pClipRaw->m_arFrame[iThumbIdx];
	pClipRaw->m_arFrame[m_iCurFrameIdx].m_arData[0] = frmThumbIdx.m_arData[0];
	pClipRaw->m_arFrame[m_iCurFrameIdx].m_arData[1] = frmThumbIdx.m_arData[1];
	pClipRaw->m_arFrame[m_iCurFrameIdx].m_arData[2] = frmThumbIdx.m_arData[2];
	pClipRaw->m_arFrame[m_iCurFrameIdx].m_arData[3] = frmThumbIdx.m_arData[3];
	pClipRaw->m_arFrame[m_iCurFrameIdx].m_arData[4] = frmThumbIdx.m_arData[4];

	PlayCurFrame();
}

void CGlovePlayDlg::OnBnClickedButtonNormalizeWrist()
{	
	CRawClip* pClipRaw = dynamic_cast<CRawClip*>(m_pClip);
	if(pClipRaw)
	{
		//GloveUtil::AdjustWrist(pClipRaw);
		pClipRaw->ZeroWristRotations();

		/*//wocao
		for(int f= 0; f < pClipRaw->GetFrameCount(); ++f)
		{
			CRawFrame frmRaw = ((CRawClip*)pClipRaw)->m_arFrame[f];
			for(int i = 0; i < frmRaw.m_arData.size(); ++i)
			{
				if(i ==3 || i ==4 || 
				i ==6 || i ==8 || i ==9 || i ==10 ||
				i == 12 || i == 14 || i == 15 || i == 16 ||
				i == 18 || i == 20 || i == 21 || i == 22 ||
				i == 24 || i == 26 || i == 27 || i == 28)
					continue;		

				frmRaw.m_arData[i] = - frmRaw.m_arData[i];
			}
			pClipRaw->SetFrameAt(f, &frmRaw);
		}*/

		return;
	}
	CGlvClip* pClipGlv = dynamic_cast<CGlvClip*>(m_pClip);
	if(pClipGlv)
	{
		pClipGlv->ZeroWristRotations();
		return;
	}
}

void CGlovePlayDlg::OnBnClickedButtonAddOffset()
{
	CString strIndex, strOffset;
	GetDlgItem(IDC_EDIT_ADD_OFFSET_INDEX)->GetWindowText(strIndex);
	GetDlgItem(IDC_EDIT_ADD_OFFSET)->GetWindowText(strOffset);
	int iIndex = _wtoi(strIndex.GetBuffer());
	float fOffset = _wtof(strOffset.GetBuffer());

	CRawClip* pClipRaw = dynamic_cast<CRawClip*>(m_pClip);
	if(pClipRaw)
	{
		CString strBeg, strEnd;
		GetDlgItem(IDC_EDIT_ITP_BEG)->GetWindowText(strBeg);
		GetDlgItem(IDC_EDIT_ITP_END)->GetWindowText(strEnd);
		int iBeg = _wtoi(strBeg.GetBuffer());
		int iEnd = _wtoi(strEnd.GetBuffer());

		for(int i = iBeg; i <=iEnd; ++i)
		{
			CRawFrame frmRaw = pClipRaw->m_arFrame[i];
			frmRaw.m_arData[iIndex] = frmRaw.m_arData[iIndex] + fOffset;
			pClipRaw->m_arFrame[i] = frmRaw;
		}
		return;
	}
}

void CGlovePlayDlg::OnBnClickedButtonCopyThumbFrom()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw", NULL, 4|2, L"Raw Kinematic File(*.raw)||");
	if(IDOK == dlgFile.DoModal())
	{
		CString strFile = dlgFile.GetFileName();
		CRawClip thumbClip;
		thumbClip.LoadFromFile(GloveUtil::ToChar(strFile));

		GloveUtil::CopyThumb(&thumbClip, (CRawClip*)m_pClip);
	}
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CGlovePlayDlg::OnBnClickedButtonSuppressOverbend()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->GetCheck();
	//((CRawClip*)m_pClip)->SuppressOverbend(bLeft, 30, 30, 30, 30);
	((CRawClip*)m_pClip)->SuppressOverbendSigmoid(bLeft);
}

void CGlovePlayDlg::OnBnClickedButtonItp()
{
	CString strBeg, strEnd, strFinger;
	GetDlgItem(IDC_EDIT_ITP_BEG)->GetWindowText(strBeg);
	GetDlgItem(IDC_EDIT_ITP_END)->GetWindowText(strEnd);
	GetDlgItem(IDC_EDIT_ITP_FINGER)->GetWindowText(strFinger);
	int iBeg = _wtoi(strBeg.GetBuffer());
	int iEnd = _wtoi(strEnd.GetBuffer());
	int iFinger = _wtoi(strFinger.GetBuffer());
	((CRawClip*)m_pClip)->ItpFinger(iBeg, iEnd, iFinger);
}


void CGlovePlayDlg::OnBnClickedButtonMulCoef()
{
	CString strIndex, strCoef, strBase;
	GetDlgItem(IDC_EDIT_MUL_COEF_INDEX)->GetWindowText(strIndex);
	GetDlgItem(IDC_EDIT_MUL_COEF)->GetWindowText(strCoef);
	GetDlgItem(IDC_EDIT_MUL_COEF_BASE)->GetWindowText(strBase);
	int iIndex = _wtoi(strIndex.GetBuffer());
	float fCoef = _wtof(strCoef.GetBuffer());
	float fBase = _wtof(strBase.GetBuffer());

	CRawClip* pClipRaw = dynamic_cast<CRawClip*>(m_pClip);
	if(pClipRaw)
	{
		CString strBeg, strEnd;
		GetDlgItem(IDC_EDIT_ITP_BEG)->GetWindowText(strBeg);
		GetDlgItem(IDC_EDIT_ITP_END)->GetWindowText(strEnd);
		int iBeg = _wtoi(strBeg.GetBuffer());
		int iEnd = _wtoi(strEnd.GetBuffer());
		
		for(int i = iBeg; i <=iEnd; ++i)
		{
			CRawFrame frmRaw = pClipRaw->m_arFrame[i];
			frmRaw.m_arData[iIndex] = (frmRaw.m_arData[iIndex] - fBase) * fCoef + fBase;
			pClipRaw->m_arFrame[i] = frmRaw;
		}
		return;
	}	
}

void CGlovePlayDlg::OnBnClickedCheck2radian()
{
	CGlvClip* pClipGlv = dynamic_cast<CGlvClip*>(m_pClip);
	if(pClipGlv != NULL)
		pClipGlv->ToRadian();
	
	CGlvFrame frmGlv = CGlvFrame::GetEmptyFrame();
	m_pHandRenderer->m_pHand->UpdateToFrame(&frmGlv);
	frmGlv.ToRadian();
	m_pHandRenderer->m_pHand->UpdateFromFrame(&frmGlv);

	RefreshPlay();
}

void CGlovePlayDlg::OnBnClickedButtonExportTrj()
{
	CRawClip* pClipRaw = dynamic_cast<CRawClip*>(m_pClip);
	if(pClipRaw == NULL)
		return;

	CString strTrjIndex;
	GetDlgItem(IDC_EDIT_TRJ_INDEX)->GetWindowText(strTrjIndex);
	int iTrjIndex = _wtoi(strTrjIndex.GetBuffer());

	CFileDialog dlgFile(FALSE, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv||");
	if(IDOK == dlgFile.DoModal())
	{
		CString strFile = dlgFile.GetFileName();
		m_pHandRenderer->m_pHand->ExportTrajectory(*pClipRaw, iTrjIndex, GloveUtil::ToChar(strFile));
	}
}

void CGlovePlayDlg::OnBnClickedButtonExportRot()
{
	CRawClip* pClipRaw = dynamic_cast<CRawClip*>(m_pClip);
	if(pClipRaw == NULL)
		return;

	CString strDOFIndex;
	GetDlgItem(IDC_EDIT_TRJ_INDEX)->GetWindowText(strDOFIndex);
	int iDOFIndex = _wtoi(strDOFIndex.GetBuffer());

	CFileDialog dlgFile(FALSE, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv||");
	if(IDOK == dlgFile.DoModal())
	{
		CString strFile = dlgFile.GetFileName();
		pClipRaw->ExportRotation(iDOFIndex, GloveUtil::ToChar(strFile));
	}
}

void CGlovePlayDlg::OnBnClickedButtonExportFingertipDistance()
{
	IK_FINGER_TOUCHING_TYPE eTouchingType = IK_FINGER_TOUCHING_TYPE::eThumbIndex;
	CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_INDEX);
	if(pBut->GetCheck())
		eTouchingType = IK_FINGER_TOUCHING_TYPE::eThumbIndex;

	pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_MID);
	if(pBut->GetCheck())
		eTouchingType = IK_FINGER_TOUCHING_TYPE::eThumbMid;

	pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_RING);
	if(pBut->GetCheck())
		eTouchingType = IK_FINGER_TOUCHING_TYPE::eThumbRing;

	pBut = (CButton*)GetDlgItem(IDC_CHECK_ACTIVE_PINKY);
	if(pBut->GetCheck())
		eTouchingType = IK_FINGER_TOUCHING_TYPE::eThumbPinky;


	CRawClip* pClipRaw = dynamic_cast<CRawClip*>(m_pClip);
	if(pClipRaw == NULL)
		return;

	CFileDialog dlgFile(FALSE, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv||");
	if(IDOK == dlgFile.DoModal())
	{
		CString strFile = dlgFile.GetFileName();
		m_pHandRenderer->m_pHand->ExportTipDistance(*pClipRaw, eTouchingType, GloveUtil::ToChar(strFile));
	}
}

void CGlovePlayDlg::OnBnClickedButtonExportBvh()
{
	CRawClip* pClipRaw = dynamic_cast<CRawClip*>(m_pClip);
	if(pClipRaw == NULL)
		return;

	CFileDialog dlgFile(FALSE, L"BVH File(*.bvh)|*.bvh|BVH(*.bvh)|*.bvh", NULL, 4|2, L"BVH(*.bvh)|*.bvh|BVH(*.bvh)|*.bvh||");
	if(IDOK == dlgFile.DoModal())
	{
		CString strFile = dlgFile.GetFileName();
		m_pHandRenderer->m_pHand->ExportBvh(*pClipRaw, GloveUtil::ToChar(strFile));
	}
}

void CGlovePlayDlg::OnBnClickedButtonImportFramesFrom()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw||");
	if(IDOK == dlgFile.DoModal())
	{
		CString strFile = dlgFile.GetFileName();
		CRawClip clipImported;
		clipImported.LoadFromFile(GloveUtil::ToChar(strFile));

		CString strBeg, strEnd;
		GetDlgItem(IDC_EDIT_ITP_BEG)->GetWindowText(strBeg);
		GetDlgItem(IDC_EDIT_ITP_END)->GetWindowText(strEnd);
		int iBeg = _wtoi(strBeg.GetBuffer());
		int iEnd = _wtoi(strEnd.GetBuffer());

		CRawClip* pRawClip = dynamic_cast<CRawClip*>(m_pClip);
		int iLength = pRawClip->m_arFrame.size();
		if(pRawClip == NULL)
			return;

		for(int i = iBeg; i <=iEnd; ++i)
		{
			//pRawClip->m_arFrame[i].m_arData[14] = clipImported.m_arFrame[i].m_arData[14];
			pRawClip->m_arFrame[i].m_arData[15] = 0.2*pRawClip->m_arFrame[i].m_arData[15] + 0.4*clipImported.m_arFrame[i].m_arData[21]+0.4*clipImported.m_arFrame[i].m_arData[9];
			pRawClip->m_arFrame[i].m_arData[16] = 0.2*pRawClip->m_arFrame[i].m_arData[16] + 0.4*clipImported.m_arFrame[i].m_arData[22]+0.4*clipImported.m_arFrame[i].m_arData[10];

			/*thumb import 
			pRawClip->m_arFrame[i].m_arData[0] = clipImported.m_arFrame[i].m_arData[0];
			pRawClip->m_arFrame[i].m_arData[1] = clipImported.m_arFrame[i].m_arData[1];
			pRawClip->m_arFrame[i].m_arData[2] = clipImported.m_arFrame[i].m_arData[2];
			pRawClip->m_arFrame[i].m_arData[3] = clipImported.m_arFrame[i].m_arData[3];
			pRawClip->m_arFrame[i].m_arData[4] = clipImported.m_arFrame[i].m_arData[4];*/

			//pRawClip->m_arFrame[i].m_arData[20] = clipImported.m_arFrame[i].m_arData[20];
			//pRawClip->m_arFrame[i].m_arData[21] = clipImported.m_arFrame[i].m_arData[21];
			//pRawClip->m_arFrame[i].m_arData[22] = clipImported.m_arFrame[i].m_arData[22];

		}	
	}
}


void CGlovePlayDlg::OnBnClickedButtonRescale()
{
	/*CString strDOFIndex;
	GetDlgItem(IDC_EDIT_ADD_OFFSET_INDEX)->GetWindowText(strDOFIndex);
	int iDOFIdx = _wtoi(strDOFIndex.GetBuffer());*/

	CString strFingerIndex;
	GetDlgItem(IDC_EDIT_ITP_FINGER)->GetWindowText(strFingerIndex);
	int iFingerIndex = _wtoi(strFingerIndex.GetBuffer());

	CString strFixedFrameIdx;
	GetDlgItem(IDC_EDIT_FIXED_MERGEIN_FRAME_IDX)->GetWindowText(strFixedFrameIdx);
	int iFixedMergeInFrameIdx = _wtoi(strFixedFrameIdx.GetBuffer());

	CString strCurFrameIdx;
	GetDlgItem(IDC_EDIT_FRAME)->GetWindowText(strCurFrameIdx);
	int iCurFrameIdx = _wtoi(strCurFrameIdx.GetBuffer());

	CString strCurRescaledNewValue;
	GetDlgItem(IDC_EDIT_RESCALE_CUR_NEW_VALUE)->GetWindowText(strCurRescaledNewValue);
	float fCurRescaledNewValue = _wtof(strCurRescaledNewValue);

	CRawClip* pClipRaw = dynamic_cast<CRawClip*>(m_pClip);
	if(pClipRaw)
	{
		pClipRaw->Rescale(iFingerIndex, iFixedMergeInFrameIdx, iCurFrameIdx);
	}

}
//special function that you want the UI API
void CGlovePlayDlg::OnBnClickedButtonCopyFrom()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv||");
	if(IDOK == dlgFile.DoModal())
	{
		CRawClip clipSrc;
		CString strFile = dlgFile.GetFileName();
		clipSrc.LoadFromFile(GloveUtil::ToChar(strFile));

		CString strBeg, strEnd;
		GetDlgItem(IDC_EDIT_ITP_BEG)->GetWindowText(strBeg);
		GetDlgItem(IDC_EDIT_ITP_END)->GetWindowText(strEnd);
		int iBeg = _wtoi(strBeg.GetBuffer());
		int iEnd = _wtoi(strEnd.GetBuffer());

		CRawClip* pClipRaw = dynamic_cast<CRawClip*>(m_pClip);
		if(pClipRaw == NULL)
			return;

		/***********some other functionality************************************
		for(int i = iBeg; i <=iEnd; ++i)
			pClipRaw->m_arFrame[i] = clipSrc.m_arFrame[i];*/

		CRawClip clipOtherHandness = pClipRaw->SwapHandness();
		clipOtherHandness.SaveToFile(GloveUtil::ToChar(strFile));


		/*for(int i = iBeg; i <=iEnd; ++i)
		{
			CRawFrame frmRaw = pClipRaw->m_arFrame[i];
			frmRaw.m_arData[0] -= -42.11995;
			frmRaw.m_arData[1] -= -26.9888;
			frmRaw.m_arData[2] -= -0.4092;
			frmRaw.m_arData[3] -= 34.47009;
			frmRaw.m_arData[4] -= -14.4402;

			//index
			frmRaw.m_arData[7] -= 0.2517;
			frmRaw.m_arData[8] -= 24.26366;
			frmRaw.m_arData[9] -= 4.6771;
			//frmRaw.m_arData[10] -= -0.95942;
			frmRaw.m_arData[10] = -5.9 + (frmRaw.m_arData[10] + 5.9) * 2;
			
			//mid
			frmRaw.m_arData[14] -= -14.8511;
			frmRaw.m_arData[15] -= 11.85707;
			frmRaw.m_arData[16] = -0.0563417 + (frmRaw.m_arData[16] - 0.810168) * 2.2;

			//ring
			frmRaw.m_arData[19] -= -11.22046;
			frmRaw.m_arData[20] -= -23.8125;
			frmRaw.m_arData[21] -= -30.7937;
			//frmRaw.m_arData[22] -= -20.6117;			
			frmRaw.m_arData[22] = -42.353 + (frmRaw.m_arData[22] + 73.1467) * 0.5;


			//pinky
			frmRaw.m_arData[25] -= -13.912533;
			frmRaw.m_arData[26] -= -34.2916;
			frmRaw.m_arData[27] -= -21.9071;
			//frmRaw.m_arData[28] -= 0.325;
			frmRaw.m_arData[28] = -37 + (frmRaw.m_arData[28] + 37) * 0.5;

			pClipRaw->m_arFrame[i] = frmRaw;
		}*/

		//pClipRaw->SaveToFile(GloveUtil::ToChar(strFile));
	}
}

void CGlovePlayDlg::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: Add your message handler code here and/or call default
	switch(nChar)
	{
		if(nChar == 'a')
			break;
	
	}

	CDialog::OnKeyDown(nChar, nRepCnt, nFlags);
}
BOOL CGlovePlayDlg::PreTranslateMessage(MSG* pMsg)
{
	/*if(pMsg->message==WM_KEYDOWN)
	{
		CString strCurFrame = L"";
		CEdit* pEdit;
		int iLength = 1;
		if(m_pClip==NULL)
			return FALSE;

		switch(pMsg->wParam)
		{
		case VK_LEFT:
				m_iCurFrameIdx = max(m_iCurFrameIdx-1, 0);
				strCurFrame.Format(L"%d", m_iCurFrameIdx);
				pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FRAME);
				pEdit->SetWindowText(strCurFrame);
				UpdateCurFrame();
				m_wndOpenGL.Invalidate();
				 return TRUE;
		case VK_RIGHT:
				if(m_pClip)
					iLength = m_pClip->GetFrameCount();
				m_iCurFrameIdx = min(m_iCurFrameIdx+1, iLength-1);
				strCurFrame.Format(L"%d", m_iCurFrameIdx);
				pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FRAME);
				pEdit->SetWindowText(strCurFrame);
				UpdateCurFrame();
				m_wndOpenGL.Invalidate();
				return TRUE;
		case VK_UP:
				m_iCurFrameIdx = max(m_iCurFrameIdx-10, 0);
				strCurFrame.Format(L"%d", m_iCurFrameIdx);
				pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FRAME);
				pEdit->SetWindowText(strCurFrame);
				UpdateCurFrame();
				m_wndOpenGL.Invalidate();
				return TRUE;
		case VK_DOWN:
				if(m_pClip)
					iLength = m_pClip->GetFrameCount();
				m_iCurFrameIdx = min(m_iCurFrameIdx+10, iLength-1);
				strCurFrame.Format(L"%d", m_iCurFrameIdx);
				pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FRAME);
				pEdit->SetWindowText(strCurFrame);
				UpdateCurFrame();
				m_wndOpenGL.Invalidate();
				return TRUE;
		}
	}*/
	return FALSE;
}
