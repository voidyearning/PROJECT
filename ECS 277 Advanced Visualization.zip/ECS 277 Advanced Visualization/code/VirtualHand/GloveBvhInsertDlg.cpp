// GloveBvhInsertDlg.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "GloveBvhInsertDlg.h"


// CGloveBvhInsertDlg dialog

IMPLEMENT_DYNAMIC(CGloveBvhInsertDlg, CDialog)

CGloveBvhInsertDlg::CGloveBvhInsertDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGloveBvhInsertDlg::IDD, pParent)
{

}

CGloveBvhInsertDlg::~CGloveBvhInsertDlg()
{
}

void CGloveBvhInsertDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CGloveBvhInsertDlg, CDialog)
	ON_BN_CLICKED(IDC_RADIO_LEFT, &CGloveBvhInsertDlg::OnBnClickedRadioLeft)
	ON_BN_CLICKED(IDC_RADIO_RIGHT, &CGloveBvhInsertDlg::OnBnClickedRadioRight)
	ON_EN_CHANGE(IDC_EDIT_START, &CGloveBvhInsertDlg::OnEnChangeEditStart)
	ON_EN_CHANGE(IDC_EDIT_END, &CGloveBvhInsertDlg::OnEnChangeEditEnd)
END_MESSAGE_MAP()

BOOL CGloveBvhInsertDlg::OnInitDialog()
{
	CListBox* pList = (CListBox*) GetDlgItem(IDC_LIST_BVH);
	for(int i = 0; i < m_glvInsert.GetBvhDataSize(); ++i)
	{
		CString strIdx = L"";
		strIdx.Format(L"%d:\t", i);
		pList->AddString(strIdx + m_glvInsert.GetBvhDataNameAt(i));
	}
	CButton* pRadio = (CButton*)GetDlgItem(IDC_RADIO_LEFT);
	pRadio->SetCheck(1);
	return TRUE;

}
// CGloveBvhInsertDlg message handlers

void CGloveBvhInsertDlg::OnBnClickedRadioLeft()
{
	// TODO: Add your control notification handler code here
}

void CGloveBvhInsertDlg::OnBnClickedRadioRight()
{
	// TODO: Add your control notification handler code here
}

void CGloveBvhInsertDlg::OnEnChangeEditStart()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}

void CGloveBvhInsertDlg::OnEnChangeEditEnd()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}
