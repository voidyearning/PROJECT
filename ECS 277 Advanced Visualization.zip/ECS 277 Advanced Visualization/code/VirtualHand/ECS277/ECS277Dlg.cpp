// ECS277Dlg.cpp : implementation file
//

#include "..\stdafx.h"
#include "..\VirtualHand.h"
#include "ECS277Dlg.h"
#include "..\GloveUtil.h"


// CECS277Dlg dialog

#define TIMER_EVENT_PLAY_CURVE 7
#define TIMER_EVENT_PLAY_CLIP 8

IMPLEMENT_DYNAMIC(CECS277Dlg, CDialog)

CECS277Dlg::CECS277Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CECS277Dlg::IDD, pParent)
{
	m_iPlayCurveIndex = 0;
	m_iPlayClipIndex = 0;

	m_pHR000 = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_pHR001 = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_pHR010 = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_pHR011 = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_pHR100 = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_pHR101 = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_pHR110 = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_pHR111 = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_pHRTrilinear = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_pHRTricubic = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_pHRTruth = new COpenGLHandRendererKin(new CHandSkeletonKin());

	InitCornerHandPose();
}

CECS277Dlg::~CECS277Dlg()
{
}

void CECS277Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CECS277Dlg, CDialog)
	ON_WM_KEYDOWN()	
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_TRICUBIC_CALC64, &CECS277Dlg::OnBnClickedButtonTricubicCalc64)
	ON_BN_CLICKED(IDC_CHECK_CORNERPOSE2, &CECS277Dlg::OnBnClickedCheckCornerpose2)
	ON_BN_CLICKED(IDC_BUTTON_CALC_GRIDPOSES, &CECS277Dlg::OnBnClickedButtonCalcGridposes)
	ON_BN_CLICKED(IDC_CHECK_SHOW_GRID, &CECS277Dlg::OnBnClickedCheckShowGrid)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_CLIP, &CECS277Dlg::OnBnClickedButtonLoadClip)
	ON_BN_CLICKED(IDC_BUTTON_PLAY_CURVE, &CECS277Dlg::OnBnClickedButtonPlayCurve)
	ON_BN_CLICKED(IDC_BUTTON_GENERATE_CURVE, &CECS277Dlg::OnBnClickedButtonGenerateCurve)
	ON_BN_CLICKED(IDC_BUTTON_PLAY_MOTION_CLIP, &CECS277Dlg::OnBnClickedButtonPlayMotionClip)
	ON_BN_CLICKED(IDC_CHECK_SHOW_CUBE, &CECS277Dlg::OnBnClickedCheckShowCube)
	ON_BN_CLICKED(IDC_CHECK_EDIT_CURVE, &CECS277Dlg::OnBnClickedCheckEditCurve)
END_MESSAGE_MAP()

void CECS277Dlg::OnTimer(UINT_PTR nIDEvent)
{
	if (nIDEvent == TIMER_EVENT_PLAY_CURVE)
	{
		KillTimer(TIMER_EVENT_PLAY_CURVE);

		if(m_iPlayCurveIndex < m_wndMorphCube.m_arTrace.size())
		{
			m_iPlayClipIndex = m_iPlayCurveIndex;
			m_wndMorphCube.m_ptCurrent = m_wndMorphCube.m_arTrace[m_iPlayCurveIndex];
			m_wndMorphCube.OnDraw(NULL);
			UpdateToTruth();
			UpdateCurrentPtToUI();
		}

		m_iPlayCurveIndex++;
		if(m_iPlayCurveIndex >= m_wndMorphCube.m_arTrace.size())
		{
			m_iPlayCurveIndex = m_wndMorphCube.m_arTrace.size() -1;
			KillTimer(TIMER_EVENT_PLAY_CURVE);
		}
		else
			SetTimer(TIMER_EVENT_PLAY_CURVE, 30, NULL);

		return;
	}

	if (nIDEvent == TIMER_EVENT_PLAY_CLIP)
	{
		KillTimer(TIMER_EVENT_PLAY_CLIP);

		if(m_iPlayClipIndex < m_clipMotion.m_arFrame.size())
		{
			UpdateToTruth();
		}

		m_iPlayClipIndex++;
		if(m_iPlayClipIndex >= m_clipMotion.m_arFrame.size())
		{
			m_iPlayClipIndex =m_clipMotion.m_arFrame.size() -1;
			KillTimer(TIMER_EVENT_PLAY_CLIP);
		}
		else
			SetTimer(TIMER_EVENT_PLAY_CLIP, 30, NULL);

		return;
	}
}
void CECS277Dlg::SetCornerPose1()
{
	//flat, fist, spread, pointing, thumbup, touching
	CRawClip clipFlat, clipSpread, clipFist, clipPurse, clipThumbUp, clipIndexUp, clipPistol, clipOk, clipVictory;
	clipFlat.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\flat.raw");
	clipSpread.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\spread.raw");
	clipFist.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\fist.raw");
	clipPurse.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\purse.raw");
	clipThumbUp.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\thumbUp.raw");
	clipIndexUp.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\indexUp.raw");
	clipPistol.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\pistol.raw");
	clipOk.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\ok.raw");
	clipVictory.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\victory.raw");

	m_frmPose000 = clipIndexUp.m_arFrame[0];
	m_frmPose001 = clipFist.m_arFrame[0] ;
	m_frmPose010 = clipPistol.m_arFrame[0];
	m_frmPose011 = clipThumbUp.m_arFrame[0];
	
	m_frmPose100 = clipFlat.m_arFrame[0];
	m_frmPose101 = clipPurse.m_arFrame[0];
	m_frmPose110 = clipSpread.m_arFrame[0];
	m_frmPose111 = clipOk.m_arFrame[0];

	m_pHR000->m_pHand->UpdateFromFrame(&m_frmPose000);
	m_wndHand000.OnDraw(NULL);

	m_pHR001->m_pHand->UpdateFromFrame(&m_frmPose001);
	m_wndHand001.OnDraw(NULL);

	m_pHR010->m_pHand->UpdateFromFrame(&m_frmPose010);
	m_wndHand010.OnDraw(NULL);

	m_pHR011->m_pHand->UpdateFromFrame(&m_frmPose011);
	m_wndHand011.OnDraw(NULL);

	m_pHR100->m_pHand->UpdateFromFrame(&m_frmPose100);
	m_wndHand100.OnDraw(NULL);

	m_pHR101->m_pHand->UpdateFromFrame(&m_frmPose101);
	m_wndHand101.OnDraw(NULL);

	m_pHR110->m_pHand->UpdateFromFrame(&m_frmPose110);
	m_wndHand110.OnDraw(NULL);

	m_pHR111->m_pHand->UpdateFromFrame(&m_frmPose111);
	m_wndHand111.OnDraw(NULL);	

	CRawFrame frmTrilinearPose = TriLinearInterpolatePose(m_wndMorphCube.m_ptCurrent);
	m_pHRTrilinear->m_pHand->UpdateFromFrame(&frmTrilinearPose);
	m_wndTrilinear.OnDraw(NULL);

	CalculateTricubicCoef64();
	CRawFrame frmTricubicPose = TriCubicInterpolatePose(m_wndMorphCube.m_ptCurrent);
	m_pHRTricubic->m_pHand->UpdateFromFrame(&frmTricubicPose);
	m_wndTricubic.OnDraw(NULL);
}
void CECS277Dlg::SetCornerPose2()
{	
	//flat, fist, spread, pointing, thumbup, touching
	CRawClip clipFlat, clipSpread, clipFist, clipPurse, clipThumbUp, clipIndexUp, clipPistol, clipOk, clipVictory, clipHorn;
	clipFlat.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\flat.raw");
	clipSpread.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\spread.raw");
	clipFist.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\fist.raw");
	clipPurse.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\purse.raw");
	clipThumbUp.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\thumbUp.raw");
	clipIndexUp.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\indexUp.raw");
	clipPistol.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\pistol.raw");
	clipOk.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\ok.raw");
	clipVictory.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\victory.raw");
	clipHorn.LoadFromFile("K:\\research\\ecs277\\VirtualHandCalib\\VirtualHand\\ECS277\\cornerPoses\\horn.raw");

	m_frmPose000 = clipPistol.m_arFrame[0];
	m_frmPose001 = clipOk.m_arFrame[0] ;
	m_frmPose010 = clipSpread.m_arFrame[0]; 
	m_frmPose011 = clipVictory.m_arFrame[0];
	
	m_frmPose100 = clipHorn.m_arFrame[0];
	m_frmPose101 =  clipThumbUp.m_arFrame[0]; 
	m_frmPose110 = clipIndexUp.m_arFrame[0];
	m_frmPose111 = clipFist.m_arFrame[0];

	m_pHR000->m_pHand->UpdateFromFrame(&m_frmPose000);
	m_wndHand000.OnDraw(NULL);

	m_pHR001->m_pHand->UpdateFromFrame(&m_frmPose001);
	m_wndHand001.OnDraw(NULL);

	m_pHR010->m_pHand->UpdateFromFrame(&m_frmPose010);
	m_wndHand010.OnDraw(NULL);

	m_pHR011->m_pHand->UpdateFromFrame(&m_frmPose011);
	m_wndHand011.OnDraw(NULL);

	m_pHR100->m_pHand->UpdateFromFrame(&m_frmPose100);
	m_wndHand100.OnDraw(NULL);

	m_pHR101->m_pHand->UpdateFromFrame(&m_frmPose101);
	m_wndHand101.OnDraw(NULL);

	m_pHR110->m_pHand->UpdateFromFrame(&m_frmPose110);
	m_wndHand110.OnDraw(NULL);

	m_pHR111->m_pHand->UpdateFromFrame(&m_frmPose111);
	m_wndHand111.OnDraw(NULL);	

	CRawFrame frmTrilinearPose = TriLinearInterpolatePose(m_wndMorphCube.m_ptCurrent);
	m_pHRTrilinear->m_pHand->UpdateFromFrame(&frmTrilinearPose);
	m_wndTrilinear.OnDraw(NULL);

	CalculateTricubicCoef64();
	CRawFrame frmTricubicPose = TriCubicInterpolatePose(m_wndMorphCube.m_ptCurrent);
	m_pHRTricubic->m_pHand->UpdateFromFrame(&frmTricubicPose);
	m_wndTricubic.OnDraw(NULL);

}
void CECS277Dlg::InitCornerHandPose()
{
	SetCornerPose1();
}
BOOL CECS277Dlg::OnInitDialog()
{
	 ((CButton*)GetDlgItem(IDC_CHECK_SHOW_CUBE))->SetCheck(1);

	CRect rcWndHandCorner, rcWndMorphCube, rcMorphCubeRegion;
	::GetClientRect(GetDlgItem(IDC_STATIC_CORNER)->m_hWnd, rcWndHandCorner);	
	::GetClientRect(GetDlgItem(IDC_STATIC_MORPHCUBE)->m_hWnd, rcWndMorphCube);
	::GetClientRect(GetDlgItem(IDC_STATIC_MORPHCUBE_REGION)->m_hWnd, rcMorphCubeRegion);

	//The Cube
	rcWndMorphCube.OffsetRect((rcMorphCubeRegion.left + rcMorphCubeRegion.right - rcWndMorphCube.Width())/2, (rcMorphCubeRegion.top + rcMorphCubeRegion.bottom - rcWndMorphCube.Height())/2);
	m_wndMorphCube.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcWndMorphCube, this, 0);  
	m_wndMorphCube.Invalidate(1);
	m_wndMorphCube.OnDraw(NULL);
	::SetFocus(m_wndMorphCube.m_hWnd);

	//8 Corner Hand Poses
	CRect rcWnd000=rcWndHandCorner;
	rcWnd000.OffsetRect(rcWndMorphCube.left-rcWndHandCorner.Width(), rcWndMorphCube.bottom-rcWndHandCorner.Height());
	m_wndHand000.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcWnd000, this, 0);    
	m_wndHand000.SetRender((COpenGLRenderer*)m_pHR000);	
	m_wndHand000.Invalidate(1);
	::SetFocus(m_wndHand000.m_hWnd);
	
	CRect rcWnd001 = rcWndHandCorner;
	rcWnd001.OffsetRect(rcWndMorphCube.left, rcWndMorphCube.bottom);
	m_wndHand001.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcWnd001, this, 0);    
	m_wndHand001.SetRender((COpenGLRenderer*)m_pHR001);	
	m_wndHand001.Invalidate(1);
	::SetFocus(m_wndHand001.m_hWnd);

	CRect rcWnd010 = rcWndHandCorner;
	rcWnd010.OffsetRect(rcWndMorphCube.left, rcWndMorphCube.top - rcWndHandCorner.Height());	
	m_wndHand010.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcWnd010, this, 0);    
	m_wndHand010.SetRender((COpenGLRenderer*)m_pHR010);
	m_wndHand010.Invalidate(1);
	::BringWindowToTop(m_wndHand010.m_hWnd);

	CRect rcWnd011 = rcWndHandCorner;
	rcWnd011.OffsetRect(rcWndMorphCube.left-rcWndHandCorner.Width(), rcWndMorphCube.top);
	m_wndHand011.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcWnd011, this, 0);    
	m_wndHand011.SetRender((COpenGLRenderer*)m_pHR011);
	m_wndHand011.Invalidate(1);

	CRect rcWnd100=rcWndHandCorner;
	rcWnd100.OffsetRect(rcWndMorphCube.right,rcWndMorphCube.bottom-rcWndHandCorner.Height());
	m_wndHand100.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcWnd100, this, 0);    
	m_wndHand100.SetRender((COpenGLRenderer*)m_pHR100);	
	m_wndHand100.Invalidate(1);
	::SetFocus(m_wndHand100.m_hWnd);
	
	CRect rcWnd101 = rcWndHandCorner;
	rcWnd101.OffsetRect(rcWndMorphCube.right-rcWndHandCorner.Width(), rcWndMorphCube.bottom);
	m_wndHand101.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcWnd101, this, 0);    
	m_wndHand101.SetRender((COpenGLRenderer*)m_pHR101);	
	m_wndHand101.Invalidate(1);
	::SetFocus(m_wndHand101.m_hWnd);

	CRect rcWnd110 = rcWndHandCorner;
	rcWnd110.OffsetRect(rcWndMorphCube.right-rcWndHandCorner.Width(), rcWndMorphCube.top-rcWndHandCorner.Height());	
	m_wndHand110.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcWnd110, this, 0);    
	m_wndHand110.SetRender((COpenGLRenderer*)m_pHR110);
	m_wndHand110.Invalidate(1);
	::BringWindowToTop(m_wndHand110.m_hWnd);

	CRect rcWnd111 = rcWndHandCorner;
	rcWnd111.OffsetRect(rcWndMorphCube.right, rcWndMorphCube.top);
	m_wndHand111.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcWnd111, this, 0);    
	m_wndHand111.SetRender((COpenGLRenderer*)m_pHR111);
	m_wndHand111.Invalidate(1);

	//Interpolated
	CRect rcInterpolated;
	::GetClientRect(GetDlgItem(IDC_STATIC_INTERPOLATED)->m_hWnd, rcInterpolated);
	rcInterpolated.OffsetRect(rcWnd111.right + 250, rcWnd111.top-120);
	m_wndTrilinear.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcInterpolated, this, 0);
	m_wndTrilinear.SetRender((COpenGLRenderer*)m_pHRTrilinear);
	m_wndTrilinear.Invalidate(1);

	rcInterpolated.OffsetRect(0,rcInterpolated.Height());
	m_wndTricubic.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcInterpolated, this, 0);
	m_wndTricubic.SetRender((COpenGLRenderer*)m_pHRTricubic);
	m_wndTricubic.Invalidate(1);

	//truth
	CRect rcTruth = rcInterpolated;
	rcTruth.OffsetRect(0, rcInterpolated.Height());
	m_wndTruth.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcTruth, this, 0);
	m_wndTruth.m_bShowHand = false;
	m_wndTruth.SetRender((COpenGLRenderer*)m_pHRTruth);
	m_wndTruth.Invalidate(1);

	UpdateCurrentPtToUI();
	return TRUE;
}
// CECS277Dlg message handlers
BOOL CECS277Dlg::PreTranslateMessage(MSG* pMsg)
{
	BOOL bProcessed = FALSE;
	if(pMsg->message==WM_KEYDOWN)
	{
		int iKeyStateX = ::GetKeyState('x') + ::GetKeyState('X');//return value: -127 down, -128 down+toggled
		int iKeyStateY = ::GetKeyState('y') + ::GetKeyState('Y');
		int iKeyStateZ = ::GetKeyState('z') + ::GetKeyState('Z');
		int iKeyStateLeft = ::GetKeyState(VK_LEFT);
		int iKeyStateRight = ::GetKeyState(VK_RIGHT);
		if (iKeyStateX<0)
		{
			if(iKeyStateRight<0)
			{
				if(!m_wndMorphCube.m_bEditTrace)
					m_wndMorphCube.m_ptCurrent.s_fX = min(1, m_wndMorphCube.m_ptCurrent.s_fX + 0.02);
				else
					m_wndMorphCube.ShiftTrace(0.02, 0, 0);
				m_wndMorphCube.OnDraw(NULL);
				UpdateCurrentPtToUI();
				bProcessed = TRUE;
			}

			if(iKeyStateLeft<0)
			{
				if(!m_wndMorphCube.m_bEditTrace)
					m_wndMorphCube.m_ptCurrent.s_fX = max(0, m_wndMorphCube.m_ptCurrent.s_fX - 0.02);
				else
					m_wndMorphCube.ShiftTrace(-0.02, 0, 0);
				m_wndMorphCube.OnDraw(NULL);
				UpdateCurrentPtToUI();
				bProcessed = TRUE;
			}
		}

		if (iKeyStateY<0)
		{
			if(iKeyStateRight<0)
			{
				if(!m_wndMorphCube.m_bEditTrace)
					m_wndMorphCube.m_ptCurrent.s_fY = min(1, m_wndMorphCube.m_ptCurrent.s_fY + 0.02);
				else
					m_wndMorphCube.ShiftTrace(0, 0.02, 0);
				m_wndMorphCube.OnDraw(NULL);
				UpdateCurrentPtToUI();
				bProcessed = TRUE;
			}
			if(iKeyStateLeft<0)
			{
				if(!m_wndMorphCube.m_bEditTrace)
					m_wndMorphCube.m_ptCurrent.s_fY = max(0, m_wndMorphCube.m_ptCurrent.s_fY - 0.02);
				else
					m_wndMorphCube.ShiftTrace(0,-0.02, 0);
				m_wndMorphCube.OnDraw(NULL);
				UpdateCurrentPtToUI();
				bProcessed = TRUE;
			}
		}

		if (iKeyStateZ<0)
		{
			if(iKeyStateRight<0)
			{
				if(!m_wndMorphCube.m_bEditTrace)
					m_wndMorphCube.m_ptCurrent.s_fZ = min(1, m_wndMorphCube.m_ptCurrent.s_fZ + 0.02);
				else
					m_wndMorphCube.ShiftTrace(0,0,0.02);
				m_wndMorphCube.OnDraw(NULL);
				UpdateCurrentPtToUI();
				bProcessed = TRUE;
			}
			if(iKeyStateLeft<0)
			{
				if(!m_wndMorphCube.m_bEditTrace)
					m_wndMorphCube.m_ptCurrent.s_fZ = max(0, m_wndMorphCube.m_ptCurrent.s_fZ - 0.02);
				else
					m_wndMorphCube.ShiftTrace(0,0,-0.02);
				m_wndMorphCube.OnDraw(NULL);
				UpdateCurrentPtToUI();
				bProcessed = TRUE;
			}
		}
	}	
	return bProcessed;
}
void CECS277Dlg::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	int iShiftState = ::GetKeyState(VK_SHIFT) ;
	
	if( nChar == 'X' && nChar == VK_ADD ) m_wndMorphCube.m_ptCurrent.s_fX += 0.05;
	if( nChar == 'Y' && nChar == VK_ADD )	 m_wndMorphCube.m_ptCurrent.s_fY += 0.05;
	if( nChar == 'Z' && nChar == VK_ADD ) m_wndMorphCube.m_ptCurrent.s_fZ += 0.05;

	if( nChar == 'X' && nChar == VK_SUBTRACT ) m_wndMorphCube.m_ptCurrent.s_fX -= 0.05;
	if( nChar == 'Y' && nChar == VK_SUBTRACT ) m_wndMorphCube.m_ptCurrent.s_fY -= 0.05;
	if( nChar == 'Z' && nChar == VK_SUBTRACT ) m_wndMorphCube.m_ptCurrent.s_fZ -= 0.05;
	
	m_wndMorphCube.OnDraw(NULL);
	Invalidate(TRUE);

	CDialog::OnKeyDown(nChar, nRepCnt, nFlags);
}
void CECS277Dlg::UpdateToTruth()
{
	if(m_iPlayClipIndex >= m_clipMotion.m_arFrame.size())
		return;

	CRawFrame frmTruth = m_clipMotion.m_arFrame[m_iPlayClipIndex];
	CString strTruth = L"";
	strTruth.Format(L"truth joint rotations:\r\n\r\nthumb:\r\n%.2f,%.2f,%.2f,%.2f,%.2f\r\nindex:\r\n%.2f,%.2f,%.2f,%.2f\r\nmid:\r\n%.2f,%.2f,%.2f,%.2f\r\nring:\r\n%.2f,%.2f,%.2f,%.2f\r\npinky:\r\n%.2f,%.2f,%.2f,%.2f",
		frmTruth.m_arData[0],frmTruth.m_arData[1],frmTruth.m_arData[2],frmTruth.m_arData[3],frmTruth.m_arData[4],
		frmTruth.m_arData[7],frmTruth.m_arData[8],frmTruth.m_arData[9],frmTruth.m_arData[10],
		frmTruth.m_arData[13],frmTruth.m_arData[14],frmTruth.m_arData[15],frmTruth.m_arData[16],
		frmTruth.m_arData[19],frmTruth.m_arData[20],frmTruth.m_arData[21],frmTruth.m_arData[22],
		frmTruth.m_arData[25],frmTruth.m_arData[26],frmTruth.m_arData[27],frmTruth.m_arData[28]);
	GetDlgItem(IDC_STATIC_TRUTH_ROTATIONS)->SetWindowTextW(strTruth);
	m_pHRTruth->m_pHand->UpdateFromFrame(&frmTruth);
	m_wndTruth.m_bShowHand = true;
	m_wndTruth.OnDraw(NULL);
}
void CECS277Dlg::UpdateCurrentPtToUI()
{
	CString strUI = L"";
	strUI.Format(L"current position (x, y, z):\r\n(%.3f, %.3f, %.3f)", m_wndMorphCube.m_ptCurrent.s_fX, m_wndMorphCube.m_ptCurrent.s_fY, m_wndMorphCube.m_ptCurrent.s_fZ);
	GetDlgItem(IDC_STATIC_CURRENT_POS)->SetWindowTextW(strUI);

	CRawFrame frmTrilinearPose = TriLinearInterpolatePose(m_wndMorphCube.m_ptCurrent);
	CString strTrilinear = L"";
	strTrilinear.Format(L"trilinear joint rotations:\r\n\r\nthumb:\r\n%.2f,%.2f,%.2f,%.2f,%.2f\r\nindex:\r\n%.2f,%.2f,%.2f,%.2f\r\nmid:\r\n%.2f,%.2f,%.2f,%.2f\r\nring:\r\n%.2f,%.2f,%.2f,%.2f\r\npinky:\r\n%.2f,%.2f,%.2f,%.2f",
		frmTrilinearPose.m_arData[0],frmTrilinearPose.m_arData[1],frmTrilinearPose.m_arData[2],frmTrilinearPose.m_arData[3],frmTrilinearPose.m_arData[4],
		frmTrilinearPose.m_arData[7],frmTrilinearPose.m_arData[8],frmTrilinearPose.m_arData[9],frmTrilinearPose.m_arData[10],
		frmTrilinearPose.m_arData[13],frmTrilinearPose.m_arData[14],frmTrilinearPose.m_arData[15],frmTrilinearPose.m_arData[16],
		frmTrilinearPose.m_arData[19],frmTrilinearPose.m_arData[20],frmTrilinearPose.m_arData[21],frmTrilinearPose.m_arData[22],
		frmTrilinearPose.m_arData[25],frmTrilinearPose.m_arData[26],frmTrilinearPose.m_arData[27],frmTrilinearPose.m_arData[28]);
	GetDlgItem(IDC_STATIC_TRILINEAR_ROTATIONS)->SetWindowTextW(strTrilinear);
	m_pHRTrilinear->m_pHand->UpdateFromFrame(&frmTrilinearPose);
	m_wndTrilinear.OnDraw(NULL);

	CRawFrame frmTricubicPose = TriCubicInterpolatePose(m_wndMorphCube.m_ptCurrent);
	CString strTricubic = L"";
	strTricubic.Format(L"tricubic joint rotations:\r\n\r\nthumb:\r\n%.2f,%.2f,%.2f,%.2f,%.2f\r\nindex:\n%.2f,%.2f,%.2f,%.2f\r\nmid:\r\n%.2f,%.2f,%.2f,%.2f\r\nring:\r\n%.2f,%.2f,%.2f,%.2f\r\npinky:\r\n%.2f,%.2f,%.2f,%.2f",
		frmTricubicPose.m_arData[0],frmTricubicPose.m_arData[1],frmTricubicPose.m_arData[2],frmTricubicPose.m_arData[3],frmTricubicPose.m_arData[4],
		frmTricubicPose.m_arData[7],frmTricubicPose.m_arData[8],frmTricubicPose.m_arData[9],frmTricubicPose.m_arData[10],
		frmTricubicPose.m_arData[13],frmTricubicPose.m_arData[14],frmTricubicPose.m_arData[15],frmTricubicPose.m_arData[16],
		frmTricubicPose.m_arData[19],frmTricubicPose.m_arData[20],frmTricubicPose.m_arData[21],frmTricubicPose.m_arData[22],
		frmTricubicPose.m_arData[25],frmTricubicPose.m_arData[26],frmTricubicPose.m_arData[27],frmTricubicPose.m_arData[28]);
	GetDlgItem(IDC_STATIC_TRICUBIC_ROTATIONS)->SetWindowTextW(strTricubic);
	m_pHRTricubic->m_pHand->UpdateFromFrame(&frmTricubicPose);
	m_wndTricubic.OnDraw(NULL);
}

CRawFrame CECS277Dlg::TriLinearInterpolatePose(SPoint3D ptPos)
{
	CRawFrame frmPose00;
	for(int i = 0; i < 31; ++i)
	{
		float fRotation = (1-ptPos.s_fX) * m_frmPose000.m_arData[i] + ptPos.s_fX * m_frmPose100.m_arData[i];
		frmPose00.m_arData.push_back(fRotation);
	}

	CRawFrame frmPose01;
	for(int i = 0; i < 31; ++i)
	{
		float fRotation = (1-ptPos.s_fX) * m_frmPose001.m_arData[i] + ptPos.s_fX * m_frmPose101.m_arData[i];
		frmPose01.m_arData.push_back(fRotation);
	}

	CRawFrame frmPose10;
	for(int i = 0; i < 31; ++i)
	{
		float fRotation = (1-ptPos.s_fX) * m_frmPose010.m_arData[i] + ptPos.s_fX * m_frmPose110.m_arData[i];
		frmPose10.m_arData.push_back(fRotation);
	}

	CRawFrame frmPose11;
	for(int i = 0; i < 31; ++i)
	{
		float fRotation = (1-ptPos.s_fX) * m_frmPose011.m_arData[i] + ptPos.s_fX * m_frmPose111.m_arData[i];
		frmPose11.m_arData.push_back(fRotation);
	}

	CRawFrame frmPose0;
	for(int i = 0; i < 31; ++i)
	{
		float fRotation = (1-ptPos.s_fY) * frmPose00.m_arData[i] + ptPos.s_fY * frmPose10.m_arData[i];
		frmPose0.m_arData.push_back(fRotation);
	}

	CRawFrame frmPose1;
	for(int i = 0; i < 31; ++i)
	{
		float fRotation = (1-ptPos.s_fY) * frmPose01.m_arData[i] + ptPos.s_fY * frmPose11.m_arData[i];
		frmPose1.m_arData.push_back(fRotation);
	}

	CRawFrame frmResult;
	for(int i = 0; i < 31; ++i)
	{
		float fRotation = (1-ptPos.s_fZ) * frmPose0.m_arData[i] + ptPos.s_fZ * frmPose1.m_arData[i];
		frmResult.m_arData.push_back(fRotation);
	}
	return frmResult;
}

int fac(int n)
{
	int iResult=1;
	for(int i = n; i > 0; -- i)
		iResult = iResult * i;
	return iResult;
}
float bigB(int i, float x)
{
	int fac_i = fac(i);
	int fac_3_i = fac(3 - i);
	int fac_3 = fac(3);
	
	float fpow_1_x = pow(1-x, 3 - i);
	float fpow_x = pow(x, i);

	return (fac_3 * fpow_1_x * fpow_x) / (fac_i * fac_3_i);
}
CRawFrame CECS277Dlg::TriCubicInterpolatePose(SPoint3D ptPos)
{
	CRawFrame frmResult = CRawFrame::GetEmptyFrame();
	for(int i = 0; i < 4; ++ i)
	{
		for(int j = 0; j < 4; ++ j)
		{
			for(int k = 0; k < 4; ++ k)
			{
				float fBi = bigB(i, ptPos.s_fX);
				float fBj = bigB(j, ptPos.s_fY);
				float fBk = bigB(k, ptPos.s_fZ);
				float fB=fBi * fBj * fBk;

				frmResult = frmResult + (m_frmTricubic_b[i][j][k] * fB);
			}
		}
	}
	return frmResult;
}
void CECS277Dlg::CalculateTricubicCoef64()
{
	m_frmTricubic_b[0][0][0] = m_frmPose000;
	m_frmTricubic_b[0][0][1] = m_frmPose000 + (m_frmPose001 - m_frmPose000) / 3;
    m_frmTricubic_b[0][1][0] = m_frmPose000 + (m_frmPose010 - m_frmPose000) / 3;
    m_frmTricubic_b[0][1][1] = m_frmPose000 + (m_frmPose010 - m_frmPose000) /3 + (m_frmPose001 - m_frmPose000) / 3;
    m_frmTricubic_b[1][0][0] = m_frmPose000 + (m_frmPose100 - m_frmPose000) / 3;
    m_frmTricubic_b[1][0][1] = m_frmPose000 + (m_frmPose100 - m_frmPose000) / 3 + (m_frmPose001 - m_frmPose000) / 3;    
    m_frmTricubic_b[1][1][0] = m_frmPose000 + (m_frmPose100 - m_frmPose000) / 3 + (m_frmPose010 - m_frmPose000) /3;
    m_frmTricubic_b[1][1][1] = m_frmPose000 + (m_frmPose100 - m_frmPose000) / 3 + (m_frmPose010 - m_frmPose000) / 3 + (m_frmPose001 - m_frmPose000) / 3;

    m_frmTricubic_b[3][0][0] = m_frmPose100;
    m_frmTricubic_b[3][0][1] = m_frmPose100 + (m_frmPose101 - m_frmPose100) / 3;
    m_frmTricubic_b[2][0][1] = m_frmPose100 + (m_frmPose000 - m_frmPose100) / 3 + (m_frmPose101 - m_frmPose100) / 3;
    m_frmTricubic_b[2][0][0] = m_frmPose100 + (m_frmPose000 - m_frmPose100) / 3;
    m_frmTricubic_b[3][1][0] = m_frmPose100 + (m_frmPose110 - m_frmPose100) /3;
    m_frmTricubic_b[3][1][1] = m_frmPose100 + (m_frmPose110 - m_frmPose100) / 3 + (m_frmPose101 - m_frmPose100) / 3;
    m_frmTricubic_b[2][1][1] = m_frmPose100 + (m_frmPose000 - m_frmPose100) / 3 + (m_frmPose110 - m_frmPose100) / 3 + (m_frmPose101 - m_frmPose100) / 3;
    m_frmTricubic_b[2][1][0] = m_frmPose100 + (m_frmPose000 - m_frmPose100) / 3 + (m_frmPose101 - m_frmPose100) /3;

    m_frmTricubic_b[0][3][0] = m_frmPose010;
    m_frmTricubic_b[1][3][0] = m_frmPose010 + (m_frmPose110 - m_frmPose010) / 3;
    m_frmTricubic_b[1][3][1] = m_frmPose010 + (m_frmPose110 - m_frmPose010) / 3 + (m_frmPose011 - m_frmPose010) / 3;
    m_frmTricubic_b[0][3][1] = m_frmPose010 + (m_frmPose011 - m_frmPose010) / 3;
    m_frmTricubic_b[0][2][0] = m_frmPose010 + (m_frmPose000 - m_frmPose010) / 3;
    m_frmTricubic_b[1][2][0] = m_frmPose010 + (m_frmPose110 - m_frmPose010) / 3 + (m_frmPose000 - m_frmPose010) / 3;
    m_frmTricubic_b[1][2][1] = m_frmPose010 + (m_frmPose110 - m_frmPose010) / 3 + (m_frmPose000 - m_frmPose010) / 3 + (m_frmPose011 - m_frmPose010) / 3;
    m_frmTricubic_b[0][2][1] = m_frmPose010 + (m_frmPose000 - m_frmPose010) /3 + (m_frmPose011 - m_frmPose010) / 3;

    m_frmTricubic_b[3][3][0] = m_frmPose110;
    m_frmTricubic_b[3][3][1] = m_frmPose110 + (m_frmPose111 - m_frmPose110) / 3;
    m_frmTricubic_b[2][3][1] = m_frmPose110 + (m_frmPose010 - m_frmPose110) / 3 + (m_frmPose111 - m_frmPose110) / 3;
    m_frmTricubic_b[2][3][0] = m_frmPose110 + (m_frmPose010 - m_frmPose110) / 3;
    m_frmTricubic_b[3][2][0] = m_frmPose110 + (m_frmPose100 - m_frmPose110) / 3;
    m_frmTricubic_b[3][2][1] = m_frmPose110 + (m_frmPose100 - m_frmPose110) / 3 + (m_frmPose111 - m_frmPose110) / 3;
    m_frmTricubic_b[2][2][1] = m_frmPose110 + (m_frmPose010 - m_frmPose110) / 3 + (m_frmPose100 - m_frmPose110) / 3 + (m_frmPose111 - m_frmPose110) / 3;
    m_frmTricubic_b[2][2][0] = m_frmPose110 + (m_frmPose010 - m_frmPose110) / 3 + (m_frmPose100 - m_frmPose110) / 3;

    m_frmTricubic_b[0][0][3] = m_frmPose001;
    m_frmTricubic_b[1][0][3] = m_frmPose001 + (m_frmPose101 - m_frmPose001) / 3;
    m_frmTricubic_b[1][0][2] = m_frmPose001 + (m_frmPose101 - m_frmPose001) / 3 + (m_frmPose000 - m_frmPose001) / 3;
    m_frmTricubic_b[0][0][2] = m_frmPose001 + (m_frmPose000 - m_frmPose001) / 3;
    m_frmTricubic_b[0][1][3] = m_frmPose001 + (m_frmPose011 - m_frmPose001) / 3;
    m_frmTricubic_b[1][1][3] = m_frmPose001 + (m_frmPose101 - m_frmPose001) / 3 + (m_frmPose011 - m_frmPose001) / 3;
    m_frmTricubic_b[1][1][2] = m_frmPose001 + (m_frmPose101 - m_frmPose001) / 3 + (m_frmPose011 - m_frmPose001) / 3 - (m_frmPose000 - m_frmPose001) / 3;
    m_frmTricubic_b[0][1][2] = m_frmPose001 + (m_frmPose011 - m_frmPose001) / 3 + (m_frmPose000 - m_frmPose001) / 3;

    m_frmTricubic_b[3][0][3] = m_frmPose101;    
    m_frmTricubic_b[3][0][2] = m_frmPose101 + (m_frmPose100 - m_frmPose101) / 3;  
    m_frmTricubic_b[2][0][2] = m_frmPose101 + (m_frmPose001 - m_frmPose101) / 3 + (m_frmPose100 - m_frmPose101) / 3;
    m_frmTricubic_b[2][0][3] = m_frmPose101 + (m_frmPose001 - m_frmPose101) / 3;
    m_frmTricubic_b[3][1][3] = m_frmPose101 + (m_frmPose111 - m_frmPose101) / 3;
    m_frmTricubic_b[3][1][2] = m_frmPose101 + (m_frmPose111 - m_frmPose101) / 3 + (m_frmPose100 - m_frmPose101) / 3;
    m_frmTricubic_b[2][1][2] = m_frmPose101 + (m_frmPose001 - m_frmPose101) / 3 + (m_frmPose111 - m_frmPose101) / 3 + (m_frmPose100 - m_frmPose101) / 3;
    m_frmTricubic_b[2][1][3] = m_frmPose101 + (m_frmPose001 - m_frmPose101) / 3 + (m_frmPose111 - m_frmPose101) / 3;

    m_frmTricubic_b[0][3][3] = m_frmPose011;    
    m_frmTricubic_b[1][3][3] = m_frmPose011 + (m_frmPose111 - m_frmPose011)  / 3;
    m_frmTricubic_b[1][3][2] = m_frmPose011 + (m_frmPose111 - m_frmPose011) / 3 + (m_frmPose010 - m_frmPose011) / 3;
    m_frmTricubic_b[0][3][2] = m_frmPose011 + (m_frmPose010 - m_frmPose011) / 3;
    m_frmTricubic_b[0][2][3] = m_frmPose011 + (m_frmPose001 - m_frmPose011) / 3;
    m_frmTricubic_b[1][2][3] = m_frmPose011 + (m_frmPose111 - m_frmPose011) / 3 + (m_frmPose001 - m_frmPose011) / 3;
    m_frmTricubic_b[1][2][2] = m_frmPose011 + (m_frmPose111 - m_frmPose011) / 3 + (m_frmPose001 - m_frmPose011) / 3 + (m_frmPose010 - m_frmPose011) / 3;
    m_frmTricubic_b[0][2][2] = m_frmPose011 + (m_frmPose001 - m_frmPose011) / 3 + (m_frmPose010 - m_frmPose011) / 3;

    m_frmTricubic_b[3][3][3] = m_frmPose111;
    m_frmTricubic_b[3][3][2] = m_frmPose111 + (m_frmPose110 - m_frmPose111) / 3;
    m_frmTricubic_b[2][3][2] = m_frmPose111 + (m_frmPose011 - m_frmPose111) / 3 + (m_frmPose110 - m_frmPose111) /3;
    m_frmTricubic_b[2][3][3] = m_frmPose111 + (m_frmPose011 - m_frmPose111) / 3;
    m_frmTricubic_b[3][2][3] = m_frmPose111 + (m_frmPose101 - m_frmPose111) / 3;
    m_frmTricubic_b[3][2][2] = m_frmPose111 + (m_frmPose101 - m_frmPose111) / 3 + (m_frmPose110 - m_frmPose111) / 3;
    m_frmTricubic_b[2][2][2] = m_frmPose111 + (m_frmPose011 - m_frmPose111) / 3 + (m_frmPose101 - m_frmPose111) / 3 + (m_frmPose110 - m_frmPose111) / 3;
    m_frmTricubic_b[2][2][3] = m_frmPose111 + (m_frmPose011 - m_frmPose111) / 3 + (m_frmPose101 - m_frmPose111) / 3;
}

void CECS277Dlg::CalculateGridPoses()
{
	for(int i = 0; i <=10; ++i)
	{
		for(int j = 0; j <= 10; ++j)
		{
			for(int k = 0; k <= 10; ++k)
			{
				SPoint3D pos;
				pos.s_fX = i * 0.1;
				pos.s_fY = j * 0.1;
				pos.s_fZ = k * 0.1;
				CRawFrame frmGrid = TriLinearInterpolatePose(pos);
				m_frmGrid[i][j][k] = frmGrid;
			}
		}
	}
}
void CECS277Dlg::OnBnClickedButtonTricubicCalc64()
{
	CalculateTricubicCoef64();
}

void CECS277Dlg::OnBnClickedCheckCornerpose2()
{
	int iCorner2 = ((CButton*)GetDlgItem(IDC_CHECK_CORNERPOSE2))->GetCheck();
	if (iCorner2 > 0)
		SetCornerPose2();
	else
		SetCornerPose1();
}

void CECS277Dlg::OnBnClickedButtonCalcGridposes()
{
	CalculateGridPoses();
}

void CECS277Dlg::OnBnClickedCheckShowGrid()
{
	int iChecked = ((CButton*)GetDlgItem(IDC_CHECK_SHOW_GRID))->GetCheck();
	m_wndMorphCube.m_bMorphGridOn = (iChecked > 0) ? true : false;
	m_wndMorphCube.OnDraw(NULL);
}

void CECS277Dlg::OnBnClickedButtonLoadClip()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw||");
	if(IDOK == dlgFile.DoModal())
	{
		m_clipMotion.LoadFromFile(GloveUtil::ToChar(dlgFile.GetPathName()));
		m_wndTruth.m_bShowHand = true;
		m_iPlayClipIndex = 0;
		UpdateToTruth();
	}	
}
SPoint3D CECS277Dlg::FindGridPose(CRawFrame frmPose)
{
	SPoint3D ptMin;
	float fMinDistance = 999999999;
	for(int i = 0; i <= 10; ++i)
	{
		for(int j = 0; j <= 10; ++j)
		{
			for(int k = 0; k <=10; ++k)
			{
				float fDistance = frmPose.DistanceTo(m_frmGrid[i][j][k]);
				if(fDistance < fMinDistance)
				{
					fMinDistance = fDistance;
					ptMin.s_fX = i;
					ptMin.s_fY = j;
					ptMin.s_fZ = k;
				}
			}
		}
	}
	return ptMin;
}
void CECS277Dlg::GenerateCurveFromMotionClip(CRawClip clipMotion)
{
	//1. find the grid point first
	std::vector<SPoint3D> arPtIndex;
	m_wndMorphCube.m_arTrace.clear();
	for(int i = 0; i < clipMotion.m_arFrame.size(); ++i)
	{
		SPoint3D ptIndexPos = FindGridPose(clipMotion.m_arFrame[i]);
		arPtIndex.push_back(ptIndexPos);

		SPoint3D ptInCubePos;
		ptInCubePos.s_fX = ptIndexPos.s_fX / 10.0;
		ptInCubePos.s_fY = ptIndexPos.s_fY / 10.0;
		ptInCubePos.s_fZ = ptIndexPos.s_fZ /10.0;
		m_wndMorphCube.m_arTrace.push_back(ptInCubePos);
		m_wndMorphCube.OnDraw(NULL);
	}

	//2. smooth the curve
	int iFirstIdx=0;
	for(int i = 0; i < clipMotion.m_arFrame.size(); ++i)
	{
		SPoint3D ptIndexCur = arPtIndex[i];
		SPoint3D ptIndexFirst = arPtIndex[iFirstIdx];
		if(ptIndexCur.s_fX == ptIndexFirst.s_fX && 
			ptIndexCur.s_fY == ptIndexFirst.s_fY &&
			ptIndexCur.s_fZ == ptIndexFirst.s_fZ)
			continue;

		if(i - iFirstIdx <= 1)
			continue;

		SPoint3D ptInCubeFirst, ptInCubeCur;
		ptInCubeFirst.s_fX = m_wndMorphCube.m_arTrace[iFirstIdx].s_fX;
		ptInCubeFirst.s_fY = m_wndMorphCube.m_arTrace[iFirstIdx].s_fY;
		ptInCubeFirst.s_fZ = m_wndMorphCube.m_arTrace[iFirstIdx].s_fZ;
		ptInCubeCur.s_fX = m_wndMorphCube.m_arTrace[i].s_fX;
		ptInCubeCur.s_fY = m_wndMorphCube.m_arTrace[i].s_fY;
		ptInCubeCur.s_fZ = m_wndMorphCube.m_arTrace[i].s_fZ;

		for(int j = iFirstIdx+1; j < i; ++j)
		{
			float fDistToFirst = clipMotion.m_arFrame[j].DistanceTo(clipMotion.m_arFrame[iFirstIdx]);
			float fDistToCur = clipMotion.m_arFrame[j].DistanceTo(clipMotion.m_arFrame[i]);
			float fRatio = fDistToFirst / (fDistToFirst + fDistToCur);
			SPoint3D ptInCubePos;
			ptInCubePos.s_fX = ptInCubeFirst.s_fX * (1 - fRatio) + ptInCubeCur.s_fX * fRatio;
			ptInCubePos.s_fY = ptInCubeFirst.s_fY * (1 - fRatio) + ptInCubeCur.s_fY * fRatio;
			ptInCubePos.s_fZ = ptInCubeFirst.s_fZ * (1 - fRatio) + ptInCubeCur.s_fZ * fRatio;
			m_wndMorphCube.m_arTrace[j] = ptInCubePos;
			m_wndMorphCube.OnDraw(NULL);
		}
		iFirstIdx = i;
	}		
}
void CECS277Dlg::OnBnClickedButtonPlayCurve()
{
	m_iPlayCurveIndex = 0;
	m_iPlayClipIndex = 0;
	SetTimer(TIMER_EVENT_PLAY_CURVE, 30, NULL);
}

void CECS277Dlg::OnBnClickedButtonGenerateCurve()
{
	GenerateCurveFromMotionClip(m_clipMotion);
}

void CECS277Dlg::OnBnClickedButtonPlayMotionClip()
{
	m_iPlayClipIndex = 0;
	SetTimer(TIMER_EVENT_PLAY_CLIP, 30, NULL);
}

void CECS277Dlg::OnBnClickedCheckShowCube()
{
	int iChecked = ((CButton*)GetDlgItem(IDC_CHECK_SHOW_CUBE))->GetCheck();
	m_wndMorphCube.m_bShowCube = (iChecked > 0) ? true : false;
	m_wndMorphCube.OnDraw(NULL);
}

void CECS277Dlg::OnBnClickedCheckEditCurve()
{
	int iChecked = ((CButton*)GetDlgItem(IDC_CHECK_EDIT_CURVE))->GetCheck();
	m_wndMorphCube.m_bEditTrace = (iChecked > 0) ? true : false;
	m_wndMorphCube.OnDraw(NULL);
}
