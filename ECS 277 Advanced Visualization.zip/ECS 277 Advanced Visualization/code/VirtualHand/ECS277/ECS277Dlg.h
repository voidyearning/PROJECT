#pragma once
#include "..\RawAnimation.h"
#include "..\OpenGLWnd.h"
#include "..\GloveAnimation.h"
#include "..\resource.h"
#include "OpenGLMorphCubeWnd.h"

// CECS277Dlg dialog

struct SViewPoint
{
	int s_iXmin;
	int s_iXmax;
	int s_iYmin;
	int s_iYmax;
	int s_iZmin;
	int s_iZmax;

	double s_dXOffset;
	double s_dYOffset;

	double s_dXAngle;
	double s_dYAngle;
	double s_dZAngle;
};

class CECS277Dlg : public CDialog
{
	DECLARE_DYNAMIC(CECS277Dlg)

public:
	CECS277Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CECS277Dlg();	
	virtual BOOL OnInitDialog();
	void InitCornerHandPose();

	COpenGLMorphCubeWnd m_wndMorphCube;
	COpenGLWnd m_wndHand000;
	COpenGLWnd m_wndHand001;
	COpenGLWnd m_wndHand010;
	COpenGLWnd m_wndHand011;	
	COpenGLWnd m_wndHand100;
	COpenGLWnd m_wndHand101;
	COpenGLWnd m_wndHand110;
	COpenGLWnd m_wndHand111;
	COpenGLWnd m_wndTrilinear;
	COpenGLWnd m_wndTricubic;
	COpenGLWnd m_wndTruth;

	COpenGLHandRendererKin* m_pHR000;
	COpenGLHandRendererKin* m_pHR001;
	COpenGLHandRendererKin* m_pHR010;
	COpenGLHandRendererKin* m_pHR011;
	COpenGLHandRendererKin* m_pHR100;
	COpenGLHandRendererKin* m_pHR101;
	COpenGLHandRendererKin* m_pHR110;
	COpenGLHandRendererKin* m_pHR111;
	COpenGLHandRendererKin* m_pHRTrilinear;
	COpenGLHandRendererKin* m_pHRTricubic;
	COpenGLHandRendererKin* m_pHRTruth;

	CRawFrame m_frmPose000;
	CRawFrame m_frmPose001;
	CRawFrame m_frmPose010;
	CRawFrame m_frmPose011;
	CRawFrame m_frmPose100;
	CRawFrame m_frmPose101;
	CRawFrame m_frmPose110;
	CRawFrame m_frmPose111;

	CRawFrame m_frmTricubic_b[4][4][4];
	CRawFrame m_frmGrid[11][11][11];
	CRawClip m_clipMotion;

	SViewPoint m_sViewPoint;
	int m_iPlayCurveIndex;
	int m_iPlayClipIndex;

// Dialog Data
	enum { IDD = IDD_DIALOG_ECS277 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	BOOL PreTranslateMessage(MSG* pMsg);
	void UpdateCurrentPtToUI();
	void UpdateToTruth();
	CRawFrame TriLinearInterpolatePose(SPoint3D ptPos);
	CRawFrame TriCubicInterpolatePose(SPoint3D ptPos);
	void CalculateTricubicCoef64();
	void CalculateGridPoses();
	void GenerateCurveFromMotionClip(CRawClip clipMotion);
	SPoint3D FindGridPose(CRawFrame frmPose);
	afx_msg void OnBnClickedButtonTricubicCalc64();
	void SetCornerPose1();
	void SetCornerPose2();
	afx_msg void OnBnClickedCheckCornerpose2();
	afx_msg void OnBnClickedButtonCalcGridposes();
	afx_msg void OnBnClickedCheckShowGrid();
	afx_msg void OnBnClickedButtonLoadClip();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonPlayCurve();
	afx_msg void OnBnClickedButtonGenerateCurve();
	afx_msg void OnBnClickedButtonPlayMotionClip();
	afx_msg void OnBnClickedCheckShowCube();
	afx_msg void OnBnClickedCheckEditCurve();
};
