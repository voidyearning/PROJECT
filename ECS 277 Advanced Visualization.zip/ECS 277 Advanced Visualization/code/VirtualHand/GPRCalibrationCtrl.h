#pragma once


// CGPRCalibrationCtrl dialog

class CGPRCalibrationCtrl : public CDialog
{
	DECLARE_DYNAMIC(CGPRCalibrationCtrl)

public:
	CGPRCalibrationCtrl(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGPRCalibrationCtrl();

// Dialog Data
	enum { IDD = IDD_CTRL_GPR_CALIBRATION };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonBrowseLmcgprDir();
	afx_msg void OnBnClickedButtonLoadLmcgprModel();
	afx_msg void OnBnClickedButtonBrowseSpgpsDir();
	afx_msg void OnBnClickedButtonLoadSpgpsModel();
};
