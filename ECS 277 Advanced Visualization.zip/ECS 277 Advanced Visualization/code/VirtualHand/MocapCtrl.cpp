// MocapCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "MocapCtrl.h"
#include "stdio.h"
#include "GloveMocapMgr.h"
#include "GloveUtil.h"


#define TIMER_EVENT_MOCAP	15
// CMocapCtrl dialog

IMPLEMENT_DYNAMIC(CMocapCtrl, CDialog)

CMocapCtrl::CMocapCtrl(CWnd* pParent /*=NULL*/)
	: CDialog(CMocapCtrl::IDD, pParent)
{
	m_pGlvMgrLeft = CGloveMocapMgr::GetGloveMgr(LEFT_HAND);
	m_pGlvMgrRight = CGloveMocapMgr::GetGloveMgr(RIGHT_HAND);
	m_iHandness = 0;
}

CMocapCtrl::~CMocapCtrl()
{
}

void CMocapCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CMocapCtrl::OnInitDialog()
{
	CComboBox* pComboFreq = (CComboBox*)GetDlgItem(IDC_COMBO_MOCAP_FREQ);
	if(pComboFreq)
	{
		pComboFreq->AddString(L"30");
		pComboFreq->AddString(L"45");		
		pComboFreq->AddString(L"60");		
		pComboFreq->AddString(L"90");		
		pComboFreq->AddString(L"120");
		pComboFreq->SelectString(0, L"30");
	}
	((CButton*)GetDlgItem(IDC_RADIO_MOCAP_LEFT_HAND))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_RADIO_MOCAP_RIGHT_HAND))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_RADIO_MOCAP_BOTH_HANDS))->SetCheck(1);

	TCHAR arDir[256] = L"\0";
	int iLenDir = ::GetCurrentDirectory(256, arDir);
	CString	strFile(arDir, iLenDir);
	GetDlgItem(IDC_EDIT_MOCAP_HOME_DIR)->SetWindowText(strFile);

	GetDlgItem(IDC_EDIT_MOCAP_SESSION_NAME)->SetWindowText(L"glvCap");
	GetDlgItem(IDC_BUTTON_MOCAP_STOP)->EnableWindow(FALSE);
	return CDialog::OnInitDialog();
}

BEGIN_MESSAGE_MAP(CMocapCtrl, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_MOCAP_HOME_DIR, &CMocapCtrl::OnBnClickedButtonMocapHomeDir)
	ON_BN_CLICKED(IDC_RADIO_MOCAP_BOTH_HANDS, &CMocapCtrl::OnBnClickedRadioMocapBothHands)
	ON_BN_CLICKED(IDC_RADIO_MOCAP_LEFT_HAND, &CMocapCtrl::OnBnClickedRadioMocapLeftHand)
	ON_BN_CLICKED(IDC_RADIO_MOCAP_RIGHT_HAND, &CMocapCtrl::OnBnClickedRadioMocapRightHand)
	ON_CBN_SELCHANGE(IDC_COMBO_MOCAP_FREQ, &CMocapCtrl::OnCbnSelchangeComboMocapFreq)
	ON_BN_CLICKED(IDC_BUTTON_MOCAP_START, &CMocapCtrl::OnBnClickedButtonMocapStart)
	ON_BN_CLICKED(IDC_BUTTON_MOCAP_STOP, &CMocapCtrl::OnBnClickedButtonMocapStop)
	ON_WM_TIMER()
END_MESSAGE_MAP()


void CMocapCtrl::OnBnClickedButtonMocapHomeDir()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MOCAP_HOME_DIR);
	CString strPath = GloveUtil::ShowFolderDlg(L"Home directory of captured glove data");
	pEdit->SetWindowText(strPath);
}

void CMocapCtrl::OnBnClickedRadioMocapBothHands()
{
	m_iHandness = 0;
}

void CMocapCtrl::OnBnClickedRadioMocapLeftHand()
{
	m_iHandness = 1;
}

void CMocapCtrl::OnBnClickedRadioMocapRightHand()
{
	m_iHandness = 2;
}

void CMocapCtrl::OnCbnSelchangeComboMocapFreq()
{
	CComboBox* pComboFreq = (CComboBox*)GetDlgItem(IDC_COMBO_FREQ);
	switch(pComboFreq->GetCurSel())
	{
	case 0: m_iFreq_ms = 30;
		break;
	case 1: m_iFreq_ms = 45;
		break;
	case 2: m_iFreq_ms = 60;
		break;
	case 3: m_iFreq_ms = 90;
		break;
	case 4: m_iFreq_ms = 120;
		break;
	default: m_iFreq_ms = 30;
	}
}

void CMocapCtrl::OnBnClickedButtonMocapStart()
{
	GetDlgItem(IDC_BUTTON_MOCAP_START)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_MOCAP_STOP)->EnableWindow(TRUE);

	CString strHome, strSession;
	GetDlgItem(IDC_EDIT_MOCAP_HOME_DIR)->GetWindowText(strHome);
	GetDlgItem(IDC_EDIT_MOCAP_SESSION_NAME)->GetWindowText(strSession);
    CString strName_l = strHome + L"\\" + strSession + L"_l.glv";
	CString strName_r = strHome + L"\\" + strSession + L"_r.glv";
	m_pGlvMgrLeft->SetName(GloveUtil::ToChar(strName_l));
	m_pGlvMgrRight->SetName(GloveUtil::ToChar(strName_r));
	
	switch(m_iHandness)
	{		
	case 0:
		if(!m_pGlvMgrLeft->IsConnected())
			m_pGlvMgrLeft->Connect();
		if(!m_pGlvMgrRight->IsConnected())
			m_pGlvMgrRight->Connect();
		break;
	case 1:
		if(!m_pGlvMgrLeft->IsConnected())
			m_pGlvMgrLeft->Connect();
		break;
	case 2:
		if(!m_pGlvMgrRight->IsConnected())
			m_pGlvMgrRight->Connect();
		break;
	}
	
	SetTimer(TIMER_EVENT_MOCAP, m_iFreq_ms, NULL);
}

void CMocapCtrl::OnBnClickedButtonMocapStop()
{	
	KillTimer(TIMER_EVENT_MOCAP);
	GetDlgItem(IDC_BUTTON_MOCAP_START)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUTTON_MOCAP_STOP)->EnableWindow(FALSE);

	string strMsg = "";
	switch(m_iHandness)
	{
	case 1:
		strMsg = m_pGlvMgrLeft->EndRecord();
		break;
	case 2:
		strMsg = m_pGlvMgrRight->EndRecord();
		break;
	case 0:
		strMsg = m_pGlvMgrRight->EndRecord();
		strMsg += m_pGlvMgrLeft->EndRecord();
	}
	CString strMsg2(strMsg.c_str());
	GetDlgItem(IDC_STATIC_MOCAP_MSG)->SetWindowText(strMsg2);
}

void CMocapCtrl::OnTimer(UINT_PTR nIDEvent)
{
	switch(m_iHandness)
	{
	case 1:
		m_pGlvMgrLeft->RecordData();
		break;
	case 2:
		m_pGlvMgrRight->RecordData();
		break;
	case 0:
		m_pGlvMgrLeft->RecordData();
		m_pGlvMgrRight->RecordData();
	}

	CDialog::OnTimer(nIDEvent);
}
