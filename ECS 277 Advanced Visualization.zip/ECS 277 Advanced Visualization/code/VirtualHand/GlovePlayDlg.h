#pragma once
#include "GloveAnimation.h"
#include "GloveRenderer.h"
#include "OpenGLWnd.h"
#include "resource.h"
#include "PtTrajRenderer.h"

#define TIMER_EVENT_ID2	2
class CGlovePlayDlg : public CDialog
{
// Construction
public:
	CGlovePlayDlg(CWnd* pParent = NULL);
	~CGlovePlayDlg(void);

	COpenGLWnd m_wndOpenGL;
	COpenGLHandRendererKin* m_pHandRenderer;
	std::vector<	CPtTrajRenderer*>  m_arEndEffectorTrajRenderer;
	CPtTrajRenderer* m_pMaxProbTrajRenderer;
	CPtTrajRenderer* m_pCOMTrajRenderer;

	CBaseClip* m_pClip;
	int m_iCurFrameIdx;	
	bool m_bPaused;
	bool m_bFPSOriginal;
	float m_fFPS;

	bool m_bCalibrateClip;

	void PlayCurFrame();
	void UpdateCurFrame();
	void RefreshPlay();
	enum { IDD = IDD_GLOVEPLAY_DIALOG };
protected:
	virtual void DoDataExchange(CDataExchange* pDX);

protected:
	HICON m_hIcon;

	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCheckShowOrigin();
	afx_msg void OnBnClickedCheckWireframe();
	afx_msg void OnBnClickedButtonSizefile();
	afx_msg void OnBnClickedButtonMotionfile();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedCheckLighting();
	afx_msg void OnBnClickedRadioFront();
	afx_msg void OnBnClickedRadioLeft();
	afx_msg void OnBnClickedRadioTop();
	afx_msg void OnBnClickedButtonPlay();
	afx_msg void OnBnClickedButtonBeginning();
	afx_msg void OnBnClickedButtonBackward();
	afx_msg void OnBnClickedButtonStop();
	afx_msg void OnBnClickedButtonForward();
	afx_msg void OnBnClickedButtonEnding();
	afx_msg void OnEnChangeEditFrame();
	afx_msg void OnBnClickedCheckOriginalFps();
	afx_msg void OnBnClickedButtonLoadFrame();
	afx_msg void OnBnClickedRadioLefthand();
	afx_msg void OnBnClickedRadioRighthand();
	afx_msg void OnBnClickedButtonKinProp();
	afx_msg void OnBnClickedButtonPlayTouch();
	afx_msg void OnBnClickedButtonViewAve();
	afx_msg void OnBnClickedButtonCurFrame();
	afx_msg void OnBnClickedButtonSaveMotion();
	afx_msg void OnBnClickedCheckActiveThumb();
	afx_msg void OnBnClickedCheckActiveIndex();
	afx_msg void OnBnClickedCheckActiveMid();
	afx_msg void OnBnClickedCheckActiveRing();
	afx_msg void OnBnClickedCheckActivePinky();
	afx_msg void OnBnClickedCheckShowProb();
	afx_msg void OnEnChangeEditProbValveMin();
	afx_msg void OnBnClickedCheckShowHand();
	afx_msg void OnEnChangeEditRangeStepSize();
	afx_msg void OnBnClickedButtonRecalProb();
	afx_msg void OnBnClickedButtonLoadProbFrame();
	afx_msg void OnBnClickedButtonSaveProbFrame();
	afx_msg void OnEnChangeEditProbValveMax();
	afx_msg void OnEnChangeEditRenderRangeMin();
	afx_msg void OnEnChangeEditRenderRangeMax();
	afx_msg void OnNMCustomdrawSliderProbSize(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedCheckRenderOriginalCalculated();
	afx_msg void OnEnChangeEditRenderValve();
	afx_msg void OnBnClickedCheckShowEndTraj();
	afx_msg void OnBnClickedCheckShowMaxProbTraj();
	afx_msg void OnNMCustomdrawSliderEndTrajSize(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnEnChangeEditColorEndTraj();
	afx_msg void OnEnChangeEditColorMaxProbTraj();
	afx_msg void OnBnClickedCheckDiscreteEndTraj();
	afx_msg void OnBnClickedCheckDiscreteMaxProbTraj();
	afx_msg void OnNMCustomdrawSliderMaxProbTrajSize(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedButtonRecalEndTraj();
	afx_msg void OnBnClickedButtonRecalMaxRpobTraj();
	afx_msg void OnEnChangeEditTrajBegIdx();
	afx_msg void OnEnChangeEditTrajEndIdx();
	afx_msg void OnBnClickedCheckShowComTraj();
	afx_msg void OnNMCustomdrawSliderComTrajSize(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnEnChangeEditColorComTraj();
	afx_msg void OnBnClickedCheckDiscreteComTraj();
	afx_msg void OnBnClickedButtonRecalComTraj();
	afx_msg void OnEnChangeEditLightPos();
	afx_msg void OnEnChangeEditThumbColor();
	afx_msg void OnEnChangeEditIndexColor();
	afx_msg void OnEnChangeEditMidColor();
	afx_msg void OnEnChangeEditRingColor();
	afx_msg void OnEnChangeEditPinkyColor();
	afx_msg void OnBnClickedButtonCalibrateFkIndependent();
	afx_msg void OnBnClickedCheckCalibrateClip();
	afx_msg void OnBnClickedButtonSavePose();
	afx_msg void OnBnClickedButtonCalibrateFkFull();
	afx_msg void OnBnClickedButtonCalibrateFkFitc();
	afx_msg void OnBnClickedButtonCalibrateFitc();
	afx_msg void OnBnClickedButtonCalibrateFull();
	afx_msg void OnBnClickedCheckThumbRollActive();
	afx_msg void OnBnClickedCheckThumbAbdActive();
	afx_msg void OnBnClickedCheckThumbVirtualActive();
	afx_msg void OnBnClickedCheckThumbInnerFlexActive();
	afx_msg void OnBnClickedCheckThumbDistFlexActive();
	afx_msg void OnBnClickedButtonCalibrateThumbFull();
	afx_msg void OnBnClickedButtonWatchDataRedundant();
	afx_msg void OnBnClickedButtonRefresh();
	afx_msg void OnBnClickedButtonWatchDataNonRedundant();
	afx_msg void OnBnClickedButtonWatchOrderedByThumb();
	afx_msg void OnBnClickedButtonCalibrateFingerabdFull();
	afx_msg void OnBnClickedButtonFindCloseInput();
	afx_msg void OnBnClickedButtonThumbCopyPrev();
	afx_msg void OnBnClickedButtonNormalizeWrist();
	afx_msg void OnBnClickedButtonAddOffset();
	afx_msg void OnBnClickedButtonCopyThumbFrom();
	afx_msg void OnBnClickedButtonSuppressOverbend();
	afx_msg void OnBnClickedButtonItp();
	afx_msg void OnBnClickedButtonMulCoef();
	afx_msg void OnBnClickedCheck2radian();
	afx_msg void OnBnClickedButtonExportTrj();
	afx_msg void OnBnClickedButtonExportRot();
	afx_msg void OnBnClickedButtonExportFingertipDistance();
	afx_msg void OnBnClickedButtonExportBvh();
	afx_msg void OnBnClickedButtonImportFramesFrom();
	afx_msg void OnBnClickedButtonCalibrateFingerflexFull();
	afx_msg void OnBnClickedButtonCalibrateFullSimple();
	afx_msg void OnBnClickedButtonCalibrateFitcSimple();
	afx_msg void OnBnClickedButtonRescale();
	afx_msg void OnBnClickedButtonCopyFrom();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	BOOL PreTranslateMessage(MSG* pMsg);
};
