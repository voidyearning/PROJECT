#pragma once
#include <vector>
#include "CRenderer.h"
enum FINGER_TYPE
{
	THUMB,
	INDEX,
	MIDDLE,
	RING,
	PINKY, 
	GENERAL
};

class CFingerSkeleton
{
public:	
	CFingerSkeleton();
	void Init();
	FINGER_TYPE m_eType;

	//3DOF each finger
	float m_fMPJ;
	float m_fPIJ;
	float m_fDIJ;
	float m_fAbd;

	float m_fEndLen;
	float m_fMidLen;
	float m_fTipLen;
	
	void Update(float fMPJ, float fPIJ, float fDIJ, float fAbd, float fELen, float fMLen, float fTLen);
	void Update(float fMPJ, float fPIJ, float fDIJ, float fAbd);
};
class CHandSkeleton
{
public:
	CHandSkeleton();
	~CHandSkeleton();
	std::vector<float> m_arData;//here's store the angles from sensor readings

	CFingerSkeleton* m_pSkelThumb;
	CFingerSkeleton* m_pSkelIndex;
	CFingerSkeleton* m_pSkelMiddle;
	CFingerSkeleton* m_pSkelRing;
	CFingerSkeleton* m_pSkelPinky;	

	float m_fToThumb;
	float m_fToIndex;
	float m_fToMiddle;
	float m_fToRing;
	float m_fToPinky;

	//these angles are fixed as rigid palm, just customizable for different people's hand
	float m_fPalmThumbAbd;
	float m_fPalmIndexAbd;
	float m_fPalmMiddleAbd;
	float m_fPalmRingAbd;
	float m_fPalmPinkyAbd;
	float m_fPalmThumbRoll;

	float m_fWristAbd;
	float m_fWristFlex;
	bool m_bRightHand;


	void Init();
	void InitSize();
	void InitMotion();
	void InitMotionLeft();
	void InitMotionRight();
	void Update(std::vector<float> arData);
	void Update();

	void LoadSizeFromFile(CString strPath);
	void SaveSizeToFile(CString strPath);
};

//do not new m_pFinger, do not delete m_pFinger
class COpenGLFingerRenderer : public COpenGLRenderer
{
public:
	COpenGLFingerRenderer();
	COpenGLFingerRenderer(CFingerSkeleton* pFinger);
	~COpenGLFingerRenderer();
	void SetFinger(CFingerSkeleton* pFinger);
	virtual void Render();	
	void SetWireframe(bool bWireframe);
private:
	CFingerSkeleton* m_pFinger;
	float m_fJointSize;
	bool m_bWireframe;
};

//do not new m_pHand, do not delete m_pHand
class COpenGLHandRenderer : COpenGLRenderer
{
public:
	COpenGLHandRenderer();
	COpenGLHandRenderer(CHandSkeleton* pHand);
	virtual ~COpenGLHandRenderer();

	void SetHand(CHandSkeleton* pHand);
	void SetWireframe(bool bWireframe);
	void UpdateHand(std::vector<float> arData);
	virtual void Render();

	CHandSkeleton* m_pHand;
	float m_fJointSize;
	bool m_bWireframe;

	COpenGLFingerRenderer* m_pThumbRenderer;
	COpenGLFingerRenderer* m_pIndexRenderer;
	COpenGLFingerRenderer* m_pMiddleRenderer;
	COpenGLFingerRenderer* m_pRingRenderer;
	COpenGLFingerRenderer* m_pPinkyRenderer;
};
