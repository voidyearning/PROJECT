#pragma once
#include <string>
#include <vector>
#include <string>

class CMarkerPosition
{
public:
	CMarkerPosition();
	CMarkerPosition(float fX, float fY, float fZ);
	CMarkerPosition vecNormalize() const;
	CMarkerPosition Negate() const;
	CMarkerPosition Multiply(float fCoef) const;
	CMarkerPosition DivideBy(float fCoef) const;
	CMarkerPosition Add(CMarkerPosition posToAdd) const;
	CMarkerPosition Substract(CMarkerPosition posToSub) const;
	float DotMul(CMarkerPosition posToMul) const;
	CMarkerPosition XMul(CMarkerPosition posToMul) const;
	float Cosine(CMarkerPosition vecAnother) const;
	float vecLength() const;

	float m_fX;
	float m_fY;
	float m_fZ;
};

class CMarkersFrame
{
public:
	CMarkersFrame();
	CMarkersFrame(CString strLine);
	std::vector<CMarkerPosition> m_arMarkers;
	CMarkersFrame ViconEVTransformCoord();
	void MM2CM();
	float m_fTime;
};

class CMarkersClip
{
public:
	CMarkersClip();
	std::vector<CMarkersFrame> m_arFrame;
	CMarkersClip ViconEVTransformCoord();
	void LoadFromFile(std::string strPath);
	void SaveToFile(std::string strPath);
	void MM2CM();
};