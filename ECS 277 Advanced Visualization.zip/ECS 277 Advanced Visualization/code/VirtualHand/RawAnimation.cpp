#include "stdafx.h"
#include "RawAnimation.h"
#include <fstream>
#include "math.h"
#include "GloveUtil.h"


CRawFrame::CRawFrame()
{
}
CRawFrame::CRawFrame(const std::vector<float>& arData)
{
	m_arData.clear();
	for(int i = 0; i < arData.size(); ++i)
		m_arData.push_back(arData[i]);
}

bool CRawFrame::operator == (const CRawFrame& frame)
{
	if(m_arData.size() != frame.m_arData.size())
		return false;
	for(int i = 0; i < m_arData.size(); ++i)
	{
		if(m_arData[i] != frame.m_arData[i])
			return false;
	}
	return true;
}

CRawFrame CRawFrame::operator+(const CRawFrame& frame)
{
	CRawFrame frmResult;
	for(int i = 0; i < m_arData.size(); ++i)
		frmResult.m_arData.push_back(m_arData[i] + frame.m_arData[i]);
	return frmResult;
}
CRawFrame CRawFrame::operator-(const CRawFrame& frame)
{
	CRawFrame frmResult;
	for(int i = 0; i < m_arData.size(); ++i)
		frmResult.m_arData.push_back(m_arData[i] - frame.m_arData[i]);
	return frmResult;
}
CRawFrame CRawFrame::operator/(float fDiv)
{
	CRawFrame frmResult;
	if(fDiv == 0)
		return frmResult;

	for(int i = 0; i < m_arData.size(); ++i)
		frmResult.m_arData.push_back(m_arData[i]/fDiv);
	return frmResult;
}
CRawFrame CRawFrame::operator*(float fMul)
{
	CRawFrame frmResult;
	for(int i = 0; i < m_arData.size(); ++i)
		frmResult.m_arData.push_back(m_arData[i] * fMul);
	return frmResult;
}
float CRawFrame::DistanceToThumbHD(CRawFrame& frmRaw)
{
	float fDist = 0;
	if(m_arData.size() < 5 || frmRaw.m_arData.size() < 5)
		return fDist;

	fDist = (m_arData[0] - frmRaw.m_arData[0]) * (m_arData[0] - frmRaw.m_arData[0]);
	fDist += (m_arData[1] - frmRaw.m_arData[1]) * (m_arData[1] - frmRaw.m_arData[1]);
	fDist += (m_arData[2] - frmRaw.m_arData[2]) * (m_arData[2] - frmRaw.m_arData[2]);
	fDist += (m_arData[3] - frmRaw.m_arData[3]) * (m_arData[3] - frmRaw.m_arData[3]);
	fDist += (m_arData[4] - frmRaw.m_arData[4]) * (m_arData[4] - frmRaw.m_arData[4]);

	fDist += (m_arData[8] - frmRaw.m_arData[8]) * (m_arData[8] - frmRaw.m_arData[8]);
	fDist += (m_arData[14] - frmRaw.m_arData[14]) * (m_arData[14] - frmRaw.m_arData[14]);
	fDist += (m_arData[20] - frmRaw.m_arData[20]) * (m_arData[20] - frmRaw.m_arData[20]);
	fDist += (m_arData[26] - frmRaw.m_arData[26]) * (m_arData[26] - frmRaw.m_arData[26]);
	fDist = sqrt(fDist);
	return fDist;
}
float CRawFrame::DistanceTo(CRawFrame& frmRaw)
{
	float fResult = 0;
	for(int i = 0; i < 31; ++i)
	{
		fResult = fResult + (m_arData[i] - frmRaw.m_arData[i]) * (m_arData[i] - frmRaw.m_arData[i]);
	}
	fResult = sqrt(fResult);
	return fResult;
}
float CRawFrame::DistanceToThumb(CRawFrame& frmRaw)
{
	float fDist = 0;
	if(m_arData.size() < 5 || frmRaw.m_arData.size() < 5)
		return fDist;

	fDist = (m_arData[0] - frmRaw.m_arData[0]) * (m_arData[0] - frmRaw.m_arData[0]);
	fDist += (m_arData[1] - frmRaw.m_arData[1]) * (m_arData[1] - frmRaw.m_arData[1]);
	fDist += (m_arData[2] - frmRaw.m_arData[2]) * (m_arData[2] - frmRaw.m_arData[2]);
	fDist += (m_arData[3] - frmRaw.m_arData[3]) * (m_arData[3] - frmRaw.m_arData[3]);
	fDist += (m_arData[4] - frmRaw.m_arData[4]) * (m_arData[4] - frmRaw.m_arData[4]);
	fDist = sqrt(fDist);
	return fDist;
}
CRawFrame CRawFrame::GetEmptyFrame(int iDataNum)
{
	CRawFrame frmEmpty;
	for(int i = 0; i < iDataNum; ++ i)
		frmEmpty.m_arData.push_back(0);
	return frmEmpty;
}

void CRawFrame::ZeroWristRotations()
{
	if(m_arData.size() < HAND_SKEL_DOF_DATA_SIZE)
		return;

	m_arData[HAND_SKEL_DOF_WRIST_FLEX] = 0;
	m_arData[HAND_SKEL_DOF_WRIST_ABD] = 0;
}

void CRawFrame::ZeroFingerFlex()
{
	m_arData[8] = 0;
	m_arData[9] = 0;
	m_arData[10] = 0;

	m_arData[14] = 0;
	m_arData[15] = 0;
	m_arData[16] = 0;

	m_arData[20] = 0;
	m_arData[21] = 0;
	m_arData[22] = 0;

	m_arData[26] = 0;
	m_arData[27] = 0;
	m_arData[28] = 0;
}
float CRawFrame::GetRotationAngle(int iKinIndex, bool bLeft)
{
	switch(iKinIndex)
	{
	case HAND_SKEL_DOF_THUMB_ABD: return GetAbductionJiajiao(E_THUMB_INDEX, bLeft);
	case HAND_SKEL_DOF_INDEX_ABD: return GetAbductionJiajiao(E_INDEX_MID, bLeft);
	case HAND_SKEL_DOF_MID_ABD: return m_arData[iKinIndex];//should be always 0
	case HAND_SKEL_DOF_RING_ABD: return GetAbductionJiajiao(E_MID_RING, bLeft);
	case HAND_SKEL_DOF_PINKY_ABD: return GetAbductionJiajiao(E_RING_PINKY, bLeft);
	default: return m_arData[iKinIndex];
	}
}
void CRawFrame::SetRotationAngle(int iKinIndex, float fRotationAngle, bool bLeft)
{
	switch(iKinIndex)
	{
	case HAND_SKEL_DOF_THUMB_ABD: SetAbductionJiajiao(E_THUMB_INDEX, fRotationAngle, bLeft); break;
	case HAND_SKEL_DOF_INDEX_ABD: SetAbductionJiajiao(E_INDEX_MID, fRotationAngle, bLeft); break;
	case HAND_SKEL_DOF_MID_ABD: m_arData[iKinIndex]; break;
	case HAND_SKEL_DOF_RING_ABD: SetAbductionJiajiao(E_MID_RING, fRotationAngle, bLeft); break;
	case HAND_SKEL_DOF_PINKY_ABD: SetAbductionJiajiao(E_RING_PINKY, fRotationAngle, bLeft); break;
	default: m_arData[iKinIndex] = fRotationAngle;
	}
}

//sensor is jiajiao, kinematic is kjiao
//that is: jiajiao (index 15, 0) = kjiao (index 0, -15) + palm_abd_kjiao (15)
//->     : kjiao = jiajiao - palm_abd_kjiao
//zhuyi:  jiajiao rengran you zhengfu de
float CRawFrame::GetAbductionJiajiao(E_ABDUCTION_TYPE eType, bool bLeft)
{
	switch(eType)
	{
	case E_THUMB_INDEX: return m_arData[HAND_SKEL_DOF_THUMB_ABD];
	case E_INDEX_MID: return m_arData[HAND_SKEL_DOF_INDEX_ABD] + m_arData[HAND_SKEL_DOF_INDEX_ABD_PALM]; 
	case E_MID_RING: return m_arData[HAND_SKEL_DOF_RING_ABD] + m_arData[HAND_SKEL_DOF_RING_ABD_PALM];
	case E_RING_PINKY: return m_arData[HAND_SKEL_DOF_PINKY_ABD] + m_arData[HAND_SKEL_DOF_PINKY_ABD_PALM];
	}
	return 0;
}
void CRawFrame::SetAbductionJiajiao(E_ABDUCTION_TYPE eType, float fAbdSensor, bool bLeft)
{
	switch(eType)
	{
		case E_THUMB_INDEX:  m_arData[HAND_SKEL_DOF_THUMB_ABD] = fAbdSensor; break;
		case E_INDEX_MID: m_arData[HAND_SKEL_DOF_INDEX_ABD] = fAbdSensor - m_arData[HAND_SKEL_DOF_INDEX_ABD_PALM]; break;
		case E_MID_RING: m_arData[HAND_SKEL_DOF_RING_ABD] = fAbdSensor - m_arData[HAND_SKEL_DOF_RING_ABD_PALM]; break;
		case E_RING_PINKY:	 m_arData[HAND_SKEL_DOF_PINKY_ABD] = fAbdSensor - m_arData[HAND_SKEL_DOF_PINKY_ABD_PALM]; break;
	}
}
void CRawFrame::SuppressOverbendSigmoid(bool bLeft, int iDOFIndex, float fMin, float fMax)
{
	if(iDOFIndex < 0 || iDOFIndex >= m_arData.size())
		return;

	float fInput = m_arData[iDOFIndex];
	if( fInput <= fMax && fInput >= fMin)
		return;

	float fRange = fMax - fMin;

	if(fInput > fMax)
	{
		float fDeci = 1 + exp(-(fInput-fMax));
		float fNum = 0.1 * fRange;
		float fResult = fNum / fDeci + (fMax - 0.05 * fRange);
		m_arData[iDOFIndex] = fResult;
		return;
	}

	if(fInput < fMin)
	{
		float fDeci = 1 + exp(-(fInput-fMin));
		float fNum = 0.1 * fRange;
		float fResult = fNum / fDeci + (fMin - 0.05 * fRange);
		m_arData[iDOFIndex] = fResult;
		return;
	}
}
void CRawFrame::SuppressOverbend(bool bLeft, float fIndexExt, float fMidExt, float fRingExt, float fPinkyExt)
{
	m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX] = min(m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX], fIndexExt);
	m_arData[HAND_SKEL_DOF_MID_FLEX_PROX] = min(m_arData[HAND_SKEL_DOF_MID_FLEX_PROX], fMidExt);
	m_arData[HAND_SKEL_DOF_RING_FLEX_PROX] = min(m_arData[HAND_SKEL_DOF_RING_FLEX_PROX], fRingExt);
	m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX] = min(m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX], fPinkyExt);

	m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID] = min(m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID], 0.5 * fIndexExt);
	m_arData[HAND_SKEL_DOF_MID_FLEX_MID] = min(m_arData[HAND_SKEL_DOF_MID_FLEX_MID], 0.5 * fMidExt);
	m_arData[HAND_SKEL_DOF_RING_FLEX_MID] = min(m_arData[HAND_SKEL_DOF_RING_FLEX_MID], 0.5 * fRingExt);
	m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID] = min(m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID], 0.5 * fPinkyExt);	
}
CRawFrame CRawFrame::SwapHandness() const
{
	CRawFrame frmResult;
	frmResult = *this;
	frmResult.m_arData[0] = - frmResult.m_arData[0];
	frmResult.m_arData[1] = - frmResult.m_arData[1];
	frmResult.m_arData[2] = - frmResult.m_arData[2];

	frmResult.m_arData[5] = - frmResult.m_arData[5];
	frmResult.m_arData[7] = - frmResult.m_arData[7];

	frmResult.m_arData[11] = - frmResult.m_arData[11];
	frmResult.m_arData[13] = - frmResult.m_arData[13];

	frmResult.m_arData[17] = - frmResult.m_arData[17];
	frmResult.m_arData[19] = - frmResult.m_arData[19];

	frmResult.m_arData[23] = - frmResult.m_arData[23];
	frmResult.m_arData[25] = - frmResult.m_arData[25];

	frmResult.m_arData[30] = - frmResult.m_arData[30];

	return frmResult;
}

void CRawFrame::SaveToFile(std::string strPath)
{
	CRawClip clipRaw;
	clipRaw.m_arFrame.push_back(*this);
	clipRaw.SaveToFile(strPath);
}
CRawFrame CRawFrame::InterpolateBetween(CRawFrame& frmBeg, CRawFrame& frmEnd, float fCoeff)
{
	CRawFrame frmResult;
	if(frmBeg.m_arData.size()!= frmEnd.m_arData.size())
		return frmResult;

	for(int i = 0; i < frmBeg.m_arData.size(); ++i)
	{
		float fData = frmBeg.m_arData[i] * (1-fCoeff) +  fCoeff * frmEnd.m_arData[i];
		frmResult.m_arData.push_back(fData);
	}
	return frmResult;
}
//#define ALERT_ON
void CRawFrame::CheckRange(bool bLeft)
{
	std::string strMsg = "";
	char strBuffer[120];
	if(bLeft)
	{
		if(!(m_arData[HAND_SKEL_DOF_THUMB_ROLL] > -120 && m_arData[HAND_SKEL_DOF_THUMB_ROLL] < 15))
		{
			sprintf(strBuffer, "HAND_SKEL_DOF_THUMB_ROLL=%f\r\n", m_arData[HAND_SKEL_DOF_THUMB_ROLL]);
			strMsg.append(strBuffer);
		}
		if(!(m_arData[HAND_SKEL_DOF_THUMB_ABD] > 0 && m_arData[HAND_SKEL_DOF_THUMB_ABD] < 100))
		{
			sprintf(strBuffer, "HAND_SKEL_DOF_THUMB_ABD=%f\r\n", m_arData[HAND_SKEL_DOF_THUMB_ABD]);
			strMsg.append(strBuffer);
		}
	}
	else
	{	
		if(!(m_arData[HAND_SKEL_DOF_THUMB_ROLL] > -15 && m_arData[HAND_SKEL_DOF_THUMB_ROLL] < 120))	
		{
			sprintf(strBuffer, "HAND_SKEL_DOF_THUMB_ROLL=%f\r\n", m_arData[HAND_SKEL_DOF_THUMB_ROLL]);
			strMsg.append(strBuffer);
		}
		if(!(m_arData[HAND_SKEL_DOF_THUMB_ABD] > -100 && m_arData[HAND_SKEL_DOF_THUMB_ABD] < 0))
		{
			sprintf(strBuffer, "HAND_SKEL_DOF_THUMB_ABD=%f\r\n", m_arData[HAND_SKEL_DOF_THUMB_ABD]);
			strMsg.append(strBuffer);
		}
	}
	
	if(!(m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX] > -80 && m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_THUMB_FLEX_PROX", m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX]);
		strMsg.append(strBuffer);
	}
	if(!(m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST] > -90 && m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST] < 20))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_THUMB_FLEX_DIST=%f\r\n", m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST]);
		strMsg.append(strBuffer);
	}

	//index
	if(!(m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX] > -100 && m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_INDEX_FLEX_PROX=%f\r\n", m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX]);
		strMsg.append(strBuffer);
	}
	if(!(m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID] > -100 && m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_INDEX_FLEX_MID=%f\r\n", m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID]);
		strMsg.append(strBuffer);
	}
	if(!(m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST] > -100 && m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_INDEX_FLEX_DIST=%f\r\n", m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST]);
		strMsg.append(strBuffer);
	}

	//mid			
	if(!(m_arData[HAND_SKEL_DOF_MID_FLEX_PROX] > -100 && m_arData[HAND_SKEL_DOF_MID_FLEX_PROX] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_MID_FLEX_PROX=%f\r\n", m_arData[HAND_SKEL_DOF_MID_FLEX_PROX]);
		strMsg.append(strBuffer);
	}

	if(!(m_arData[HAND_SKEL_DOF_MID_FLEX_MID] > -100 && m_arData[HAND_SKEL_DOF_MID_FLEX_MID] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_MID_FLEX_MID=%f\r\n", m_arData[HAND_SKEL_DOF_MID_FLEX_MID]);
		strMsg.append(strBuffer);
	}

	if(!(m_arData[HAND_SKEL_DOF_MID_FLEX_DIST] > -100 && m_arData[HAND_SKEL_DOF_MID_FLEX_DIST] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_MID_FLEX_DIST=%f\r\n", m_arData[HAND_SKEL_DOF_MID_FLEX_DIST]);
		strMsg.append(strBuffer);
	}

	//ring
	if(!(m_arData[HAND_SKEL_DOF_RING_FLEX_PROX] > -100 && m_arData[HAND_SKEL_DOF_RING_FLEX_PROX] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_RING_FLEX_PROX=%f\r\n", m_arData[HAND_SKEL_DOF_RING_FLEX_PROX]);
		strMsg.append(strBuffer);
	}

	if(!(m_arData[HAND_SKEL_DOF_RING_FLEX_MID] > -100 && m_arData[HAND_SKEL_DOF_RING_FLEX_MID] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_RING_FLEX_MID=%f\r\n", m_arData[HAND_SKEL_DOF_RING_FLEX_MID]);
		strMsg.append(strBuffer);
	}

	if(!(m_arData[HAND_SKEL_DOF_RING_FLEX_DIST] > -100 && m_arData[HAND_SKEL_DOF_RING_FLEX_DIST] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_RING_FLEX_DIST=%f\r\n", m_arData[HAND_SKEL_DOF_RING_FLEX_DIST]);
		strMsg.append(strBuffer);
	}

	//pinky			
	if(!(m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX] > -100 && m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_PINKY_FLEX_PROX=%f\r\n", m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX]);
		strMsg.append(strBuffer);
	}

	if(!(m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID] > -100 && m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_PINKY_FLEX_MID=%f\r\n", m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID]);
		strMsg.append(strBuffer);
	}

	if(!(m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST] > -100 && m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST] < 10))
	{
		sprintf(strBuffer, "HAND_SKEL_DOF_PINKY_FLEX_DIST=%f\r\n", m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST]);
		strMsg.append(strBuffer);
	}


	//abd
	if(bLeft)
	{
		if(!(m_arData[HAND_SKEL_DOF_INDEX_ABD] > -20 && m_arData[HAND_SKEL_DOF_INDEX_ABD] < 20))
		{
			sprintf(strBuffer, "HAND_SKEL_DOF_INDEX_ABD=%f\r\n", m_arData[HAND_SKEL_DOF_INDEX_ABD]);
			strMsg.append(strBuffer);
		}

		if(!(m_arData[HAND_SKEL_DOF_RING_ABD] > -5 && m_arData[HAND_SKEL_DOF_RING_ABD] < 17))
		{
			sprintf(strBuffer, "HAND_SKEL_DOF_RING_ABD=%f\r\n", m_arData[HAND_SKEL_DOF_RING_ABD]);
			strMsg.append(strBuffer);
		}

		if(!(m_arData[HAND_SKEL_DOF_PINKY_ABD] > -15 && m_arData[HAND_SKEL_DOF_PINKY_ABD] < 35))
		{
			sprintf(strBuffer, "HAND_SKEL_DOF_PINKY_ABD=%f\r\n", m_arData[HAND_SKEL_DOF_PINKY_ABD]);
			strMsg.append(strBuffer);
		}
	}
	else
	{
		if(!(m_arData[HAND_SKEL_DOF_INDEX_ABD] > -20 && m_arData[HAND_SKEL_DOF_INDEX_ABD] < 20))
		{
			sprintf(strBuffer, "HAND_SKEL_DOF_INDEX_ABD=%f\r\n", m_arData[HAND_SKEL_DOF_INDEX_ABD]);
			strMsg.append(strBuffer);
		}

		if(!(m_arData[HAND_SKEL_DOF_RING_ABD] > -17 && m_arData[HAND_SKEL_DOF_RING_ABD] < 5))
		{
			sprintf(strBuffer, "HAND_SKEL_DOF_RING_ABD=%f\r\n", m_arData[HAND_SKEL_DOF_RING_ABD]);
			strMsg.append(strBuffer);
		}
		if(!(m_arData[HAND_SKEL_DOF_PINKY_ABD] > -35 && m_arData[HAND_SKEL_DOF_PINKY_ABD] < 15))
		{
			sprintf(strBuffer, "HAND_SKEL_DOF_PINKY_ABD=%f\r\n", m_arData[HAND_SKEL_DOF_PINKY_ABD]);
			strMsg.append(strBuffer);
		}
	}

	if(strMsg != "")
		::MessageBox(NULL, CString(strMsg.c_str()), L"RawFrame Range Check", MB_OK);
}

	//xtreme fast
CRawFrame CRawFrame::xfast_calibrate_finger_flex(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmFist, CRawFrame frmFist_gt, 
		CRawFrame frmOverbend, CRawFrame frmOverbend_gt, 
		bool bLeft)
{
	CRawFrame frmResult = *this;

	/*[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[for allison
	frmResult.m_arData[15] = frmResult.m_arData[15] - 5;
	frmResult.m_arData[15] = frmResult.m_arData[15] * 1.5;
	return frmResult;
	//]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]*/

	/*/check training data validity, but do nothing==================================================
	ASSERT(frmFist.m_arData[8] <= frmFlat.m_arData[8] && frmFlat.m_arData[8] <= frmOverbend.m_arData[8]);	
	ASSERT(frmFist.m_arData[9] <= frmFlat.m_arData[9] && frmFlat.m_arData[9] <= frmOverbend.m_arData[9]);	
	ASSERT(frmFist.m_arData[10] <= frmFlat.m_arData[10] && frmFlat.m_arData[10] <= frmOverbend.m_arData[10]);
		
	ASSERT(frmFist.m_arData[14] <= frmFlat.m_arData[14] && frmFlat.m_arData[14] <= frmOverbend.m_arData[14]);
	ASSERT(frmFist.m_arData[15] <= frmFlat.m_arData[15] && frmFlat.m_arData[15] <= frmOverbend.m_arData[15]);
	ASSERT(frmFist.m_arData[16] <= frmFlat.m_arData[16] && frmFlat.m_arData[16] <= frmOverbend.m_arData[16]);
	
	ASSERT(frmFist.m_arData[20] <= frmFlat.m_arData[20] && frmFlat.m_arData[20] <= frmOverbend.m_arData[20]);
	ASSERT(frmFist.m_arData[21] <= frmFlat.m_arData[21] && frmFlat.m_arData[21] <= frmOverbend.m_arData[21]);	
	ASSERT(frmFist.m_arData[22] <= frmFlat.m_arData[22] && frmFlat.m_arData[22] <= frmOverbend.m_arData[22]);

	ASSERT(frmFist.m_arData[26] <= frmFlat.m_arData[26] && frmFlat.m_arData[26] <= frmOverbend.m_arData[26]);
	ASSERT(frmFist.m_arData[27] <= frmFlat.m_arData[27] && frmFlat.m_arData[27] <= frmOverbend.m_arData[27]);	
	ASSERT(frmFist.m_arData[28] <= frmFlat.m_arData[28] && frmFlat.m_arData[28] <= frmOverbend.m_arData[28]);*/

	//index==================================================
	/*if(m_arData[8] > frmFlat.m_arData[8]) //flat ~ overbend
		frmResult.m_arData[8] = GloveUtil::linearAdjust(m_arData[8], frmFlat.m_arData[8], frmOverbend.m_arData[8], frmFlat_gt.m_arData[8], frmOverbend_gt.m_arData[8]);
	else //fist ~ flat*/
		frmResult.m_arData[8] = GloveUtil::linearAdjust(m_arData[8], frmFist.m_arData[8], frmFlat.m_arData[8], frmFist_gt.m_arData[8], frmFlat_gt.m_arData[8]); 
	//if the training data is not valid 
	/*if(m_arData[8] > frmFlat.m_arData[8] && abs(frmFlat.m_arData[8] - frmOverbend.m_arData[8]) < 1)
		 frmResult.m_arData[8] = frmFlat_gt.m_arData[8] + 0.2 * (m_arData[8] - frmFlat.m_arData[8]);*/

		
	/*if(m_arData[9] > frmFlat.m_arData[9] &&  frmFlat.m_arData[9] <= frmOverbend.m_arData[9])
		frmResult.m_arData[9] = GloveUtil::linearAdjust(m_arData[9], frmFlat.m_arData[9], frmOverbend.m_arData[9], frmFlat_gt.m_arData[9], frmOverbend_gt.m_arData[9]);
	else */
		frmResult.m_arData[9] = GloveUtil::linearAdjust(m_arData[9], frmFist.m_arData[9], frmFlat.m_arData[9], frmFist_gt.m_arData[9], frmFlat_gt.m_arData[9]); //fist ~ flat
	//if the training data is not valid 
	/*if(m_arData[9] > frmFlat.m_arData[9] && abs(frmFlat.m_arData[9] - frmOverbend.m_arData[9]) < 1)
		 frmResult.m_arData[9] = frmFlat_gt.m_arData[9] + 0.2 * (m_arData[9] - frmFlat.m_arData[9]);*/

	/*if(m_arData[10] > frmFlat.m_arData[10])
		frmResult.m_arData[10] = GloveUtil::linearAdjust(m_arData[10], frmFlat.m_arData[10], frmOverbend.m_arData[10], frmFlat_gt.m_arData[10], frmOverbend_gt.m_arData[10]);
	else */
		frmResult.m_arData[10] = GloveUtil::linearAdjust(m_arData[10], frmFist.m_arData[10], frmFlat.m_arData[10], frmFist_gt.m_arData[10], frmFlat_gt.m_arData[10]); //fist ~ flat
	//if the training data is not valid 
	/*if(m_arData[10] > frmFlat.m_arData[10] && abs(frmFlat.m_arData[10] - frmOverbend.m_arData[10]) < 1)
		 frmResult.m_arData[10] = frmFlat_gt.m_arData[10]  + 0.2 * (m_arData[10] - frmFlat.m_arData[10]);*/
	//frmResult.m_arData[10] = (frmResult.m_arData[8] + frmResult.m_arData[9]) / 2.0;

	//mid==================================================
	frmResult.m_arData[14] = GloveUtil::linearAdjust(m_arData[14], frmFist.m_arData[14], frmFlat.m_arData[14], frmFist_gt.m_arData[14], frmFlat_gt.m_arData[14]);
	/*if(m_arData[14] > frmFlat.m_arData[14]) 
		frmResult.m_arData[14] =GloveUtil::linearAdjust(m_arData[14], frmFlat.m_arData[14], frmOverbend.m_arData[14], frmFlat_gt.m_arData[14], frmOverbend_gt.m_arData[14]);
	else 
		frmResult.m_arData[14] = GloveUtil::linearAdjust(m_arData[14], frmFist.m_arData[14], frmFlat.m_arData[14], frmFist_gt.m_arData[14], frmFlat_gt.m_arData[14]); //fist ~ flat
	//if the training data is not valid 
	if(m_arData[14] > frmFlat.m_arData[14] && abs(frmFlat.m_arData[14] - frmOverbend.m_arData[14]) < 1)
		 frmResult.m_arData[14] = frmFlat_gt.m_arData[14]+ 0.2 * (m_arData[14] - frmFlat.m_arData[14]);*/

	frmResult.m_arData[15] = GloveUtil::linearAdjust(m_arData[15], frmFist.m_arData[15], frmFlat.m_arData[15], frmFist_gt.m_arData[15], frmFlat_gt.m_arData[15]);
	/*if(m_arData[15] > frmFlat.m_arData[15]) 
		frmResult.m_arData[15] =  GloveUtil::linearAdjust(m_arData[15], frmFlat.m_arData[15], frmOverbend.m_arData[15], frmFlat_gt.m_arData[15], frmOverbend_gt.m_arData[15]);
	else 
		frmResult.m_arData[15] = GloveUtil::linearAdjust(m_arData[15], frmFist.m_arData[15], frmFlat.m_arData[15], frmFist_gt.m_arData[15], frmFlat_gt.m_arData[15]); //fist ~ flat
	//if the training data is not valid 
	if(m_arData[15] > frmFlat.m_arData[15] && abs(frmFlat.m_arData[15] - frmOverbend.m_arData[15]) < 1)
		 frmResult.m_arData[15] = frmFlat_gt.m_arData[15] + 0.2 * (m_arData[15] - frmFlat.m_arData[15]);*/
	
	frmResult.m_arData[16] = GloveUtil::linearAdjust(m_arData[16], frmFist.m_arData[16], frmFlat.m_arData[16], frmFist_gt.m_arData[16], frmFlat_gt.m_arData[16]);
	//frmResult.m_arData[16] = (frmResult.m_arData[14] + frmResult.m_arData[15]) / 2.0;

	//ring ==================================================
	/*if(m_arData[20] > frmFlat.m_arData[20]) 
		frmResult.m_arData[20] = GloveUtil::linearAdjust(m_arData[20], frmFlat.m_arData[20], frmOverbend.m_arData[20], frmFlat_gt.m_arData[20], frmOverbend_gt.m_arData[20]);
	else*/
		frmResult.m_arData[20] = GloveUtil::linearAdjust(m_arData[20], frmFist.m_arData[20], frmFlat.m_arData[20], frmFist_gt.m_arData[20], frmFlat_gt.m_arData[20]); //fist ~ flat
	//if the training data is not valid 
	/*if(m_arData[20] > frmFlat.m_arData[20] && abs(frmFlat.m_arData[20] - frmOverbend.m_arData[20]) < 5)
		 frmResult.m_arData[20] = frmFlat_gt.m_arData[20] + 0.2 * (m_arData[20] - frmFlat.m_arData[20]);*/

	/*if(m_arData[21] > frmFlat.m_arData[21]) 
		frmResult.m_arData[21] = GloveUtil::linearAdjust(m_arData[21], frmFlat.m_arData[21], frmOverbend.m_arData[21], frmFlat_gt.m_arData[21], frmOverbend_gt.m_arData[21]);
	else*/
		frmResult.m_arData[21] = GloveUtil::linearAdjust(m_arData[21], frmFist.m_arData[21], frmFlat.m_arData[21], frmFist_gt.m_arData[21], frmFlat_gt.m_arData[21]); //fist ~ flat
	//if the training data is not valid 
	/*if(m_arData[21] > frmFlat.m_arData[21] && abs(frmFlat.m_arData[21] - frmOverbend.m_arData[21]) < 5)
		 frmResult.m_arData[21] = frmFlat_gt.m_arData[21] + 0.2 * (m_arData[21] - frmFlat.m_arData[21]);*/

	/*if(m_arData[22] > frmFlat.m_arData[22])
		frmResult.m_arData[22] = GloveUtil::linearAdjust(m_arData[22], frmFlat.m_arData[22], frmOverbend.m_arData[22], frmFlat_gt.m_arData[22], frmOverbend_gt.m_arData[22]);
	else*/
		frmResult.m_arData[22] = GloveUtil::linearAdjust(m_arData[22], frmFist.m_arData[22], frmFlat.m_arData[22], frmFist_gt.m_arData[22], frmFlat_gt.m_arData[22]); //fist ~ flat
	//if the training data is not valid 
	/*if(m_arData[22] > frmFlat.m_arData[22] && abs(frmFlat.m_arData[22] - frmOverbend.m_arData[22]) < 5)
		 frmResult.m_arData[22] = frmFlat_gt.m_arData[22] + 0.2 * (m_arData[22] - frmFlat.m_arData[22]);*/

	//frmResult.m_arData[22] = (frmResult.m_arData[20] + frmResult.m_arData[21]) / 2.0;

	//pinky==================================================
	/*if(m_arData[26] > frmFlat.m_arData[26]) 
		frmResult.m_arData[26] = GloveUtil::linearAdjust(m_arData[26], frmFlat.m_arData[26], frmOverbend.m_arData[26], frmFlat_gt.m_arData[26], frmOverbend_gt.m_arData[26]);
	else*/
		frmResult.m_arData[26] = GloveUtil::linearAdjust(m_arData[26], frmFist.m_arData[26], frmFlat.m_arData[26], frmFist_gt.m_arData[26], frmFlat_gt.m_arData[26]); //fist ~ flat
	//if the training data is not valid 
	/*if(m_arData[26] > frmFlat.m_arData[26] && abs(frmFlat.m_arData[26] - frmOverbend.m_arData[26]) < 1)
		 frmResult.m_arData[26] = frmFlat_gt.m_arData[26] + 0.2 * (m_arData[26] - frmFlat.m_arData[26]);*/

	/*if(m_arData[27] > frmFlat.m_arData[27]) 
		frmResult.m_arData[27] = GloveUtil::linearAdjust(m_arData[27], frmFlat.m_arData[27], frmOverbend.m_arData[27], frmFlat_gt.m_arData[27], frmOverbend_gt.m_arData[27]);
	else */
		frmResult.m_arData[27] = GloveUtil::linearAdjust(m_arData[27], frmFist.m_arData[27], frmFlat.m_arData[27], frmFist_gt.m_arData[27], frmFlat_gt.m_arData[27]); //fist ~ flat
	//if the training data is not valid 
	/*if(m_arData[27] > frmFlat.m_arData[27] && abs(frmFlat.m_arData[27] - frmOverbend.m_arData[27]) < 1)
		 frmResult.m_arData[27] = frmFlat_gt.m_arData[27] + 0.2 * (m_arData[27] - frmFlat.m_arData[27]);*/

	/*if(m_arData[28] > frmFlat.m_arData[28]) 
		frmResult.m_arData[28] = GloveUtil::linearAdjust(m_arData[28], frmFlat.m_arData[28], frmOverbend.m_arData[28], frmFlat_gt.m_arData[28], frmOverbend_gt.m_arData[28]);
	else */
		frmResult.m_arData[28] = GloveUtil::linearAdjust(m_arData[28], frmFist.m_arData[28], frmFlat.m_arData[28], frmFist_gt.m_arData[28], frmFlat_gt.m_arData[28]); //fist ~ flat
	//if the training data is not valid 
	/*if(m_arData[28] > frmFlat.m_arData[28] && abs(frmFlat.m_arData[28] - frmOverbend.m_arData[28]) < 1)
		 frmResult.m_arData[28] = frmFlat_gt.m_arData[28] + 0.2 * (m_arData[28] - frmFlat.m_arData[28]);*/

    //frmResult.m_arData[28] = (frmResult.m_arData[27] + frmResult.m_arData[26]) / 2.0;

	return frmResult;
}

CRawFrame CRawFrame::xfast_calibrate_finger_abd(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmSpread, CRawFrame frmSpread_gt, 
		bool bLeft)
{
	CRawFrame frmResult = *this;
	frmResult.m_arData[7] = GloveUtil::linearAdjust(m_arData[7], frmFlat.m_arData[7], frmSpread.m_arData[7], frmFlat_gt.m_arData[7], frmSpread_gt.m_arData[7]);
	frmResult.m_arData[19] = GloveUtil::linearAdjust(m_arData[19], frmFlat.m_arData[19], frmSpread.m_arData[19], frmFlat_gt.m_arData[19], frmSpread_gt.m_arData[19]);
	frmResult.m_arData[25] = GloveUtil::linearAdjust(m_arData[25], frmFlat.m_arData[25], frmSpread.m_arData[25], frmFlat_gt.m_arData[25], frmSpread_gt.m_arData[25]);
	return frmResult;
}

CRawFrame CRawFrame::xfast_calibrate_thumb(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmFist, CRawFrame frmFist_gt,
		CRawFrame frmSpread, CRawFrame frmSpread_gt, 
		bool bLeft)
{
	CRawFrame frmResult = *this;
	//thumb roll======================================================================
	frmResult.m_arData[0] = GloveUtil::linearAdjust(m_arData[0], frmFist.m_arData[0], frmFlat.m_arData[0], frmFist_gt.m_arData[0], frmFlat_gt.m_arData[0]);
	
	//thumb abd======================================================================
	float x1 = frmFlat.m_arData[1], x2 = (frmFist.m_arData[1] + frmSpread.m_arData[1]) / 2.0, y1 = frmFlat_gt.m_arData[1], y2 = (frmFist_gt.m_arData[1] + frmSpread_gt.m_arData[1]) / 2.0;
	//frmResult.m_arData[1] = GloveUtil::linearAdjust(m_arData[1], x1, x2, y1, y2);
	//first use flat/spread to calib abd, abd tend to be big
	//frmResult.m_arData[1] = GloveUtil::linearAdjust(m_arData[1], frmSpread.m_arData[1], frmFlat.m_arData[1], frmSpread_gt.m_arData[1], frmFlat_gt.m_arData[1]);
	//frmResult.m_arData[1] = 1 * frmResult.m_arData[0] + frmResult.m_arData[1] ;

	frmResult.m_arData[1] = GloveUtil::linearAdjust(m_arData[1], frmFist.m_arData[1], frmFlat.m_arData[1], frmFist_gt.m_arData[1], frmFlat_gt.m_arData[1]);

	//flat also get added, good or bad?
	if(bLeft && frmResult.m_arData[0] > -30)
		frmResult.m_arData[1] =  frmResult.m_arData[1]  - 0.3 *(- 30 - frmResult.m_arData[0]);
	if((!bLeft) && frmResult.m_arData[0] < 30)
		frmResult.m_arData[1] =  frmResult.m_arData[1] - 0.3*(30 - frmResult.m_arData[0]);
	

	//thumb virtual=====================================================================
	//frmResult.m_arData[2] = 0.25 * frmResult.m_arData[0] - 0.375 * frmResult.m_arData[1];
	frmResult.m_arData[2] = - 0.46 * frmResult.m_arData[0] - 1.38 * frmResult.m_arData[1];

	//thumb flexion=====================================================================
	//linear flexion
	//ASSERT(frmFist.m_arData[3] <= frmFlat.m_arData[3] && frmFlat.m_arData[3] <= frmSpread.m_arData[4]);	
	//ASSERT(frmFist.m_arData[4] <= frmFlat.m_arData[4] && frmFlat.m_arData[4] <= frmSpread.m_arData[4]);	

	/*if(m_arData[3] > frmFlat.m_arData[3]) //flat ~ spread
		frmResult.m_arData[3] = GloveUtil::linearAdjust(m_arData[3], frmFlat.m_arData[3], frmSpread.m_arData[3], frmFlat_gt.m_arData[3], frmSpread_gt.m_arData[3]+10);
	else //fist ~ flat*/
		frmResult.m_arData[3] = GloveUtil::linearAdjust(m_arData[3], frmFist.m_arData[3], frmFlat.m_arData[3], frmFist_gt.m_arData[3], frmFlat_gt.m_arData[3]); 
	//if the training data is not valid 
	//if(m_arData[3] > frmFlat.m_arData[3] && frmFlat.m_arData[3] > frmSpread.m_arData[3])
	//	 frmResult.m_arData[3] = frmFlat_gt.m_arData[3];

	/*if(m_arData[4] > frmFlat.m_arData[4]) //flat ~ spread
		frmResult.m_arData[4] = GloveUtil::linearAdjust(m_arData[4], frmFlat.m_arData[4], frmSpread.m_arData[4], frmFlat_gt.m_arData[4], frmSpread_gt.m_arData[4]+10);
	else //fist ~ flat*/
		frmResult.m_arData[4] = GloveUtil::linearAdjust(m_arData[4], frmFist.m_arData[4], frmFlat.m_arData[4], frmFist_gt.m_arData[4], frmFlat_gt.m_arData[4]); 
	//if the training data is not valid 
	//if(m_arData[4] > frmFlat.m_arData[4] && frmFlat.m_arData[4] > frmSpread.m_arData[4])
	//	 frmResult.m_arData[4] = frmFlat_gt.m_arData[4];


//	frmResult.m_arData[3] = GloveUtil::linearAdjust(m_arData[3], frmFist.m_arData[3], frmFlat.m_arData[3], frmFist_gt.m_arData[3], frmFlat_gt.m_arData[3]);
//	frmResult.m_arData[4] = GloveUtil::linearAdjust(m_arData[4], frmFist.m_arData[4], frmFlat.m_arData[4], frmFist_gt.m_arData[4], frmFlat_gt.m_arData[4]);
	return frmResult;
}

void CRawFrame::RangeFilter(bool bLeft)
{
	//thumb
#ifdef ALERT_ON
	CheckRange(bLeft);	
#endif

	if(bLeft)
	{
		m_arData[HAND_SKEL_DOF_THUMB_ROLL] = min(max(m_arData[HAND_SKEL_DOF_THUMB_ROLL], -120), 15);
		m_arData[HAND_SKEL_DOF_THUMB_ABD] = min(max(m_arData[HAND_SKEL_DOF_THUMB_ABD], 0), 100);	
	}
	else
	{	
		m_arData[HAND_SKEL_DOF_THUMB_ROLL] = min(max(m_arData[HAND_SKEL_DOF_THUMB_ROLL], -15), 120);
		m_arData[HAND_SKEL_DOF_THUMB_ABD] = min(max(m_arData[HAND_SKEL_DOF_THUMB_ABD], -100), 0);	
	}
	
	m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX] = min(max(m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX], -80), 10);
	m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST] = min(max(m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST], -90), 20);		
	m_arData[HAND_SKEL_DOF_THUMB_VIRTUAL] = 0.25*m_arData[HAND_SKEL_DOF_THUMB_ROLL]-0.375*m_arData[HAND_SKEL_DOF_THUMB_ABD];

	//index
	m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX] = min(max(m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX], -100), 10);
	m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID] = min(max(m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID], -100), 10);
	m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST] = min(max(m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST], -100), 10);

	//mid			
	m_arData[HAND_SKEL_DOF_MID_FLEX_PROX] = min(max(m_arData[HAND_SKEL_DOF_MID_FLEX_PROX], -100), 10);	
	m_arData[HAND_SKEL_DOF_MID_FLEX_MID] = min(max(m_arData[HAND_SKEL_DOF_MID_FLEX_MID], -100), 10);
	m_arData[HAND_SKEL_DOF_MID_FLEX_DIST] = min(max(m_arData[HAND_SKEL_DOF_MID_FLEX_DIST], -100), 10);

	//ring
	m_arData[HAND_SKEL_DOF_RING_FLEX_PROX] = min(max(m_arData[HAND_SKEL_DOF_RING_FLEX_PROX], -100), 10);
	m_arData[HAND_SKEL_DOF_RING_FLEX_MID] = min(max(m_arData[HAND_SKEL_DOF_RING_FLEX_MID], -100), 10);
	m_arData[HAND_SKEL_DOF_RING_FLEX_DIST] = min(max(m_arData[HAND_SKEL_DOF_RING_FLEX_DIST], -100), 10);

	//pinky			
	m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX] = min(max(m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX], -100), 10);	
	m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID] = min(max(m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID], -100), 10);	
	m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST] = min(max(m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST], -100), 10);

	//abd
	if(bLeft)
	{
		m_arData[HAND_SKEL_DOF_INDEX_ABD] = min(max(m_arData[HAND_SKEL_DOF_INDEX_ABD], -20), 20);
		m_arData[HAND_SKEL_DOF_MID_ABD] = 0;
		m_arData[HAND_SKEL_DOF_RING_ABD] = min(max(m_arData[HAND_SKEL_DOF_RING_ABD], -5), 17);
		m_arData[HAND_SKEL_DOF_PINKY_ABD] = min(max(m_arData[HAND_SKEL_DOF_PINKY_ABD], -15), 35);
	}
	else
	{
		m_arData[HAND_SKEL_DOF_INDEX_ABD] = min(max(m_arData[HAND_SKEL_DOF_INDEX_ABD], -20), 20);
		m_arData[HAND_SKEL_DOF_MID_ABD] = 0;
		m_arData[HAND_SKEL_DOF_RING_ABD] = min(max(m_arData[HAND_SKEL_DOF_RING_ABD], -17), 5);
		m_arData[HAND_SKEL_DOF_PINKY_ABD] = min(max(m_arData[HAND_SKEL_DOF_PINKY_ABD], -35), 15);
	}
}

CRawFrame CRawClip::GetAveragePose()
{
	CRawFrame frmAvePose;
	if(m_arFrame.size() <= 0)
		return frmAvePose;
	
	frmAvePose = CRawFrame::GetEmptyFrame(m_arFrame[0].m_arData.size());
	for(int f = 0; f < m_arFrame.size(); ++f)
	{
		CRawFrame frmCur = m_arFrame[f];
		for(int d = 0; d < frmCur.m_arData.size(); ++d)
			frmAvePose.m_arData[d] += frmCur.m_arData[d];
	}
	for(int d = 0; d < frmAvePose.m_arData.size(); ++d)
		frmAvePose.m_arData[d] = frmAvePose.m_arData[d] / m_arFrame.size();

	return frmAvePose;
}

void CRawFrame::CalError(CRawFrame frmSample, CRawFrame frmTruth, float& fMaxErr, int& iMaxIdx, float& fMeanErr, float& fStdErr)
{
	frmSample.CalError(frmTruth, fMaxErr, iMaxIdx, fMeanErr, fStdErr);
}
void CRawFrame::CalError(CRawFrame frmTruth, float& fMaxErr, int& iMaxIdx, float& fMeanErr, float& fStdErr)
{	
	iMaxIdx = -1;
	fMaxErr = -10000;
	fMeanErr = 0;
	fStdErr = 0;

	//calculate max and mean
	for(int i = 0; i < 29; ++i)
	{
		if(i == HAND_SKEL_DOF_THUMB_VIRTUAL)
			continue;

		float fCurErr = abs(frmTruth.m_arData[i] - m_arData[i]);
		if(fCurErr > fMaxErr)
		{
			fMaxErr = fCurErr;
			iMaxIdx = i;
		}

		fMeanErr += fCurErr;
	}
	fMeanErr = fMeanErr / 30.0;

	//calculate standard deviation
	float fDevSum = 0;
	for(int i = 0; i < 29; ++i)
	{
		if(i == HAND_SKEL_DOF_THUMB_VIRTUAL)
			continue;

		float fCurErr = abs(frmTruth.m_arData[i] - m_arData[i]);
		float fCurDev = fCurErr - fMeanErr;
		fCurDev = fCurDev * fCurDev;
		fDevSum += fCurDev;
	}
	fStdErr = fDevSum / 30.0;
	fStdErr = sqrt(fStdErr);
}
void CRawClip::SaveToBvh(std::string strPath, std::string strBvhHeader)
{
	std::ofstream fout(strPath.c_str());
	//structure header: depends on handness, hand size
	//fout << IDS_RAW_BVH_STRUCTURE;
	fout << strBvhHeader.c_str();
	fout << "MOTION" << std::endl;
	float fInterval = 0.033333333;
	fout << "Frame Time: " << fInterval << std::endl;
	fout << "Frames: " << m_arFrame.size() << std::endl;	
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		fout << frmRaw.m_arData[30];
		fout << " " << frmRaw.m_arData[29];
		for(int j = 0; j < frmRaw.m_arData.size() -2; ++j)
			fout << " " << frmRaw.m_arData[j];
		fout << std::endl;
	}
	fout.flush();
	fout.close();

}

void CRawFrame::SaveToBvhConsistentWithBody(bool bLeft, std::ofstream& fout)
{
		/*fout << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_WRIST_ABD] : - frmRaw.m_arData[HAND_SKEL_DOF_WRIST_ABD]); 
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_WRIST_FLEX] : - frmRaw.m_arData[HAND_SKEL_DOF_WRIST_FLEX]);*/
		
		fout << ((bLeft) ? - m_arData[HAND_SKEL_DOF_THUMB_ROLL] : m_arData[HAND_SKEL_DOF_THUMB_ROLL]);
		fout << " " << ((bLeft) ? - m_arData[HAND_SKEL_DOF_THUMB_ABD] : - m_arData[HAND_SKEL_DOF_THUMB_ABD]);
		fout << " " << ((bLeft) ? - m_arData[HAND_SKEL_DOF_THUMB_VIRTUAL] : m_arData[HAND_SKEL_DOF_THUMB_VIRTUAL]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX] : - m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST] : - m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST]);

		fout << " " << ((bLeft) ? - m_arData[HAND_SKEL_DOF_INDEX_ABD_PALM] : - m_arData[HAND_SKEL_DOF_INDEX_ABD_PALM]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_INDEX_FLEX_PALM] : - m_arData[HAND_SKEL_DOF_INDEX_FLEX_PALM]);
		fout << " " << ((bLeft) ? - m_arData[HAND_SKEL_DOF_INDEX_ABD] : - m_arData[HAND_SKEL_DOF_INDEX_ABD]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX] : - m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID] : - m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST] : - m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST]);

		fout << " " << ((bLeft) ? - m_arData[HAND_SKEL_DOF_MID_ABD_PALM] : - m_arData[HAND_SKEL_DOF_MID_ABD_PALM]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_MID_FLEX_PALM] : - m_arData[HAND_SKEL_DOF_MID_FLEX_PALM]);
		fout << " " << ((bLeft) ? - m_arData[HAND_SKEL_DOF_MID_ABD] : - m_arData[HAND_SKEL_DOF_MID_ABD]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_MID_FLEX_PROX] : - m_arData[HAND_SKEL_DOF_MID_FLEX_PROX]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_MID_FLEX_MID] : - m_arData[HAND_SKEL_DOF_MID_FLEX_MID]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_MID_FLEX_DIST] : - m_arData[HAND_SKEL_DOF_MID_FLEX_DIST]);

		fout << " " << ((bLeft) ? - m_arData[HAND_SKEL_DOF_RING_ABD_PALM] : - m_arData[HAND_SKEL_DOF_RING_ABD_PALM]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_RING_FLEX_PALM] : - m_arData[HAND_SKEL_DOF_RING_FLEX_PALM]);
		fout << " " << ((bLeft) ? - m_arData[HAND_SKEL_DOF_RING_ABD] : - m_arData[HAND_SKEL_DOF_RING_ABD]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_RING_FLEX_PROX] : - m_arData[HAND_SKEL_DOF_RING_FLEX_PROX]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_RING_FLEX_MID] : - m_arData[HAND_SKEL_DOF_RING_FLEX_MID]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_RING_FLEX_DIST] : - m_arData[HAND_SKEL_DOF_RING_FLEX_DIST]);

		fout << " " << ((bLeft) ? - m_arData[HAND_SKEL_DOF_PINKY_ABD_PALM] : - m_arData[HAND_SKEL_DOF_PINKY_ABD_PALM]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_PINKY_FLEX_PALM] : - m_arData[HAND_SKEL_DOF_PINKY_FLEX_PALM]);
		fout << " " << ((bLeft) ? - m_arData[HAND_SKEL_DOF_PINKY_ABD] : - m_arData[HAND_SKEL_DOF_PINKY_ABD]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX] : - m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID] : - m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID]);
		fout << " " << ((bLeft) ? m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST] : - m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST]);

		fout << " ";

}
void CRawClip::SaveToBvhConsistentWithBody(bool bLeft, std::string strPath, std::string strBvhHeader)
{
	std::ofstream fout(strPath.c_str());
	fout << strBvhHeader.c_str();
	fout << "MOTION" << std::endl;
	float fInterval = 0.033333333;
	fout << "Frame Time: " << fInterval << std::endl;
	fout << "Frames: " << m_arFrame.size() << std::endl;	
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		fout << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_WRIST_ABD] : - frmRaw.m_arData[HAND_SKEL_DOF_WRIST_ABD]); 
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_WRIST_FLEX] : - frmRaw.m_arData[HAND_SKEL_DOF_WRIST_FLEX]);
		
		fout << " " << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_THUMB_ROLL] : frmRaw.m_arData[HAND_SKEL_DOF_THUMB_ROLL]);
		fout << " " << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_THUMB_ABD] : - frmRaw.m_arData[HAND_SKEL_DOF_THUMB_ABD]);
		fout << " " << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_THUMB_VIRTUAL] : frmRaw.m_arData[HAND_SKEL_DOF_THUMB_VIRTUAL]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX] : - frmRaw.m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST] : - frmRaw.m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST]);

		fout << " " << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_INDEX_ABD_PALM] : - frmRaw.m_arData[HAND_SKEL_DOF_INDEX_ABD_PALM]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_PALM] : - frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_PALM]);
		fout << " " << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_INDEX_ABD] : - frmRaw.m_arData[HAND_SKEL_DOF_INDEX_ABD]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX] : - frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID] : - frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST] : - frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST]);

		fout << " " << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_MID_ABD_PALM] : - frmRaw.m_arData[HAND_SKEL_DOF_MID_ABD_PALM]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_PALM] : - frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_PALM]);
		fout << " " << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_MID_ABD] : - frmRaw.m_arData[HAND_SKEL_DOF_MID_ABD]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_PROX] : - frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_PROX]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_MID] : - frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_MID]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_DIST] : - frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_DIST]);

		fout << " " << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_RING_ABD_PALM] : - frmRaw.m_arData[HAND_SKEL_DOF_RING_ABD_PALM]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_PALM] : - frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_PALM]);
		fout << " " << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_RING_ABD] : - frmRaw.m_arData[HAND_SKEL_DOF_RING_ABD]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_PROX] : - frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_PROX]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_MID] : - frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_MID]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_DIST] : - frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_DIST]);

		fout << " " << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_PINKY_ABD_PALM] : - frmRaw.m_arData[HAND_SKEL_DOF_PINKY_ABD_PALM]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_PALM] : - frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_PALM]);
		fout << " " << ((bLeft) ? - frmRaw.m_arData[HAND_SKEL_DOF_PINKY_ABD] : - frmRaw.m_arData[HAND_SKEL_DOF_PINKY_ABD]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX] : - frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID] : - frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID]);
		fout << " " << ((bLeft) ? frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST] : - frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST]);

		fout << std::endl;
	}
	fout.flush();
	fout.close();

}
void CRawClip::SaveToFile(std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frm = m_arFrame[i];
		for(int j = 0; j < frm.m_arData.size(); ++j)
		{
			fout << frm.m_arData[j];
			if(j < frm.m_arData.size()-1)
				fout << " ";
		}
		fout<<std::endl;
	}
	fout.flush();
	fout.close();
}

void CRawClip::LoadFromFile(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	m_arFrame.clear();
	while(fin.good())
	{
		char buf[1024] = {0};
		fin.getline(buf, sizeof(buf));
		CRawFrame frm;
		CString strData(buf);
		int iStart = 0, iEnd = strData.Find(L" ");
		int iCount = 0;
		while(iEnd > iStart)
		{
			CString strOneData = strData.Mid(iStart, iEnd - iStart);
			strOneData.Trim();
			float fData = _wtof(strOneData);
			frm.m_arData.push_back(fData);
			iStart = iEnd + 1;
			iEnd = strData.Find(L" ", iStart);
		}
		//last one
		CString strOneData = strData.Mid(iStart);
		strOneData.Trim();
		if(!strOneData.IsEmpty())
		{
			float fData = _wtof(strOneData);
			frm.m_arData.push_back(fData);
		}

		if(frm.m_arData.size() != 0)
			m_arFrame.push_back(frm);
	}

	/*//bio rule
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frm = m_arFrame[i];
		frm.m_arData[10] = frm.m_arData[9] * 0.667;
		frm.m_arData[16] = frm.m_arData[15] * 0.667;
		frm.m_arData[22] = frm.m_arData[21] * 0.667;
		frm.m_arData[28] = frm.m_arData[27] * 0.667;
	}*/
}
int CRawClip::GetFrameCount()
{
	return m_arFrame.size();
}
CBaseFrame* CRawClip::GetFrameAt(int iFrmIdx)
{
	return (CBaseFrame*)(&m_arFrame[iFrmIdx]);
}

void CRawClip::SetFrameAt(int iFrmIdx, CBaseFrame* pFrame)
{
	m_arFrame[iFrmIdx] = *(CRawFrame*)pFrame;
}
bool CRawClip::HasFrame(const CRawFrame& frame)
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		if(m_arFrame[i] == frame)
			return true;
	}
	return false;
}
void CRawClip::EliminateRedundancy()
{
	CRawClip clipResult;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];	
		if(!clipResult.HasFrame(frmRaw))
			clipResult.m_arFrame.push_back(frmRaw);
	}
	m_arFrame.clear();
	m_arFrame =clipResult.m_arFrame;
}
void CRawClip::EliminateOutputRedundancy(float fGranularity)
{
	//to check if different(but close) input generate same output
	CRawClip clipResult;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];	
		bool bSmallButDifferentInput = true;
		for(int j = 0; j < clipResult.m_arFrame.size(); ++j)
		{
			CRawFrame frmRawResult = clipResult.m_arFrame[j];
			bSmallButDifferentInput = true;
			for(int d = 0; d < frmRawResult.m_arData.size()-1; ++d)
			{
				if(abs(frmRawResult.m_arData[d]-frmRaw.m_arData[d]) > fGranularity)
				{
					bSmallButDifferentInput = false;
					break;
				}
			}
			//if(bSmallButDifferentInput && 
			if(	abs(frmRawResult.m_arData[frmRawResult.m_arData.size()-1] - 
				frmRaw.m_arData[frmRaw.m_arData.size()-1]) < 0.1)
			{
				bSmallButDifferentInput = true;
				break;
			}
			else
				bSmallButDifferentInput = false;
		}
		if(i==0 || !bSmallButDifferentInput)
			clipResult.m_arFrame.push_back(frmRaw);
	}
	m_arFrame.clear();
	m_arFrame =clipResult.m_arFrame;
}
void CRawClip::EliminateInputRedundancy(float fGranularity)
{
	CRawClip clipResult;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];	
		bool bTooClose = true;
		for(int j = 0; j < clipResult.m_arFrame.size(); ++j)
		{
			CRawFrame frmRawResult = clipResult.m_arFrame[j];
			bTooClose = true;
			for(int d = 0; d < frmRawResult.m_arData.size()-1; ++d)
			{
				if(abs(frmRawResult.m_arData[d]-frmRaw.m_arData[d]) > fGranularity)
				{
					bTooClose = false;
					break;
				}
			}
			if(bTooClose)
				break;
		}
		if(i==0 || !bTooClose)
			clipResult.m_arFrame.push_back(frmRaw);
	}
	m_arFrame.clear();
	m_arFrame =clipResult.m_arFrame;
}

void CRawClip::CheckInputVariance(float fGranularity)
{
	std::string strMsg = "";
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];	
		bool bTooClose = true;
		float fVarianceMax = 0;
		int iIndexMax = -1;
		int iDataSize = frmRaw.m_arData.size();
		for(int j = 0; j < m_arFrame.size(); ++j)
		{
			CRawFrame frmTarget = m_arFrame[j];
			bTooClose = true;
			for(int d = 0; d <iDataSize -1; ++d)
			{
				if(abs(frmTarget.m_arData[d]-frmRaw.m_arData[d]) > fGranularity)
				{
					bTooClose = false;
					break;
				}
			}
			if(bTooClose)
			{
				if(abs(frmTarget.m_arData[iDataSize-1] - frmRaw.m_arData[iDataSize-1]) > fVarianceMax)
				{
					fVarianceMax = abs(frmTarget.m_arData[iDataSize-1] - frmRaw.m_arData[iDataSize-1]);
					iIndexMax = j;
				}
			}
		}

		if(fVarianceMax > fGranularity)
		{
			char buffer[200];
			sprintf(buffer, "%d max variance with %d is %f \r\n", i, iIndexMax, fVarianceMax);
			strMsg.append(buffer);
		}
	}
	if(strMsg != "")
		::MessageBox(NULL, CString(strMsg.c_str()), L"Input Variance", MB_OK);
}
void CRawClip::EliminateThumbRedundancy(float fGranularity)
{
	CRawClip clipResult;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];	
		bool bTooClose = true;
		for(int j = 0; j < clipResult.m_arFrame.size(); ++j)
		{
			CRawFrame frmRawResult = clipResult.m_arFrame[j];
			bTooClose = true;
			if(abs(frmRawResult.m_arData[0]-frmRaw.m_arData[0]) > fGranularity ||
				abs(frmRawResult.m_arData[1]-frmRaw.m_arData[1]) > fGranularity ||
				abs(frmRawResult.m_arData[2]-frmRaw.m_arData[2]) > fGranularity ||
				abs(frmRawResult.m_arData[3]-frmRaw.m_arData[3]) > fGranularity ||
				abs(frmRawResult.m_arData[4]-frmRaw.m_arData[4]) > fGranularity)
				bTooClose = false;

			if(bTooClose)
				break;
		}
		if(i==0 || !bTooClose)
			clipResult.m_arFrame.push_back(frmRaw);
	}
	m_arFrame.clear();
	m_arFrame =clipResult.m_arFrame;
}

void CRawClip::EliminateThumbRedundancy(CRawClip& clipSample, CRawClip& clipGroundTruth, float fGranularity)
{
	ASSERT(clipSample.m_arFrame.size() == clipGroundTruth.m_arFrame.size());

	CRawClip clipResultSample, clipResultGroundTruth;
	for(int i = 0; i < clipSample.m_arFrame.size(); ++i)
	{
		CRawFrame frmSample = clipSample.m_arFrame[i];	
		CRawFrame frmTruth = clipGroundTruth.m_arFrame[i];

		bool bTooClose = true;
		for(int j = 0; j < clipResultSample.m_arFrame.size(); ++j)
		{
			CRawFrame frmSampleInResult = clipResultSample.m_arFrame[j];
			bTooClose = true;
			if(abs(frmSampleInResult.m_arData[0]-frmSample.m_arData[0]) > fGranularity ||
				abs(frmSampleInResult.m_arData[1]-frmSample.m_arData[1]) > fGranularity ||
				abs(frmSampleInResult.m_arData[2]-frmSample.m_arData[2]) > fGranularity ||
				abs(frmSampleInResult.m_arData[3]-frmSample.m_arData[3]) > fGranularity ||
				abs(frmSampleInResult.m_arData[4]-frmSample.m_arData[4]) > fGranularity)
				bTooClose = false;

			if(bTooClose)
				break;
		}
		if(i==0 || !bTooClose)
		{
			clipResultSample.m_arFrame.push_back(frmSample);
			clipResultGroundTruth.m_arFrame.push_back(frmTruth);
		}
	}

	clipSample.m_arFrame.clear();
	clipSample.m_arFrame = clipResultSample.m_arFrame;

	clipGroundTruth.m_arFrame.clear();
	clipGroundTruth.m_arFrame = clipResultGroundTruth.m_arFrame;
}
void CRawClip::EliminateThumbRedundancyHD(float fGranularity)
{
	CRawClip clipResult;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];	
		bool bTooClose = true;
		for(int j = 0; j < clipResult.m_arFrame.size(); ++j)
		{
			CRawFrame frmRawResult = clipResult.m_arFrame[j];
			bTooClose = true;
			if(abs(frmRawResult.m_arData[0]-frmRaw.m_arData[0]) > fGranularity ||
				abs(frmRawResult.m_arData[1]-frmRaw.m_arData[1]) > fGranularity ||
				abs(frmRawResult.m_arData[2]-frmRaw.m_arData[2]) > fGranularity ||
				abs(frmRawResult.m_arData[3]-frmRaw.m_arData[3]) > fGranularity ||
				abs(frmRawResult.m_arData[4]-frmRaw.m_arData[4]) > fGranularity ||
				abs(frmRawResult.m_arData[8]-frmRaw.m_arData[8]) > fGranularity ||
				abs(frmRawResult.m_arData[14]-frmRaw.m_arData[14]) > fGranularity || 
				abs(frmRawResult.m_arData[20]-frmRaw.m_arData[20]) > fGranularity || 
				abs(frmRawResult.m_arData[26]-frmRaw.m_arData[26]) > fGranularity )
				bTooClose = false;

			if(bTooClose)
				break;
		}
		if(i==0 || !bTooClose)
			clipResult.m_arFrame.push_back(frmRaw);
	}
	m_arFrame.clear();
	m_arFrame =clipResult.m_arFrame;
}
void CRawClip::EliminateThumbRedundancyHD(CRawClip& clipSample, CRawClip& clipGroundTruth, float fGranularity)
{
	//ASSERT(clipSample.m_arFrame.size() == clipGroundTruth.m_arFrame.size());

	CRawClip clipResultSample, clipResultGroundTruth;
	for(int i = 0; i < clipSample.m_arFrame.size(); ++i)
	{
		CRawFrame frmSample = clipSample.m_arFrame[i];	
		CRawFrame frmGroundTruth = clipGroundTruth.m_arFrame[0];
		if(i < clipGroundTruth.m_arFrame.size())
			frmGroundTruth = clipGroundTruth.m_arFrame[i];

		bool bTooClose = true;
		for(int j = 0; j < clipResultSample.m_arFrame.size(); ++j)
		{
			CRawFrame frmSampleInResult = clipResultSample.m_arFrame[j];
			bTooClose = true;
			if(abs(frmSampleInResult.m_arData[0]-frmSample.m_arData[0]) > fGranularity ||
				abs(frmSampleInResult.m_arData[1]-frmSample.m_arData[1]) > fGranularity ||
				abs(frmSampleInResult.m_arData[2]-frmSample.m_arData[2]) > fGranularity ||
				abs(frmSampleInResult.m_arData[3]-frmSample.m_arData[3]) > fGranularity ||
				abs(frmSampleInResult.m_arData[4]-frmSample.m_arData[4]) > fGranularity ||
				abs(frmSampleInResult.m_arData[8]-frmSample.m_arData[8]) > fGranularity ||
				abs(frmSampleInResult.m_arData[14]-frmSample.m_arData[14]) > fGranularity || 
				abs(frmSampleInResult.m_arData[20]-frmSample.m_arData[20]) > fGranularity || 
				abs(frmSampleInResult.m_arData[26]-frmSample.m_arData[26]) > fGranularity )
				bTooClose = false;

			if(bTooClose)
				break;
		}
		if(i==0 || !bTooClose)
		{
			clipResultSample.m_arFrame.push_back(frmSample);
			clipResultGroundTruth.m_arFrame.push_back(frmGroundTruth);
		}
	}
	clipSample.m_arFrame.clear();
	clipSample.m_arFrame =clipResultSample.m_arFrame;
	clipGroundTruth.m_arFrame.clear();
	clipGroundTruth.m_arFrame = clipResultGroundTruth.m_arFrame;
}

CRawClip CRawClip::ExtractThumbHD(CRawClip clipSample, CRawClip clipGroundTruth, int iDOF)
{
	CRawClip clipTr;
	for(int i = 0; i < clipSample.m_arFrame.size(); ++i)
	{
			CRawFrame frmSample = clipSample.m_arFrame[i];
			CRawFrame frmTruth;
			if(clipSample.m_arFrame.size() == clipGroundTruth.m_arFrame.size())
				frmTruth = clipGroundTruth.m_arFrame[i];
			else if(clipGroundTruth.m_arFrame.size() < clipSample.m_arFrame.size())
				frmTruth = clipGroundTruth.m_arFrame[0];//POSE

			CRawFrame frmTr;
			frmTr.m_arData.push_back(frmSample.m_arData[0]);
			frmTr.m_arData.push_back(frmSample.m_arData[1]);
			frmTr.m_arData.push_back(frmSample.m_arData[2]);
			frmTr.m_arData.push_back(frmSample.m_arData[3]);
			frmTr.m_arData.push_back(frmSample.m_arData[4]);
			frmTr.m_arData.push_back(frmSample.m_arData[8]);
			frmTr.m_arData.push_back(frmSample.m_arData[14]);
			frmTr.m_arData.push_back(frmSample.m_arData[20]);
			frmTr.m_arData.push_back(frmSample.m_arData[26]);

			frmTr.m_arData.push_back(frmTruth.m_arData[iDOF]);

			clipTr.m_arFrame.push_back(frmTr);
	}
	return clipTr;
}
CRawClip CRawClip::ExtractThumbNoRedundancyHD(CRawClip clipSample, CRawClip clipGroundTruth, int iDOF, float fGranularity)
{
	CRawClip::EliminateThumbRedundancyHD(clipSample, clipGroundTruth, fGranularity);
	return CRawClip::ExtractThumbHD(clipSample, clipGroundTruth, iDOF);	
}
void CRawClip::EliminateIndexAbdRedundancy(CRawClip& clipSample, CRawClip& clipGroundTruth, float fGranularity)
{	
	ASSERT(clipSample.m_arFrame.size() == clipGroundTruth.m_arFrame.size());

	CRawClip clipResultSample, clipResultGroundTruth;
	for(int i = 0; i < clipSample.m_arFrame.size(); ++i)
	{
		CRawFrame frmSample = clipSample.m_arFrame[i];	
		CRawFrame frmGroundTruth = clipGroundTruth.m_arFrame[i];

		bool bTooClose = true;
		for(int j = 0; j < clipResultSample.m_arFrame.size(); ++j)
		{
			CRawFrame frmSampleInResult = clipResultSample.m_arFrame[j];
			bTooClose = true;
			if(abs(frmSampleInResult.m_arData[8]-frmSample.m_arData[8]) > fGranularity ||
				abs(frmSampleInResult.m_arData[14]-frmSample.m_arData[14]) > fGranularity ||
				abs(frmSampleInResult.m_arData[7]-frmSample.m_arData[7]) > fGranularity)
				bTooClose = false;

			if(bTooClose)
				break;
		}
		if(i==0 || !bTooClose)
		{
			clipResultSample.m_arFrame.push_back(frmSample);
			clipResultGroundTruth.m_arFrame.push_back(frmGroundTruth);
		}
	}
	clipSample.m_arFrame.clear();
	clipSample.m_arFrame =clipResultSample.m_arFrame;
	clipGroundTruth.m_arFrame.clear();
	clipGroundTruth.m_arFrame = clipResultGroundTruth.m_arFrame;
}
void CRawClip::EliminatePinkyAbdRedundancy(CRawClip& clipSample, CRawClip& clipGroundTruth, float fGranularity)
{
	ASSERT(clipSample.m_arFrame.size() == clipGroundTruth.m_arFrame.size());

	CRawClip clipResultSample, clipResultGroundTruth;
	for(int i = 0; i < clipSample.m_arFrame.size(); ++i)
	{
		CRawFrame frmSample = clipSample.m_arFrame[i];	
		CRawFrame frmGroundTruth = clipGroundTruth.m_arFrame[i];

		bool bTooClose = true;
		for(int j = 0; j < clipResultSample.m_arFrame.size(); ++j)
		{
			CRawFrame frmSampleInResult = clipResultSample.m_arFrame[j];
			bTooClose = true;
			if(abs(frmSampleInResult.m_arData[20]-frmSample.m_arData[20]) > fGranularity ||
				abs(frmSampleInResult.m_arData[26]-frmSample.m_arData[26]) > fGranularity ||
				abs(frmSampleInResult.m_arData[25]-frmSample.m_arData[25]) > fGranularity)
				bTooClose = false;

			if(bTooClose)
				break;
		}
		if(i==0 || !bTooClose)
		{
			clipResultSample.m_arFrame.push_back(frmSample);
			clipResultGroundTruth.m_arFrame.push_back(frmGroundTruth);
		}
	}
	clipSample.m_arFrame.clear();
	clipSample.m_arFrame =clipResultSample.m_arFrame;
	clipGroundTruth.m_arFrame.clear();
	clipGroundTruth.m_arFrame = clipResultGroundTruth.m_arFrame;
}
void CRawClip::MergeWith(const CRawClip& clipToMerge)
{
	for(int i = 0; i < clipToMerge.m_arFrame.size(); ++i)
	{
		CRawFrame frmToMerge = clipToMerge.m_arFrame[i];
		m_arFrame.push_back(frmToMerge);
	}
}
CRawClip CRawClip::GetReorderedClipByThumb_no_redundancy()
{
	CRawClip clipReordered;
	return clipReordered;
}
CBaseClip* CRawClip::GetSubClip(int iBegIdx, int iEndIdx)
{
	CRawClip* pResultClip = new CRawClip();
	for(int i = iBegIdx; i < iEndIdx; ++i)
	{
		CRawFrame frmSub = m_arFrame[i];
		pResultClip->m_arFrame.push_back(frmSub);
	}
	return (CBaseClip*)pResultClip;
}
#include "GloveSkeleton.h"
CRawClip CRawClip::CalculateIKAccuracy(IK_FINGER_TOUCHING_TYPE eTouchingType, bool bLeft)
{
	CHandSkeletonKin* pHand = new CHandSkeletonKin(!bLeft);
	CKinematicChain* pThumbChain = pHand->m_pHand->m_arChain[0];
	CKinematicChain* pFingerChain = NULL;
	switch(eTouchingType)
	{
	case IK_FINGER_TOUCHING_TYPE::eThumbIndex: pFingerChain = pHand->m_pHand->m_arChain[1];
		break;
	case IK_FINGER_TOUCHING_TYPE::eThumbMid: pFingerChain = pHand->m_pHand->m_arChain[2];
		break;
	case IK_FINGER_TOUCHING_TYPE::eThumbRing: pFingerChain = pHand->m_pHand->m_arChain[3];
		break;
	case IK_FINGER_TOUCHING_TYPE::eThumbPinky: pFingerChain = pHand->m_pHand->m_arChain[4];
		break;
	}

	CRawClip clipResult;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmCur = m_arFrame[i];
		pHand->UpdateFromKinematicData(frmCur.m_arData);
		pThumbChain->PopulateGlobalPosAndAxis();
		pFingerChain->PopulateGlobalPosAndAxis();
		CKinematicPoint ptThumbEnd = pThumbChain->GetGlobalEndEffectorPos();
		CKinematicPoint ptFingerEnd = pFingerChain->GetGlobalEndEffectorPos();
		float fDist = ptThumbEnd.DistanceTo(ptFingerEnd);

		CRawFrame frmResult;
		frmResult.m_arData.push_back(fDist);		
		clipResult.m_arFrame.push_back(frmResult);
	}
	delete pHand;
	return clipResult;
}

void CRawClip::ZeroWristRotations()
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		frmRaw.ZeroWristRotations();
		m_arFrame[i] = frmRaw;
	}
}
void CRawClip::ZeroProxFlex()
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		frmRaw.m_arData[8] = 0;
		frmRaw.m_arData[14] = 0;
		frmRaw.m_arData[20] = 0;
		frmRaw.m_arData[26] = 0;
		m_arFrame[i] = frmRaw;
	}
}

void CRawClip::Rescale(int iFingerIdx, int iFixedMergeInFrameIdx, int iRescaledFrameIdx)
{
	int iBeg, iEnd, iRescaledNext;
	if(iFixedMergeInFrameIdx < iRescaledFrameIdx)
	{
		iBeg = iFixedMergeInFrameIdx + 1;
		iEnd = iRescaledFrameIdx;
		iRescaledNext = iRescaledFrameIdx - 1;
	}
	else
	{
		iBeg = iRescaledFrameIdx + 1;
		iEnd = iFixedMergeInFrameIdx;
		iRescaledNext = iRescaledFrameIdx + 1;
	}


	CRawFrame frmRawFixedMergeIn = m_arFrame[iFixedMergeInFrameIdx];
	CRawFrame frmRawRescaledOld = m_arFrame[iRescaledNext];
	CRawFrame frmRawRescaledNew = m_arFrame[iRescaledFrameIdx];
	frmRawRescaledNew.m_arData[0] = 0.2 * frmRawRescaledOld.m_arData[0] + 0.8* frmRawRescaledNew.m_arData[0];
	frmRawRescaledNew.m_arData[1] = 0.2 * frmRawRescaledOld.m_arData[1] + 0.8* frmRawRescaledNew.m_arData[1];
	frmRawRescaledNew.m_arData[2] = 0.2 * frmRawRescaledOld.m_arData[2] + 0.8* frmRawRescaledNew.m_arData[2];	
	frmRawRescaledNew.m_arData[3] = 0.2 * frmRawRescaledOld.m_arData[3] + 0.8* frmRawRescaledNew.m_arData[3];	
	frmRawRescaledNew.m_arData[4] = 0.2 * frmRawRescaledOld.m_arData[4] + 0.8* frmRawRescaledNew.m_arData[4];
	
	for(int i = iBeg; i < iEnd; ++i)
	{
		CRawFrame frmRawCur = m_arFrame[i];
		frmRawCur.m_arData[0] = 	GloveUtil::linearAdjust(frmRawCur.m_arData[0], 
			frmRawFixedMergeIn.m_arData[0], frmRawRescaledOld.m_arData[0], //old value
			frmRawFixedMergeIn.m_arData[0], frmRawRescaledNew.m_arData[0]);//new value
		
			frmRawCur.m_arData[1] = 	GloveUtil::linearAdjust(frmRawCur.m_arData[1], 
			frmRawFixedMergeIn.m_arData[1], frmRawRescaledOld.m_arData[1], //old value
			frmRawFixedMergeIn.m_arData[1], frmRawRescaledNew.m_arData[1]);//new value

			frmRawCur.m_arData[2] = 	GloveUtil::linearAdjust(frmRawCur.m_arData[2], 
			frmRawFixedMergeIn.m_arData[2], frmRawRescaledOld.m_arData[2], //old value
			frmRawFixedMergeIn.m_arData[2], frmRawRescaledNew.m_arData[2]);//new value

			frmRawCur.m_arData[3] = 	GloveUtil::linearAdjust(frmRawCur.m_arData[3], 
			frmRawFixedMergeIn.m_arData[3], frmRawRescaledOld.m_arData[3], //old value
			frmRawFixedMergeIn.m_arData[3], frmRawRescaledNew.m_arData[3]);//new value
		
			frmRawCur.m_arData[4] = 	GloveUtil::linearAdjust(frmRawCur.m_arData[4], 
			frmRawFixedMergeIn.m_arData[4], frmRawRescaledOld.m_arData[4], //old value
			frmRawFixedMergeIn.m_arData[4], frmRawRescaledNew.m_arData[4]);//new value
		
		m_arFrame[i] = frmRawCur;
	}
}

void CRawClip::ZeroFingerFlex()
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		frmRaw.ZeroFingerFlex();
		m_arFrame[i] = frmRaw;
	}
}
void CRawClip::SuppressOverbendSigmoid(bool bLeft)
{
	if(bLeft)
	{
		SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_THUMB_ROLL, -80, 0);
		SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_THUMB_ABD, 10, 80);

		SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_INDEX_ABD, -15, 0);//0-15
		SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_RING_ABD, 0,15);
		SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_PINKY_ABD, -10,30);

	}
	else
	{
		SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_THUMB_ROLL, 0, 80);
		SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_THUMB_ABD, -80, -10);

		SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_INDEX_ABD, 0, 15);//0-15
		SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_RING_ABD, -15,0);
		SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_PINKY_ABD, -30,10);
	}

	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_THUMB_FLEX_PROX, -90, 0);
	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_THUMB_FLEX_DIST, -90, 0);

	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_INDEX_FLEX_PROX, -100,10);
	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_INDEX_FLEX_MID, -100,10);
	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_INDEX_FLEX_DIST, -90,0);

	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_MID_FLEX_PROX, -100, 10);
	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_MID_FLEX_MID,-100,10);
	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_MID_FLEX_DIST,-90,0);

	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_RING_FLEX_PROX, -100,10);
	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_RING_FLEX_MID, -100,10);
	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_RING_FLEX_DIST, -90,0);

	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_PINKY_FLEX_PROX, -100,10);
	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_PINKY_FLEX_MID, -100,10);
	SuppressOverbendSigmoid(bLeft, HAND_SKEL_DOF_PINKY_FLEX_DIST, -90,0);

	/*for(int i = 0 ; i < m_arFrame.size(); ++i)
	{
		CRawFrame frm = m_arFrame[i];
		frm.m_arData[2] = 0.25 * frm.m_arData[0] - 0.375 * frm.m_arData[1];
		m_arFrame[i] = frm;
	}*/
}
void CRawClip::SuppressOverbendSigmoid(bool bLeft, int iDOFIndex, float fMin, float fMax)
{
	for(int i = 0; i < m_arFrame.size(); ++ i)
		m_arFrame[i].SuppressOverbendSigmoid(bLeft, iDOFIndex, fMin, fMax);
}
CRawClip CRawClip::SwapHandness() const
{
	CRawClip clipResult;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmResult = m_arFrame[i].SwapHandness();
		clipResult.m_arFrame.push_back(frmResult);
	}
	return clipResult;
}
void CRawClip::ReinforceRelation(bool bLeft)
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmResult = m_arFrame[i];
		frmResult.m_arData[2] =  0.25 * frmResult.m_arData[0] - 0.375 *  frmResult.m_arData[1];
		m_arFrame[i] = frmResult;
	}
}
void CRawClip::SuppressOverbend(bool bLeft, float fIndexExt, float fMidExt, float fRingExt, float fPinkyExt)
{
	//find out max
	float fIndexMax = 0, fMidMax = 0, fRingMax = 0, fPinkyMax = 0;;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		if(frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX] > fIndexMax)
			fIndexMax = frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX];
		
		if(frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_PROX] > fMidMax)
			fMidMax = frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_PROX];
		
		if(frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_PROX] > fRingMax)
			fRingMax = frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_PROX];
		
		if(frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX] > fPinkyMax)
			fPinkyMax = frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX];
	}

	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		/*/this is more soft
		if(fIndexMax > fIndexExt && frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX] > fIndexExt)
		{
			frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX] = 
				fIndexExt * frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX] / fIndexMax;
		}
		if(fMidMax > fMidExt && frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_PROX] > fMidExt)
		{			
			frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_PROX] = 
				fMidExt * frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_PROX] / fMidMax;
		}
		if(fRingMax > fRingExt && frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_PROX] > fRingExt)
		{			
			frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_PROX] = 
				fRingExt * frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_PROX] / fRingMax;
		}
		if(fPinkyMax > fPinkyExt && frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX] > fPinkyExt)
		{			
			frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX] = 
				fPinkyExt * frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX] / fPinkyMax;
		}
	*/	
		//abduction
		if(bLeft)
		{
			if(frmRaw.m_arData[7] < -15) frmRaw.m_arData[7] = -15;
			if(frmRaw.m_arData[19] > 15) frmRaw.m_arData[19] = 15;
			if(frmRaw.m_arData[25]  > 30) frmRaw.m_arData[25] = 30;
		}
		//frmRaw.SuppressOverbend(bLeft);
		m_arFrame[i] = frmRaw;
	}
}
//iBeg, iEnd are not interpolated, are key sample
void CRawClip::ItpFinger(int iBeg, int iEnd, int iFinger)
{
	CRawFrame frmBeg = m_arFrame[iBeg];
	CRawFrame frmEnd = m_arFrame[iEnd];

	for(int i = iBeg; i <= iEnd; ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		float fPE = (i-iBeg) / float(iEnd - iBeg);
		float fPB = 1 - fPE;
		switch(iFinger)
		{
		case 0://thumb
			frmRaw.m_arData[0] = fPB * frmBeg.m_arData[0] + fPE * frmEnd.m_arData[0];
			frmRaw.m_arData[1] = fPB * frmBeg.m_arData[1] + fPE * frmEnd.m_arData[1];
			frmRaw.m_arData[2] = fPB * frmBeg.m_arData[2] + fPE * frmEnd.m_arData[2];
			frmRaw.m_arData[3] = fPB * frmBeg.m_arData[3] + fPE * frmEnd.m_arData[3];
			frmRaw.m_arData[4] = fPB * frmBeg.m_arData[4] + fPE * frmEnd.m_arData[4];
			break;
		case 1://index
			frmRaw.m_arData[7] = fPB * frmBeg.m_arData[7] + fPE * frmEnd.m_arData[7];
			frmRaw.m_arData[8] = fPB * frmBeg.m_arData[8] + fPE * frmEnd.m_arData[8];
			frmRaw.m_arData[9] = fPB * frmBeg.m_arData[9] + fPE * frmEnd.m_arData[9];
			frmRaw.m_arData[10] = fPB * frmBeg.m_arData[10] + fPE * frmEnd.m_arData[10];
			break;
		case 2://mid
			frmRaw.m_arData[14] = fPB * frmBeg.m_arData[14] + fPE * frmEnd.m_arData[14];
			frmRaw.m_arData[15] = fPB * frmBeg.m_arData[15] + fPE * frmEnd.m_arData[15];
			frmRaw.m_arData[16] = fPB * frmBeg.m_arData[16] + fPE * frmEnd.m_arData[16];
			break;
		case 3://ring
			frmRaw.m_arData[19] = fPB * frmBeg.m_arData[19] + fPE * frmEnd.m_arData[19];
			frmRaw.m_arData[20] = fPB * frmBeg.m_arData[20] + fPE * frmEnd.m_arData[20];
			frmRaw.m_arData[21] = fPB * frmBeg.m_arData[21] + fPE * frmEnd.m_arData[21];
			frmRaw.m_arData[22] = fPB * frmBeg.m_arData[22] + fPE * frmEnd.m_arData[22];
			break;
		case 4://pinky
			frmRaw.m_arData[25] = fPB * frmBeg.m_arData[25] + fPE * frmEnd.m_arData[25];
			frmRaw.m_arData[26] = fPB * frmBeg.m_arData[26] + fPE * frmEnd.m_arData[26];
			frmRaw.m_arData[27] = fPB * frmBeg.m_arData[27] + fPE * frmEnd.m_arData[27];
			frmRaw.m_arData[28] = fPB * frmBeg.m_arData[28] + fPE * frmEnd.m_arData[28];
			break;
		}
		m_arFrame[i] = frmRaw;
	}
}

float CRawClip::AvgVelocity(int iDOF)
{
	float fVelSum=0;
	for(int i = 0; i < m_arFrame.size()-1; ++i)
	{
		CRawFrame frmCurrent = m_arFrame[i];
		CRawFrame frmNext = m_arFrame[i+1];
		float fVelocity = abs(frmCurrent.m_arData[iDOF]-frmNext.m_arData[iDOF]);
		fVelSum+=fVelocity;
	}
	float fVelAvg = fVelSum / (m_arFrame.size()-1);
	return fVelAvg;
}
void CRawClip::CorrectStandardSpreadOutThumb(bool bLeft, float fFlatAbd_r, float fSpreadAbd_r)
{
	float fFlatAbd_s = 100, fSpreadAbd_s = 0; 
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		float fThumbAbd = m_arFrame[i].m_arData[1];
		if(!bLeft)
			fThumbAbd = - fThumbAbd;

		if(fThumbAbd > fSpreadAbd_s)
			fSpreadAbd_s = fThumbAbd;
		if(fThumbAbd < fFlatAbd_s)
			fFlatAbd_s = fThumbAbd;
	}
	if(!bLeft)
	{
		fFlatAbd_s = - fFlatAbd_s;
		fSpreadAbd_s = - fSpreadAbd_s;
	}

	if(fFlatAbd_s == fSpreadAbd_s)
		return;

	float a = (fSpreadAbd_r - fFlatAbd_r) / (fSpreadAbd_s - fFlatAbd_s);
	float b = fFlatAbd_r - (a * fFlatAbd_s);
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		float fThumbAbd = m_arFrame[i].m_arData[1];
		fThumbAbd = a * fThumbAbd + b;
		m_arFrame[i].m_arData[0] = -15;
		m_arFrame[i].m_arData[1] = fThumbAbd;		
		m_arFrame[i].m_arData[2] = 0.25 * (-15) - 0.375 * fThumbAbd;
		m_arFrame[i].m_arData[3] = 0;
		m_arFrame[i].m_arData[4] = 0;
	}
}
void CRawClip::CorrectBetweenThumb(bool bLeft, CRawFrame frmFlat, CRawFrame frmFlex)
{
	if(m_arFrame.size() == 0)
		return;

	CRawFrame frmFlat_s = m_arFrame[0];
	float fFlat0 = frmFlat_s.m_arData[0], fFlat1 = frmFlat_s.m_arData[1], fFlat3 = frmFlat_s.m_arData[3], fFlat4 = frmFlat_s.m_arData[4];
	CRawFrame frmFlex_s = m_arFrame[m_arFrame.size() - 1];
	float fFlex0 = frmFlex_s.m_arData[0], fFlex1 = frmFlex_s.m_arData[1], fFlex3 = frmFlex_s.m_arData[3], fFlex4 = frmFlex_s.m_arData[4];

	float a0 = (frmFlex.m_arData[0] - frmFlat.m_arData[0]) / (fFlex0 - fFlat0);
	float b0 =  frmFlat.m_arData[0] - (a0 * fFlat0);

	float a1 = (frmFlex.m_arData[1] - frmFlat.m_arData[1]) / (fFlex1 - fFlat1);
	float b1 = frmFlat.m_arData[1] - (a1 * fFlat1);

	float a3 = (frmFlex.m_arData[3] - frmFlat.m_arData[3]) / (fFlex3 - fFlat3);
	float b3 = frmFlat.m_arData[3] - (a3 * fFlat3);

	float a4 = (frmFlex.m_arData[4] - frmFlat.m_arData[4]) / (fFlex4 - fFlat4);
	float b4 = frmFlat.m_arData[4] - (a4 * fFlat4);

	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		frmRaw.m_arData[0] = a0 * frmRaw.m_arData[0] + b0;
		if(bLeft)
			frmRaw.SuppressOverbendSigmoid(bLeft, 0, frmFlex.m_arData[0], frmFlat.m_arData[0]);
		else
			frmRaw.SuppressOverbendSigmoid(bLeft, 0, frmFlat.m_arData[0], frmFlex.m_arData[0]);

		frmRaw.m_arData[1] = a1 * frmRaw.m_arData[1] + b1;	
		if(bLeft)
			frmRaw.SuppressOverbendSigmoid(bLeft, 1, frmFlat.m_arData[1], frmFlex.m_arData[1]);
		else
			frmRaw.SuppressOverbendSigmoid(bLeft, 1, frmFlex.m_arData[1], frmFlat.m_arData[1]);

		frmRaw.m_arData[2] = 0.25 * frmRaw.m_arData[0] - 0.375 *  frmRaw.m_arData[1];

		frmRaw.m_arData[3] = a3 * frmRaw.m_arData[3] + b3;
		frmRaw.SuppressOverbendSigmoid(bLeft, 3, frmFlex.m_arData[3], frmFlat.m_arData[3]);

		frmRaw.m_arData[4] = a4 * frmRaw.m_arData[4] + b4;
		frmRaw.SuppressOverbendSigmoid(bLeft, 4, frmFlex.m_arData[4], frmFlat.m_arData[4]);
		m_arFrame[i] = frmRaw;
	}
}

void CRawClip::RangeFilter(bool bLeft)
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		frmRaw.RangeFilter(bLeft);
	}
}

void CRawClip::ExportRotation(int iDOFIndex, std::string strPath)
{
	std::ofstream fout(strPath.c_str());

	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		fout << frmRaw.m_arData[iDOFIndex] << endl;
	}
	fout.flush();
	fout.close();
}
void CRawClip::ExportRawWithTarget(bool bLeft, std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	CHandSkeletonKin* pHand = new CHandSkeletonKin(!bLeft);

	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		pHand->UpdateFromKinematicData(frmRaw.m_arData);
		pHand->m_pHand->PopulateGlobalPosAndAxis();
		for(int j = 0; j < frmRaw.m_arData.size(); ++j)
		{
			fout << frmRaw.m_arData[j] <<" ";
		}
		float fTargetX=pHand->m_pHand->m_arChain[0]->m_arJoint[3]->m_posGlobalCoord.m_fX;
		float fTargetY=pHand->m_pHand->m_arChain[0]->m_arJoint[3]->m_posGlobalCoord.m_fY;
		float fTargetZ=pHand->m_pHand->m_arChain[0]->m_arJoint[3]->m_posGlobalCoord.m_fZ;
		fout << fTargetX << " "
			<< fTargetY << " "
			<< fTargetZ << " ";
		fTargetX=pHand->m_pHand->m_arChain[0]->m_arJoint[4]->m_posGlobalCoord.m_fX;
		fTargetY=pHand->m_pHand->m_arChain[0]->m_arJoint[4]->m_posGlobalCoord.m_fY;;
		fTargetZ=pHand->m_pHand->m_arChain[0]->m_arJoint[4]->m_posGlobalCoord.m_fZ;;
		fout << fTargetX << " "
			<< fTargetY << " "
			<< fTargetZ << std::endl;
	}
	fout.flush();
	fout.close();
}
STATIC_GAPS CRawClip::FindUnchaningData(int iConsecutiveThreshold)
{
	STATIC_GAPS gaps; 
	int iGapBeg = 0,  iGapEnd = 0;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmGapBeg = m_arFrame[iGapBeg];
		CRawFrame frmRaw = m_arFrame[i];
		if(frmGapBeg == frmRaw)
			iGapEnd = i;
		else
		{
			if(iGapEnd - iGapBeg + 1>= iConsecutiveThreshold)
			{
				STATIC_GAP gap;
				gap.first = iGapBeg;
				gap.second = iGapEnd;
				gaps.push_back(gap);
			}
			iGapBeg = i;
			iGapEnd = i;
		}
		
	}
	return gaps;
}

void CRawClip::AddExtrapolationTr1D()
{
	//find out the min, max of target
	float fMinTarget = 100000, fMaxTarget = -100000;
	float fMinInput, fMaxInput;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frm = m_arFrame[i];
		float fTarget = frm.m_arData[frm.m_arData.size()-1];
		float fInput = frm.m_arData[0];
		if(fTarget < fMinTarget)
		{
			fMinTarget = fTarget;
			fMinInput = fInput;
		}
		if(fTarget > fMaxTarget)
		{
			fMaxTarget = fTarget;
			fMaxInput = fInput;
		}
	}

	//low
	CRawFrame frmExtra;
	/*frmExtra.m_arData.push_back(fMinInput - 30);
	frmExtra.m_arData.push_back(fMinTarget);
	m_arFrame.push_back(frmExtra);

	frmExtra.m_arData.clear();
	frmExtra.m_arData.push_back(fMinInput - 20);
	frmExtra.m_arData.push_back(fMinTarget);
	m_arFrame.push_back(frmExtra);

	frmExtra.m_arData.clear();
	frmExtra.m_arData.push_back(fMinInput - 10);
	frmExtra.m_arData.push_back(fMinTarget);
	m_arFrame.push_back(frmExtra);*/

	//high
	frmExtra.m_arData.clear();
	frmExtra.m_arData.push_back(fMaxInput + 10);
	frmExtra.m_arData.push_back(fMaxTarget);
	m_arFrame.push_back(frmExtra);

	frmExtra.m_arData.clear();
	frmExtra.m_arData.push_back(fMaxInput + 20);
	frmExtra.m_arData.push_back(fMaxTarget);
	m_arFrame.push_back(frmExtra);

	frmExtra.m_arData.clear();
	frmExtra.m_arData.push_back(fMaxInput + 30);
	frmExtra.m_arData.push_back(fMaxTarget);
	m_arFrame.push_back(frmExtra);
}

std::vector<int> CRawClip::GetKNearestThumb(CRawFrame frmRaw, int iK, bool bHD)
{
	std::vector<int> arFrameIdx;
	for(int i = 0; i < iK; ++i)
	{
		int iNearestIdx = -1;
		float fNearestDist = 10000;
		for(int j = 0; j < m_arFrame.size(); ++j)
		{
			CRawFrame frmCur = m_arFrame[j];
			float fDistCur = bHD ? frmRaw.DistanceToThumbHD(frmCur) : frmRaw.DistanceToThumb(frmCur);
			if(fDistCur < fNearestDist)
			{
				int k = 0;
				for(k = 0; k < arFrameIdx.size(); ++k)
					if(arFrameIdx[k] == j)
						break;
				if ( k >=  arFrameIdx.size())//never had before
				{
					iNearestIdx = j;
					fNearestDist = fDistCur;
				}
			}
		}
		if(iNearestIdx != -1)
			arFrameIdx.push_back(iNearestIdx);
	}
	return arFrameIdx;
}

	//xtreme fast
CRawClip CRawClip::xfast_calibrate_finger_flex(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmFist, CRawFrame frmFist_gt, 
		CRawFrame frmOverbend, CRawFrame frmOverbend_gt, 
		bool bLeft)
{
	/*check training data validity, but do nothing==================================================
	ASSERT(frmFist.m_arData[8] <= frmFlat.m_arData[8] && frmFlat.m_arData[8] <= frmOverbend.m_arData[8]);	
	ASSERT(frmFist.m_arData[9] <= frmFlat.m_arData[9] && frmFlat.m_arData[9] <= frmOverbend.m_arData[9]);	
	ASSERT(frmFist.m_arData[10] <= frmFlat.m_arData[10] && frmFlat.m_arData[10] <= frmOverbend.m_arData[10]);
		
	ASSERT(frmFist.m_arData[14] <= frmFlat.m_arData[14] && frmFlat.m_arData[14] <= frmOverbend.m_arData[14]);
	ASSERT(frmFist.m_arData[15] <= frmFlat.m_arData[15] && frmFlat.m_arData[15] <= frmOverbend.m_arData[15]);
	ASSERT(frmFist.m_arData[16] <= frmFlat.m_arData[16] && frmFlat.m_arData[16] <= frmOverbend.m_arData[16]);
	
	ASSERT(frmFist.m_arData[20] <= frmFlat.m_arData[20] && frmFlat.m_arData[20] <= frmOverbend.m_arData[20]);
	ASSERT(frmFist.m_arData[21] <= frmFlat.m_arData[21] && frmFlat.m_arData[21] <= frmOverbend.m_arData[21]);	
	ASSERT(frmFist.m_arData[22] <= frmFlat.m_arData[22] && frmFlat.m_arData[22] <= frmOverbend.m_arData[22]);

	ASSERT(frmFist.m_arData[26] <= frmFlat.m_arData[26] && frmFlat.m_arData[26] <= frmOverbend.m_arData[26]);
	ASSERT(frmFist.m_arData[27] <= frmFlat.m_arData[27] && frmFlat.m_arData[27] <= frmOverbend.m_arData[27]);	
	ASSERT(frmFist.m_arData[28] <= frmFlat.m_arData[28] && frmFlat.m_arData[28] <= frmOverbend.m_arData[28]);*/

	CRawClip clipResult;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmInput = m_arFrame[i];
		CRawFrame frmResult = frmInput.xfast_calibrate_finger_flex(frmFlat, frmFlat_gt,
			frmFist, frmFist_gt,
			frmOverbend, frmOverbend_gt,
			bLeft);
		clipResult.m_arFrame.push_back(frmResult);
	}

	return clipResult;
}

CRawClip CRawClip::xfast_calibrate_im_abd(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmSpread, CRawFrame frmSpread_gt, 
		CRawClip clipIM0, bool bLeft)
{
	CRawClip clipTrainingTarget, clipTrainingInput;

	CRawFrame frmTrainingTarget_flat, frmTrainingInput_flat,
		frmTrainingTarget_spread, frmTrainingInput_spread,
		frmTrainingTarget_im0, frmTrainingInput_im0;

	frmTrainingTarget_flat.m_arData.push_back(frmFlat_gt.m_arData[7]);
	frmTrainingInput_flat.m_arData.push_back(frmFlat.m_arData[8]);
	frmTrainingInput_flat.m_arData.push_back(frmFlat.m_arData[14]);
	frmTrainingInput_flat.m_arData.push_back(frmFlat.m_arData[7]);
	clipTrainingTarget.m_arFrame.push_back(frmTrainingTarget_flat);
	clipTrainingInput.m_arFrame.push_back(frmTrainingInput_flat);

	frmTrainingTarget_spread.m_arData.push_back(frmSpread_gt.m_arData[7]);
	frmTrainingInput_spread.m_arData.push_back(frmSpread.m_arData[8]);
	frmTrainingInput_spread.m_arData.push_back(frmSpread.m_arData[14]);
	frmTrainingInput_spread.m_arData.push_back(frmSpread.m_arData[7]);
	clipTrainingTarget.m_arFrame.push_back(frmTrainingTarget_spread);
	clipTrainingInput.m_arFrame.push_back(frmTrainingInput_spread);

	CRawFrame frmIM0_diffMax;
	float fDiff = 0;
	for(int i = 0; i < clipIM0.m_arFrame.size(); ++i)
	{ 
		CRawFrame frmIM0 = clipIM0.m_arFrame[i];
		if(frmIM0.m_arData[8] - frmIM0.m_arData[14] > fDiff)
		{
			frmIM0_diffMax = frmIM0;
			fDiff = frmIM0.m_arData[8] - frmIM0.m_arData[14];
		}
	}
	frmTrainingTarget_im0.m_arData.push_back(0);
	frmTrainingInput_im0.m_arData.push_back(frmIM0_diffMax.m_arData[8]);
	frmTrainingInput_im0.m_arData.push_back(frmIM0_diffMax.m_arData[14]);
	frmTrainingInput_im0.m_arData.push_back(frmIM0_diffMax.m_arData[7]);
	clipTrainingTarget.m_arFrame.push_back(frmTrainingTarget_im0);
	clipTrainingInput.m_arFrame.push_back(frmTrainingInput_im0);

	CRawClip clipResult = MatlabUtil::MultilinearRegress(clipTrainingTarget, clipTrainingInput, *this, 7);
	return clipResult;
}

CRawClip CRawClip::xfast_calibrate_finger_abd(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmSpread, CRawFrame frmSpread_gt, 
		CRawClip clipIM0, bool bLeft)
{
	CRawClip clipResult;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmInput = m_arFrame[i];
		CRawFrame frmResult = frmInput.xfast_calibrate_finger_abd(frmFlat, frmFlat_gt, 
			frmSpread, frmSpread_gt,
			bLeft);
		clipResult.m_arFrame.push_back(frmResult);
	}
	//clipResult = clipResult.xfast_calibrate_im_abd(frmFlat, frmFlat_gt, frmSpread, frmSpread_gt, clipIM0, bLeft);
	//im0 correction
	//clipResult = xfast_im0_correction(clipResult, bLeft);
	return clipResult;
}

	//clipInput should be xfast_finger_flex/abd calibrated
CRawClip CRawClip::xfast_im0_correction(CRawClip clipInput, bool bLeft)
{
	for(int i = 0; i < clipInput.m_arFrame.size(); ++i)
	{
		float fFlexDiff = clipInput.m_arFrame[i].m_arData[8] - clipInput.m_arFrame[i].m_arData[14];
		if(fFlexDiff <= 0)
			continue;
		if(bLeft)
			clipInput.m_arFrame[i].m_arData[7] = clipInput.m_arFrame[i].m_arData[7] - 0.39 * fFlexDiff;
		else
			clipInput.m_arFrame[i].m_arData[7] = clipInput.m_arFrame[i].m_arData[7] + 0.39 * fFlexDiff;

	}
	return clipInput;

	//left hand===============================================================================
	if (bLeft)
	{
		int iBeg = -1, iEnd = -1;
		float fBegOrig =0, fEndOrig = 0;
		for(int i = 0; i < clipInput.m_arFrame.size(); ++i)
		{
			CRawFrame frmInput = clipInput.m_arFrame[i];
			//no stretch
			if ((frmInput.m_arData[8] - frmInput.m_arData[14]) < 35)
				continue;
			
			//no effect
			if(frmInput.m_arData[7] < -5)
				continue;

			//one gap [iBeg, iEnd] is complete
			if(iEnd+1 != i && iBeg!=-1)
			{
				//smooth pre gap
				int iSmoothBeg = max(0, iBeg - 10);
				for(int s = iSmoothBeg; s <iBeg; ++s)
				{
					float fSmoothBegOrig = clipInput.m_arFrame[iSmoothBeg].m_arData[7];
					float fSmoothBegNow = fSmoothBegOrig;
					float fBegNow = clipInput.m_arFrame[iBeg].m_arData[7];
					float fCurrentOrig = clipInput.m_arFrame[s].m_arData[7];
					float fCurrentNow = GloveUtil::linearAdjust(fCurrentOrig, fSmoothBegOrig, fBegOrig, fSmoothBegNow, fBegNow);
					clipInput.m_arFrame[s].m_arData[7] = fCurrentNow;
				}

				//smooth post gap
				int iSmoothEnd = min(clipInput.m_arFrame.size()-1, iEnd + 10);
				for(int s = iEnd+1; s<iSmoothEnd; ++s)
				{
					float fSmoothEndOrig = clipInput.m_arFrame[iSmoothEnd].m_arData[7];
					float fSmoothEndNow = fSmoothEndOrig;
					float fEndNow = clipInput.m_arFrame[iEnd].m_arData[7];
					float fCurrentOrig = clipInput.m_arFrame[s].m_arData[7];
					float fCurrentNow = GloveUtil::linearAdjust(fCurrentOrig, fEndOrig, fSmoothEndOrig, fEndNow, fSmoothEndNow);
					clipInput.m_arFrame[s].m_arData[7] = fCurrentNow;
				}
				//new gap
				iBeg = i; fBegOrig = frmInput.m_arData[7];
			}

			if(iBeg==-1)
			{
				iBeg = i; fBegOrig = frmInput.m_arData[7];
			}
			iEnd = i; fEndOrig = frmInput.m_arData[7];

			frmInput.m_arData[7] = GloveUtil::linearAdjust(frmInput.m_arData[7], -5, 20, -5, 0);			
			clipInput.m_arFrame[i] = frmInput;
		}
		return clipInput;
	}

	//right hand================================================================================
	if (!bLeft)
	{
		int iBeg = -1, iEnd = -1;
		float fBegOrig =0, fEndOrig = 0;
		for(int i = 0; i < clipInput.m_arFrame.size(); ++i)
		{
			CRawFrame frmInput = clipInput.m_arFrame[i];
			//no stretch
			if ((frmInput.m_arData[8] - frmInput.m_arData[14]) < 35)
				continue;
			
			//no effect
			if(frmInput.m_arData[7] > 5)
				continue;

			//one gap [iBeg, iEnd] is complete
			if(iEnd+1 != i && iBeg!=-1)
			{
				//smooth pre gap
				int iSmoothBeg = max(0, iBeg - 10);
				for(int s = iSmoothBeg; s <iBeg; ++s)
				{
					float fSmoothBegOrig = clipInput.m_arFrame[iSmoothBeg].m_arData[7];
					float fSmoothBegNow = fSmoothBegOrig;
					float fBegNow = clipInput.m_arFrame[iBeg].m_arData[7];
					float fCurrentOrig = clipInput.m_arFrame[s].m_arData[7];
					float fCurrentNow = GloveUtil::linearAdjust(fCurrentOrig, fSmoothBegOrig, fBegOrig, fSmoothBegNow, fBegNow);
					clipInput.m_arFrame[s].m_arData[7] = fCurrentNow;
				}

				//smooth post gap
				int iSmoothEnd = min(clipInput.m_arFrame.size()-1, iEnd + 10);
				for(int s = iEnd+1; s<iSmoothEnd; ++s)
				{
					float fSmoothEndOrig = clipInput.m_arFrame[iSmoothEnd].m_arData[7];
					float fSmoothEndNow = fSmoothEndOrig;
					float fEndNow = clipInput.m_arFrame[iEnd].m_arData[7];
					float fCurrentOrig = clipInput.m_arFrame[s].m_arData[7];
					float fCurrentNow = GloveUtil::linearAdjust(fCurrentOrig, fEndOrig, fSmoothEndOrig, fEndNow, fSmoothEndNow);
					clipInput.m_arFrame[s].m_arData[7] = fCurrentNow;
				}
				//new gap
				iBeg = i; fBegOrig = frmInput.m_arData[7];
			}

			if(iBeg==-1)
			{
				iBeg = i; fBegOrig = frmInput.m_arData[7];
			}
			iEnd = i; fEndOrig = frmInput.m_arData[7];

			frmInput.m_arData[7] = GloveUtil::linearAdjust(frmInput.m_arData[7], 5, -20, 5, 0);			
			clipInput.m_arFrame[i] = frmInput;
		}
		return clipInput;

	}
}

CRawClip CRawClip::xfast_calibrate_thumb(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmFist, CRawFrame frmFist_gt,
		CRawFrame frmSpread, CRawFrame frmSpread_gt, 
		bool bLeft)
{
	CRawClip clipResult;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmInput = m_arFrame[i];
		CRawFrame frmResult= frmInput.xfast_calibrate_thumb(frmFlat, frmFlat_gt,
			frmFist, frmFist_gt,
			frmSpread, frmSpread_gt,
			bLeft);
		clipResult.m_arFrame.push_back(frmResult);
	}

	return clipResult;
}

CRawClip CRawClip::xfast_calibrate_ik(CRawClip clipThisOrig, CRawClip clipIndexOrig, CRawClip clipIndex2Orig, std::string strFileLog, bool bLeft)
{
	//1. detect =================================================
	std::ofstream fout(strFileLog.c_str());
	std::vector<int> arTouch;
	for(int i = 0; i < m_arFrame.size(); ++ i)
	{
		CRawFrame frmThisOrig = clipThisOrig.m_arFrame[i];
		bool bMatched = false;
		//find match in index.raw =======================================
		for(int j = 0; j < clipIndexOrig.m_arFrame.size(); ++j)
		{
			CRawFrame frmIndexOrig = clipIndexOrig.m_arFrame[j];

			if(abs(frmThisOrig.m_arData[0]-frmIndexOrig.m_arData[0]) < 15 &&
			abs(frmThisOrig.m_arData[1]-frmIndexOrig.m_arData[1]) < 15 &&
			abs(frmThisOrig.m_arData[3]-frmIndexOrig.m_arData[3]) < 15 &&
			abs(frmThisOrig.m_arData[4]-frmIndexOrig.m_arData[4]) < 15 &&

			abs(frmThisOrig.m_arData[8]-frmIndexOrig.m_arData[8]) < 15 && 
			abs(frmThisOrig.m_arData[9]-frmIndexOrig.m_arData[9]) < 15 && 
			abs(frmThisOrig.m_arData[10]-frmIndexOrig.m_arData[10]) < 15 /*&& 
			abs(frmThisOrig.m_arData[14]-frmIndexOrig.m_arData[14]) < 20 && 
			abs(frmThisOrig.m_arData[20]-frmIndexOrig.m_arData[20]) < 20 && 
			abs(frmThisOrig.m_arData[26]-frmIndexOrig.m_arData[26]) < 20*/
			)
			{
				bMatched = true;
				break;
			}
		}
		//find match in index2.raw ================================
		for(int j = 0; j < clipIndex2Orig.m_arFrame.size(); ++j)
		{
			CRawFrame frmIndex2Orig = clipIndex2Orig.m_arFrame[j];

			if(abs(frmThisOrig.m_arData[0]-frmIndex2Orig.m_arData[0]) < 15 &&
			abs(frmThisOrig.m_arData[1]-frmIndex2Orig.m_arData[1]) < 15 &&
			abs(frmThisOrig.m_arData[3]-frmIndex2Orig.m_arData[3]) < 15 &&
			abs(frmThisOrig.m_arData[4]-frmIndex2Orig.m_arData[4]) < 15 &&

			abs(frmThisOrig.m_arData[8]-frmIndex2Orig.m_arData[8]) < 15 && 
			abs(frmThisOrig.m_arData[9]-frmIndex2Orig.m_arData[9]) < 15 && 
			abs(frmThisOrig.m_arData[10]-frmIndex2Orig.m_arData[10]) < 15 /*&& 			
			abs(frmThisOrig.m_arData[14]-frmIndex2Orig.m_arData[14]) < 20 && 
			abs(frmThisOrig.m_arData[20]-frmIndex2Orig.m_arData[20]) < 20 && 
			abs(frmThisOrig.m_arData[26]-frmIndex2Orig.m_arData[26]) < 20*/)
			{
				bMatched = true;
				break;
			}
		}
		//to see if found
		if(bMatched)
		{
			arTouch.push_back(1);
			fout << i << " " << std::endl;
		}
		else
			arTouch.push_back(-1);
	}
	fout.flush();
	fout.close();

	//2. touch =================================================
	//3. smooth ================================================
	CRawClip clipResult = *this;
	return clipResult;
}