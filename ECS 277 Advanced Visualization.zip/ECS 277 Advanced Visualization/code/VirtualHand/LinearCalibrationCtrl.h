#pragma once

#include <vector>
#include "GloveAnimation.h"
#include "OpenGLWnd.h"
#include "GloveRenderer.h"
#include "GloveMocapMgr.h"
class CGloveCalibration;
// CLinearCalibrationCtrl dialog

class CLinearCalibrationCtrl : public CDialog
{
	DECLARE_DYNAMIC(CLinearCalibrationCtrl)

public:
	CLinearCalibrationCtrl(bool bLeft = true, CWnd* pParent = NULL);   // standard constructor
	virtual ~CLinearCalibrationCtrl();	
	virtual BOOL OnInitDialog();
	void UpdateCalibrationToUI();
	void UpdateUIToCalibration();

	bool m_bLeft;
	CGloveMocapMgr* m_pGlvMgr;
	CGloveCalibration* m_pLinearCalibration;
	COpenGLWnd m_wndOpenGL;
	enum {E_INDEX_KEY_FLAT=0, E_INDEX_KEY_SPREAD, E_INDEX_KEY_FIST, E_INDEX_KEY_EXTBEND};
	std::vector<CGlvFrame> m_arKeyPoses_s;
	std::vector<CGlvFrame> m_arKeyPoses_r;

// Dialog Data
	enum { IDD = IDD_CTRL_LINEAR_CALIBRATION };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:	
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnEnChangeEditGain0();
	afx_msg void OnEnChangeEditOffset0();
	afx_msg void OnEnChangeEditGain1();
	afx_msg void OnEnChangeEditOffset1();
	afx_msg void OnEnChangeEditGain2();
	afx_msg void OnEnChangeEditOffset2();
	afx_msg void OnEnChangeEditGain3();
	afx_msg void OnEnChangeEditOffset3();
	afx_msg void OnEnChangeEditGain4();
	afx_msg void OnEnChangeEditOffset4();
	afx_msg void OnEnChangeEditGain5();
	afx_msg void OnEnChangeEditOffset5();
	afx_msg void OnEnChangeEditGain6();
	afx_msg void OnEnChangeEditOffset6();
	afx_msg void OnEnChangeEditGain7();
	afx_msg void OnEnChangeEditOffset7();
	afx_msg void OnEnChangeEditGain8();
	afx_msg void OnEnChangeEditOffset8();
	afx_msg void OnEnChangeEditGain9();
	afx_msg void OnEnChangeEditOffset9();
	afx_msg void OnEnChangeEditGain10();
	afx_msg void OnEnChangeEditOffset10();
	afx_msg void OnEnChangeEditGain11();
	afx_msg void OnEnChangeEditOffset11();
	afx_msg void OnEnChangeEditGain12();
	afx_msg void OnEnChangeEditOffset12();
	afx_msg void OnEnChangeEditGain13();
	afx_msg void OnEnChangeEditOffset13();
	afx_msg void OnEnChangeEditGain14();
	afx_msg void OnEnChangeEditOffset14();
	afx_msg void OnEnChangeEditGain15();
	afx_msg void OnEnChangeEditOffset15();
	afx_msg void OnEnChangeEditGain16();
	afx_msg void OnEnChangeEditOffset16();
	afx_msg void OnEnChangeEditGain17();
	afx_msg void OnEnChangeEditOffset17();
	afx_msg void OnEnChangeEditGain18();
	afx_msg void OnEnChangeEditOffset18();
	afx_msg void OnEnChangeEditGain19();
	afx_msg void OnEnChangeEditOffset19();
	afx_msg void OnEnChangeEditGain20();
	afx_msg void OnEnChangeEditOffset20();
	afx_msg void OnEnChangeEditGain21();
	afx_msg void OnEnChangeEditOffset21();
	afx_msg void OnEnChangeEditGain22();
	afx_msg void OnEnChangeEditOffset22();
	afx_msg void OnBnClickedButtonSenseFist();
	afx_msg void OnBnClickedButtonSenseSpread();
	afx_msg void OnBnClickedButtonSenseExtbend();
	afx_msg void OnBnClickedButtonSenseFlat();
	afx_msg void OnBnClickedButtonLoadFistReal();
	afx_msg void OnBnClickedButtonLoadSpreadReal();
	afx_msg void OnBnClickedButtonLoadExtbendReal();
	afx_msg void OnBnClickedButtonLoadFlatReal();
	afx_msg void OnBnClickedRadioShowFistSensor();
	afx_msg void OnBnClickedRadioShowSpreadSensor();
	afx_msg void OnBnClickedRadioShowExtbendSensor();
	afx_msg void OnBnClickedRadioShowFlatSensor();
	afx_msg void OnBnClickedRadioShowFistReal();
	afx_msg void OnBnClickedRadioShowSpreadReal();
	afx_msg void OnBnClickedRadioShowExtbendReal();
	afx_msg void OnBnClickedRadioShowFlatReal();
	afx_msg void OnBnClickedButtonCalibrateLinearRegress();
	afx_msg void OnBnClickedButtonLoadLinearCalibration();
	afx_msg void OnBnClickedButtonSaveLinearCalibration();
	afx_msg void OnBnClickedRadioShowRealtimeLinear();
};
