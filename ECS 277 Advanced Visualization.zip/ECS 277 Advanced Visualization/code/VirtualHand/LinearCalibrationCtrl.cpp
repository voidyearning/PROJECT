// LinearCalibrationCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "LinearCalibrationCtrl.h"
#include "GloveCalibration.h"
#include "GloveUtil.h"

// CLinearCalibrationCtrl dialog

IMPLEMENT_DYNAMIC(CLinearCalibrationCtrl, CDialog)

CLinearCalibrationCtrl::CLinearCalibrationCtrl(bool bLeft, CWnd* pParent /*=NULL*/)
	: CDialog(CLinearCalibrationCtrl::IDD, pParent)
{
	for(int i = 0; i < 4; i++)
	{
		m_arKeyPoses_s.push_back(CGlvFrame::GetEmptyFrame());
		m_arKeyPoses_r.push_back(CGlvFrame::GetEmptyFrame());
	}
	m_bLeft = bLeft;

	COpenGLHandRendererKin* pRenderer = new COpenGLHandRendererKin(new CHandSkeletonKin(!bLeft));
	m_wndOpenGL.m_pRenderer = (COpenGLRenderer*)pRenderer;

	if(m_bLeft)
		m_pGlvMgr = CGloveMocapMgr::GetGloveMgr(LEFT_HAND);
	else
		m_pGlvMgr = CGloveMocapMgr::GetGloveMgr(RIGHT_HAND);
	
	if(m_pGlvMgr)
		m_pLinearCalibration = m_pGlvMgr->m_pCalib;
	
	if(m_pLinearCalibration == NULL)
		m_pLinearCalibration = new CGloveCalibration();
}

CLinearCalibrationCtrl::~CLinearCalibrationCtrl()
{
	COpenGLHandRendererKin* pRenderer = dynamic_cast<COpenGLHandRendererKin*>(m_wndOpenGL.m_pRenderer);
	delete pRenderer->m_pHand;
	delete pRenderer;

	if(m_pGlvMgr == NULL || m_pGlvMgr->m_pCalib != m_pLinearCalibration)
		delete m_pLinearCalibration;
}

void CLinearCalibrationCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}
BOOL CLinearCalibrationCtrl::OnInitDialog()
{
	CRect rcWndOpenGL, rcParent;
	GetDlgItem(IDC_OPENGL_WND_KEYPOSE)->GetWindowRect(rcWndOpenGL);
	GetWindowRect(rcParent);
	rcWndOpenGL.MoveToXY(rcWndOpenGL.left-rcParent.left, rcWndOpenGL.top-rcParent.top);
	m_wndOpenGL.Create(NULL,
						NULL,
						WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE,						       
						rcWndOpenGL,  
						this,  
						0);  
	m_wndOpenGL.m_bShowOrigin = false;
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.BringWindowToTop();
	m_wndOpenGL.OnDraw(NULL);
	UpdateCalibrationToUI();

	return CDialog::OnInitDialog();
}
void CLinearCalibrationCtrl::UpdateCalibrationToUI()
{
	if(m_pLinearCalibration == NULL)
		return;

	CString strText;
	//gain
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[0].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_0)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[1].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_1)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[2].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_2)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[3].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_3)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[4].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_4)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[5].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_5)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[6].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_6)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[7].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_7)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[8].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_8)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[9].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_9)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[10].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_10)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[11].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_11)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[12].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_12)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[13].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_13)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[14].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_14)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[15].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_15)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[16].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_16)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[17].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_17)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[18].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_18)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[19].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_19)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[20].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_20)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[21].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_21)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[22].m_fGain);
	GetDlgItem(IDC_EDIT_GAIN_22)->SetWindowText(strText);

	//offset
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[0].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_0)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[1].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_1)->SetWindowText(strText);		
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[2].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_2)->SetWindowText(strText);		
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[3].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_3)->SetWindowText(strText);		
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[4].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_4)->SetWindowText(strText);		
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[5].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_5)->SetWindowText(strText);		
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[6].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_6)->SetWindowText(strText);		
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[7].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_7)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[8].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_8)->SetWindowText(strText);	
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[9].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_9)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[10].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_10)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[11].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_11)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[12].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_12)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[13].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_13)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[14].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_14)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[15].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_15)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[16].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_16)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[17].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_17)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[18].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_18)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[19].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_19)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[20].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_20)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[21].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_21)->SetWindowText(strText);
	strText.Format(L"%.2f", m_pLinearCalibration->m_arAdjustItem[22].m_fOffset);
	GetDlgItem(IDC_EDIT_OFFSET_22)->SetWindowText(strText);
}
void CLinearCalibrationCtrl::UpdateUIToCalibration()
{	
	CString strText;
	//gain
	GetDlgItem(IDC_EDIT_GAIN_0)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[0].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_1)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[1].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_2)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[2].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_3)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[3].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_4)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[4].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_5)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[5].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_6)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[6].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_7)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[7].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_8)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[8].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_9)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[9].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_10)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[10].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_11)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[11].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_12)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[12].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_13)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[13].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_14)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[14].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_15)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[15].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_16)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[16].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_17)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[17].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_18)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[18].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_19)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[19].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_20)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[20].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_21)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[21].m_fGain = _wtof(strText.GetBuffer());
	GetDlgItem(IDC_EDIT_GAIN_22)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[22].m_fGain = _wtof(strText.GetBuffer());

	//offset
	GetDlgItem(IDC_EDIT_OFFSET_0)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[0].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_1)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[1].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_2)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[2].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_3)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[3].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_4)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[4].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_5)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[5].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_6)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[6].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_7)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[7].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_8)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[8].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_9)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[9].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_10)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[10].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_11)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[11].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_12)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[12].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_13)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[13].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_14)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[14].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_15)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[15].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_16)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[16].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_17)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[17].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_18)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[18].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_19)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[19].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_20)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[20].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_21)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[21].m_fOffset = _wtof(strText.GetBuffer());	
	GetDlgItem(IDC_EDIT_OFFSET_22)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[22].m_fOffset = _wtof(strText.GetBuffer());
}

BEGIN_MESSAGE_MAP(CLinearCalibrationCtrl, CDialog)
	ON_WM_TIMER()
	ON_EN_CHANGE(IDC_EDIT_GAIN_0, &CLinearCalibrationCtrl::OnEnChangeEditGain0)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_0, &CLinearCalibrationCtrl::OnEnChangeEditOffset0)
	ON_EN_CHANGE(IDC_EDIT_GAIN_1, &CLinearCalibrationCtrl::OnEnChangeEditGain1)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_1, &CLinearCalibrationCtrl::OnEnChangeEditOffset1)
	ON_EN_CHANGE(IDC_EDIT_GAIN_2, &CLinearCalibrationCtrl::OnEnChangeEditGain2)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_2, &CLinearCalibrationCtrl::OnEnChangeEditOffset2)
	ON_EN_CHANGE(IDC_EDIT_GAIN_3, &CLinearCalibrationCtrl::OnEnChangeEditGain3)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_3, &CLinearCalibrationCtrl::OnEnChangeEditOffset3)
	ON_EN_CHANGE(IDC_EDIT_GAIN_4, &CLinearCalibrationCtrl::OnEnChangeEditGain4)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_4, &CLinearCalibrationCtrl::OnEnChangeEditOffset4)
	ON_EN_CHANGE(IDC_EDIT_GAIN_5, &CLinearCalibrationCtrl::OnEnChangeEditGain5)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_5, &CLinearCalibrationCtrl::OnEnChangeEditOffset5)
	ON_EN_CHANGE(IDC_EDIT_GAIN_6, &CLinearCalibrationCtrl::OnEnChangeEditGain6)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_6, &CLinearCalibrationCtrl::OnEnChangeEditOffset6)
	ON_EN_CHANGE(IDC_EDIT_GAIN_7, &CLinearCalibrationCtrl::OnEnChangeEditGain7)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_7, &CLinearCalibrationCtrl::OnEnChangeEditOffset7)
	ON_EN_CHANGE(IDC_EDIT_GAIN_8, &CLinearCalibrationCtrl::OnEnChangeEditGain8)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_8, &CLinearCalibrationCtrl::OnEnChangeEditOffset8)
	ON_EN_CHANGE(IDC_EDIT_GAIN_9, &CLinearCalibrationCtrl::OnEnChangeEditGain9)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_9, &CLinearCalibrationCtrl::OnEnChangeEditOffset9)
	ON_EN_CHANGE(IDC_EDIT_GAIN_10, &CLinearCalibrationCtrl::OnEnChangeEditGain10)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_10, &CLinearCalibrationCtrl::OnEnChangeEditOffset10)
	ON_EN_CHANGE(IDC_EDIT_GAIN_11, &CLinearCalibrationCtrl::OnEnChangeEditGain11)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_11, &CLinearCalibrationCtrl::OnEnChangeEditOffset11)
	ON_EN_CHANGE(IDC_EDIT_GAIN_12, &CLinearCalibrationCtrl::OnEnChangeEditGain12)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_12, &CLinearCalibrationCtrl::OnEnChangeEditOffset12)
	ON_EN_CHANGE(IDC_EDIT_GAIN_13, &CLinearCalibrationCtrl::OnEnChangeEditGain13)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_13, &CLinearCalibrationCtrl::OnEnChangeEditOffset13)
	ON_EN_CHANGE(IDC_EDIT_GAIN_14, &CLinearCalibrationCtrl::OnEnChangeEditGain14)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_14, &CLinearCalibrationCtrl::OnEnChangeEditOffset14)
	ON_EN_CHANGE(IDC_EDIT_GAIN_15, &CLinearCalibrationCtrl::OnEnChangeEditGain15)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_15, &CLinearCalibrationCtrl::OnEnChangeEditOffset15)
	ON_EN_CHANGE(IDC_EDIT_GAIN_16, &CLinearCalibrationCtrl::OnEnChangeEditGain16)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_16, &CLinearCalibrationCtrl::OnEnChangeEditOffset16)
	ON_EN_CHANGE(IDC_EDIT_GAIN_17, &CLinearCalibrationCtrl::OnEnChangeEditGain17)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_17, &CLinearCalibrationCtrl::OnEnChangeEditOffset17)
	ON_EN_CHANGE(IDC_EDIT_GAIN_18, &CLinearCalibrationCtrl::OnEnChangeEditGain18)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_18, &CLinearCalibrationCtrl::OnEnChangeEditOffset18)
	ON_EN_CHANGE(IDC_EDIT_GAIN_19, &CLinearCalibrationCtrl::OnEnChangeEditGain19)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_19, &CLinearCalibrationCtrl::OnEnChangeEditOffset19)
	ON_EN_CHANGE(IDC_EDIT_GAIN_20, &CLinearCalibrationCtrl::OnEnChangeEditGain20)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_20, &CLinearCalibrationCtrl::OnEnChangeEditOffset20)
	ON_EN_CHANGE(IDC_EDIT_GAIN_21, &CLinearCalibrationCtrl::OnEnChangeEditGain21)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_21, &CLinearCalibrationCtrl::OnEnChangeEditOffset21)
	ON_EN_CHANGE(IDC_EDIT_GAIN_22, &CLinearCalibrationCtrl::OnEnChangeEditGain22)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_22, &CLinearCalibrationCtrl::OnEnChangeEditOffset22)
	ON_BN_CLICKED(IDC_BUTTON_SENSE_FIST, &CLinearCalibrationCtrl::OnBnClickedButtonSenseFist)
	ON_BN_CLICKED(IDC_BUTTON_SENSE_SPREAD, &CLinearCalibrationCtrl::OnBnClickedButtonSenseSpread)
	ON_BN_CLICKED(IDC_BUTTON_SENSE_EXTBEND, &CLinearCalibrationCtrl::OnBnClickedButtonSenseExtbend)
	ON_BN_CLICKED(IDC_BUTTON_SENSE_FLAT, &CLinearCalibrationCtrl::OnBnClickedButtonSenseFlat)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_FIST_REAL, &CLinearCalibrationCtrl::OnBnClickedButtonLoadFistReal)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_SPREAD_REAL, &CLinearCalibrationCtrl::OnBnClickedButtonLoadSpreadReal)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_EXTBEND_REAL, &CLinearCalibrationCtrl::OnBnClickedButtonLoadExtbendReal)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_FLAT_REAL, &CLinearCalibrationCtrl::OnBnClickedButtonLoadFlatReal)
	ON_BN_CLICKED(IDC_RADIO_SHOW_FIST_SENSOR, &CLinearCalibrationCtrl::OnBnClickedRadioShowFistSensor)
	ON_BN_CLICKED(IDC_RADIO_SHOW_SPREAD_SENSOR, &CLinearCalibrationCtrl::OnBnClickedRadioShowSpreadSensor)
	ON_BN_CLICKED(IDC_RADIO_SHOW_EXTBEND_SENSOR, &CLinearCalibrationCtrl::OnBnClickedRadioShowExtbendSensor)
	ON_BN_CLICKED(IDC_RADIO_SHOW_FLAT_SENSOR, &CLinearCalibrationCtrl::OnBnClickedRadioShowFlatSensor)
	ON_BN_CLICKED(IDC_RADIO_SHOW_FIST_REAL, &CLinearCalibrationCtrl::OnBnClickedRadioShowFistReal)
	ON_BN_CLICKED(IDC_RADIO_SHOW_SPREAD_REAL, &CLinearCalibrationCtrl::OnBnClickedRadioShowSpreadReal)
	ON_BN_CLICKED(IDC_RADIO_SHOW_EXTBEND_REAL, &CLinearCalibrationCtrl::OnBnClickedRadioShowExtbendReal)
	ON_BN_CLICKED(IDC_RADIO_SHOW_FLAT_REAL, &CLinearCalibrationCtrl::OnBnClickedRadioShowFlatReal)
	ON_BN_CLICKED(IDC_BUTTON_CALIBRATE_LINEAR_REGRESS, &CLinearCalibrationCtrl::OnBnClickedButtonCalibrateLinearRegress)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_LINEAR_CALIBRATION, &CLinearCalibrationCtrl::OnBnClickedButtonLoadLinearCalibration)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_LINEAR_CALIBRATION, &CLinearCalibrationCtrl::OnBnClickedButtonSaveLinearCalibration)
	ON_BN_CLICKED(IDC_RADIO_SHOW_REALTIME_LINEAR, &CLinearCalibrationCtrl::OnBnClickedRadioShowRealtimeLinear)
END_MESSAGE_MAP()

#define TIMER_EVENT_LINEAR_CALIB	12
// CLinearCalibrationCtrl message handlers
void CLinearCalibrationCtrl::OnTimer(UINT_PTR nIDEvent)
{
	if(nIDEvent != TIMER_EVENT_LINEAR_CALIB)
		return;

	std::vector<float>arData = m_pGlvMgr->RetrieveAdjustedDataLinear();
	((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromSensorData(arData);
	m_wndOpenGL.OnDraw(NULL);
}
void CLinearCalibrationCtrl::OnEnChangeEditGain0()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_0)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[0].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset0()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_0)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[0].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain1()
{	
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_1)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[1].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset1()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_1)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[1].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain2()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_2)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[2].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset2()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_2)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[2].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain3()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_3)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[3].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset3()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_3)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[3].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain4()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_4)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[4].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset4()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_4)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[4].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain5()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_5)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[5].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset5()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_5)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[5].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain6()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_6)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[6].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset6()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_6)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[6].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain7()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_7)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[7].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset7()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_7)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[7].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain8()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_8)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[8].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset8()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_8)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[8].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain9()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_9)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[9].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset9()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_9)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[9].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain10()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_10)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[10].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset10()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_10)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[10].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain11()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_11)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[11].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset11()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_11)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[11].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain12()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_12)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[12].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset12()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_12)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[12].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain13()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_13)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[13].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset13()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_13)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[13].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain14()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_14)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[14].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset14()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_14)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[14].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain15()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_15)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[15].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset15()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_15)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[15].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain16()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_16)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[16].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset16()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_16)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[16].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain17()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_17)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[17].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset17()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_17)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[17].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain18()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_18)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[18].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset18()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_18)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[18].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain19()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_19)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[19].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset19()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_19)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[19].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain20()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_20)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[20].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset20()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_20)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[20].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain21()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_21)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[21].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset21()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_21)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[21].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditGain22()
{
	CString strText;
	GetDlgItem(IDC_EDIT_GAIN_22)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[22].m_fGain = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnEnChangeEditOffset22()
{
	CString strText;
	GetDlgItem(IDC_EDIT_OFFSET_22)->GetWindowText(strText);
	m_pLinearCalibration->m_arAdjustItem[22].m_fOffset = _wtof(strText.GetBuffer());
}

void CLinearCalibrationCtrl::OnBnClickedButtonSenseFist()
{
	if(m_pGlvMgr == NULL || !m_pGlvMgr->IsConnected())
		return;

	std::vector<float> arData = m_pGlvMgr->RetrieveSensorData();
	CGlvFrame frmGlv(arData);
	m_arKeyPoses_s[E_INDEX_KEY_FIST] = frmGlv;
}

void CLinearCalibrationCtrl::OnBnClickedButtonSenseSpread()
{	
	if(m_pGlvMgr == NULL || !m_pGlvMgr->IsConnected())
		return;

	std::vector<float> arData = m_pGlvMgr->RetrieveSensorData();
	CGlvFrame frmGlv(arData);
	m_arKeyPoses_s[E_INDEX_KEY_SPREAD] = frmGlv;
}

void CLinearCalibrationCtrl::OnBnClickedButtonSenseExtbend()
{	
	if(m_pGlvMgr == NULL || !m_pGlvMgr->IsConnected())
		return;

	std::vector<float> arData = m_pGlvMgr->RetrieveSensorData();
	CGlvFrame frmGlv(arData);
	m_arKeyPoses_s[E_INDEX_KEY_EXTBEND] = frmGlv;
}

void CLinearCalibrationCtrl::OnBnClickedButtonSenseFlat()
{	
	if(m_pGlvMgr == NULL || !m_pGlvMgr->IsConnected())
		return;

	std::vector<float> arData = m_pGlvMgr->RetrieveSensorData();
	CGlvFrame frmGlv(arData);
	m_arKeyPoses_s[E_INDEX_KEY_FLAT] = frmGlv;
}

void CLinearCalibrationCtrl::OnBnClickedButtonLoadFistReal()
{	
	if(m_pGlvMgr == NULL || !m_pGlvMgr->IsConnected())
		return;

	CFileDialog dlgFile(TRUE, L"Glove Frame(*.gfm)|*.gfm", 0, 4|2, L"Gove Frame(*.gfm)|*.gfm||");
	if(IDOK != dlgFile.DoModal())
		return;
	CGlvFrame frmGlv;
	frmGlv.LoadFromFile(GloveUtil::ToChar(dlgFile.GetPathName()));
	m_arKeyPoses_r[E_INDEX_KEY_FIST] = frmGlv;
}

void CLinearCalibrationCtrl::OnBnClickedButtonLoadSpreadReal()
{	
	if(m_pGlvMgr == NULL || !m_pGlvMgr->IsConnected())
		return;

	CFileDialog dlgFile(TRUE, L"Glove Frame(*.gfm)|*.gfm", 0, 4|2, L"Gove Frame(*.gfm)|*.gfm||");
	if(IDOK != dlgFile.DoModal())
		return;
	CGlvFrame frmGlv;
	frmGlv.LoadFromFile(GloveUtil::ToChar(dlgFile.GetPathName()));
	m_arKeyPoses_r[E_INDEX_KEY_SPREAD] = frmGlv;
}

void CLinearCalibrationCtrl::OnBnClickedButtonLoadExtbendReal()
{	
	if(m_pGlvMgr == NULL || !m_pGlvMgr->IsConnected())
		return;

	CFileDialog dlgFile(TRUE, L"Glove Frame(*.gfm)|*.gfm", 0, 4|2, L"Gove Frame(*.gfm)|*.gfm||");
	if(IDOK != dlgFile.DoModal())
		return;
	CGlvFrame frmGlv;
	frmGlv.LoadFromFile(GloveUtil::ToChar(dlgFile.GetPathName()));
	m_arKeyPoses_r[E_INDEX_KEY_EXTBEND] = frmGlv;
}

void CLinearCalibrationCtrl::OnBnClickedButtonLoadFlatReal()
{
	if(m_pGlvMgr == NULL || !m_pGlvMgr->IsConnected())
		return;

	CFileDialog dlgFile(TRUE, L"Glove Frame(*.gfm)|*.gfm", 0, 4|2, L"Gove Frame(*.gfm)|*.gfm||");
	if(IDOK != dlgFile.DoModal())
		return;
	CGlvFrame frmGlv;
	frmGlv.LoadFromFile(GloveUtil::ToChar(dlgFile.GetPathName()));
	m_arKeyPoses_r[E_INDEX_KEY_FLAT] = frmGlv;
}

void CLinearCalibrationCtrl::OnBnClickedRadioShowFistSensor()
{
	KillTimer(TIMER_EVENT_LINEAR_CALIB);
	((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromSensorData(m_arKeyPoses_s[E_INDEX_KEY_FIST].m_arData);
	m_wndOpenGL.OnDraw(NULL);
}

void CLinearCalibrationCtrl::OnBnClickedRadioShowSpreadSensor()
{
	KillTimer(TIMER_EVENT_LINEAR_CALIB);
	((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromSensorData(m_arKeyPoses_s[E_INDEX_KEY_SPREAD].m_arData);
	m_wndOpenGL.OnDraw(NULL);
}

void CLinearCalibrationCtrl::OnBnClickedRadioShowExtbendSensor()
{
	KillTimer(TIMER_EVENT_LINEAR_CALIB);
	((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromSensorData(m_arKeyPoses_s[E_INDEX_KEY_EXTBEND].m_arData);
	m_wndOpenGL.OnDraw(NULL);
}

void CLinearCalibrationCtrl::OnBnClickedRadioShowFlatSensor()
{
	KillTimer(TIMER_EVENT_LINEAR_CALIB);
	((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromSensorData(m_arKeyPoses_s[E_INDEX_KEY_FLAT].m_arData);
	m_wndOpenGL.OnDraw(NULL);
}

void CLinearCalibrationCtrl::OnBnClickedRadioShowFistReal()
{
	KillTimer(TIMER_EVENT_LINEAR_CALIB);
	((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromSensorData(m_arKeyPoses_r[E_INDEX_KEY_FIST].m_arData);
	m_wndOpenGL.OnDraw(NULL);
}

void CLinearCalibrationCtrl::OnBnClickedRadioShowSpreadReal()
{
	KillTimer(TIMER_EVENT_LINEAR_CALIB);
	((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromSensorData(m_arKeyPoses_r[E_INDEX_KEY_SPREAD].m_arData);
	m_wndOpenGL.OnDraw(NULL);
}

void CLinearCalibrationCtrl::OnBnClickedRadioShowExtbendReal()
{
	KillTimer(TIMER_EVENT_LINEAR_CALIB);
	((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromSensorData(m_arKeyPoses_r[E_INDEX_KEY_EXTBEND].m_arData);
	m_wndOpenGL.OnDraw(NULL);
}

void CLinearCalibrationCtrl::OnBnClickedRadioShowFlatReal()
{
	KillTimer(TIMER_EVENT_LINEAR_CALIB);
	((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromSensorData(m_arKeyPoses_r[E_INDEX_KEY_FLAT].m_arData);
	m_wndOpenGL.OnDraw(NULL);
}
void CLinearCalibrationCtrl::OnBnClickedRadioShowRealtimeLinear()
{
	SetTimer(TIMER_EVENT_LINEAR_CALIB, 100, NULL);
}
void CLinearCalibrationCtrl::OnBnClickedButtonCalibrateLinearRegress()
{
	CGloveCalibration cal = GloveUtil::LinearCalibrate(m_arKeyPoses_s[E_INDEX_KEY_FLAT], m_arKeyPoses_s[E_INDEX_KEY_SPREAD], m_arKeyPoses_s[E_INDEX_KEY_FIST], m_arKeyPoses_s[E_INDEX_KEY_EXTBEND], 
		m_arKeyPoses_r[E_INDEX_KEY_FLAT], m_arKeyPoses_r[E_INDEX_KEY_SPREAD], m_arKeyPoses_r[E_INDEX_KEY_FIST], m_arKeyPoses_r[E_INDEX_KEY_EXTBEND]);
	
	m_pLinearCalibration->UpdateCalibration(cal);
	m_pGlvMgr->m_pCalib->UpdateCalibration(cal);
	UpdateCalibrationToUI();
}

void CLinearCalibrationCtrl::OnBnClickedButtonLoadLinearCalibration()
{
	CFileDialog dlgFile(TRUE, L"Glove Calibration(*.gcb)|*.gcb", 0, 4|2, L"Gove Calibration(*.gcb)|*.gcb||");
	if(IDOK != dlgFile.DoModal())
		return;
	m_pLinearCalibration->LoadFromFile(GloveUtil::ToChar(dlgFile.GetPathName()));
	UpdateCalibrationToUI();
}

void CLinearCalibrationCtrl::OnBnClickedButtonSaveLinearCalibration()
{
	UpdateUIToCalibration();
	CFileDialog dlgFile(FALSE, L"Glove Calibration(*.gcb)|*.gcb", 0, 4|2, L"Gove Calibration(*.gcb)|*.gcb||");
	if(IDOK != dlgFile.DoModal())
		return;
	m_pLinearCalibration->SaveToFile(GloveUtil::ToChar(dlgFile.GetPathName()));
}


