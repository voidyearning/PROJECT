// GloveEditDlg.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "GloveEditDlg.h"
#include "GloveUtil.h"
#include "IKAnimation.h"


// CGloveEditDlg dialog

IMPLEMENT_DYNAMIC(CGloveEditDlg, CDialog)

CGloveEditDlg::CGloveEditDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGloveEditDlg::IDD, pParent)
{
	m_pClip = NULL;
}

CGloveEditDlg::~CGloveEditDlg()
{
}

void CGloveEditDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}
BOOL CGloveEditDlg::OnInitDialog()
{
	/*CString strCurPath = L"";
	TCHAR arDir[256] = L"\0";
	int iLenDir = ::GetCurrentDirectory(256, arDir);
	strCurPath = CString(arDir, iLenDir);*/

	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FPS_DEST);
	if(pEdit)		
		pEdit->EnableWindow(FALSE);

	CButton* pButton = (CButton*)GetDlgItem(IDC_CHECK_ORIGINAL);
	if(pButton)
		pButton->SetCheck(1);

	pButton = (CButton*)GetDlgItem(IDC_BUTTON_CONVERT);
	pButton->EnableWindow(TRUE);

	m_typeDest =CLIP_TYPE::GLV;

	((CButton*)GetDlgItem(IDC_RADIO_THUMB_INDEX))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_RADIO_IK_LEFT_HAND))->SetCheck(1);	

	//dof active	
	((CButton*)GetDlgItem(IDC_CHECK_THUMB_ROLL_ACTIVE))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_CHECK_THUMB_ABD_ACTIVE))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_CHECK_THUMB_VIRTUAL_ACTIVE))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_CHECK_THUMB_INNER_FLEX_ACTIVE))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_CHECK_THUMB_DIST_FLEX_ACTIVE))->SetCheck(1);

	return TRUE;
}


BEGIN_MESSAGE_MAP(CGloveEditDlg, CDialog)
	ON_EN_CHANGE(IDC_EDIT_SRC, &CGloveEditDlg::OnEnChangeEditSrc)
	ON_BN_CLICKED(IDC_BUTTON_BSW_SRC, &CGloveEditDlg::OnBnClickedButtonBswSrc)
	ON_EN_CHANGE(IDC_EDIT_DEST, &CGloveEditDlg::OnEnChangeEditDest)
	ON_BN_CLICKED(IDC_BUTTON_BWS_DEST, &CGloveEditDlg::OnBnClickedButtonBwsDest)
	ON_BN_CLICKED(IDC_BUTTON_CONVERT, &CGloveEditDlg::OnBnClickedButtonConvert)
	ON_BN_CLICKED(IDC_CHECK_ORIGINAL, &CGloveEditDlg::OnBnClickedCheckOriginal)
	ON_BN_CLICKED(IDC_BUTTON_IK_SAMPLE, &CGloveEditDlg::OnBnClickedButtonIkSample)
	ON_BN_CLICKED(IDC_CHECK_CONCATENATED_J, &CGloveEditDlg::OnBnClickedCheckConcatenatedJ)
	ON_BN_CLICKED(IDC_CHECK_SMOOTH_BY_FK, &CGloveEditDlg::OnBnClickedCheckSmoothByFk)
	ON_BN_CLICKED(IDC_CHECK_CONTINOUS_IK, &CGloveEditDlg::OnBnClickedCheckContinousIk)
	ON_EN_CHANGE(IDC_EDIT_RATIO_TO_FINGER, &CGloveEditDlg::OnEnChangeEditRatioToFinger)
	ON_BN_CLICKED(IDC_BUTTON_BSW_THUMB_INDEX, &CGloveEditDlg::OnBnClickedButtonBswThumbIndex)
	ON_BN_CLICKED(IDC_BUTTON_BSW_THUMB_MID, &CGloveEditDlg::OnBnClickedButtonBswThumbMid)
	ON_BN_CLICKED(IDC_BUTTON_BSW_THUMB_RING, &CGloveEditDlg::OnBnClickedButtonBswThumbRing)
	ON_BN_CLICKED(IDC_BUTTON_BSW_THUMB_PINKY, &CGloveEditDlg::OnBnClickedButtonBswThumbPinky)
	ON_BN_CLICKED(IDC_BUTTON_BSW_THUMB_ALL_DEST, &CGloveEditDlg::OnBnClickedButtonBswThumbAllDest)
	ON_BN_CLICKED(IDC_BUTTON_MERGE_TO_IKCLIP, &CGloveEditDlg::OnBnClickedButtonMergeToIkclip)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE_IK_CLIP, &CGloveEditDlg::OnBnClickedButtonCloseIkClip)
	ON_BN_CLICKED(IDC_BUTTON_EXTRACT_SUBCLIP, &CGloveEditDlg::OnBnClickedButtonExtractSubclip)
	ON_BN_CLICKED(IDC_BUTTON_TI_IK_ACCURACY, &CGloveEditDlg::OnBnClickedButtonTiIkAccuracy)
	ON_BN_CLICKED(IDC_BUTTON_TM_IK_ACCURACY, &CGloveEditDlg::OnBnClickedButtonTmIkAccuracy)
	ON_BN_CLICKED(IDC_BUTTON_TR_IK_ACCURACY, &CGloveEditDlg::OnBnClickedButtonTrIkAccuracy)
	ON_BN_CLICKED(IDC_BUTTON_TP_IK_ACCURACY, &CGloveEditDlg::OnBnClickedButtonTpIkAccuracy)
	ON_BN_CLICKED(IDC_BUTTON_BSW_GLV_FLAT_PATH, &CGloveEditDlg::OnBnClickedButtonBswGlvFlatPath)
	ON_BN_CLICKED(IDC_BUTTON_BSW_REAL_FLAT_PATH, &CGloveEditDlg::OnBnClickedButtonBswRealFlatPath)
	ON_BN_CLICKED(IDC_BUTTON_BSW_GLV_SPREAD_PATH, &CGloveEditDlg::OnBnClickedButtonBswGlvSpreadPath)
	ON_BN_CLICKED(IDC_BUTTON_BSW_REAL_SPREAD_PATH, &CGloveEditDlg::OnBnClickedButtonBswRealSpreadPath)
	ON_BN_CLICKED(IDC_BUTTON_BSW_GLV_FIST_PATH, &CGloveEditDlg::OnBnClickedButtonBswGlvFistPath)
	ON_BN_CLICKED(IDC_BUTTON_BSW_REAL_FIST_PATH, &CGloveEditDlg::OnBnClickedButtonBswRealFistPath)
	ON_BN_CLICKED(IDC_BUTTON_BSW_GLV_EXTBEND_PATH, &CGloveEditDlg::OnBnClickedButtonBswGlvExtbendPath)
	ON_BN_CLICKED(IDC_BUTTON_BSW_REAL_EXTBEND_PATH, &CGloveEditDlg::OnBnClickedButtonBswRealExtbendPath)
	ON_BN_CLICKED(IDC_BUTTON_BSW_LINEAR_CALIBRATION_PATH, &CGloveEditDlg::OnBnClickedButtonBswLinearCalibrationPath)
	ON_BN_CLICKED(IDC_BUTTON_LINEAR_CALIBRATE, &CGloveEditDlg::OnBnClickedButtonLinearCalibrate)
	ON_BN_CLICKED(IDC_BUTTON_TEST_EV_TRANSFORM, &CGloveEditDlg::OnBnClickedButtonTestEvTransform)
	ON_BN_CLICKED(IDC_BUTTON_EV_TRANSFORM, &CGloveEditDlg::OnBnClickedButtonEvTransform)
	ON_BN_CLICKED(IDC_BUTTON_EXPORT_MARKERS_RAW, &CGloveEditDlg::OnBnClickedButtonExportMarkersRaw)
	ON_BN_CLICKED(IDC_BUTTON_EXPORT_MARKERS_RAWTIME, &CGloveEditDlg::OnBnClickedButtonExportMarkersRawtime)
	ON_BN_CLICKED(IDC_BUTTON_RESAMPLE_FROM_RAWTIME, &CGloveEditDlg::OnBnClickedButtonResampleFromRawtime)
	ON_BN_CLICKED(IDC_BUTTON1, &CGloveEditDlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// CGloveEditDlg message handlers

CLIP_TYPE CGloveEditDlg::GetClipTypeFromExt(CString strExt)
{
	if(strExt == L"glv")
		return CLIP_TYPE::GLV;
	if(strExt == L"bvh")
		return CLIP_TYPE::BVH;
	if(strExt == L"raw")
		return CLIP_TYPE::KIN;

	return CLIP_TYPE::GLV;
}
void CGloveEditDlg::OnEnChangeEditSrc()
{
	CString strSrcPath = L"";
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SRC);
	if(pEdit)
		pEdit->GetWindowText(strSrcPath);

	delete m_pClip;
	m_pClip = CBaseClip::NewFromFile(GloveUtil::ToChar(strSrcPath));
}

void CGloveEditDlg::OnBnClickedButtonBswSrc()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic Data(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv|Motion Capture File(*.bvh)|*.bvh", 0, 4|2, L"Raw Kinematic Data(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv|Motion Capture File(*.bvh)|*.bvh||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\ik\\unclosed\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_SRC)->SetWindowTextW(dlgFile.GetPathName());
	delete m_pClip;
	m_pClip = CBaseClip::NewFromFile(GloveUtil::ToChar(dlgFile.GetPathName()));
}

void CGloveEditDlg::OnEnChangeEditDest()
{
	CString strDestPath = L"";
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_DEST);
	if(pEdit)
		pEdit->GetWindowText(strDestPath);

	if(strDestPath.Find(L".bvh") != -1)
		m_typeDest == CLIP_TYPE::BVH;
	else if(strDestPath.Find(L".glv") != -1)
		m_typeDest == CLIP_TYPE::GLV;
	else if(strDestPath.Find(L".raw") != -1)
		m_typeDest == CLIP_TYPE::KIN;
}

void CGloveEditDlg::OnBnClickedButtonBwsDest()
{
	CFileDialog dlgFile(FALSE, L"Raw Kinematic Data(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv|Motion Capture File(*.bvh)|*.bvh", 0, 4|2, L"Raw Kinematic Data(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv|Motion Capture File(*.bvh)|*.bvh||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\ik\\closed"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK == dlgFile.DoModal())
	{
		GetDlgItem(IDC_EDIT_DEST)->SetWindowTextW(dlgFile.GetPathName());
		m_typeDest = GetClipTypeFromExt(dlgFile.GetFileExt());
	}
}
#include "GloveSkeleton.h"
#include "BvhAnimation.h"
void CGloveEditDlg::OnBnClickedButtonConvert()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_IK_LEFT_HAND))->GetCheck() == true;
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_DEST);
	CString strOutput;
	pEdit->GetWindowText(strOutput);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FPS_DEST);
	CString strFPS;
	pEdit->GetWindowText(strFPS);
	int iFPS = _wtoi(strFPS.GetBuffer());

	CButton* pButton = (CButton*) GetDlgItem(IDC_CHECK_ORIGINAL);
	if(pButton->GetCheck())
		iFPS = -1;

	CGlvClip* pClipGlv = dynamic_cast<CGlvClip*>(m_pClip);
	if(pClipGlv !=NULL)
	{
		pClipGlv->Resample(1.0/iFPS);
		if(m_typeDest == CLIP_TYPE::BVH)
			pClipGlv->SaveToBvh(GloveUtil::ToChar(strOutput));
		else if(m_typeDest == CLIP_TYPE::KIN)
		{
			CRawClip clipRaw = GloveUtil::GlvToRaw(*pClipGlv, bLeft);
			clipRaw.SaveToFile(GloveUtil::ToChar(strOutput));
		}
		else
			m_pClip->SaveToFile(GloveUtil::ToChar(strOutput));
	}
	else
	{
		CRawClip* pClipRaw = dynamic_cast<CRawClip*>(m_pClip);
		if(pClipRaw)
		{
			if(m_typeDest == CLIP_TYPE::BVH)
			{
				CHandSkeletonKin* pHand;	
				if(((CButton*)GetDlgItem(IDC_RADIO_IK_LEFT_HAND))->GetCheck())
					pHand = new CHandSkeletonKin(false);
				else
					pHand = new CHandSkeletonKin(true);
				std::string strHeader = pHand->GetBvhHeader();
				//std::string strHeader = pHand->GetBvhHeaderConsistentWithBody();
				pClipRaw->SaveToBvh(GloveUtil::ToChar(strOutput), strHeader);
				//pClipRaw->SaveToBvhConsistentWithBody(bLeft, GloveUtil::ToChar(strOutput), strHeader);
			}
		}
	}
}

void CGloveEditDlg::OnBnClickedCheckOriginal()
{
	CButton* pCheck = (CButton*)GetDlgItem(IDC_CHECK_ORIGINAL);
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FPS_DEST);
	if(pCheck->GetCheck())
		pEdit->EnableWindow(FALSE);
	else
		pEdit->EnableWindow(TRUE);
}

void CGloveEditDlg::OnBnClickedButtonIkSample()
{
	//the kin hand
	CHandSkeletonKin* pHand;	
	if(((CButton*)GetDlgItem(IDC_RADIO_IK_LEFT_HAND))->GetCheck())
		pHand = new CHandSkeletonKin(false);
	else
		pHand = new CHandSkeletonKin(true);
	UpdataDOFActiveFromUI(*pHand->m_pHand);

	//file name
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_DEST);
	CString strOutput;
	pEdit->GetWindowText(strOutput);

	/*/deprecated concatenated solution for the entire clip ===================================================
	if(((CButton*)GetDlgItem(IDC_CHECK_CONCATENATED_J))->GetCheck())
	{
		CGloveCalibration defaultCalibration;		
		std::vector<float> arGainGlove;
		std::vector<float> arOffsetGlove;
		for(int i = 0; i < defaultCalibration.m_arAdjustItem.size(); ++i)
		{
			arGainGlove.push_back(1);//defaultCalibration.m_arAdjustItem[i].m_fGain);
			arOffsetGlove.push_back(0);//defaultCalibration.m_arAdjustItem[i].m_fOffset);
		}

		CRawClip outputClip;
		if(((CButton*)GetDlgItem(IDC_RADIO_THUMB_INDEX))->GetCheck())
			hand.FingerTouchingSamplingConcatenated(eThumbIndex, *m_pClip, outputClip, arGainGlove, arOffsetGlove);
		if(((CButton*)GetDlgItem(IDC_RADIO_THUMB_MID))->GetCheck())
			hand.FingerTouchingSamplingConcatenated(eThumbMid, *m_pClip, outputClip, arGainGlove, arOffsetGlove);
		if(((CButton*)GetDlgItem(IDC_RADIO_THUMB_RING))->GetCheck())
			hand.FingerTouchingSamplingConcatenated(eThumbRing, *m_pClip, outputClip, arGainGlove, arOffsetGlove);
		if(((CButton*)GetDlgItem(IDC_RADIO_THUMB_PINKY))->GetCheck())
			hand.FingerTouchingSamplingConcatenated(eThumbPinky, *m_pClip, outputClip, arGainGlove, arOffsetGlove);

		outputClip.SaveToFile(GloveUtil::ToChar(strOutput));		
		return;
	}
	*///end of deprecated =======================================================================
	
	//frame by frame solution
	CBaseClip* pOutputClip = NULL;
	if(strOutput.Find(L".raw")!=-1)
	{ 
		pOutputClip = new CRawClip();
	}
	else if(strOutput.Find(L".glv")!=-1)
	{
		pOutputClip = new CGlvClip();
	}
	if(((CButton*)GetDlgItem(IDC_RADIO_THUMB_INDEX))->GetCheck())
		pHand->FingerTouchingSampling(eThumbIndex, m_pClip, pOutputClip);
	if(((CButton*)GetDlgItem(IDC_RADIO_THUMB_MID))->GetCheck())
		pHand->FingerTouchingSampling(eThumbMid, m_pClip, pOutputClip);
	if(((CButton*)GetDlgItem(IDC_RADIO_THUMB_RING))->GetCheck())
		pHand->FingerTouchingSampling(eThumbRing, m_pClip, pOutputClip);
	if(((CButton*)GetDlgItem(IDC_RADIO_THUMB_PINKY))->GetCheck())
		pHand->FingerTouchingSampling(eThumbPinky, m_pClip, pOutputClip);

	pOutputClip->SaveToFile(GloveUtil::ToChar(strOutput));
	delete pHand;
	delete pOutputClip;
}

void CGloveEditDlg::OnBnClickedCheckConcatenatedJ()
{
}

extern bool g_bSmoothenByFK = false;
void CGloveEditDlg::OnBnClickedCheckSmoothByFk()
{
	if(((CButton*)GetDlgItem(IDC_CHECK_SMOOTH_BY_FK))->GetCheck())
		g_bSmoothenByFK = true;
	else
		g_bSmoothenByFK = false;
}
extern bool g_bContinuousIK = false;
void CGloveEditDlg::OnBnClickedCheckContinousIk()
{
	if(((CButton*)GetDlgItem(IDC_CHECK_CONTINOUS_IK))->GetCheck())
		g_bContinuousIK = true;
	else
		g_bContinuousIK = false;
}
extern double g_fRatioToFinger = 1;
void CGloveEditDlg::OnEnChangeEditRatioToFinger()
{
	CString strRatioToFinger;
	GetDlgItem(IDC_EDIT_RATIO_TO_FINGER)->GetWindowTextW(strRatioToFinger);
	g_fRatioToFinger = _wtof(strRatioToFinger.GetBuffer());
}

void CGloveEditDlg::UpdataDOFActiveFromUI(CKinematicHand& hand)
{
	hand.m_arChain[0]->GetDOFAt(0)->m_bActive = 
		((CButton*)GetDlgItem(IDC_CHECK_THUMB_ROLL_ACTIVE))->GetCheck();

	hand.m_arChain[0]->GetDOFAt(1)->m_bActive = 
		((CButton*)GetDlgItem(IDC_CHECK_THUMB_ABD_ACTIVE))->GetCheck();

	hand.m_arChain[0]->GetDOFAt(2)->m_bActive = 
		((CButton*)GetDlgItem(IDC_CHECK_THUMB_VIRTUAL_ACTIVE))->GetCheck();

	hand.m_arChain[0]->GetDOFAt(3)->m_bActive = 
		((CButton*)GetDlgItem(IDC_CHECK_THUMB_INNER_FLEX_ACTIVE))->GetCheck();

	hand.m_arChain[0]->GetDOFAt(4)->m_bActive = 
		((CButton*)GetDlgItem(IDC_CHECK_THUMB_DIST_FLEX_ACTIVE))->GetCheck();
}


void CGloveEditDlg::OnBnClickedButtonBswThumbIndex()
{	
	CFileDialog dlgFile(TRUE, L"Raw Kinematic Data(*.raw)|*.raw", 0, 4|2, L"Raw Kinematic Data(*.raw)|*.raw||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\ik\\unclosed\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_THUMB_INDEX)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonBswThumbMid()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic Data(*.raw)|*.raw", 0, 4|2, L"Raw Kinematic Data(*.raw)|*.raw||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\ik\\unclosed\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_THUMB_MID)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonBswThumbRing()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic Data(*.raw)|*.raw", 0, 4|2, L"Raw Kinematic Data(*.raw)|*.raw||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\ik\\unclosed\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_THUMB_RING)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonBswThumbPinky()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic Data(*.raw)|*.raw", 0, 4|2, L"Raw Kinematic Data(*.raw)|*.raw||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\ik\\unclosed\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_THUMB_PINKY)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonBswThumbAllDest()
{
	CFileDialog dlgFile(FALSE, L"Raw Kinematic Data(*.raw)|*.raw", 0, 4|2, L"Raw Kinematic Data(*.raw)|*.raw||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\ik\\unclosed\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_THUMB_ALL_DEST)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonMergeToIkclip()
{
	CString strThumbIndexPath, strThumbMidPath, strThumbRingPath, strThumbPinkyPath, strMergedPath;
	GetDlgItem(IDC_EDIT_THUMB_INDEX)->GetWindowText(strThumbIndexPath);
	GetDlgItem(IDC_EDIT_THUMB_MID)->GetWindowText(strThumbMidPath);
	GetDlgItem(IDC_EDIT_THUMB_RING)->GetWindowText(strThumbRingPath);
	GetDlgItem(IDC_EDIT_THUMB_PINKY)->GetWindowText(strThumbPinkyPath);
	GetDlgItem(IDC_EDIT_THUMB_ALL_DEST)->GetWindowText(strMergedPath);

	CRawClip clipIndex, clipMid, clipRing, clipPinky;
	clipIndex.LoadFromFile(GloveUtil::ToChar(strThumbIndexPath));
	clipMid.LoadFromFile(GloveUtil::ToChar(strThumbMidPath));
	clipRing.LoadFromFile(GloveUtil::ToChar(strThumbRingPath));
	clipPinky.LoadFromFile(GloveUtil::ToChar(strThumbPinkyPath));

	CIKClip clipIKIndex = CIKClip::NewFromRawClip(clipIndex, eThumbIndex);
	CIKClip clipIKMid = CIKClip::NewFromRawClip(clipMid, eThumbMid);
	CIKClip clipIKRing = CIKClip::NewFromRawClip(clipRing, eThumbRing);
	CIKClip clipIKPinky = CIKClip::NewFromRawClip(clipPinky, eThumbPinky);

	CIKClip clipIKAll;
	clipIKAll.MergeWith(clipIKIndex);
	clipIKAll.MergeWith(clipIKMid);
	clipIKAll.MergeWith(clipIKRing);
	clipIKAll.MergeWith(clipIKPinky);

	//clipIKAll = clipIKAll.GetNoDataRedundantClip();
	clipIKAll.SaveToFile(GloveUtil::ToChar(strMergedPath));
}

void CGloveEditDlg::OnBnClickedButtonCloseIkClip()
{
	CString strThumbIndexPath, strThumbMidPath, strThumbRingPath, strThumbPinkyPath, strClosedPath;
	GetDlgItem(IDC_EDIT_THUMB_INDEX)->GetWindowText(strThumbIndexPath);
	GetDlgItem(IDC_EDIT_THUMB_MID)->GetWindowText(strThumbMidPath);
	GetDlgItem(IDC_EDIT_THUMB_RING)->GetWindowText(strThumbRingPath);
	GetDlgItem(IDC_EDIT_THUMB_PINKY)->GetWindowText(strThumbPinkyPath);
	GetDlgItem(IDC_EDIT_THUMB_ALL_DEST)->GetWindowText(strClosedPath);

	CRawClip clipIndex, clipMid, clipRing, clipPinky;
	clipIndex.LoadFromFile(GloveUtil::ToChar(strThumbIndexPath));
	clipMid.LoadFromFile(GloveUtil::ToChar(strThumbMidPath));
	clipRing.LoadFromFile(GloveUtil::ToChar(strThumbRingPath));
	clipPinky.LoadFromFile(GloveUtil::ToChar(strThumbPinkyPath));

	CIKClip clipIKIndex = CIKClip::NewFromRawClip(clipIndex, eThumbIndex);
	CIKClip clipIKMid = CIKClip::NewFromRawClip(clipMid, eThumbMid);
	CIKClip clipIKRing = CIKClip::NewFromRawClip(clipRing, eThumbRing);
	CIKClip clipIKPinky = CIKClip::NewFromRawClip(clipPinky, eThumbPinky);

	CIKClip clipIKAll;
	clipIKAll.MergeWith(clipIKIndex);
	clipIKAll.MergeWith(clipIKMid);
	clipIKAll.MergeWith(clipIKRing);
	clipIKAll.MergeWith(clipIKPinky);

	//clipIKAll = clipIKAll.GetNoDataRedundantClip();

	

	//close the unclosed IK clip and save it
	//the kin hand
	CHandSkeletonKin hand;	
	if(((CButton*)GetDlgItem(IDC_RADIO_IK_LEFT_HAND))->GetCheck())
		hand.m_bRightHand = false;
	else
		hand.m_bRightHand = true;
	hand.InitMotion();	
	UpdataDOFActiveFromUI(*hand.m_pHand);
	CRawClip clipRawOutput;
	hand.FingerTouchingSampling(clipIKAll, clipRawOutput);
	clipRawOutput.SaveToFile(GloveUtil::ToChar(strClosedPath));
}

void CGloveEditDlg::OnBnClickedButtonExtractSubclip()
{
	CString strBegIdx, strEndIdx;
	GetDlgItem(IDC_EDIT_SUBCLIP_BEG_IDX)->GetWindowText(strBegIdx);
	GetDlgItem(IDC_EDIT_SUBCLIP_END_IDX)->GetWindowText(strEndIdx);

	int iBegIdx, iEndIdx;
	iBegIdx = _wtoi(strBegIdx);
	if(iBegIdx <= 0)
		iBegIdx = 0;
	iEndIdx = _wtoi(strEndIdx);
	if(iEndIdx <= iBegIdx)
		iEndIdx = m_pClip->GetFrameCount();

	CBaseClip* pSubClip = m_pClip->GetSubClip(iBegIdx, iEndIdx);

	CString strOutputPath;
	GetDlgItem(IDC_EDIT_DEST)->GetWindowText(strOutputPath);
	pSubClip->SaveToFile(GloveUtil::ToChar(strOutputPath));
	delete pSubClip;
}

void CGloveEditDlg::OnBnClickedButtonTiIkAccuracy()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_IK_LEFT_HAND))->GetCheck() == true;
	CString strThumbIndexPath, strResultPath;
	GetDlgItem(IDC_EDIT_THUMB_INDEX)->GetWindowText(strThumbIndexPath);
	GetDlgItem(IDC_EDIT_THUMB_ALL_DEST)->GetWindowText(strResultPath);

	CRawClip clipIndexTouching;
	clipIndexTouching.LoadFromFile(GloveUtil::ToChar(strThumbIndexPath));
	CRawClip clipDistResult = clipIndexTouching.CalculateIKAccuracy(IK_FINGER_TOUCHING_TYPE::eThumbIndex, bLeft);
	clipDistResult.SaveToFile(GloveUtil::ToChar(strResultPath));
	
	float fMean = clipDistResult.GetMean(0);
	float fSTD = clipDistResult.GetStandardDeviation(0);
	CString strIKResult;
	strIKResult.Format(L"%s Thumb-Index Distance mean: %f, std: %f", strThumbIndexPath, fMean, fSTD);
	GetDlgItem(IDC_EDIT_IK_ACCURACY)->SetWindowText(strIKResult);
}

void CGloveEditDlg::OnBnClickedButtonTmIkAccuracy()
{	
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_IK_LEFT_HAND))->GetCheck() == true;
	CString strThumbMidPath, strResultPath;
	GetDlgItem(IDC_EDIT_THUMB_MID)->GetWindowText(strThumbMidPath);
	GetDlgItem(IDC_EDIT_THUMB_ALL_DEST)->GetWindowText(strResultPath);

	CRawClip clipMidTouching;
	clipMidTouching.LoadFromFile(GloveUtil::ToChar(strThumbMidPath));
	CRawClip clipDistResult = clipMidTouching.CalculateIKAccuracy(IK_FINGER_TOUCHING_TYPE::eThumbMid, bLeft);
	clipDistResult.SaveToFile(GloveUtil::ToChar(strResultPath));
	
	float fMean = clipDistResult.GetMean(0);
	float fSTD = clipDistResult.GetStandardDeviation(0);
	CString strIKResult;
	strIKResult.Format(L"%s Thumb-Mid Distance mean: %f, std: %f", strThumbMidPath, fMean, fSTD);
	GetDlgItem(IDC_EDIT_IK_ACCURACY)->SetWindowText(strIKResult);
}

void CGloveEditDlg::OnBnClickedButtonTrIkAccuracy()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_IK_LEFT_HAND))->GetCheck() == true;
	CString strThumbRingPath, strResultPath;
	GetDlgItem(IDC_EDIT_THUMB_RING)->GetWindowText(strThumbRingPath);
	GetDlgItem(IDC_EDIT_THUMB_ALL_DEST)->GetWindowText(strResultPath);

	CRawClip clipRingTouching;
	clipRingTouching.LoadFromFile(GloveUtil::ToChar(strThumbRingPath));
	CRawClip clipDistResult = clipRingTouching.CalculateIKAccuracy(IK_FINGER_TOUCHING_TYPE::eThumbRing, bLeft);
	clipDistResult.SaveToFile(GloveUtil::ToChar(strResultPath));
	
	float fMean = clipDistResult.GetMean(0);
	float fSTD = clipDistResult.GetStandardDeviation(0);
	CString strIKResult;
	strIKResult.Format(L"%s Thumb-Ring Distance mean: %f, std: %f", strThumbRingPath, fMean, fSTD);
	GetDlgItem(IDC_EDIT_IK_ACCURACY)->SetWindowText(strIKResult);
}

void CGloveEditDlg::OnBnClickedButtonTpIkAccuracy()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_IK_LEFT_HAND))->GetCheck() == true;
	CString strThumbPinkyPath, strResultPath;
	GetDlgItem(IDC_EDIT_THUMB_PINKY)->GetWindowText(strThumbPinkyPath);
	GetDlgItem(IDC_EDIT_THUMB_ALL_DEST)->GetWindowText(strResultPath);

	CRawClip clipPinkyTouching;
	clipPinkyTouching.LoadFromFile(GloveUtil::ToChar(strThumbPinkyPath));
	CRawClip clipDistResult = clipPinkyTouching.CalculateIKAccuracy(IK_FINGER_TOUCHING_TYPE::eThumbPinky, bLeft);
	clipDistResult.SaveToFile(GloveUtil::ToChar(strResultPath));
	
	float fMean = clipDistResult.GetMean(0);
	float fSTD = clipDistResult.GetStandardDeviation(0);
	CString strIKResult;
	strIKResult.Format(L"%s Thumb-Pinky Distance mean: %f, std: %f", strThumbPinkyPath, fMean, fSTD);
	GetDlgItem(IDC_EDIT_IK_ACCURACY)->SetWindowText(strIKResult);
}

void CGloveEditDlg::OnBnClickedButtonBswGlvFlatPath()
{
	CFileDialog dlgFile(TRUE, L"Glove Clip(*.glv)|*.glv", 0, 4|2, L"Gove Clip(*.glv)|*.glv||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\glv\\left\\fk\\pose\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_GLV_FLAT_PATH)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonBswRealFlatPath()
{
	CFileDialog dlgFile(TRUE, L"Glove Frame(*.gfm)|*.gfm", 0, 4|2, L"Gove Frame(*.gfm)|*.gfm||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\glv\\left\\fk\\pose\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_REAL_FLAT_PATH)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonBswGlvSpreadPath()
{
	CFileDialog dlgFile(TRUE, L"Glove Clip(*.glv)|*.glv", 0, 4|2, L"Glove Clip(*.glv)|*.glv||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\glv\\left\\fk\\pose\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_GLV_SPREAD_PATH)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonBswRealSpreadPath()
{	
	CFileDialog dlgFile(TRUE, L"Glove Frame(*.gfm)|*.gfm", 0, 4|2, L"Gove Frame(*.gfm)|*.gfm||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\glv\\left\\fk\\pose\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_REAL_SPREAD_PATH)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonBswGlvFistPath()
{
	CFileDialog dlgFile(TRUE, L"Glove Clip(*.glv)|*.glv", 0, 4|2, L"Glove Clip(*.glv)|*.glv||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\glv\\left\\fk\\pose\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_GLV_FIST_PATH)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonBswRealFistPath()
{
	CFileDialog dlgFile(TRUE, L"Glove Frame(*.gfm)|*.gfm", 0, 4|2, L"Gove Frame(*.gfm)|*.gfm||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\glv\\left\\fk\\pose\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_REAL_FIST_PATH)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonBswGlvExtbendPath()
{
	CFileDialog dlgFile(TRUE, L"Glove Clip(*.glv)|*.glv", 0, 4|2, L"Glove Clip(*.glv)|*.glv||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\glv\\left\\fk\\pose\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_GLV_EXTBEND_PATH)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonBswRealExtbendPath()
{	
	CFileDialog dlgFile(TRUE, L"Glove Frame(*.gfm)|*.gfm", 0, 4|2, L"Gove Frame(*.gfm)|*.gfm||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\glv\\left\\fk\\pose\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_REAL_EXTBEND_PATH)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonBswLinearCalibrationPath()
{
	CFileDialog dlgFile(TRUE, L"Glove Calibration(*.gcb)|*.gcb", 0, 4|2, L"Gove Calibration(*.gcb)|*.gcb||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\glv\\left\\fk\\pose"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK != dlgFile.DoModal())
		return;

	GetDlgItem(IDC_EDIT_LINEAR_CALIBRATION_PATH)->SetWindowTextW(dlgFile.GetPathName());
}

void CGloveEditDlg::OnBnClickedButtonLinearCalibrate()
{
	CGlvClip clipGlvFlat, clipGlvSpread, clipGlvFist, clipGlvExtBend;
	CGlvFrame frmGlvFlat, frmGlvSpread, frmGlvFist, frmGlvExtBend;
	CGlvFrame frmRealFlat, frmRealSpread, frmRealFist, frmRealExtBend;

	//glv data
	CString strGlvFlat;
	GetDlgItem(IDC_EDIT_GLV_FLAT_PATH)->GetWindowText(strGlvFlat);
	clipGlvFlat.LoadFromFile(GloveUtil::ToChar(strGlvFlat));

	CString strGlvSpread;
	GetDlgItem(IDC_EDIT_GLV_SPREAD_PATH)->GetWindowText(strGlvSpread);
	clipGlvSpread.LoadFromFile(GloveUtil::ToChar(strGlvSpread));

	CString strGlvFist;
	GetDlgItem(IDC_EDIT_GLV_FIST_PATH)->GetWindowText(strGlvFist);
	clipGlvFist.LoadFromFile(GloveUtil::ToChar(strGlvFist));

	CString strGlvExtBend;
	GetDlgItem(IDC_EDIT_GLV_EXTBEND_PATH)->GetWindowText(strGlvExtBend);
	clipGlvExtBend.LoadFromFile(GloveUtil::ToChar(strGlvExtBend));

	frmGlvFlat = clipGlvFlat.GetAveragePose();
	frmGlvSpread = clipGlvSpread.GetAveragePose();
	frmGlvFist = clipGlvFist.GetAveragePose();
	frmGlvExtBend = clipGlvFist.GetAveragePose();

	//read value
	CString strRealFlat;
	GetDlgItem(IDC_EDIT_REAL_FLAT_PATH)->GetWindowText(strRealFlat);
	frmRealFlat.LoadFromFile(GloveUtil::ToChar(strRealFlat));

	CString strRealSpread;
	GetDlgItem(IDC_EDIT_REAL_SPREAD_PATH)->GetWindowText(strRealSpread);
	frmRealSpread.LoadFromFile(GloveUtil::ToChar(strRealSpread));

	CString strRealFist;
	GetDlgItem(IDC_EDIT_REAL_FIST_PATH)->GetWindowText(strRealFist);
	frmRealFist.LoadFromFile(GloveUtil::ToChar(strRealFist));

	CString strRealExtBend;
	GetDlgItem(IDC_EDIT_REAL_EXTBEND_PATH)->GetWindowText(strRealExtBend);
	frmRealExtBend.LoadFromFile(GloveUtil::ToChar(strRealExtBend));

	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_IK_LEFT_HAND))->GetCheck() == true;
	CGloveCalibration cal = MatlabUtil::LinearRegressCalibrate(frmGlvFlat, frmGlvSpread, frmGlvFist, frmGlvExtBend, 
		frmRealFlat, frmRealSpread, frmRealFist, frmRealExtBend, bLeft);

	CString strCalibration;
	GetDlgItem(IDC_EDIT_LINEAR_CALIBRATION_PATH)->GetWindowText(strCalibration);
	cal.SaveToFile(GloveUtil::ToChar(strCalibration));
}

#include "MarkerAnimation.h"
void CGloveEditDlg::OnBnClickedButtonTestEvTransform()
{
	CRawClip clipRaw;
	clipRaw.LoadFromFile("C:\\wangyi\\research\\glove\\text\\To Siggraph Aisa 2012\\VirtualHandCalib\\spv\\raw\\linear\\v1_l.raw");
	CMarkersClip clipMarkers = GloveUtil::RawToMarkers(clipRaw, true);

	CMarkersClip clipMarkersNew = clipMarkers.ViconEVTransformCoord();
	ASSERT(clipMarkersNew.m_arFrame.size() == clipMarkers.m_arFrame.size());

	for(int i = 0; i < clipMarkersNew.m_arFrame.size(); ++i)
	{
		CMarkersFrame frmMarkersNew = clipMarkersNew.m_arFrame[i];
		CMarkersFrame frmMarkers = clipMarkers.m_arFrame[i];
		ASSERT(frmMarkersNew.m_arMarkers.size() == frmMarkers.m_arMarkers.size());

		for(int j = 0; j < frmMarkersNew.m_arMarkers.size(); ++ j)
		{
			CMarkerPosition posMarker = frmMarkers.m_arMarkers[j];
			CMarkerPosition posMarkerNew = frmMarkersNew.m_arMarkers[j];
			CMarkerPosition vecDis = posMarker.Substract(posMarkerNew);
			float fDiff = vecDis.vecLength();
			ASSERT(fDiff < 0.1);
		}
	}
}

void CGloveEditDlg::OnBnClickedButtonEvTransform()
{
	CFileDialog dlgFile(TRUE, L"CSV(*.csv)|*.csv", 0, 4|2, L"CSV(*.csv)|*.csv||");
	if(IDOK != dlgFile.DoModal())
		return;
	CString strPathOriginal = dlgFile.GetPathName();
	int iDot = strPathOriginal.Find(L".");
	CString strPathName = strPathOriginal.Left(iDot);
	CString strPathNew = strPathName + L"_transformed.csv";

	CMarkersClip clipMarkers;
	clipMarkers.LoadFromFile(GloveUtil::ToChar(strPathOriginal));
	CMarkersClip clipMarkersNew = clipMarkers.ViconEVTransformCoord();
	clipMarkersNew.MM2CM();
	clipMarkersNew.SaveToFile(GloveUtil::ToChar(strPathNew));
}

void CGloveEditDlg::OnBnClickedButtonExportMarkersRaw()
{
	CFileDialog dlgFile(TRUE, L"raw(*.raw)|*.raw", 0, 4|2, L"raw(*.raw)|*.raw||");
	if(IDOK != dlgFile.DoModal())
		return;
	CString strPathOriginal = dlgFile.GetPathName();
	int iDot = strPathOriginal.Find(L".");
	CString strPathName = strPathOriginal.Left(iDot);
	CString strPathNew = strPathName + L".csv";

	CRawClip clipRaw;
	clipRaw.LoadFromFile(GloveUtil::ToChar(strPathOriginal));
	CMarkersClip clipMarkers = GloveUtil::RawToMarkers(clipRaw, true);
	clipMarkers.SaveToFile(GloveUtil::ToChar(strPathNew));
}

void CGloveEditDlg::OnBnClickedButtonExportMarkersRawtime()
{
	CFileDialog dlgFile(TRUE, L"rawt(*.rawt)|*.rawt", 0, 4|2, L"rawt(*.rawt)|*.rawt||");
	if(IDOK != dlgFile.DoModal())
		return;
	CString strPathOriginal = dlgFile.GetPathName();
	int iDot = strPathOriginal.Find(L".");
	CString strPathName = strPathOriginal.Left(iDot);
	CString strPathNew = strPathName + L".csv";

	CRawTimeClip clipRawTime;
	clipRawTime.LoadFromFile(GloveUtil::ToChar(strPathOriginal));
	CMarkersClip clipMarkers = GloveUtil::RawTimeToMarkers(clipRawTime, true);
	clipMarkers.SaveToFile(GloveUtil::ToChar(strPathNew));
}

void CGloveEditDlg::OnBnClickedButtonResampleFromRawtime()
{
	//motion from CRawClip
	CFileDialog dlgFileMotion(TRUE, L"raw(*.raw)|*.raw", 0, 4|2, L"raw(*.raw)|*.raw||");
	if(IDOK != dlgFileMotion.DoModal())
		return;
	CString strPathMotion = dlgFileMotion.GetPathName();
	CRawClip clipMotion;
	clipMotion.LoadFromFile(GloveUtil::ToChar(strPathMotion));

	//time from CGlvClip
	CFileDialog dlgFileTime(TRUE, L"glv(*.glv)|*.glv", 0, 4|2, L"glv(*.glv)|*.glv||");
	if(IDOK != dlgFileTime.DoModal())
		return;
	CString strPathTime = dlgFileTime.GetPathName();
	CGlvClip clipTime;
	clipTime.LoadFromFile(GloveUtil::ToChar(strPathTime));

	//create CRawTimeClip and Resample
	CRawTimeClip clipRawTime(clipMotion, clipTime);
	CRawClip clipResampled = clipRawTime.ReSample(30, false);
	clipResampled.SaveToFile("c:\\ev2_resampled.raw");
}

void CGloveEditDlg::OnBnClickedButton1()
{
	CFileDialog dlgFileImg(TRUE, L"all(*.*)|*.*", 0, 4|2, L"all(*.*)|*.*||");
	if(IDOK != dlgFileImg.DoModal())
		return;

	CString strPath = dlgFileImg.GetPathName();
	/*int iPathEnd = strPath.ReverseFind('\\');
	strPath = strPath.Left(iPathEnd);
	strPath = strPath + L"\\*.*";

	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(strPath);

	int iErrCode = 0;
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		CString strTitle = finder.GetFileTitle();
		//if
		{
			CString strFileName = finder.GetFilePath();
			int iStart = strFileName.Find(L" (");
			if(iStart == -1)
				continue;

			int iEnd = strFileName.Find(L")", iStart);
			CString strFileNameNew = strFileName.Left(iStart);
			CString strSeqNum = strFileName.Mid(iStart + 2, iEnd - iStart-2);
			CString strSuffix = strFileName.Right(4);
			strFileNameNew = strFileNameNew + L"." + strSeqNum + strSuffix;
			iErrCode = ::rename(GloveUtil::ToChar(strFileName), GloveUtil::ToChar(strFileNameNew));
		}
	}*/
	CRawClip clipRaw;
	clipRaw.LoadFromFile(GloveUtil::ToChar(strPath));
	bool bLeft = ((CButton*)GetDlgItem(IDC_RADIO_IK_LEFT_HAND))->GetCheck() == true;
	strPath.Append(L".raw2");
	clipRaw.ExportRawWithTarget(bLeft, GloveUtil::ToChar(strPath));
	
	int iFPS=30;
	float v1=clipRaw.AvgVelocity(0) * iFPS;
	float v2=clipRaw.AvgVelocity(1) * iFPS;
	float v3=clipRaw.AvgVelocity(3) * iFPS;
	float v4=clipRaw.AvgVelocity(4) * iFPS;

	float v5=clipRaw.AvgVelocity(8) * iFPS;
	float v6=clipRaw.AvgVelocity(14) * iFPS;
	float v7=clipRaw.AvgVelocity(20) * iFPS;
	float v8=clipRaw.AvgVelocity(26) * iFPS;

	float v9=clipRaw.AvgVelocity(9) * iFPS;
	float v10=clipRaw.AvgVelocity(15) * iFPS;
	float v11=clipRaw.AvgVelocity(21) * iFPS;
	float v12=clipRaw.AvgVelocity(27) * iFPS;

	float v0=clipRaw.AvgVelocity(0) * iFPS;	
}
