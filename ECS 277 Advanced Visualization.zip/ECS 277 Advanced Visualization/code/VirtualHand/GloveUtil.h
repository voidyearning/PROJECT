#pragma once
#include "stdafx.h"
#include "RawAnimation.h"
#include "GloveAnimation.h"
#include "GloveCalibration.h"
#include "RawTimeAnimation.h"
#include "MarkerAnimation.h"
#include <vector>

namespace GloveUtil
{
	int GlvIdx2RawIdx(int iGlvIdx);
	int RawIdx2GlvIdx(int iRawIdx);

	float RadianToDegree(float fRadian);
	float DegreeToRadian(float fDegree);	
	float NormalizeDegree(float fDegree);//adjust to  (-180, 180]
	char* ToChar(CString strWide);
	CString ShowFolderDlg(CString strTitle = L"");
	CGlvFrame GloveDataToFrame(std::vector<float> arData);
	CString GloveDataToStringDegree(std::vector<float> arData);
	CString GloveDataToStringRadian(std::vector<float> arData);
	CString GloveDataToString(std::vector<float> arData, std::vector<float> arSensor);
	CString FrameToString(CGlvFrame frame);
	CGloveCalibration AutoCalibrate(CGloveCalibration curCalibration, CGlvFrame frmCap1, CGlvFrame frmReal1, CGlvFrame frmCap2, CGlvFrame frmReal2);
	CGloveCalibration LinearCalibrate(CGlvFrame frmFlat_s, CGlvFrame frmSpread_s, CGlvFrame frmFist_s, CGlvFrame frmExtBend_s,
		CGlvFrame frmFlat_r, CGlvFrame frmSpread_r, CGlvFrame frmFist_r, CGlvFrame frmExtBend_r);
	CGloveCalibrationItem LinearCalibrate(float fs1, float fs2, float fr1, float fr2);

	//some conversion
	CRawFrame GlvToRaw(CGlvFrame frmGlv, bool bLeft = true);
	CGlvFrame RawToGlv(CRawFrame frmRaw, bool bLeft = true);
	CRawClip GlvToRaw(CGlvClip clipGlv, bool bLeft = true);
	CGlvClip RawToGlv(CRawClip clipRaw, bool bLeft = true);
	CRawTimeClip GlvToRawTime(CGlvClip clipGlv, bool bLeft = true);
	CMarkersClip RawToMarkers(CRawClip clipRaw, bool bLeft = true);
	CMarkersClip RawTimeToMarkers(CRawTimeClip clipRawTime, bool bLeft = true);
	CRawClip RawTimeToRaw(CRawTimeClip clipRawTime);
	CRawTimeClip RawToRawTime(CRawClip clipRaw, CGlvClip clipGlvTimeRef);
	void ExportMarkers(CRawClip clipRaw, std::string strPath, bool bLeft = true);
	void ExportMarkers(CRawTimeClip clipRawTime, std::string strPath, bool bLeft = true);

	//calibration
	CGlvClip LinearCalibrateGlvToGlv(CGlvClip clipUncalib, CGloveCalibration calib);
	CGlvFrame LinearCalibrateGlvToGlv(CGlvFrame frmGlv, CGloveCalibration calib);
	CGlvFrame LinearUnCalibrateGlvToGlv(CGlvFrame frmGlv, CGloveCalibration calib);

	CRawClip LinearCalibrateGlvToRaw(CGlvClip clipUncalib, CGloveCalibration calib, bool bLeft = true);
	CRawFrame LinearCalibrateGlvToRaw(CGlvFrame frmRaw, CGloveCalibration calib, bool bLeft = true);

	CRawClip LinearCalibrateRawToRaw(CRawClip clipRaw, CGloveCalibration calib, bool bLeft = true);
	CRawFrame LinearCalibrateRawToRaw(CRawFrame frmRaw, CGloveCalibration calib, bool bLeft = true);

	CRawClip LinearUnCalibrateRawToRaw(CRawClip clipRaw, CGloveCalibration calib, bool bLeft = true);
	CRawFrame LinearUnCalibrateRawToRaw(CRawFrame frmRaw, CGloveCalibration calib, bool bLeft = true);

	//adjust wrist
	void AdjustWrist(CRawClip* pClipRaw);
	void CopyThumb(CRawClip* pClipFrom, CRawClip* pClipTo);
	
	//batch
	void BatchGlvToRawUnder(CString strGlvPath, CString strRawPath, bool bLeft);
	void BatchRecalibUnder(CString strSrcPath, CString strDestPath, CGloveCalibration calib, bool bLeft);
	void BatchUncalibUnder(CString strSrcPath, CString strDestPath, CGloveCalibration calib, bool bLeft);
	void BatchGPRfullUnder(CString strSrcPath, CString strDestPath, bool bLeft);
	void BatchGPRfitcUnder(CString strSrcPath, CString strDestPath, bool bLeft);
	void BatchWristUnder(CString strSrcPath, CString strDestPath, bool bLeft);
	void BatchToBvh(CString strSrcPath, CString strDestPath, bool bLeft);
	void CreateTrUnder(CString strTr);

	void CalculateFKError(std::string strPath, std::string strSuffix, std::ofstream& fout);
	void CalculateFKError();

	//new IK stablized sampling
	CRawClip IKSampling(CRawClip& clipRawSensor, int iTouchingType, bool bLeft = true);

	//linear
	float linearAdjust(float x, float x1, float x2, float y1, float y2);

	//constuct static motion
	void constructStaticPoseForPerception(CString strPoseInputFile, CString strPoseOutputFile);
	void UseHandPose(CString strPoseFile, CString strWristFile, CString strOutput);
}