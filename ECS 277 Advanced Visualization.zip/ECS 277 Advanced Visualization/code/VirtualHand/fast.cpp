 #include "stdafx.h"
#include "fast.h"
#include <vector>
#include "gloveCalibration.h"
#include "gloveAnimation.h"
#include "gloveUtil.h"
//TRAINING PROCESS======================================================
//PROCESS STEP 1.
//sensor data, if linearly calibrated, that's it; else linearly calibrate it, called linear adjustment
//PROCESS STEP 2.
//extract finger flex, train
//PROCESS STEP 3.
//calibrate flex with model from STEP 2, extract finger abd, train
//PROCESS STEP 4.
//calibrate abd with model from STEP 3, extract thumb ik, train
//CALIBRATION PROCESS====================================================
//CALIBRATE STEP 1.
//linear adjust if the trained model is based on this adjustment, otherwise that's it
//CALIBRATE STEP 2.
//calibrate flex
//CALIBRATE STEP 3.
//calibrate abd
//CALIBRATE STEP 4.
//calibrate thumb

//**********************************************************************************************
//calib.gcb		-------------->	\\base\\glv\\left[right]
//flat.glv, spread.glv, fist.glv, overbend.glv, thumbUp.glv, thumbOut.glv	--------------> \\base\\glv\\left[right]\\sp\\groundTruth
//*.raw sampling	-------------->	\\base\\raw\\left[right]\\sp\\
//**********************************************************************************************
//public API
CFastCal::CFastCal()
{
	m_strBasePath = "C:/wangyi/research/2person/cyberII/Allison0204/";	
	m_pHandLeft = new CHandSkeletonKin(/*bRightHand=*/false);
	m_pHandRight = new CHandSkeletonKin(true);
	m_iHD = 1;

}
CFastCal::CFastCal(std::string strBasePath)
{
	m_strBasePath = strBasePath;
	m_pHandLeft = new CHandSkeletonKin(/*bRightHand=*/false);
	m_pHandRight = new CHandSkeletonKin(true);
	m_iHD = 1;
}

void CFastCal::SetBasePath(std::string strBasePath)
{
	m_strBasePath = strBasePath;
}
void CFastCal::ExtractTrainingData()
{
	//extract_training_data(true);
	//extract_training_data(false);
}

void CFastCal::Train()
{
	//train(true);
	//train(false);
}

void CFastCal::BatchCalibrate()
{
	batch_calibrate(true);
	//batch_calibrate(false);
}
void CFastCal::Calibrate(CRawClip& clipInput, CRawClip& clipOutput, bool bLeft)
{
}

//**********************************************************************************************
void CFastCal::load_hand_size(CString strSizePath, bool bLeft)
{
	if(bLeft && m_pHandLeft)
		m_pHandLeft->LoadSizeFromFile(strSizePath);

	if(!bLeft && m_pHandRight)
		m_pHandRight->LoadSizeFromFile(strSizePath);
}
//Private Internal Implementation
//FK Key: flat, spread, fist, overbend, thumbUp, thumbOut 
//IK Key: index, mid, ring, pinky
//CC Key: spreadOut, im0, pr0
void CFastCal::generate_fk_groundtruth(bool bLeft)
{
	std::string strBase;
	std::string strSuffix;
	std::string strBaseProj;
	CHandSkeletonKin* pHand = NULL;
	if(bLeft)
	{
		strBase = m_strBasePath + "raw/left/";
		strBaseProj = m_strBasePath + "glv/left/fk_groundTruth/";
		strSuffix = "_l.raw";
		pHand = m_pHandLeft;
	}
	else
	{
		strBase = m_strBasePath + "raw/right/";
		strBaseProj = m_strBasePath + "glv/right/fk_groundTruth/";
		strSuffix = "_r.raw";
		pHand = m_pHandRight;
	}

	//FK==========================================================================
	//frame in degree, to radian
	CGlvClip clipGlvFlat, clipGlvSpread, clipGlvFist, clipGlvOverbend, clipGlvThumbUp, clipGlvThumbOut,  clipGlvPistol/*FK*/;
	clipGlvFlat.LoadFromFile(strBaseProj + "flat.glv"); clipGlvFlat.ToRadian();
	clipGlvSpread.LoadFromFile(strBaseProj + "spread.glv"); clipGlvSpread.ToRadian();
	clipGlvFist.LoadFromFile(strBaseProj + "fist.glv"); clipGlvFist.ToRadian();
	clipGlvOverbend.LoadFromFile(strBaseProj + "overbend.glv"); clipGlvOverbend.ToRadian();
	clipGlvThumbUp.LoadFromFile(strBaseProj + "thumbUp.glv"); clipGlvThumbUp.ToRadian();
	clipGlvThumbOut.LoadFromFile(strBaseProj + "thumbOut.glv"); clipGlvThumbOut.ToRadian();
	clipGlvPistol.LoadFromFile(strBaseProj + "pistol.glv"); clipGlvPistol.ToRadian();
	
	//to raw gound truth
	CRawClip clipFlat_gt = GloveUtil::GlvToRaw(clipGlvFlat, bLeft);
	CRawClip clipSpread_gt = GloveUtil::GlvToRaw(clipGlvSpread, bLeft);
	CRawClip clipFist_gt = GloveUtil::GlvToRaw(clipGlvFist, bLeft);
	//correction for the virtual joint
	for(int i = 0; i < clipFist_gt.m_arFrame.size(); ++i)
	{
		clipFist_gt.m_arFrame[i].m_arData[2] =  - 0.46 * clipFist_gt.m_arFrame[i].m_arData[0] - 1.38 *clipFist_gt.m_arFrame[i].m_arData[1];
	}
	CRawClip clipOverbend_gt = GloveUtil::GlvToRaw(clipGlvOverbend, bLeft);
	CRawClip clipThumbUp_gt = GloveUtil::GlvToRaw(clipGlvThumbUp, bLeft);
	CRawClip clipThumbOut_gt = GloveUtil::GlvToRaw(clipGlvThumbOut, bLeft);
	CRawClip clipPistol_gt = GloveUtil::GlvToRaw(clipGlvPistol, bLeft);

	//Rest
	CRawClip clipRest_gt1, clipRest_gt2;
	clipRest_gt1.LoadFromFile(strBase + "sp/1base/rest" + strSuffix);//linearly calibrated
	clipRest_gt2.LoadFromFile(strBase + "sp/1base/rest2" + strSuffix);
	clipRest_gt2.CorrectBetweenThumb(bLeft, clipFlat_gt.m_arFrame[0], clipFist_gt.m_arFrame[0]);
	//CC===========================================================================
	CRawClip clipSpreadOut_gt, clipIM0_gt, clipPR0_gt;
	clipSpreadOut_gt.LoadFromFile(strBase + "sp/1base/spreadOut" + strSuffix); //linearly calibrated
	float fFlatAbd_r = clipFlat_gt.m_arFrame[0].m_arData[1];
	float fSpreadAbd_r = clipSpread_gt.m_arFrame[0].m_arData[1];
	clipSpreadOut_gt.CorrectStandardSpreadOutThumb(bLeft, fFlatAbd_r, fSpreadAbd_r);
	clipSpreadOut_gt.ZeroFingerFlex();

	clipIM0_gt.LoadFromFile(strBase + "sp/1base/im0" + strSuffix);
	for(int i = 0; i < clipIM0_gt.m_arFrame.size(); ++i)
	{
		if(bLeft)
			clipIM0_gt.m_arFrame[i].m_arData[7] =  -15;
		else
			clipIM0_gt.m_arFrame[i].m_arData[7] =  15;
	}

	clipPR0_gt.LoadFromFile(strBase + "sp/1base/pr0" + strSuffix);
	for(int i = 0; i < clipPR0_gt.m_arFrame.size(); ++i)
	{
		if(bLeft)
			clipPR0_gt.m_arFrame[i].m_arData[25] =  30;
		else
			clipPR0_gt.m_arFrame[i].m_arData[25] =  -30;
	}


	//write out========================================================================
	CreateDirectory(CString(strBase.c_str()) + L"groundTruth", NULL);

	clipFlat_gt.SaveToFile(strBase + "groundTruth/flat.raw");
	clipFist_gt.SaveToFile(strBase + "groundTruth/fist.raw");
	clipSpread_gt.SaveToFile(strBase + "groundTruth/spread.raw");
	clipOverbend_gt.SaveToFile(strBase + "groundTruth/overbend.raw");
	clipThumbUp_gt.SaveToFile(strBase + "groundTruth/thumbUp.raw");
	clipThumbOut_gt.SaveToFile(strBase + "groundTruth/thumbOut.raw");
	clipSpreadOut_gt.SaveToFile(strBase + "groundTruth/spreadOut.raw");
	clipIM0_gt.SaveToFile(strBase + "groundTruth/im0.raw");
	clipPR0_gt.SaveToFile(strBase + "groundTruth/pr0.raw");

	clipRest_gt1.SaveToFile(strBase + "groundTruth/rest1.raw");
	clipRest_gt2.SaveToFile(strBase + "groundTruth/rest2.raw");

	clipPistol_gt.SaveToFile(strBase + "groundTruth/pistol.raw");
}
//0. linear if necessary========================================
void CFastCal::extract_linear_go(bool bLeft)
{
	std::string strBaseGlv;
	std::string strBaseTr;
	if(bLeft)
		strBaseGlv = m_strBasePath + "glv/left/";
	else
		strBaseGlv = m_strBasePath + "glv/right/";

	CGloveCalibration glvCal;
	glvCal.LoadFromFile(strBaseGlv + "calib.gcb");
	glvCal.WriteToTrHp(m_strBasePath, bLeft);
}
//1. finger flex=============================================
void CFastCal::extract_finger_flex_tr(bool bLeft, bool bFull)
{
	std::string strBaseRaw;
	std::string strSuffix;
	std::string strBaseTr;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strBaseTr = m_strBasePath + "trainingset/left/";
		strSuffix = "_l.raw";
	}
	else
	{		
		strBaseRaw = m_strBasePath + "raw/right/";
		strBaseTr = m_strBasePath + "trainingset/right/";
		strSuffix = "_r.raw";
	}

	//SAMPLED DATA=====================================================================================
	CRawClip clipFlat, clipFist, clipSpread, clipOverbend;

	clipFlat.LoadFromFile(strBaseRaw + "sp/1base/flat" + strSuffix);
	clipFist.LoadFromFile(strBaseRaw + "sp/1base/fist" + strSuffix);
	clipSpread.LoadFromFile(strBaseRaw + "sp/1base/spread" + strSuffix);
	CRawClip* pRaw = (CRawClip*)clipSpread.GetSubClip(0,1);
	clipSpread = *pRaw;
	delete pRaw;
	clipOverbend.LoadFromFile(strBaseRaw + "sp/1base/overbend" + strSuffix);
	pRaw = (CRawClip*)clipOverbend.GetSubClip(0,1);
	clipOverbend = *pRaw;
	delete pRaw;


	//GROUND TRUTH=====================================================================================
	CRawClip clipFlat_gt, clipFist_gt, clipSpread_gt, clipOverbend_gt;

	clipFlat_gt.LoadFromFile(strBaseRaw + "groundTruth/flat.raw");
	clipFist_gt.LoadFromFile(strBaseRaw + "groundTruth/fist.raw");
	clipSpread_gt.LoadFromFile(strBaseRaw + "groundTruth/spread.raw");
	pRaw = (CRawClip*)clipSpread_gt.GetSubClip(0,1);
	clipSpread_gt = *pRaw;
	delete pRaw;
	clipOverbend_gt.LoadFromFile(strBaseRaw + "groundTruth/overbend.raw");
	pRaw = (CRawClip*)clipOverbend_gt.GetSubClip(0,1);
	clipOverbend_gt = *pRaw;
	delete pRaw;

	//==============================================================================================
	//the following is to linearize the training data, 
	CRawClip clipLinear, clipLinear_gt;
	CRawFrame frmFlat = clipFlat.m_arFrame[0], frmFlat_gt = clipFlat_gt.m_arFrame[0];
	CRawFrame frmFist = clipFist.m_arFrame[0], frmFist_gt = clipFist_gt.m_arFrame[0];
	CRawFrame frmOverbend = clipOverbend.m_arFrame[0], frmOverbend_gt = clipOverbend_gt.m_arFrame[0];
	for(int i = 0; i < 10; i++)
	{
		float fCoeff = i/10.0;
		CRawFrame frmLinear = CRawFrame::InterpolateBetween(frmFlat, frmFist, fCoeff);
		CRawFrame frmLinear_gt = CRawFrame::InterpolateBetween(frmFlat_gt, frmFist_gt, fCoeff);
		clipLinear.m_arFrame.push_back(frmLinear);
		clipLinear_gt.m_arFrame.push_back(frmLinear_gt);

		if(i%2==0)
		{
			frmLinear = CRawFrame::InterpolateBetween(frmFlat, frmOverbend, fCoeff);
			frmLinear_gt = CRawFrame::InterpolateBetween(frmFlat_gt, frmOverbend_gt, fCoeff);
			clipLinear.m_arFrame.push_back(frmLinear);
			clipLinear_gt.m_arFrame.push_back(frmLinear_gt);
		}
	}

	//pair <sample, truth>=================================================================================
	std::vector<CRawClip> arSampledData;
	std::vector<CRawClip> arGroundTruth;

	arSampledData.push_back(clipFlat); arGroundTruth.push_back(clipFlat_gt); // pose: flat	
	arSampledData.push_back(clipFist); arGroundTruth.push_back(clipFist_gt); //pose: fist
	arSampledData.push_back(clipSpread); arGroundTruth.push_back(clipSpread_gt); //pose: spread
	arSampledData.push_back(clipOverbend); arGroundTruth.push_back(clipOverbend_gt); //pose: overbend
	arSampledData.push_back(clipLinear); arGroundTruth.push_back(clipLinear_gt);

	//produce output =================================================================
	CRawClip clipIndexMCP, clipIndexPIP, clipIndexDIP,
		clipMidMCP, clipMidPIP, clipMidDIP,
		clipRingMCP, clipRingPIP, clipRingDIP,
		clipPinkyMCP, clipPinkyPIP, clipPinkyDIP;
	
	for(int i = 0; i < arSampledData.size(); ++i)
	{
		CRawClip clipSample = arSampledData[i];
		CRawClip clipTruth = arGroundTruth[i];
		for(int j = 0; j < clipSample.m_arFrame.size(); ++j)
		{
			CRawFrame frmSample = clipSample.m_arFrame[j];
			CRawFrame frmTruth;
			if(clipSample.m_arFrame.size() == clipTruth.m_arFrame.size())
				frmTruth = clipTruth.m_arFrame[j];
			else if(clipTruth.m_arFrame.size() < clipSample.m_arFrame.size())
				frmTruth = clipTruth.m_arFrame[0];//POSE

			//index
			CRawFrame frmIndexMCP;
			frmIndexMCP.m_arData.push_back(frmSample.m_arData[8]);
			frmIndexMCP.m_arData.push_back(frmTruth.m_arData[8]);
			clipIndexMCP.m_arFrame.push_back(frmIndexMCP);

			CRawFrame frmIndexPIP;
			frmIndexPIP.m_arData.push_back(frmSample.m_arData[9]);
			frmIndexPIP.m_arData.push_back(frmTruth.m_arData[9]);
			clipIndexPIP.m_arFrame.push_back(frmIndexPIP);

			CRawFrame frmIndexDIP;
			frmIndexDIP.m_arData.push_back(frmSample.m_arData[10]);
			frmIndexDIP.m_arData.push_back(frmTruth.m_arData[10]);
			clipIndexDIP.m_arFrame.push_back(frmIndexDIP);

			//mid
			CRawFrame frmMidMCP;
			frmMidMCP.m_arData.push_back(frmSample.m_arData[14]);
			frmMidMCP.m_arData.push_back(frmTruth.m_arData[14]);
			clipMidMCP.m_arFrame.push_back(frmMidMCP);

			CRawFrame frmMidPIP;
			frmMidPIP.m_arData.push_back(frmSample.m_arData[15]);
			frmMidPIP.m_arData.push_back(frmTruth.m_arData[15]);
			clipMidPIP.m_arFrame.push_back(frmMidPIP);

			CRawFrame frmMidDIP;
			frmMidDIP.m_arData.push_back(frmSample.m_arData[16]);
			frmMidDIP.m_arData.push_back(frmTruth.m_arData[16]);
			clipMidDIP.m_arFrame.push_back(frmMidDIP);

			//ring
			CRawFrame frmRingMCP;
			frmRingMCP.m_arData.push_back(frmSample.m_arData[20]);
			frmRingMCP.m_arData.push_back(frmTruth.m_arData[20]);
			clipRingMCP.m_arFrame.push_back(frmRingMCP);

			CRawFrame frmRingPIP;
			frmRingPIP.m_arData.push_back(frmSample.m_arData[21]);
			frmRingPIP.m_arData.push_back(frmTruth.m_arData[21]);
			clipRingPIP.m_arFrame.push_back(frmRingPIP);

			CRawFrame frmRingDIP;
			frmRingDIP.m_arData.push_back(frmSample.m_arData[22]);
			frmRingDIP.m_arData.push_back(frmTruth.m_arData[22]);
			clipRingDIP.m_arFrame.push_back(frmRingDIP);

			//pinky
			CRawFrame frmPinkyMCP;
			frmPinkyMCP.m_arData.push_back(frmSample.m_arData[26]);
			frmPinkyMCP.m_arData.push_back(frmTruth.m_arData[26]);
			clipPinkyMCP.m_arFrame.push_back(frmPinkyMCP);

			CRawFrame frmPinkyPIP;
			frmPinkyPIP.m_arData.push_back(frmSample.m_arData[27]);
			frmPinkyPIP.m_arData.push_back(frmTruth.m_arData[27]);
			clipPinkyPIP.m_arFrame.push_back(frmPinkyPIP);

			CRawFrame frmPinkyDIP;
			frmPinkyDIP.m_arData.push_back(frmSample.m_arData[28]);
			frmPinkyDIP.m_arData.push_back(frmTruth.m_arData[28]);
			clipPinkyDIP.m_arFrame.push_back(frmPinkyDIP);
		}
	}

	//extra can be skipped too
	clipIndexMCP.AddExtrapolationTr1D();
	clipIndexPIP.AddExtrapolationTr1D();
	clipIndexDIP.AddExtrapolationTr1D();

	clipMidMCP.AddExtrapolationTr1D();
	clipMidPIP.AddExtrapolationTr1D();
	clipMidDIP.AddExtrapolationTr1D();

	clipRingMCP.AddExtrapolationTr1D();
	clipRingPIP.AddExtrapolationTr1D();
	clipRingDIP.AddExtrapolationTr1D();

	clipPinkyMCP.AddExtrapolationTr1D();
	clipPinkyPIP.AddExtrapolationTr1D();
	clipPinkyDIP.AddExtrapolationTr1D();

	/*/DO NOT remove redundant data here, designed and tested
	clipIndexMCP.EliminateInputRedundancy();
	clipIndexPIP.EliminateInputRedundancy();
	clipIndexDIP.EliminateInputRedundancy();
	clipMidMCP.EliminateInputRedundancy();
	clipMidPIP.EliminateInputRedundancy();
	clipMidDIP.EliminateInputRedundancy();
	clipRingMCP.EliminateInputRedundancy();
	clipRingPIP.EliminateInputRedundancy();
	clipRingDIP.EliminateInputRedundancy();
	clipPinkyMCP.EliminateInputRedundancy();
	clipPinkyPIP.EliminateInputRedundancy();
	clipPinkyDIP.EliminateInputRedundancy();
	
	clipIndexMCP.EliminateOutputRedundancy(1);
	clipIndexPIP.EliminateOutputRedundancy(1);
	clipIndexDIP.EliminateOutputRedundancy(1);
	clipMidMCP.EliminateOutputRedundancy(1);
	clipMidPIP.EliminateOutputRedundancy(1);
	clipMidDIP.EliminateOutputRedundancy(1);
	clipRingMCP.EliminateOutputRedundancy(1);
	clipRingPIP.EliminateOutputRedundancy(1);
	clipRingDIP.EliminateOutputRedundancy(1);
	clipPinkyMCP.EliminateOutputRedundancy(1);
	clipPinkyPIP.EliminateOutputRedundancy(1);
	clipPinkyDIP.EliminateOutputRedundancy(1);*/

	//write output ==============================================================
	if(bFull)
	{
		clipIndexMCP.SaveToFile(strBaseTr + "8_HAND_SKEL_DOF_INDEX_FLEX_PROX/tr.tr");
		clipIndexPIP.SaveToFile(strBaseTr + "9_HAND_SKEL_DOF_INDEX_FLEX_MID/tr.tr");
		clipIndexDIP.SaveToFile(strBaseTr + "10_HAND_SKEL_DOF_INDEX_FLEX_DIST/tr.tr");

		clipMidMCP.SaveToFile(strBaseTr + "14_HAND_SKEL_DOF_MID_FLEX_PROX/tr.tr");
		clipMidPIP.SaveToFile(strBaseTr + "15_HAND_SKEL_DOF_MID_FLEX_MID/tr.tr");
		clipMidDIP.SaveToFile(strBaseTr + "16_HAND_SKEL_DOF_MID_FLEX_DIST/tr.tr");

		clipRingMCP.SaveToFile(strBaseTr + "20_HAND_SKEL_DOF_RING_FLEX_PROX/tr.tr");
		clipRingPIP.SaveToFile(strBaseTr + "21_HAND_SKEL_DOF_RING_FLEX_MID/tr.tr");
		clipRingDIP.SaveToFile(strBaseTr + "22_HAND_SKEL_DOF_RING_FLEX_DIST/tr.tr");

		clipPinkyMCP.SaveToFile(strBaseTr + "26_HAND_SKEL_DOF_PINKY_FLEX_PROX/tr.tr");
		clipPinkyPIP.SaveToFile(strBaseTr + "27_HAND_SKEL_DOF_PINKY_FLEX_MID/tr.tr");
		clipPinkyDIP.SaveToFile(strBaseTr + "28_HAND_SKEL_DOF_PINKY_FLEX_DIST/tr.tr");
	}
	else
	{
		//should do nothing if sparse
		clipIndexMCP.SaveToFile(strBaseTr + "8_HAND_SKEL_DOF_INDEX_FLEX_PROX/active_tr.tr");
		clipIndexPIP.SaveToFile(strBaseTr + "9_HAND_SKEL_DOF_INDEX_FLEX_MID/active_tr.tr");
		clipIndexDIP.SaveToFile(strBaseTr + "10_HAND_SKEL_DOF_INDEX_FLEX_DIST/active_tr.tr");

		clipMidMCP.SaveToFile(strBaseTr + "14_HAND_SKEL_DOF_MID_FLEX_PROX/active_tr.tr");
		clipMidPIP.SaveToFile(strBaseTr + "15_HAND_SKEL_DOF_MID_FLEX_MID/active_tr.tr");
		clipMidDIP.SaveToFile(strBaseTr + "16_HAND_SKEL_DOF_MID_FLEX_DIST/active_tr.tr");

		clipRingMCP.SaveToFile(strBaseTr + "20_HAND_SKEL_DOF_RING_FLEX_PROX/active_tr.tr");
		clipRingPIP.SaveToFile(strBaseTr + "21_HAND_SKEL_DOF_RING_FLEX_MID/active_tr.tr");
		clipRingDIP.SaveToFile(strBaseTr + "22_HAND_SKEL_DOF_RING_FLEX_DIST/active_tr.tr");

		clipPinkyMCP.SaveToFile(strBaseTr + "26_HAND_SKEL_DOF_PINKY_FLEX_PROX/active_tr.tr");
		clipPinkyPIP.SaveToFile(strBaseTr + "27_HAND_SKEL_DOF_PINKY_FLEX_MID/active_tr.tr");
		clipPinkyDIP.SaveToFile(strBaseTr + "28_HAND_SKEL_DOF_PINKY_FLEX_DIST/active_tr.tr");
	}
}
void CFastCal::train_finger_flex(bool bLeft, bool bFull)
{
	std::string strBaseTr = m_strBasePath + "trainingset/";
	std::string strHand = "r";
	if(bLeft)
		strHand = "l";

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[300];
	engOutputBuffer(pMatlabEngine, outputBuffer, 300);

	char strCmd[800];
	if(bFull)
		sprintf(strCmd, "generate_fullset_fingerFLEX_%s; train_fingerFLEX_full_%s;", strHand.c_str(), strHand.c_str());
	else
		sprintf(strCmd, "generate_activeset_fingerFLEX_%s; train_fingerFLEX_fitc_%s;", strHand.c_str(), strHand.c_str());
	engEvalString(pMatlabEngine,strCmd);
}

void CFastCal::generate_finger_2flex(bool bLeft, bool bFull)
{
	std::string strBaseRaw;
	std::string strSuffix;
	CHandSkeletonKin* pHand = NULL;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strSuffix = "_l.raw";
		pHand = m_pHandLeft;
	}
	else
	{
		strBaseRaw = m_strBasePath + "raw/right/";
		strSuffix = "_r.raw";
		pHand = m_pHandRight;
	}
	std::string strResult;
	if(bFull)
		strResult = strBaseRaw + "sp/2flex_full/";
	else
		strResult = strBaseRaw + "sp/2flex_fitc/";
	CreateDirectory(CString(strResult.c_str()), NULL);

	CFileFind finder;
	CString strBR(strBaseRaw.c_str());
	BOOL bNotFinished = finder.FindFile(strBR + L"sp/1base/*.*");	
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		std::string strTitle = GloveUtil::ToChar(finder.GetFileTitle());
		if(finder.IsDirectory())
			continue;

		CString strFileName = finder.GetFileName();
		CRawClip clipRaw;
		clipRaw.LoadFromFile(GloveUtil::ToChar(finder.GetFilePath()));
		if(bFull)
			clipRaw = MatlabUtil::GPRCalibrate_fingerFLEX_full(clipRaw, bLeft);
		else
			clipRaw = MatlabUtil::GPRCalibrate_fingerFLEX_fitc(clipRaw, bLeft);
		//calibrate flex
		clipRaw.SaveToFile(strResult + strTitle + ".raw");
	};
}
//2. finger abd=============================================
void CFastCal::extract_finger_abd_tr(bool bLeft, bool bFull)
{
	std::string strBaseRaw;
	std::string strSuffix;
	std::string strBaseTr;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strBaseTr = m_strBasePath + "trainingset/left/";
		strSuffix = "_l.raw";
	}
	else
	{		
		strBaseRaw = m_strBasePath + "raw/right/";
		strBaseTr = m_strBasePath + "trainingset/right/";
		strSuffix = "_r.raw";
	}
	std::string strFull;
	if(bFull)
		strFull = "_full";
	else
		strFull = "_fitc";

	//SAMPLED DATA=====================================================================================
	CRawClip clipFlat, clipFist, clipSpread, clipSpreadOut, clipIM0, clipPR0;

	clipFlat.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/flat" + strSuffix);
	clipFist.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/fist" + strSuffix);
	clipSpread.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/spread" + strSuffix);
	clipSpreadOut.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/spreadOut" + strSuffix);

	clipIM0.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/im0" + strSuffix);
	clipPR0.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/pr0" + strSuffix);
	
	//GROUND TRUTH=====================================================================================
	CRawClip clipFlat_gt, clipFist_gt, clipSpread_gt, clipSpreadOut_gt;

	clipFlat_gt.LoadFromFile(strBaseRaw + "groundTruth/flat.raw");
	clipFist_gt.LoadFromFile(strBaseRaw + "groundTruth/fist.raw");
	clipSpread_gt.LoadFromFile(strBaseRaw + "groundTruth/spread.raw");
	clipSpreadOut_gt.LoadFromFile(strBaseRaw + "groundTruth/spreadOut.raw");

	//make sparse=======================================================================================
	if(!bFull)//fitc
	{
		CRawClip::EliminateIndexAbdRedundancy(clipSpreadOut, clipSpreadOut_gt, 3);
		clipIM0.EliminateInputRedundancy(8);
		clipPR0.EliminateInputRedundancy(8);
	}

	
	//pair <sample, truth>=================================================================================
	std::vector<CRawClip> arSampledData;
	std::vector<CRawClip> arGroundTruth;

	arSampledData.push_back(clipFlat); arGroundTruth.push_back(clipFlat_gt); // pose: flat	
	arSampledData.push_back(clipFist); arGroundTruth.push_back(clipFist_gt); //pose: fist
	arSampledData.push_back(clipSpread); arGroundTruth.push_back(clipSpread_gt); //pose: spread
	arSampledData.push_back(clipSpreadOut); arGroundTruth.push_back(clipSpreadOut_gt); //pose: fist

	//produce output =================================================================
	CRawClip clipOutput7/*index-mid-abd*/, clipOutput25/*ring-pinky-abd*/;
	for(int i = 0; i < arSampledData.size(); ++i)
	{
		CRawClip clipSample = arSampledData[i];
		CRawClip clipTruth = arGroundTruth[i];
		for(int j = 0; j < clipSample.m_arFrame.size(); ++j)
		{
			CRawFrame frmSample = clipSample.m_arFrame[j];
			CRawFrame frmTruth;
			if(clipSample.m_arFrame.size() == clipTruth.m_arFrame.size())
				frmTruth = clipTruth.m_arFrame[j];
			else if(clipTruth.m_arFrame.size() < clipSample.m_arFrame.size())
				frmTruth = clipTruth.m_arFrame[0];//POSE

			CRawFrame frmOutput7;
			frmOutput7.m_arData.push_back(frmSample.m_arData[8]);
			frmOutput7.m_arData.push_back(frmSample.m_arData[14]);
			frmOutput7.m_arData.push_back(frmSample.m_arData[7]);
			frmOutput7.m_arData.push_back(frmTruth.m_arData[7]);
			clipOutput7.m_arFrame.push_back(frmOutput7);

			CRawFrame frmOutput25;
			frmOutput25.m_arData.push_back(frmSample.m_arData[20]);
			frmOutput25.m_arData.push_back(frmSample.m_arData[26]);
			frmOutput25.m_arData.push_back(frmSample.m_arData[25]);
			frmOutput25.m_arData.push_back(frmTruth.m_arData[25]);
			clipOutput25.m_arFrame.push_back(frmOutput25);
		}
	}

	for(int j = 0; j < clipIM0.m_arFrame.size(); ++j)
	{
		CRawFrame frmSample = clipIM0.m_arFrame[j];
		CRawFrame frmOutput7;
		frmOutput7.m_arData.push_back(frmSample.m_arData[8]);
		frmOutput7.m_arData.push_back(frmSample.m_arData[14]);
		frmOutput7.m_arData.push_back(frmSample.m_arData[7]);
		if(bLeft)
			frmOutput7.m_arData.push_back(-15);
		else
			frmOutput7.m_arData.push_back(15);
		clipOutput7.m_arFrame.push_back(frmOutput7);
	}

	for(int j = 0; j < clipPR0.m_arFrame.size(); ++j)
	{
		CRawFrame frmSample = clipPR0.m_arFrame[j];
		CRawFrame frmOutput25;
		frmOutput25.m_arData.push_back(frmSample.m_arData[20]);
		frmOutput25.m_arData.push_back(frmSample.m_arData[26]);
		frmOutput25.m_arData.push_back(frmSample.m_arData[25]);
		if(bLeft)
			frmOutput25.m_arData.push_back(30);
		else
			frmOutput25.m_arData.push_back(-30);
		clipOutput25.m_arFrame.push_back(frmOutput25);
	}

	//write output ==============================================================
	if(bFull)
	{
		clipOutput7.EliminateInputRedundancy();
		clipOutput7.SaveToFile(strBaseTr + "7_HAND_SKEL_DOF_INDEX_ABD/tr.tr");

		clipOutput25.EliminateInputRedundancy();
		clipOutput25.SaveToFile(strBaseTr + "25_HAND_SKEL_DOF_PINKY_ABD/tr.tr");
	}
	else//fitc
	{
		clipOutput7.EliminateInputRedundancy();
		clipOutput7.SaveToFile(strBaseTr + "7_HAND_SKEL_DOF_INDEX_ABD/active_tr.tr");
		clipOutput25.EliminateInputRedundancy();
		clipOutput25.SaveToFile(strBaseTr + "25_HAND_SKEL_DOF_PINKY_ABD/active_tr.tr");
	}
}
void CFastCal::train_finger_abd(bool bLeft, bool bFull)
{
	std::string strBaseTr = m_strBasePath + "trainingset/";
	std::string strHand = "r";
	if(bLeft)
		strHand = "l";

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[300];
	engOutputBuffer(pMatlabEngine, outputBuffer, 300);

	char strCmd[800];
	if(bFull)
		sprintf(strCmd, "generate_fullset_fingerABD_%s; train_fingerABD_full_%s;", strHand.c_str(), strHand.c_str());
	else
		sprintf(strCmd, "generate_activeset_fingerABD_%s; train_fingerABD_fitc_%s;", strHand.c_str(), strHand.c_str());
	engEvalString(pMatlabEngine,strCmd);
}
void CFastCal::generate_finger_3abd(bool bLeft, bool bFull)
{
	std::string strBaseRaw;
	std::string strSuffix;
	CHandSkeletonKin* pHand = NULL;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strSuffix = "_l.raw";
		pHand = m_pHandLeft;
	}
	else
	{
		strBaseRaw = m_strBasePath + "raw/right/";
		strSuffix = "_r.raw";
		pHand = m_pHandRight;
	}
	std::string strFull;
	std::string strSrc, strResult;
	if(bFull)
	{
		strFull = "_full";
		strSrc = strBaseRaw + "sp/2flex_full/*.*";
		strResult = strBaseRaw + "sp/3abd_full/";
	}
	else
	{
		strFull = "_fitc";
		strSrc = strBaseRaw + "sp/2flex_fitc/*.*";
		strResult = strBaseRaw + "sp/3abd_fitc/";
	}
	CreateDirectory(CString(strResult.c_str()), NULL);

	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(CString(strSrc.c_str()));
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		std::string strTitle = GloveUtil::ToChar(finder.GetFileTitle());
		if(finder.IsDirectory())
			continue;
		CRawClip clipRaw;
		clipRaw.LoadFromFile(GloveUtil::ToChar(finder.GetFilePath()));
		if(bFull)
			clipRaw = MatlabUtil::GPRCalibrate_fingerABD_full(clipRaw, bLeft);
		else
			clipRaw = MatlabUtil::GPRCalibrate_fingerABD_fitc(clipRaw, bLeft);
		//calibrate flex
		clipRaw.SaveToFile(strResult + strTitle + ".raw");
	};
}
//3. thumb ===============================================
#include "GPRDB.h"
void CFastCal::generate_ik_groundtruth(bool bLeft, bool bFull)
{
	CGPRDB* pGPRDB = CGPRDB::GetIKDB();
	pGPRDB->m_arDBItem.clear();

	std::string strBaseRaw;
	std::string strFKSubPath;
	std::string strIKSubPath;
	std::string strSuffix;
	CHandSkeletonKin* pHand = NULL;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strSuffix = "_l.raw";
		pHand = m_pHandLeft;
	}
	else
	{
		strBaseRaw = m_strBasePath + "raw/right/";
		strSuffix = "_r.raw";
		pHand = m_pHandRight;
	}

	if(bFull) 
	{
		strFKSubPath = strBaseRaw + "sp/3abd_full/";
		strIKSubPath = strBaseRaw + "groundTruth/ik_full/";
	}
	else 
	{
		strFKSubPath = strBaseRaw + "sp/3abd_fitc/";
		strIKSubPath = strBaseRaw + "groundTruth/ik_fitc/";
	}
	::CreateDirectory(CString(strIKSubPath.c_str()), NULL);
	
	CRawClip clipIKIndex, clipIKMid, clipIKRing, clipIKPinky;
	clipIKIndex.LoadFromFile(strFKSubPath + "index" + strSuffix); 
	clipIKMid.LoadFromFile(strFKSubPath + "mid" + strSuffix); 
	clipIKRing.LoadFromFile(strFKSubPath + "ring" + strSuffix); 
	clipIKPinky.LoadFromFile(strFKSubPath + "pinky" + strSuffix); 
	
	CRawClip clipIKIndex_gt, clipIKMid_gt, clipIKRing_gt, clipIKPinky_gt;
	clipIKIndex_gt = GloveUtil::IKSampling(clipIKIndex, 1, bLeft);
	clipIKMid_gt = GloveUtil::IKSampling(clipIKMid, 2, bLeft);
	clipIKRing_gt = GloveUtil::IKSampling(clipIKRing, 3, bLeft);
	clipIKPinky_gt = GloveUtil::IKSampling(clipIKPinky, 4, bLeft);

	clipIKIndex_gt.SaveToFile(strIKSubPath + "index.raw");
	clipIKMid_gt.SaveToFile(strIKSubPath + "mid.raw");
	clipIKRing_gt.SaveToFile(strIKSubPath + "ring.raw");
	clipIKPinky_gt.SaveToFile(strIKSubPath + "pinky.raw");

	//extra IK2
	CRawClip clipIKIndex2, clipIKMid2, clipIKRing2, clipIKPinky2;
	clipIKIndex2.LoadFromFile(strFKSubPath + "index2" + strSuffix); 
	clipIKMid2.LoadFromFile(strFKSubPath + "mid2" + strSuffix); 
	clipIKRing2.LoadFromFile(strFKSubPath + "ring2" + strSuffix); 
	clipIKPinky2.LoadFromFile(strFKSubPath + "pinky2" + strSuffix); 
	
	CRawClip clipIKIndex2_gt, clipIKMid2_gt, clipIKRing2_gt, clipIKPinky2_gt;
	if(clipIKIndex2.m_arFrame.size() > 0)
	{
		clipIKIndex2_gt = GloveUtil::IKSampling(clipIKIndex2, 1, bLeft);
		clipIKIndex2_gt.SaveToFile(strIKSubPath + "index2.raw");
	}

	if(clipIKMid2.m_arFrame.size() > 0)
	{
		clipIKMid2_gt = GloveUtil::IKSampling(clipIKMid2, 2, bLeft);
		clipIKMid2_gt.SaveToFile(strIKSubPath + "mid2.raw");
	}

	if(clipIKRing2.m_arFrame.size() > 0)
	{
		clipIKRing2_gt = GloveUtil::IKSampling(clipIKRing2, 3, bLeft);
		clipIKRing2_gt.SaveToFile(strIKSubPath + "ring2.raw");
	}

	if(clipIKPinky2.m_arFrame.size() > 0)
	{
		clipIKPinky2_gt = GloveUtil::IKSampling(clipIKPinky2, 4, bLeft);
		clipIKPinky2_gt.SaveToFile(strIKSubPath + "pinky2.raw");
	}
	pGPRDB->GetClipSensor().SaveToFile(strFKSubPath + "dbSensor.raw");
	pGPRDB->GetClipSln().SaveToFile(strIKSubPath + "dbSln.raw");
}

void CFastCal::generate_ik_groundtruth2(bool bLeft, bool bFull)
{
	std::string strBaseRaw;
	std::string strSubPath;	
	std::string strSuffix;
	CHandSkeletonKin* pHand = NULL;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strSuffix = "_l.raw";
		pHand = m_pHandLeft;
	}
	else
	{
		strBaseRaw = m_strBasePath + "raw/right/";
		strSuffix = "_r.raw";
		pHand = m_pHandRight;
	}
	if(bFull) strSubPath = strBaseRaw + "sp/3abd_full/";
	else strSubPath = strBaseRaw + "sp/3abd_fitc/";

	CRawClip clipIndex, clipMid, clipRing, clipPinky;
	clipIndex.LoadFromFile(strSubPath + "index" + strSuffix);
	clipMid.LoadFromFile(strSubPath + "mid" + strSuffix);
	clipRing.LoadFromFile(strSubPath + "ring" + strSuffix);
	clipPinky.LoadFromFile(strSubPath + "pinky" + strSuffix);

	CIKClip clipIKIndex = CIKClip::NewFromRawClip(clipIndex, eThumbIndex);
	CIKClip clipIKMid = CIKClip::NewFromRawClip(clipMid, eThumbMid);
	CIKClip clipIKRing = CIKClip::NewFromRawClip(clipRing, eThumbRing);
	CIKClip clipIKPinky = CIKClip::NewFromRawClip(clipPinky, eThumbPinky);

	CIKClip clipIKAll;
	clipIKAll.MergeWith(clipIKIndex);
	clipIKAll.MergeWith(clipIKMid);
	clipIKAll.MergeWith(clipIKRing);
	clipIKAll.MergeWith(clipIKPinky);

	//check extra IK
	CRawClip clipIndex2, clipMid2, clipRing2, clipPinky2;
	clipIndex2.LoadFromFile(strSubPath + "index2" + strSuffix);
	if(clipIndex2.m_arFrame.size() > 0)
	{
		CIKClip clipIKIndex2 = CIKClip::NewFromRawClip(clipIndex2, eThumbIndex);
		clipIKAll.MergeWith(clipIKIndex2);
	}

	clipMid2.LoadFromFile(strSubPath + "mid2" + strSuffix);
	if(clipMid2.m_arFrame.size() > 0)
	{
		CIKClip clipIKMid2 = CIKClip::NewFromRawClip(clipMid2, eThumbMid);
		clipIKAll.MergeWith(clipIKMid2);
	}

	clipRing2.LoadFromFile(strSubPath + "ring2" + strSuffix);
	if(clipRing2.m_arFrame.size() > 0)
	{
		CIKClip clipIKRing2 = CIKClip::NewFromRawClip(clipRing2, eThumbRing);
		clipIKAll.MergeWith(clipIKRing2);
	}

	clipPinky2.LoadFromFile(strSubPath + "pinky2" + strSuffix);
	if(clipPinky2.m_arFrame.size() > 0)
	{
		CIKClip clipIKPinky2 = CIKClip::NewFromRawClip(clipPinky2, eThumbPinky);
		clipIKAll.MergeWith(clipIKPinky2);
	}
	clipIKAll.CheckIKSampleQuality(1, 0.2);

}
void CFastCal::check_ik_quality(bool bLeft, bool bFull)
{	
	std::string strBaseRaw;
	std::string strSubPath;	
	std::string strSuffix;
	CHandSkeletonKin* pHand = NULL;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strSuffix = "_l.raw";
		pHand = m_pHandLeft;
	}
	else
	{
		strBaseRaw = m_strBasePath + "raw/right/";
		strSuffix = "_r.raw";
		pHand = m_pHandRight;
	}
	if(bFull) strSubPath = strBaseRaw + "sp/3abd_full/";
	else strSubPath = strBaseRaw + "sp/3abd_fitc/";

	CRawClip clipIndex, clipMid, clipRing, clipPinky;
	clipIndex.LoadFromFile(strSubPath + "index" + strSuffix);
	clipMid.LoadFromFile(strSubPath + "mid" + strSuffix);
	clipRing.LoadFromFile(strSubPath + "ring" + strSuffix);
	clipPinky.LoadFromFile(strSubPath + "pinky" + strSuffix);

	CIKClip clipIKIndex = CIKClip::NewFromRawClip(clipIndex, eThumbIndex);
	CIKClip clipIKMid = CIKClip::NewFromRawClip(clipMid, eThumbMid);
	CIKClip clipIKRing = CIKClip::NewFromRawClip(clipRing, eThumbRing);
	CIKClip clipIKPinky = CIKClip::NewFromRawClip(clipPinky, eThumbPinky);

	CIKClip clipIKAll;
	clipIKAll.MergeWith(clipIKIndex);
	clipIKAll.MergeWith(clipIKMid);
	clipIKAll.MergeWith(clipIKRing);
	clipIKAll.MergeWith(clipIKPinky);

	//check extra IK
	CRawClip clipIndex2, clipMid2, clipRing2, clipPinky2;
	clipIndex2.LoadFromFile(strSubPath + "index2" + strSuffix);
	if(clipIndex2.m_arFrame.size() > 0)
	{
		CIKClip clipIKIndex2 = CIKClip::NewFromRawClip(clipIndex2, eThumbIndex);
		clipIKAll.MergeWith(clipIKIndex2);
	}

	clipMid2.LoadFromFile(strSubPath + "mid2" + strSuffix);
	if(clipMid2.m_arFrame.size() > 0)
	{
		CIKClip clipIKMid2 = CIKClip::NewFromRawClip(clipMid2, eThumbMid);
		clipIKAll.MergeWith(clipIKMid2);
	}

	clipRing2.LoadFromFile(strSubPath + "ring2" + strSuffix);
	if(clipRing2.m_arFrame.size() > 0)
	{
		CIKClip clipIKRing2 = CIKClip::NewFromRawClip(clipRing2, eThumbRing);
		clipIKAll.MergeWith(clipIKRing2);
	}

	clipPinky2.LoadFromFile(strSubPath + "pinky2" + strSuffix);
	if(clipPinky2.m_arFrame.size() > 0)
	{
		CIKClip clipIKPinky2 = CIKClip::NewFromRawClip(clipPinky2, eThumbPinky);
		clipIKAll.MergeWith(clipIKPinky2);
	}
	clipIKAll.CheckIKSampleQuality(1, 0.2);
}

void CFastCal::extract_thumb_tr(bool bLeft, bool bFull)
{
	std::string strSuffix;
	std::string strBaseRaw;
	std::string strBaseTr;
	CHandSkeletonKin* pHand = NULL;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strBaseTr = m_strBasePath + "trainingset/left/";
		strSuffix = "_l.raw";
		pHand = m_pHandLeft;
	}
	else
	{		
		strBaseRaw = m_strBasePath + "raw/right/";
		strBaseTr = m_strBasePath + "trainingset/right/";
		strSuffix = "_r.raw";
		pHand = m_pHandLeft;
	}

	std::string strFKSubPath;
	std::string strIKSubPath;
	std::string strFull;
	if(bFull)
	{
		strFull = "_full";
		strFKSubPath = strBaseRaw + "sp/3abd_full/";
		strIKSubPath = strBaseRaw + "groundTruth/ik_full/";
	}
	else
	{
		strFull = "_fitc";
		strFKSubPath = strBaseRaw + "sp/3abd_fitc/";
		strIKSubPath = strBaseRaw + "groundTruth/ik_fitc/";
	}

	//SAMPLED DATA=====================================================================================
	CRawClip clipFlat, clipSpread, clipFist, clipOverbend, clipThumbUp, clipThumbOut, clipPistol, clipRest1, clipRest2, clipSpreadOut,/*FK Key*/
		clipIK;/*IK Key*/;

	//fk sampled clip
	clipFlat.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/flat" + strSuffix);
	clipSpread.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/spread" + strSuffix);
	clipFist.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/fist" + strSuffix);
	clipOverbend.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/overbend" + strSuffix);
	clipThumbUp.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/thumbUp" + strSuffix);
	clipThumbOut.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/thumbOut" + strSuffix);
	clipRest1.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/rest" + strSuffix);
	clipRest2.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/rest2" + strSuffix);
	clipPistol.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/pistol" + strSuffix);	
	clipSpreadOut.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/spreadOut" + strSuffix);
	
	//ik sampled clip
	clipIK.LoadFromFile(strFKSubPath + "dbSensor.raw");
	
	//GROUND TRUTH=====================================================================================
	CRawClip clipFlat_gt, clipSpread_gt, clipFist_gt, clipOverbend_gt, clipThumbUp_gt, clipThumbOut_gt, clipPistol_gt, clipRest1_gt, clipRest2_gt, clipSpreadOut_gt, /*FK Key*/
		clipIK_gt;

	//fk
	clipFlat_gt.LoadFromFile(strBaseRaw + "groundTruth/flat.raw");
	clipSpread_gt.LoadFromFile(strBaseRaw + "groundTruth/spread.raw");
	clipFist_gt.LoadFromFile(strBaseRaw + "groundTruth/fist.raw");
	clipOverbend_gt.LoadFromFile(strBaseRaw + "groundTruth/overbend.raw");
	clipThumbUp_gt.LoadFromFile(strBaseRaw + "groundTruth/thumbUp.raw");
	clipThumbOut_gt.LoadFromFile(strBaseRaw + "groundTruth/thumbOut.raw");
	clipRest1_gt.LoadFromFile(strBaseRaw + "groundTruth/rest1.raw");
	clipRest2_gt.LoadFromFile(strBaseRaw + "groundTruth/rest2.raw");
	clipPistol_gt.LoadFromFile(strBaseRaw + "groundTruth/pistol.raw");
	clipSpreadOut_gt.LoadFromFile(strBaseRaw + "groundTruth/spreadOut.raw");

	//ik
	clipIK_gt.LoadFromFile(strIKSubPath + "dbSln.raw");

	//sparse operation ===================================================================================
	if(bFull)
	{
		CRawClip::EliminateThumbRedundancyHD(clipRest1, clipRest1_gt, 5);
		CRawClip::EliminateThumbRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 5);
		CRawClip::EliminateThumbRedundancyHD(clipIK, clipIK_gt, 1);//DO NOT sparse this
	}
	else//fitc
	{
		CRawClip::EliminateThumbRedundancyHD(clipFlat, clipFlat_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipSpread, clipSpread_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipFist, clipFist_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipOverbend, clipOverbend_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipThumbUp, clipThumbUp_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipThumbOut, clipThumbOut_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipPistol, clipPistol_gt, 3);

		CRawClip::EliminateThumbRedundancyHD(clipRest1, clipRest1_gt, 20);
		CRawClip::EliminateThumbRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 5);
		
		//CRawClip::EliminateThumbRedundancyHD(clipIK, clipIK_gt, 5);//DO NOT sparse this
	}


	//pair <sample, truth>=================================================================================
	std::vector<CRawClip> arSampledData;
	std::vector<CRawClip> arGroundTruth;

	arSampledData.push_back(clipFlat); arGroundTruth.push_back(clipFlat_gt); // pose: flat	
	arSampledData.push_back(clipSpread); arGroundTruth.push_back(clipSpread_gt); //pose: spread
	arSampledData.push_back(clipFist); arGroundTruth.push_back(clipFist_gt); //pose: fist
	arSampledData.push_back(clipOverbend); arGroundTruth.push_back(clipOverbend_gt); //pose: overbend
	arSampledData.push_back(clipThumbUp); arGroundTruth.push_back(clipThumbUp_gt); // pose: thumbUp
	arSampledData.push_back(clipThumbOut); arGroundTruth.push_back(clipThumbOut_gt); //pose: thumbOut
	//arSampledData.push_back(clipRest1); arGroundTruth.push_back(clipRest1_gt); //rest motion
	arSampledData.push_back(clipRest2); arGroundTruth.push_back(clipRest2_gt); //rest motion
	arSampledData.push_back(clipPistol); arGroundTruth.push_back(clipPistol_gt);//pose: pistol
	if(bFull)
	{
		arSampledData.push_back(clipSpreadOut); arGroundTruth.push_back(clipSpreadOut_gt);//spreadOut motion
	}

	arSampledData.push_back(clipIK); arGroundTruth.push_back(clipIK_gt);

	//produce output =================================================================
	CRawClip clipOutput0, clipOutput1, clipOutput2, clipOutput3, clipOutput4;
	for(int i = 0; i < arSampledData.size(); ++i)
	{
		CRawClip clipSample = arSampledData[i];
		CRawClip clipTruth = arGroundTruth[i];
		for(int j = 0; j < clipSample.m_arFrame.size(); ++j)
		{
			CRawFrame frmSample = clipSample.m_arFrame[j];
			CRawFrame frmTruth;
			if(clipSample.m_arFrame.size() == clipTruth.m_arFrame.size())
				frmTruth = clipTruth.m_arFrame[j];
			else if(clipTruth.m_arFrame.size() < clipSample.m_arFrame.size())
				frmTruth = clipTruth.m_arFrame[0];//POSE

			std::vector<float> arInput;
			arInput.push_back(frmSample.m_arData[0]);
			arInput.push_back(frmSample.m_arData[1]);
			arInput.push_back(frmSample.m_arData[2]);
			arInput.push_back(frmSample.m_arData[3]);
			arInput.push_back(frmSample.m_arData[4]);
			arInput.push_back(frmSample.m_arData[8]);
			arInput.push_back(frmSample.m_arData[14]);
			arInput.push_back(frmSample.m_arData[20]);
			arInput.push_back(frmSample.m_arData[26]);

			//thumb TMC
			CRawFrame frmOutput0(arInput);
			frmOutput0.m_arData.push_back(frmTruth.m_arData[0]);
			clipOutput0.m_arFrame.push_back(frmOutput0);

			//thumb ABD
			CRawFrame frmOutput1(arInput);
			frmOutput1.m_arData.push_back(frmTruth.m_arData[1]);
			clipOutput1.m_arFrame.push_back(frmOutput1);

			//thumb VIR
			CRawFrame frmOutput2(arInput);
			frmOutput2.m_arData.push_back(frmTruth.m_arData[2]);
			clipOutput2.m_arFrame.push_back(frmOutput2);

			//thumb MCP
			CRawFrame frmOutput3(arInput);
			frmOutput3.m_arData.push_back(frmTruth.m_arData[3]);
			clipOutput3.m_arFrame.push_back(frmOutput3);

			//thumb IP
			CRawFrame frmOutput4(arInput);
			frmOutput4.m_arData.push_back(frmTruth.m_arData[4]);
			clipOutput4.m_arFrame.push_back(frmOutput4);
		}
	}
	
	//SpreadOut
	if(!bFull)
	{
		clipOutput0.MergeWith(CRawClip::ExtractThumbNoRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 0, 10));
		clipOutput1.MergeWith(CRawClip::ExtractThumbNoRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 1, 5));
		clipOutput2.MergeWith(CRawClip::ExtractThumbNoRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 2, 12));
		clipOutput3.MergeWith(CRawClip::ExtractThumbNoRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 3, 30));
		clipOutput4.MergeWith(CRawClip::ExtractThumbNoRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 4, 30));
	}

	//write output ==============================================================
#ifdef ALERT_ON	
	clipOutput0.CheckInputVariance();	
	clipOutput1.CheckInputVariance();	
	clipOutput2.CheckInputVariance();	
	clipOutput3.CheckInputVariance();	
	clipOutput4.CheckInputVariance();
#endif 

	clipOutput0.EliminateInputRedundancy(1);
	clipOutput1.EliminateInputRedundancy(1); 
	clipOutput2.EliminateInputRedundancy(1); 
	clipOutput3.EliminateInputRedundancy(1); 
	clipOutput4.EliminateInputRedundancy(1); 

	/*clipOutput0.EliminateOutputRedundancy(5);
	clipOutput1.EliminateOutputRedundancy(5); 
	clipOutput2.EliminateOutputRedundancy(5); 
	clipOutput3.EliminateOutputRedundancy(5); 
	clipOutput4.EliminateOutputRedundancy(5); */

	if(bFull)
	{		
		clipOutput0.SaveToFile(strBaseTr + "0_HAND_SKEL_DOF_THUMB_ROLL/tr.tr");		
		clipOutput1.SaveToFile(strBaseTr + "1_HAND_SKEL_DOF_THUMB_ABD/tr.tr");		
		clipOutput2.SaveToFile(strBaseTr + "2_HAND_SKEL_DOF_THUMB_VIRTUAL/tr.tr");		
		clipOutput3.SaveToFile(strBaseTr + "3_HAND_SKEL_DOF_THUMB_FLEX_PROX/tr.tr");		
		clipOutput4.SaveToFile(strBaseTr + "4_HAND_SKEL_DOF_THUMB_FLEX_DIST/tr.tr");
	}
	else
	{
		clipOutput0.SaveToFile(strBaseTr + "0_HAND_SKEL_DOF_THUMB_ROLL/active_tr.tr");		
		clipOutput1.SaveToFile(strBaseTr + "1_HAND_SKEL_DOF_THUMB_ABD/active_tr.tr");		
		clipOutput2.SaveToFile(strBaseTr + "2_HAND_SKEL_DOF_THUMB_VIRTUAL/active_tr.tr");		
		clipOutput3.SaveToFile(strBaseTr + "3_HAND_SKEL_DOF_THUMB_FLEX_PROX/active_tr.tr");		
		clipOutput4.SaveToFile(strBaseTr + "4_HAND_SKEL_DOF_THUMB_FLEX_DIST/active_tr.tr");
	}
}

void CFastCal::extract_thumb_tr2(bool bLeft, bool bFull)
{
	std::string strSuffix;
	std::string strBaseRaw;
	std::string strBaseTr;
	CHandSkeletonKin* pHand = NULL;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strBaseTr = m_strBasePath + "trainingset/left/";
		strSuffix = "_l.raw";
		pHand = m_pHandLeft;
	}
	else
	{		
		strBaseRaw = m_strBasePath + "raw/right/";
		strBaseTr = m_strBasePath + "trainingset/right/";
		strSuffix = "_r.raw";
		pHand = m_pHandLeft;
	}

	std::string strFKSubPath;
	std::string strIKSubPath;
	std::string strFull;
	if(bFull)
	{
		strFull = "_full";
		strFKSubPath = strBaseRaw + "sp/3abd_full/";
		strIKSubPath = strBaseRaw + "groundTruth/ik_full/";
	}
	else
	{
		strFull = "_fitc";
		strFKSubPath = strBaseRaw + "sp/3abd_fitc/";
		strIKSubPath = strBaseRaw + "groundTruth/ik_fitc/";
	}

	//SAMPLED DATA=====================================================================================
	CRawClip clipFlat, clipSpread, clipFist, clipOverbend, clipThumbUp, clipThumbOut, clipPistol, clipRest1, clipSpreadOut,/*FK Key*/
		clipIKIndex, clipIKMid, clipIKRing, clipIKPinky, clipIKIndex2, clipIKMid2, clipIKRing2, clipIKPinky2/*IK Key*/;

	//fk sampled clip
	clipFlat.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/flat" + strSuffix);
	if(bLeft)//fix some thumb abd problem
	{
		float fMinAbd = 100; 
		int iMinAbdIdx = -1;
		for(int i = 0; i < clipFlat.m_arFrame.size(); ++i)
		{
			if(clipFlat.m_arFrame[i].m_arData[1] < fMinAbd)
			{
				fMinAbd = clipFlat.m_arFrame[i].m_arData[1];
				iMinAbdIdx = i;
			}
		}
		clipFlat.m_arFrame.push_back(clipFlat.m_arFrame[iMinAbdIdx]);
		clipFlat.m_arFrame[clipFlat.m_arFrame.size()-1].m_arData[1] = fMinAbd -10;
	}

	clipSpread.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/spread" + strSuffix);
	clipFist.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/fist" + strSuffix);
	clipOverbend.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/overbend" + strSuffix);
	clipThumbUp.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/thumbUp" + strSuffix);
	clipThumbOut.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/thumbOut" + strSuffix);
	clipRest1.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/rest" + strSuffix);
	clipPistol.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/pistol" + strSuffix);	
	clipSpreadOut.LoadFromFile(strBaseRaw + "sp/2flex" + strFull + "/spreadOut" + strSuffix);
	
	//ik sampled clip	
	clipIKIndex.LoadFromFile(strFKSubPath + "index" + strSuffix);
	clipIKMid.LoadFromFile(strFKSubPath + "mid" + strSuffix);
	clipIKRing.LoadFromFile(strFKSubPath + "ring" + strSuffix);
	clipIKPinky.LoadFromFile(strFKSubPath + "pinky" + strSuffix);

	//ik2 extra
	clipIKIndex2.LoadFromFile(strFKSubPath + "index2" + strSuffix);
	clipIKMid2.LoadFromFile(strFKSubPath + "mid2" + strSuffix);
	clipIKRing2.LoadFromFile(strFKSubPath + "ring2" + strSuffix);
	clipIKPinky2.LoadFromFile(strFKSubPath + "pinky2" + strSuffix);
	
	//GROUND TRUTH=====================================================================================
	CRawClip clipFlat_gt, clipSpread_gt, clipFist_gt, clipOverbend_gt, clipThumbUp_gt, clipThumbOut_gt, clipPistol_gt, clipRest1_gt, clipSpreadOut_gt, /*FK Key*/
		clipIKIndex_gt, clipIKMid_gt, clipIKRing_gt, clipIKPinky_gt, clipIKIndex2_gt, clipIKMid2_gt, clipIKRing2_gt, clipIKPinky2_gt/*IK Key*/;
	
	//fk
	clipFlat_gt.LoadFromFile(strBaseRaw + "groundTruth/flat.raw");
	clipSpread_gt.LoadFromFile(strBaseRaw + "groundTruth/spread.raw");
	clipFist_gt.LoadFromFile(strBaseRaw + "groundTruth/fist.raw");
	clipOverbend_gt.LoadFromFile(strBaseRaw + "groundTruth/overbend.raw");
	clipThumbUp_gt.LoadFromFile(strBaseRaw + "groundTruth/thumbUp.raw");
	clipThumbOut_gt.LoadFromFile(strBaseRaw + "groundTruth/thumbOut.raw");
	clipRest1_gt.LoadFromFile(strBaseRaw + "groundTruth/rest1.raw");
	clipPistol_gt.LoadFromFile(strBaseRaw + "groundTruth/pistol.raw");
	clipSpreadOut_gt.LoadFromFile(strBaseRaw + "groundTruth/spreadOut.raw");

	//ik
	clipIKIndex_gt.LoadFromFile(strIKSubPath + "index.raw");
	clipIKMid_gt.LoadFromFile(strIKSubPath + "mid.raw");
	clipIKRing_gt.LoadFromFile(strIKSubPath + "ring.raw");
	clipIKPinky_gt.LoadFromFile(strIKSubPath + "pinky.raw");

	//ik2 if exists
	clipIKIndex2_gt.LoadFromFile(strIKSubPath + "index2.raw");
	clipIKMid2_gt.LoadFromFile(strIKSubPath + "mid2.raw");
	clipIKRing2_gt.LoadFromFile(strIKSubPath + "ring2.raw");
	clipIKPinky2_gt.LoadFromFile(strIKSubPath + "pinky2.raw");

	//sparse operation ===================================================================================
	if(bFull)
	{
		CRawClip::EliminateThumbRedundancyHD(clipRest1, clipRest1_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 5);
		CRawClip::EliminateThumbRedundancyHD(clipIKIndex2, clipIKIndex2_gt, 5);
		CRawClip::EliminateThumbRedundancyHD(clipIKMid2, clipIKMid2_gt, 5);
		CRawClip::EliminateThumbRedundancyHD(clipIKRing2, clipIKRing2_gt, 5);
		CRawClip::EliminateThumbRedundancyHD(clipIKPinky2, clipIKPinky2_gt, 5);
	}
	else//fitc
	{
		CRawClip::EliminateThumbRedundancyHD(clipFlat, clipFlat_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipSpread, clipSpread_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipFist, clipFist_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipOverbend, clipOverbend_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipThumbUp, clipThumbUp_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipThumbOut, clipThumbOut_gt, 3);
		CRawClip::EliminateThumbRedundancyHD(clipPistol, clipPistol_gt, 3);

		CRawClip::EliminateThumbRedundancyHD(clipRest1, clipRest1_gt, 20);
		CRawClip::EliminateThumbRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 5);

		CRawClip::EliminateThumbRedundancyHD(clipIKIndex, clipIKIndex_gt, 8);
		CRawClip::EliminateThumbRedundancyHD(clipIKMid, clipIKMid_gt, 8);
		CRawClip::EliminateThumbRedundancyHD(clipIKRing, clipIKRing_gt, 8);
		CRawClip::EliminateThumbRedundancyHD(clipIKPinky, clipIKPinky_gt, 8);

		CRawClip::EliminateThumbRedundancyHD(clipIKIndex2, clipIKIndex2_gt, 30);
		CRawClip::EliminateThumbRedundancyHD(clipIKMid2, clipIKMid2_gt, 30);
		CRawClip::EliminateThumbRedundancyHD(clipIKRing2, clipIKRing2_gt, 30);
		CRawClip::EliminateThumbRedundancyHD(clipIKPinky2, clipIKPinky2_gt, 30);
	}


	//pair <sample, truth>=================================================================================
	std::vector<CRawClip> arSampledData;
	std::vector<CRawClip> arGroundTruth;

	arSampledData.push_back(clipFlat); arGroundTruth.push_back(clipFlat_gt); // pose: flat	
	arSampledData.push_back(clipSpread); arGroundTruth.push_back(clipSpread_gt); //pose: spread
	arSampledData.push_back(clipFist); arGroundTruth.push_back(clipFist_gt); //pose: fist
	arSampledData.push_back(clipOverbend); arGroundTruth.push_back(clipOverbend_gt); //pose: overbend
	arSampledData.push_back(clipThumbUp); arGroundTruth.push_back(clipThumbUp_gt); // pose: thumbUp
	arSampledData.push_back(clipThumbOut); arGroundTruth.push_back(clipThumbOut_gt); //pose: thumbOut
	arSampledData.push_back(clipRest1); arGroundTruth.push_back(clipRest1_gt); //rest motion
	arSampledData.push_back(clipPistol); arGroundTruth.push_back(clipPistol_gt);//pose: pistol
	if(bFull)
	{
		arSampledData.push_back(clipSpreadOut); arGroundTruth.push_back(clipSpreadOut_gt);//spreadOut motion
	}
	
	arSampledData.push_back(clipIKIndex); arGroundTruth.push_back(clipIKIndex_gt); //pose: thumb-index touching
	arSampledData.push_back(clipIKMid); arGroundTruth.push_back(clipIKMid_gt); //pose: thumb-mid touching
	arSampledData.push_back(clipIKRing); arGroundTruth.push_back(clipIKRing_gt); //pose: thumb-ring touching
	arSampledData.push_back(clipIKPinky); arGroundTruth.push_back(clipIKPinky_gt); //pose: thumb-pinky touching

	if(clipIKIndex2.m_arFrame.size() > 0 && clipIKIndex2_gt.m_arFrame.size() > 0)
		arSampledData.push_back(clipIKIndex2); arGroundTruth.push_back(clipIKIndex2_gt); //pose: thumb-index touching
	if(clipIKMid2.m_arFrame.size() > 0 && clipIKMid2_gt.m_arFrame.size() > 0)
		arSampledData.push_back(clipIKMid2); arGroundTruth.push_back(clipIKMid2_gt); //pose: thumb-mid touching
	if(clipIKRing2.m_arFrame.size() > 0 && clipIKRing2_gt.m_arFrame.size() > 0)
		arSampledData.push_back(clipIKRing2); arGroundTruth.push_back(clipIKRing2_gt); //pose: thumb-ring touching
	if(clipIKPinky2.m_arFrame.size() > 0 && clipIKPinky2.m_arFrame.size() > 0)
		arSampledData.push_back(clipIKPinky2); arGroundTruth.push_back(clipIKPinky2_gt); //pose: thumb-pinky touching

	//produce output =================================================================
	CRawClip clipOutput0, clipOutput1, clipOutput2, clipOutput3, clipOutput4;
	for(int i = 0; i < arSampledData.size(); ++i)
	{
		CRawClip clipSample = arSampledData[i];
		CRawClip clipTruth = arGroundTruth[i];
		for(int j = 0; j < clipSample.m_arFrame.size(); ++j)
		{
			CRawFrame frmSample = clipSample.m_arFrame[j];
			CRawFrame frmTruth;
			if(clipSample.m_arFrame.size() == clipTruth.m_arFrame.size())
				frmTruth = clipTruth.m_arFrame[j];
			else if(clipTruth.m_arFrame.size() < clipSample.m_arFrame.size())
				frmTruth = clipTruth.m_arFrame[0];//POSE

			std::vector<float> arInput;
			arInput.push_back(frmSample.m_arData[0]);
			arInput.push_back(frmSample.m_arData[1]);
			arInput.push_back(frmSample.m_arData[2]);
			arInput.push_back(frmSample.m_arData[3]);
			arInput.push_back(frmSample.m_arData[4]);
			arInput.push_back(frmSample.m_arData[8]);
			arInput.push_back(frmSample.m_arData[14]);
			arInput.push_back(frmSample.m_arData[20]);
			arInput.push_back(frmSample.m_arData[26]);

			//thumb TMC
			CRawFrame frmOutput0(arInput);
			frmOutput0.m_arData.push_back(frmTruth.m_arData[0]);
			clipOutput0.m_arFrame.push_back(frmOutput0);

			//thumb ABD
			CRawFrame frmOutput1(arInput);
			frmOutput1.m_arData.push_back(frmTruth.m_arData[1]);
			clipOutput1.m_arFrame.push_back(frmOutput1);

			//thumb VIR
			CRawFrame frmOutput2(arInput);
			frmOutput2.m_arData.push_back(frmTruth.m_arData[2]);
			clipOutput2.m_arFrame.push_back(frmOutput2);

			//thumb MCP
			CRawFrame frmOutput3(arInput);
			frmOutput3.m_arData.push_back(frmTruth.m_arData[3]);
			clipOutput3.m_arFrame.push_back(frmOutput3);

			//thumb IP
			CRawFrame frmOutput4(arInput);
			frmOutput4.m_arData.push_back(frmTruth.m_arData[4]);
			clipOutput4.m_arFrame.push_back(frmOutput4);
		}
	}
	
	//SpreadOut
	if(!bFull)
	{
		clipOutput0.MergeWith(CRawClip::ExtractThumbNoRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 0, 10));
		clipOutput1.MergeWith(CRawClip::ExtractThumbNoRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 1, 5));
		clipOutput2.MergeWith(CRawClip::ExtractThumbNoRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 2, 12));
		clipOutput3.MergeWith(CRawClip::ExtractThumbNoRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 3, 30));
		clipOutput4.MergeWith(CRawClip::ExtractThumbNoRedundancyHD(clipSpreadOut, clipSpreadOut_gt, 4, 30));
	}

	//write output ==============================================================
#ifdef ALERT_ON	
	clipOutput0.CheckInputVariance();	
	clipOutput1.CheckInputVariance();	
	clipOutput2.CheckInputVariance();	
	clipOutput3.CheckInputVariance();	
	clipOutput4.CheckInputVariance();
#endif 

	clipOutput0.EliminateInputRedundancy(1);
	clipOutput1.EliminateInputRedundancy(1); 
	clipOutput2.EliminateInputRedundancy(1); 
	clipOutput3.EliminateInputRedundancy(1); 
	clipOutput4.EliminateInputRedundancy(1); 

	if(bFull)
	{		
		clipOutput0.SaveToFile(strBaseTr + "0_HAND_SKEL_DOF_THUMB_ROLL/tr.tr");		
		clipOutput1.SaveToFile(strBaseTr + "1_HAND_SKEL_DOF_THUMB_ABD/tr.tr");		
		clipOutput2.SaveToFile(strBaseTr + "2_HAND_SKEL_DOF_THUMB_VIRTUAL/tr.tr");		
		clipOutput3.SaveToFile(strBaseTr + "3_HAND_SKEL_DOF_THUMB_FLEX_PROX/tr.tr");		
		clipOutput4.SaveToFile(strBaseTr + "4_HAND_SKEL_DOF_THUMB_FLEX_DIST/tr.tr");
	}
	else
	{
		clipOutput0.SaveToFile(strBaseTr + "0_HAND_SKEL_DOF_THUMB_ROLL/active_tr.tr");		
		clipOutput1.SaveToFile(strBaseTr + "1_HAND_SKEL_DOF_THUMB_ABD/active_tr.tr");		
		clipOutput2.SaveToFile(strBaseTr + "2_HAND_SKEL_DOF_THUMB_VIRTUAL/active_tr.tr");		
		clipOutput3.SaveToFile(strBaseTr + "3_HAND_SKEL_DOF_THUMB_FLEX_PROX/active_tr.tr");		
		clipOutput4.SaveToFile(strBaseTr + "4_HAND_SKEL_DOF_THUMB_FLEX_DIST/active_tr.tr");
	}

}
void CFastCal::train_thumb(bool bLeft, bool bFull)
{
	std::string strBaseTr = m_strBasePath + "trainingset/";
	std::string strHand = "r";
	if(bLeft)
		strHand = "l";

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[300];
	engOutputBuffer(pMatlabEngine, outputBuffer, 300);

	char strCmd[800];
	if(bFull)
		sprintf(strCmd, "HD=%d;generate_fullset_thumb_%s; train_thumb_full_%s;", m_iHD, strHand.c_str(), strHand.c_str());
	else
		sprintf(strCmd, "HD=%d;generate_activeset_thumb_%s; train_thumb_fitc_%s;", m_iHD, strHand.c_str(), strHand.c_str());
	engEvalString(pMatlabEngine,strCmd);
}
void CFastCal::generate_thumb_4ik(bool bLeft, bool bFull)
{
	std::string strBaseRaw;
	std::string strSuffix;
	CHandSkeletonKin* pHand = NULL;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strSuffix = "_l.raw";
		pHand = m_pHandLeft;
	}
	else
	{
		strBaseRaw = m_strBasePath + "raw/right/";
		strSuffix = "_r.raw";
		pHand = m_pHandRight;
	}
	std::string strFull;
	std::string strSrc, strResult;
	if(bFull)
	{
		strFull = "_full";
		strSrc = strBaseRaw + "sp/3abd_full/*.*";
		strResult = strBaseRaw + "sp/4ik_full/";
	}
	else
	{
		strFull = "_fitc";
		strSrc = strBaseRaw + "sp/3abd_fitc/*.*";
		strResult = strBaseRaw + "sp/4ik_fitc/";
	}
	CreateDirectory(CString(strResult.c_str()), NULL);

	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(CString(strSrc.c_str()));
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		std::string strTitle = GloveUtil::ToChar(finder.GetFileTitle());
		if(finder.IsDirectory())
			continue;
		CRawClip clipRaw;
		clipRaw.LoadFromFile(GloveUtil::ToChar(finder.GetFilePath()));
		if(bFull)
			clipRaw = MatlabUtil::GPRCalibrate_Thumb_full(clipRaw, bLeft);
		else
			clipRaw = MatlabUtil::GPRCalibrate_Thumb_fitc(clipRaw, bLeft);
		//calibrate flex
		clipRaw.SaveToFile(strResult + strTitle + ".raw");
	};

}

//something else, should not follow thumb============================
void CFastCal::batch_calibrate(bool bLeft)
{
	std::string strBaseRaw;
	std::string strBaseResult;
	CreateDirectory(CString(m_strBasePath.c_str()) + L"fast_calibrated/", NULL);
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strBaseResult = m_strBasePath + "fast_calibrated/left/";
	}
	else
	{
		strBaseRaw = m_strBasePath + "raw/right/";
		strBaseResult = m_strBasePath + "fast_calibrated/right/";
	}
	batch_calibrate_under(CString(strBaseRaw.c_str()), CString(strBaseResult.c_str()), bLeft);
}
void CFastCal::batch_calibrate_under(CString strRawPath, CString strResultPath, bool bLeft)
{
	CreateDirectory(strResultPath, NULL);

	CString strRawPath_tofind = strRawPath + L"/*.*";
	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(strRawPath_tofind);
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		CString strTitle = finder.GetFileTitle();
		if(finder.IsDirectory())
		{
			if(strTitle == L"." || strTitle == L".." || strTitle.IsEmpty())
				continue;
			batch_calibrate_under(strRawPath + L"/" + strTitle, strResultPath + L"/" + strTitle, bLeft);
		}
		else
		{
			CString strFileName = finder.GetFileName();
			if(strFileName.Find(L".raw") == -1)
				continue;
			CRawClip clipRaw;
			clipRaw.LoadFromFile(GloveUtil::ToChar(finder.GetFilePath()));
			CRawClip clipResult;
			Calibrate(clipRaw, clipResult, bLeft);
			CString strResultName = strTitle + L"_fast.raw";
			clipResult.SaveToFile(GloveUtil::ToChar(strResultPath+L"/"+strResultName));
		}
	}
}
//4. wrist ================================================
void CFastCal::extract_wrist_tr(bool bLeft, bool bFull)
{
	std::string strBase;
	std::string strSuffix;
	std::string strBaseTr;
	if(bLeft)
	{
		strBase = m_strBasePath + "raw/left/sp";
		strBaseTr = m_strBasePath + "trainingset/left";
		strSuffix = "_l.raw";
	}
	else
	{		
		strBase = m_strBasePath + "raw/right/sp";
		strBaseTr = m_strBasePath + "trainingset/right";
		strSuffix = "_r.raw";
	}

	//SAMPLED DATA=====================================================================================
	CRawClip clipWristFlex, clipWristAbd;
	clipWristFlex.LoadFromFile(strBase + "cc/wristFlex" + strSuffix);
	clipWristAbd.LoadFromFile(strBase + "cc/wristAbd" + strSuffix);
	
	//GROUND TRUTH=====================================================================================
	CRawClip clipWristFlex_gt, clipWristAbd_gt;
	clipWristFlex_gt.LoadFromFile(strBase + "cc/wristFlex_gt" + strSuffix);
	clipWristAbd_gt.LoadFromFile(strBase + "cc/wristAbd_gt" + strSuffix);
	
	//produce output =================================================================
	CRawClip clipOutput29/*wrist flex*/, clipOutput30/*wrist abd*/;
	for(int j = 0; j < clipWristFlex.m_arFrame.size(); ++j)
	{
		CRawFrame frmSample = clipWristFlex.m_arFrame[j];
		CRawFrame frmTruth;
		if(clipWristFlex.m_arFrame.size() == clipWristFlex_gt.m_arFrame.size())
			frmTruth = clipWristFlex_gt.m_arFrame[j];
		else if(clipWristFlex_gt.m_arFrame.size() < clipWristFlex.m_arFrame.size())
			frmTruth = clipWristFlex_gt.m_arFrame[0];//POSE

		CRawFrame frmOutput29;
		frmOutput29.m_arData.push_back(frmSample.m_arData[29]);
		frmOutput29.m_arData.push_back(frmSample.m_arData[30]);
		frmOutput29.m_arData.push_back(frmTruth.m_arData[29]);
		clipOutput29.m_arFrame.push_back(frmOutput29);

		CRawFrame frmOutput30;
		frmOutput30.m_arData.push_back(frmSample.m_arData[29]);
		frmOutput30.m_arData.push_back(frmSample.m_arData[30]);
		frmOutput30.m_arData.push_back(0);
		clipOutput30.m_arFrame.push_back(frmOutput30);
	}
	
	for(int j = 0; j < clipWristAbd.m_arFrame.size(); ++j)
	{
		CRawFrame frmSample = clipWristAbd.m_arFrame[j];
		CRawFrame frmTruth;
		if(clipWristAbd.m_arFrame.size() == clipWristAbd_gt.m_arFrame.size())
			frmTruth = clipWristAbd_gt.m_arFrame[j];
		else if(clipWristAbd_gt.m_arFrame.size() < clipWristAbd.m_arFrame.size())
			frmTruth = clipWristAbd_gt.m_arFrame[0];
	
		CRawFrame frmOutput29;
		frmOutput29.m_arData.push_back(frmSample.m_arData[29]);
		frmOutput29.m_arData.push_back(frmSample.m_arData[30]);
		frmOutput29.m_arData.push_back(0);
		clipOutput29.m_arFrame.push_back(frmOutput29);

		CRawFrame frmOutput30;
		frmOutput30.m_arData.push_back(frmSample.m_arData[29]);
		frmOutput30.m_arData.push_back(frmSample.m_arData[30]);
		frmOutput30.m_arData.push_back(frmTruth.m_arData[30]);
		clipOutput30.m_arFrame.push_back(frmOutput30);
	}
	
	//write output ==============================================================
	clipOutput29.SaveToFile(strBaseTr + "29_HAND_SKEL_DOF_WRIST_FLEX/tr.tr");
	clipOutput30.SaveToFile(strBaseTr + "30_HAND_SKEL_DOF_WRIST_ABD/tr.tr");
}

CRawClip CFastCal::xfast_calibrate(CRawClip clipInput, bool bLeft, std::string strFileName)
{
	CString strXFast(m_strBasePath.c_str());
	strXFast += L"raw/";
	if(bLeft)
		strXFast = strXFast + L"left/";
	else
		strXFast = strXFast + L"right/";
	strXFast = strXFast + L"sp/xfast/";	

	CRawClip clipResult = xfast_calibrate_finger_flex(clipInput, bLeft);
	CreateDirectory(strXFast +  L"after_finger_flex", NULL);
	clipResult.SaveToFile(GloveUtil::ToChar(strXFast + L"after_finger_flex/") + strFileName);
	
	clipResult = xfast_calibrate_finger_abd(clipResult, bLeft);
	CreateDirectory(strXFast +  L"after_finger_abd", NULL);
	clipResult.SaveToFile(GloveUtil::ToChar(strXFast + L"after_finger_abd/") + strFileName);
	
	clipResult = xfast_calibrate_thumb(clipResult, bLeft);	
	CreateDirectory(strXFast +  L"after_thumb", NULL);
	clipResult.SaveToFile(GloveUtil::ToChar(strXFast + L"after_thumb/") + strFileName);

	//clipResult.SuppressOverbendSigmoid(bLeft);
	//CreateDirectory(strXFast +  L"after_FK", NULL);
	//clipResult.SaveToFile(GloveUtil::ToChar(strXFast + L"after_FK/") + strFileName);

	//FK finished
	/*IK start
	clipResult = xfast_calibrate_ik(clipResult, strFileName, bLeft);
	CreateDirectory(strXFast +  L"after_IK", NULL);
	clipResult.SaveToFile(GloveUtil::ToChar(strXFast + L"after_IK/") + strFileName);*/

	return clipResult;
}
CRawClip CFastCal::xfast_calibrate_finger_flex(CRawClip clipInput, bool bLeft)
{
	std::string strBaseRaw;
	std::string strSuffix;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strSuffix = "_l.raw";
	}
	else
	{		
		strBaseRaw = m_strBasePath + "raw/right/";
		strSuffix = "_r.raw";
	}

	CRawClip clipFlat, clipFist, clipOverbend;
	clipFlat.LoadFromFile(strBaseRaw + "sp/1base/flat" + strSuffix);
	clipFist.LoadFromFile(strBaseRaw + "sp/1base/fist" + strSuffix);
	clipOverbend.LoadFromFile(strBaseRaw + "sp/1base/overbend" + strSuffix);

	//GROUND TRUTH=====================================================================================
	CRawClip clipFlat_gt, clipFist_gt, clipOverbend_gt;
	clipFlat_gt.LoadFromFile(strBaseRaw + "groundTruth/flat.raw");
	clipFist_gt.LoadFromFile(strBaseRaw + "groundTruth/fist.raw");
	clipOverbend_gt.LoadFromFile(strBaseRaw + "groundTruth/overbend.raw");

	CRawFrame frmFlat = clipFlat.GetAveragePose();
	CRawFrame frmFlat_gt = clipFlat_gt.GetAveragePose();
	CRawFrame frmFist = clipFist.GetAveragePose();
	CRawFrame frmFist_gt = clipFist_gt.GetAveragePose();
	CRawFrame frmOverbend = clipOverbend.GetAveragePose();
	CRawFrame frmOverbend_gt = clipOverbend_gt.GetAveragePose();

	CRawClip clipResult = clipInput.xfast_calibrate_finger_flex(frmFlat, frmFlat_gt, frmFist, frmFist_gt, frmOverbend, frmOverbend_gt, bLeft);
	return clipResult;
}
CRawClip CFastCal::xfast_calibrate_finger_abd(CRawClip clipInput, bool bLeft)
{
	std::string strBaseRaw;
	std::string strSuffix;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strSuffix = "_l.raw";
	}
	else
	{		
		strBaseRaw = m_strBasePath + "raw/right/";
		strSuffix = "_r.raw";
	}

	CRawClip clipFlat, clipSpread, clipIM0;
	clipFlat.LoadFromFile(strBaseRaw + "sp/1base/flat" + strSuffix);
	clipSpread.LoadFromFile(strBaseRaw + "sp/1base/spread" + strSuffix);
	clipIM0.LoadFromFile(strBaseRaw + "sp/1base/im0" + strSuffix);
	
	//GROUND TRUTH=====================================================================================
	CRawClip clipFlat_gt, clipSpread_gt;
	clipFlat_gt.LoadFromFile(strBaseRaw + "groundTruth/flat.raw");
	clipSpread_gt.LoadFromFile(strBaseRaw + "groundTruth/spread.raw");

	CRawFrame frmFlat = clipFlat.GetAveragePose();
	CRawFrame frmFlat_gt = clipFlat_gt.GetAveragePose();
	CRawFrame frmSpread = clipSpread.GetAveragePose();
	CRawFrame frmSpread_gt = clipSpread_gt.GetAveragePose();

	CRawClip clipResult = clipInput.xfast_calibrate_finger_abd(frmFlat, frmFlat_gt, frmSpread, frmSpread_gt, clipIM0, bLeft);
	return clipResult;
}
CRawClip CFastCal::xfast_calibrate_thumb(CRawClip clipInput, bool bLeft)
{
	std::string strBaseRaw;
	std::string strSuffix;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/";
		strSuffix = "_l.raw";
	}
	else
	{		
		strBaseRaw = m_strBasePath + "raw/right/";
		strSuffix = "_r.raw";
	}

	//SAMPLED DATA=====================================================================================
	CRawClip clipFlat, clipSpread, clipFist;
	clipFlat.LoadFromFile(strBaseRaw + "sp/1base/flat" + strSuffix);
	clipSpread.LoadFromFile(strBaseRaw + "sp/1base/spread" + strSuffix);
	clipFist.LoadFromFile(strBaseRaw + "sp/1base/fist" + strSuffix);	

	//GROUND TRUTH=====================================================================================
	CRawClip clipFlat_gt, clipSpread_gt, clipFist_gt;
	clipFlat_gt.LoadFromFile(strBaseRaw + "groundTruth/flat.raw");
	clipSpread_gt.LoadFromFile(strBaseRaw + "groundTruth/spread.raw");
	clipFist_gt.LoadFromFile(strBaseRaw + "groundTruth/fist.raw");

	CRawFrame frmFlat = clipFlat.GetAveragePose();
	CRawFrame frmFlat_gt = clipFlat_gt.GetAveragePose();
	CRawFrame frmFist = clipFist.GetAveragePose();
	CRawFrame frmFist_gt = clipFist_gt.GetAveragePose();
	CRawFrame frmSpread = clipSpread.GetAveragePose();
	CRawFrame frmSpread_gt = clipSpread_gt.GetAveragePose();

	CRawClip clipResult = clipInput.xfast_calibrate_thumb(frmFlat, frmFlat_gt, frmFist, frmFist_gt, frmSpread, frmSpread_gt, bLeft);
	return clipResult;
}

CRawClip CFastCal::xfast_calibrate_ik(CRawClip clipInput, std::string strThisName, bool bLeft)
{
	std::string strBaseRaw;
	std::string strSuffix;
	std::string strFileLog;
	if(bLeft)
	{
		strBaseRaw = m_strBasePath + "raw/left/sp/1base/";
		strFileLog = m_strBasePath + "raw/left/sp/xfast/" + strThisName + ".log";
		strSuffix = "_l.raw";
	}
	else
	{		
		strBaseRaw = m_strBasePath + "raw/right/sp/1base/";
		strFileLog = m_strBasePath + "raw/right/sp/xfast/" + strThisName + ".log";
		strSuffix = "_r.raw";
	}
	CRawClip clipThisOrig, clipIndexOrig, clipIndex2Orig;
	clipThisOrig.LoadFromFile(strBaseRaw + strThisName);
	clipIndexOrig.LoadFromFile(strBaseRaw + "index" + strSuffix);
	clipIndex2Orig.LoadFromFile(strBaseRaw + "index2" + strSuffix);

	CRawClip clipResult = clipInput.xfast_calibrate_ik(clipThisOrig, clipIndexOrig, clipIndex2Orig, strFileLog, bLeft);
	return clipResult;
}