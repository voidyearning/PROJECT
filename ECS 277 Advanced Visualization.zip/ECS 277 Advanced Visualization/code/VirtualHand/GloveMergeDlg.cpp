// GloveMergeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "GloveMergeDlg.h"
#include "GloveBvhRetargetDlg.h"
#include "GloveBvhInsertDlg.h"
#include "GloveUtil.h"

// CGloveMergeDlg dialog

IMPLEMENT_DYNAMIC(CGloveMergeDlg, CDialog)

CGloveMergeDlg::CGloveMergeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGloveMergeDlg::IDD, pParent)
{

}

CGloveMergeDlg::~CGloveMergeDlg()
{
}

void CGloveMergeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CGloveMergeDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_BSW_SRC_RIGHT, &CGloveMergeDlg::OnBnClickedButtonBswSrcRight)
	ON_BN_CLICKED(IDC_BUTTON_BWS_DEST, &CGloveMergeDlg::OnBnClickedButtonBwsDest)
	ON_BN_CLICKED(IDC_BUTTON_BSW_SRC_LEFT, &CGloveMergeDlg::OnBnClickedButtonBswSrcLeft)
	ON_BN_CLICKED(IDC_BUTTON_BWS_BVH_BASE, &CGloveMergeDlg::OnBnClickedButtonBwsBvhBase)
	ON_BN_CLICKED(IDC_BUTTON_MERGE, &CGloveMergeDlg::OnBnClickedButtonMerge)
	ON_BN_CLICKED(IDC_BUTTON_MAPPING, &CGloveMergeDlg::OnBnClickedButtonMapping)
	ON_BN_CLICKED(IDC_CHECK_INSERT, &CGloveMergeDlg::OnBnClickedCheckInsert)
	ON_BN_CLICKED(IDC_BUTTON_INSERT, &CGloveMergeDlg::OnBnClickedButtonInsert)
	ON_EN_CHANGE(IDC_EDIT_OFFSET_RIGHT, &CGloveMergeDlg::OnEnChangeEditOffsetRight)
	ON_BN_CLICKED(IDC_BUTTON_FAST_INTEGRATE, &CGloveMergeDlg::OnBnClickedButtonFastIntegrate)
END_MESSAGE_MAP()


BOOL CGloveMergeDlg::OnInitDialog()
{
	CString strPath = L"";
	TCHAR arDir[256] = L"\0";
	int iLenDir = ::GetCurrentDirectory(256, arDir);
	strPath = CString(arDir, iLenDir);
	
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_BVH_BASE);
	if(pEdit)		
		pEdit->SetWindowText(strPath);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SRC_LEFT);
	if(pEdit)		
		pEdit->SetWindowText(strPath);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SRC_RIGHT);
	if(pEdit)
		pEdit->SetWindowText(strPath);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_DEST);
	if(pEdit)
		pEdit->SetWindowText(strPath);

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_OFFSET_LEFT);
	if(pEdit)
		pEdit->SetWindowText(L"0");

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_OFFSET_RIGHT);
	if(pEdit)
		pEdit->SetWindowText(L"0");

	CButton* pCheck = (CButton*)GetDlgItem(IDC_CHECK_INSERT);
	pCheck->SetCheck(0);

	CGlvStructre glvStructure;
	m_glvRetarget.Init(m_filerBvh.m_bvhStructure, glvStructure);
	m_glvInsert.Init(m_filerBvh.m_bvhStructure, glvStructure);
	UpdateMergeAndCustomize();
	return TRUE;
}
// CGloveMergeDlg message handlers

void CGloveMergeDlg::OnBnClickedButtonBswSrcRight()
{
	CString strSrcPath = L"";
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SRC_RIGHT);
	if(pEdit)
		pEdit->GetWindowText(strSrcPath);

	CFileDialog dlgFile(TRUE, L"Raw File(*.raw)|*.raw|BVH File(*.bvh)|*.bvh|Glove Capture File(*.glv)|*.glv", strSrcPath, 4|2, L"Raw File(*.raw)|*.raw|BVH File(*.bvh)|*.bvh|Glove Capture File(*.glv)|*.glv||");
	if(IDOK == dlgFile.DoModal())
		pEdit->SetWindowText(dlgFile.GetPathName());

	//load
	m_filerGloveRight.LoadFromFile(GloveUtil::ToChar(dlgFile.GetPathName()));
	char buffer[100];
	sprintf(buffer, " contains: %d frames, duration: %.2f ms", m_filerGloveRight.GetFrameCount(),  m_filerGloveRight.GetFrameCount() * m_filerGloveRight.m_fIntervalTime);
	CString strMsg(buffer);
	strMsg = dlgFile.GetPathName()  + strMsg;
	CStatic* pStatic = (CStatic*)GetDlgItem(IDC_STATIC_RIGHT_INFO);
	pStatic->SetWindowText((LPCTSTR)buffer);
	UpdateMergeAndCustomize();
}

void CGloveMergeDlg::OnBnClickedButtonBswSrcLeft()
{
	CString strSrcPath = L"";
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SRC_LEFT);
	if(pEdit)
		pEdit->GetWindowText(strSrcPath);

	CFileDialog dlgFile(TRUE, L"Raw File(*.raw)|*.raw|BVH File(*.bvh)|*.bvh|Glove Capture File(*.glv)|*.glv", strSrcPath, 4|2, L"Raw File(*.raw)|*.raw|BVH File(*.bvh)|*.bvh|Glove Capture File(*.glv)|*.glv||");
	if(IDOK == dlgFile.DoModal())
		pEdit->SetWindowText(dlgFile.GetPathName());

	//load
	m_filerGloveLeft.LoadFromFile(GloveUtil::ToChar(dlgFile.GetPathName()));
	char buffer[100];
	sprintf(buffer, " contains: %d frames, duration: %.2f ms", m_filerGloveLeft.GetFrameCount(),  m_filerGloveLeft.GetFrameCount() * m_filerGloveLeft.m_fIntervalTime);
	CString strMsg(buffer);
	strMsg = dlgFile.GetPathName()  + strMsg;
	CStatic* pStatic = (CStatic*)GetDlgItem(IDC_STATIC_LEFT_INFO);
	pStatic->SetWindowText((LPCTSTR)buffer);
	UpdateMergeAndCustomize();
}

void CGloveMergeDlg::OnBnClickedButtonBwsBvhBase()
{
	CString strBvhPath = L"";
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_BVH_BASE);
	if(pEdit)
		pEdit->GetWindowText(strBvhPath);

	CFileDialog dlgFile(TRUE, L"Motion Capture File(*.bvh)|*.bvh", strBvhPath, 4|2, L"Motion Capture File(*.bvh)|*.bvh||");
	if(IDOK == dlgFile.DoModal())
		pEdit->SetWindowText(dlgFile.GetPathName());

	//load
	m_strInputPath = dlgFile.GetPathName();
	m_filerBvh.LoadFromFile(GloveUtil::ToChar(m_strInputPath));
	char buffer[100];
	sprintf(buffer, " contains: %d frames, duration: %.2f ms", m_filerBvh.GetFrameCount(),  m_filerBvh.GetFrameCount() * m_filerBvh.m_fIntervalTime);
	CString strMsg(buffer);
	strMsg = m_strInputPath + strMsg;
	CStatic* pStatic = (CStatic*)GetDlgItem(IDC_STATIC_BVH_INFO);
	pStatic->SetWindowText(strMsg);

	//test
	CString strBvh = m_filerBvh.m_bvhStructure.ToString();

	CGlvStructre glvStructure;
	m_glvRetarget.Init(m_filerBvh.m_bvhStructure, glvStructure);
	m_glvInsert.Init(m_filerBvh.m_bvhStructure, glvStructure);

	UpdateMergeAndCustomize();
}

void CGloveMergeDlg::OnBnClickedButtonBwsDest()
{
	CString strDestPath = L"";
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_DEST);
	if(pEdit)
		pEdit->GetWindowText(strDestPath);

	CFileDialog dlgFile(FALSE, L"Motion Capture File(*.bvh)|*.bvh", strDestPath, 4|2, L"Motion Capture File(*.bvh)|*.bvh||");
	if(IDOK == dlgFile.DoModal())
	{
		pEdit->SetWindowText(dlgFile.GetPathName());
		m_strOutputPath = dlgFile.GetPathName();
	}
}

void CGloveMergeDlg::OnBnClickedButtonMerge()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_OFFSET_LEFT);
	CString strOffset_l = L"";
	pEdit->GetWindowText(strOffset_l);
	int iOffset_l = 0;
	if(!strOffset_l.IsEmpty())
		iOffset_l = _wtoi(strOffset_l.GetBuffer());

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_OFFSET_RIGHT);
	CString strOffset_r = L"";
	pEdit->GetWindowText(strOffset_r);
	int iOffset_r = 0;
	if(!strOffset_r.IsEmpty())
		iOffset_r = _wtoi(strOffset_r.GetBuffer());

	CButton* pCheck = (CButton*)GetDlgItem(IDC_CHECK_INSERT);
	bool bInsert = (pCheck->GetCheck() != 0);
	m_filerBvh.FillInVirtualHand(m_strInputPath, m_strOutputPath, m_filerGloveLeft, iOffset_l, m_filerGloveRight, iOffset_r, m_glvRetarget, m_glvInsert, bInsert);
}

void CGloveMergeDlg::OnBnClickedButtonMapping()
{
	CGloveBvhRetargetDlg dlg;
	dlg.m_glvRetarget = m_glvRetarget;
	if(dlg.DoModal() == IDOK)
		m_glvRetarget = dlg.m_glvRetarget;
}

void CGloveMergeDlg::UpdateMergeAndCustomize()
{
	CStatic* pStatic = (CStatic*) GetDlgItem(IDC_STATIC_BVH_INFO);
	CString strBvhBaseInfo;
	pStatic->GetWindowText(strBvhBaseInfo);

	pStatic = (CStatic*)GetDlgItem(IDC_STATIC_LEFT_INFO);
	CString strGlvLeftInfo;
	pStatic->GetWindowText(strGlvLeftInfo);

	pStatic = (CStatic*)GetDlgItem(IDC_STATIC_RIGHT_INFO);
	CString strGlvRightInfo;
	pStatic->GetWindowText(strGlvRightInfo);

	if(strBvhBaseInfo == L"" || strBvhBaseInfo == L"Invalid file")
	{
		GetDlgItem(IDC_BUTTON_MERGE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_MAPPING)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_INSERT)->EnableWindow(FALSE);
	}
	else
	{
		if((strGlvLeftInfo == L"" || strGlvLeftInfo == L"Invalid file") &&
			(strGlvRightInfo == L"" || strGlvRightInfo == L"Invalid file"))
		{
			GetDlgItem(IDC_BUTTON_MERGE)->EnableWindow(FALSE);
			GetDlgItem(IDC_BUTTON_MAPPING)->EnableWindow(FALSE);
			GetDlgItem(IDC_BUTTON_INSERT)->EnableWindow(FALSE);
		}
		else 
		{
			GetDlgItem(IDC_BUTTON_MERGE)->EnableWindow(TRUE);
			CButton* pCheck = (CButton*)GetDlgItem(IDC_CHECK_INSERT);
			BOOL bInsert = pCheck->GetCheck();
			if(bInsert)
			{
				GetDlgItem(IDC_BUTTON_INSERT)->EnableWindow(TRUE);
				GetDlgItem(IDC_BUTTON_MAPPING)->EnableWindow(FALSE);
			}
			else
			{
				GetDlgItem(IDC_BUTTON_INSERT)->EnableWindow(FALSE);
				GetDlgItem(IDC_BUTTON_MAPPING)->EnableWindow(TRUE);
			}			
		}
	}
}
void CGloveMergeDlg::OnBnClickedCheckInsert()
{
	UpdateMergeAndCustomize();
}

void CGloveMergeDlg::OnBnClickedButtonInsert()
{
	CGloveBvhInsertDlg dlg;
	dlg.m_glvInsert = m_glvInsert;
	if(dlg.DoModal() == IDOK)
		m_glvInsert = dlg.m_glvInsert;
}

void CGloveMergeDlg::OnEnChangeEditOffsetRight()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}
#include "GloveSkeleton.h"
void CGloveMergeDlg::OnBnClickedButtonFastIntegrate()
{
	//1. test hand bvh header
	CHandSkeletonKin handL(false);
	CHandSkeletonKin handR(true);
	std::string strHeaderL = handL.GetBvhHeaderConsistentWithBody();
	std::string strHeaderR = handR.GetBvhHeaderConsistentWithBody();
	
	//2. replace the left/right hand in bvh header

	//3. handling the data
	CBvhClip clipBvh;
	CString strBvhBody;
	GetDlgItem(IDC_EDIT_BVH_BASE)->GetWindowText(strBvhBody);
	clipBvh.LoadFromFile(GloveUtil::ToChar(strBvhBody));
	CString strBvhHeader = clipBvh.m_bvhStructure.m_strHeader;

	CRawClip clipHandL;
	CString strHandL;
	GetDlgItem(IDC_EDIT_SRC_LEFT)->GetWindowText(strHandL);
	clipHandL.LoadFromFile(GloveUtil::ToChar(strHandL));

	CRawClip clipHandR;
	CString strHandR;
	GetDlgItem(IDC_EDIT_SRC_RIGHT)->GetWindowText(strHandR);
	clipHandR.LoadFromFile(GloveUtil::ToChar(strHandR));

	CString strDest;
	GetDlgItem(IDC_EDIT_DEST)->GetWindowText(strDest);
	clipBvh.FillingBodyConsistent(strDest, clipHandL, clipHandR);

}
