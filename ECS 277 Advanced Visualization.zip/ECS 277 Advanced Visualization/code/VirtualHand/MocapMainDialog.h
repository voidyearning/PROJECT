#pragma once
#include "OneHandCtrl.h"
#include "MocapCtrl.h"

// CMocapMainDialog dialog

class CMocapMainDialog : public CDialog
{
	DECLARE_DYNAMIC(CMocapMainDialog)

public:
	CMocapMainDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CMocapMainDialog();
	
	COneHandCtrl m_ctrlLeftHand;
	COneHandCtrl m_ctrlRightHand;
	CMocapCtrl m_ctrlMocap;

	virtual BOOL OnInitDialog();
// Dialog Data
	enum { IDD = IDD_DIALOG_MOCAP_MAIN };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};
