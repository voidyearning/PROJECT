//offset edits
#define IDC_EDIT_THUMB_TMJ_O            1050
#define IDC_EDIT_THUMB_MPJ_O            1051
#define IDC_EDIT_THUMB_IJ_O             1052
#define IDC_EDIT_THUMB_ABD_O            1053

#define IDC_EDIT_INDEX_MPJ_O            1054
#define IDC_EDIT_INDEX_PIJ_O            1055
#define IDC_EDIT_INDEX_DIJ_O            1056
#define IDC_EDIT_INDEX_ABD_O            1057

#define IDC_EDIT_MIDDLE_MPJ_O           1058
#define IDC_EDIT_MIDDLE_PIJ_O           1059
#define IDC_EDIT_MIDDLE_DIJ_O           1060
#define IDC_EDIT_MIDDLE_ABD_O           1061

#define IDC_EDIT_RING_MPJ_O             1062
#define IDC_EDIT_RING_PIJ_O             1063
#define IDC_EDIT_RING_DIJ_O             1064
#define IDC_EDIT_RING_ABD_O             1065

#define IDC_EDIT_PINKY_MPJ_O            1066
#define IDC_EDIT_PINKY_PIJ_O            1067
#define IDC_EDIT_PINKY_DIJ_O            1068
#define IDC_EDIT_PINKY_ABD_O            1069


//gain edits
#define IDC_EDIT_THUMB_TMJ_G            1090
#define IDC_EDIT_THUMB_MPJ_G            1091
#define IDC_EDIT_THUMB_IJ_G             1092
#define IDC_EDIT_THUMB_ABD_G            1093

#define IDC_EDIT_INDEX_MPJ_G            1094
#define IDC_EDIT_INDEX_PIJ_G            1095
#define IDC_EDIT_INDEX_DIJ_G            1096
#define IDC_EDIT_INDEX_ABD_G            1097

#define IDC_EDIT_MIDDLE_MPJ_G           1098
#define IDC_EDIT_MIDDLE_PIJ_G           1099
#define IDC_EDIT_MIDDLE_DIJ_G           1100
#define IDC_EDIT_MIDDLE_ABD_G           1101

#define IDC_EDIT_RING_MPJ_G             1102
#define IDC_EDIT_RING_PIJ_G             1103
#define IDC_EDIT_RING_DIJ_G             1104
#define IDC_EDIT_RING_ABD_G             1105

#define IDC_EDIT_PINKY_MPJ_G            1106
#define IDC_EDIT_PINKY_PIJ_G            1107
#define IDC_EDIT_PINKY_DIJ_G            1108
#define IDC_EDIT_PINKY_ABD_G            1109


//info static
#define IDC_STATIC_THUMB_TMJ            1110
#define IDC_STATIC_THUMB_MPJ            1111
#define IDC_STATIC_THUMB_IJ             1112
#define IDC_STATIC_THUMB_ABD            1113

#define IDC_STATIC_INDEX_MPJ            1114
#define IDC_STATIC_INDEX_PIJ            1115
#define IDC_STATIC_INDEX_DIJ            1116
#define IDC_STATIC_INDEX_ABD            1117

#define IDC_STATIC_MIDDLE_MPJ           1118
#define IDC_STATIC_MIDDLE_PIJ           1119
#define IDC_STATIC_MIDDLE_DIJ           1120
#define IDC_STATIC_MIDDLE_ABD           1121

#define IDC_STATIC_RING_MPJ             1122
#define IDC_STATIC_RING_PIJ             1123
#define IDC_STATIC_RING_DIJ             1124
#define IDC_STATIC_RING_ABD		        1125

#define IDC_STATIC_PINKY_MPJ            1126
#define IDC_STATIC_PINKY_PIJ            1127
#define IDC_STATIC_PINKY_DIJ            1128
#define IDC_STATIC_PINKY_ABD            1129
