#pragma once

#include "GPRCalibrationCtrl.h"
#include "LinearCalibrationCtrl.h"
#include "KinematicRotationCtrl.h"
#include "KinematicDimensionCtrl.h"
#include "PlaybackCtrl.h"
// CLeftHandCtrl dialog

class COneHandCtrl : public CDialog
{
	DECLARE_DYNAMIC(COneHandCtrl)

public:
	COneHandCtrl(bool bLeft = true, CWnd* pParent = NULL);   // standard constructor
	virtual ~COneHandCtrl();
	virtual BOOL OnInitDialog();

	bool m_bLeft;
	CPlaybackCtrl m_ctrlPlayback;
	CKinematicRotationCtrl m_ctrlKinematicRotation;
	CKinematicDimensionCtrl m_ctrlKinematicDimension;
	CGPRCalibrationCtrl m_ctrlGPRCalibration;
	CLinearCalibrationCtrl m_ctrlLinearCalibration;


protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};
