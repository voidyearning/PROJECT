// GloveBvhRetargetDlg.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "GloveBvhRetargetDlg.h"


// CGloveBvhRetargetDlg dialog

IMPLEMENT_DYNAMIC(CGloveBvhRetargetDlg, CDialog)

CGloveBvhRetargetDlg::CGloveBvhRetargetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGloveBvhRetargetDlg::IDD, pParent)
{

}

CGloveBvhRetargetDlg::~CGloveBvhRetargetDlg()
{
}

void CGloveBvhRetargetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CGloveBvhRetargetDlg::OnInitDialog()
{
	CListBox* pList = (CListBox*) GetDlgItem(IDC_LIST_BVH);
	for(int i = 0; i < m_glvRetarget.GetBvhDataSize(); ++i)
	{
		CString strIdx = L"";
		strIdx.Format(L"%d:", i);
		pList->AddString(strIdx + m_glvRetarget.GetBvhDataNameAt(i));
	}

	pList = (CListBox*) GetDlgItem(IDC_LIST_GLOVE);
	for(int i = 0; i < m_glvRetarget.GetGlvDataSize(); ++i)
	{
		CString strIdx = L"";
		strIdx.Format(L"%d:", i);
		pList->AddString(strIdx + m_glvRetarget.GetGlvDataNameAt(i));
	}

	CString strInfo = L"";
	for(int i = 0; i < m_glvRetarget.GetBvhDataSize(); ++i)
	{
		CGloveMapping mapping = m_glvRetarget.GetMappingOf(i);
		if(mapping.IsNone())
			continue;
		CString strIdx = L"";
		strIdx.Format(L"%d:", i);
		strInfo += strIdx + m_glvRetarget.GetExpressionOf(mapping) + L"\r\n\r";
	}
	GetDlgItem(IDC_EDIT_INFO)->SetWindowText(strInfo);

	GetDlgItem(IDC_EDIT_WEIGHT)->EnableWindow(FALSE);	
	CButton* pRadio = (CButton*)GetDlgItem(IDC_RADIO_LEFT);
	pRadio->SetCheck(1);

	return TRUE;
}
BEGIN_MESSAGE_MAP(CGloveBvhRetargetDlg, CDialog)
	ON_LBN_SELCHANGE(IDC_LIST_BVH, &CGloveBvhRetargetDlg::OnLbnSelchangeListBvh)
	ON_LBN_SELCHANGE(IDC_LIST_GLOVE, &CGloveBvhRetargetDlg::OnLbnSelchangeListGlove)
	ON_EN_CHANGE(IDC_EDIT_WEIGHT, &CGloveBvhRetargetDlg::OnEnChangeEditWeight)
	ON_BN_CLICKED(IDC_RADIO_LEFT, &CGloveBvhRetargetDlg::OnBnClickedRadioLeft)
	ON_BN_CLICKED(IDC_RADIO_RIGHT, &CGloveBvhRetargetDlg::OnBnClickedRadioRight)
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CGloveBvhRetargetDlg::OnBnClickedButtonReset)
	ON_BN_CLICKED(IDC_BUTTON_LOAD, &CGloveBvhRetargetDlg::OnBnClickedButtonLoad)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, &CGloveBvhRetargetDlg::OnBnClickedButtonSave)
END_MESSAGE_MAP()


// CGloveBvhRetargetDlg message handlers

void CGloveBvhRetargetDlg::OnLbnSelchangeListBvh()
{
	UpdateCtrlFromMapping();	
}

void CGloveBvhRetargetDlg::OnLbnSelchangeListGlove()
{
	UpdateCtrlFromMapping();
}

void CGloveBvhRetargetDlg::OnEnChangeEditWeight()
{
	UpdateMappingFromCtrl();
}

void CGloveBvhRetargetDlg::UpdateCtrlFromMapping()
{	
	CListBox* pList = (CListBox*) GetDlgItem(IDC_LIST_BVH);
	int iBvhIdx = pList->GetCurSel();
	m_curGlvMapping = m_glvRetarget.GetMappingOf(iBvhIdx);
	m_curGlvMapping.m_iBvhIdx = iBvhIdx;

	pList = (CListBox*) GetDlgItem(IDC_LIST_GLOVE);
	int iGlvIdx = pList->GetCurSel();

	bool bLeft = true;
	CButton* pRadio = (CButton*)GetDlgItem(IDC_RADIO_LEFT);
	if(pRadio->GetCheck())
		bLeft = true;
	pRadio = (CButton*)GetDlgItem(IDC_RADIO_RIGHT);
	if(pRadio->GetCheck())
		bLeft = false;

	m_curGlvMappingItem = m_curGlvMapping.GetMappingItemOf(iGlvIdx, bLeft);
	m_curGlvMappingItem.m_iGlvIdx = iGlvIdx;

	CEdit* pEdit = (CEdit*) GetDlgItem(IDC_EDIT_WEIGHT);
	CStatic* pStatic = (CStatic*) GetDlgItem(IDC_STATIC_MAPPING_EXP);
	
	if(iBvhIdx == -1)
	{		
		pStatic->SetWindowText(L"Mapping expression:");
		pEdit->SetWindowText(L"");
		pEdit->EnableWindow(FALSE);
		return;
	}

	if(iGlvIdx == -1)
	{
		CString strExpr = L"Mapping expression:\n" + 
			m_glvRetarget.GetExpressionOf(m_curGlvMapping);
		pStatic->SetWindowText(strExpr);
		pEdit->SetWindowText(L"");
		pEdit->EnableWindow(FALSE);			
		return;
	}

	CString strExpr = L"Mapping expression:\n" + 
			m_glvRetarget.GetExpressionOf(m_curGlvMapping);
	pStatic->SetWindowText(strExpr);

	CString strWeight = L"";
	strWeight.Format(L"%4f", m_curGlvMappingItem.m_fWeight);
	pEdit->SetWindowText(strWeight);
	pEdit->EnableWindow(TRUE);
}
void CGloveBvhRetargetDlg::UpdateMappingFromCtrl()
{
	CEdit* pEdit = (CEdit*) GetDlgItem(IDC_EDIT_WEIGHT);
	if(!pEdit->IsWindowEnabled())
		return;

	CListBox* pList = (CListBox*) GetDlgItem(IDC_LIST_BVH);
	int iBvhIdx = pList->GetCurSel();
	m_curGlvMapping = m_glvRetarget.GetMappingOf(iBvhIdx);
	m_curGlvMapping.m_iBvhIdx = iBvhIdx;

	pList = (CListBox*) GetDlgItem(IDC_LIST_GLOVE);
	int iGlvIdx = pList->GetCurSel();

	bool bLeft = true;
	CButton* pRadio = (CButton*)GetDlgItem(IDC_RADIO_LEFT);
	if(pRadio->GetCheck())
		bLeft = true;
	pRadio = (CButton*)GetDlgItem(IDC_RADIO_RIGHT);
	if(pRadio->GetCheck())
		bLeft = false;

	m_curGlvMappingItem = m_curGlvMapping.GetMappingItemOf(iGlvIdx, bLeft);
	m_curGlvMappingItem.m_iGlvIdx = iGlvIdx;

	CString strWeight;
	pEdit->GetWindowText(strWeight);
	m_curGlvMappingItem.m_fWeight = _wtof(strWeight.GetBuffer());
	m_curGlvMapping.SetMappingItemOf(iGlvIdx, bLeft, m_curGlvMappingItem);
	m_glvRetarget.SetMappingOf(iBvhIdx, m_curGlvMapping);

	CStatic* pStatic = (CStatic*)GetDlgItem(IDC_STATIC_MAPPING_EXP);
	CString strExpr = L"Mapping expression:\n" + 
			m_glvRetarget.GetExpressionOf(m_curGlvMapping);
	pStatic->SetWindowText(strExpr);

}

void CGloveBvhRetargetDlg::OnBnClickedRadioLeft()
{
	UpdateCtrlFromMapping();
}

void CGloveBvhRetargetDlg::OnBnClickedRadioRight()
{
	UpdateCtrlFromMapping();
}
void CGloveBvhRetargetDlg::OnBnClickedButtonReset()
{
	m_glvRetarget.Reset();
	UpdateCtrlFromMapping();
}

void CGloveBvhRetargetDlg::OnBnClickedButtonLoad()
{
	CString strLoadPath = L"";
	CFileDialog dlgFile(TRUE, L"Retargeting file(*.gts)|*.gts", 0, 4|2, L"Retargeting file(*.gts)|*.gts||");
	if(IDOK == dlgFile.DoModal())
	{
		strLoadPath = dlgFile.GetPathName();
		m_glvRetarget.LoadFrom(strLoadPath);
	}
	UpdateCtrlFromMapping();
}

void CGloveBvhRetargetDlg::OnBnClickedButtonSave()
{
	CString strSavePath = L"";
	CFileDialog dlgFile(FALSE, L"Retargeting file(*.gts)|*.gts", 0, 4|2, L"Retargeting file(*.gts)|*.gts||");
	if(IDOK == dlgFile.DoModal())
	{
		strSavePath = dlgFile.GetPathName();
		m_glvRetarget.SaveTo(strSavePath);
	}
}
