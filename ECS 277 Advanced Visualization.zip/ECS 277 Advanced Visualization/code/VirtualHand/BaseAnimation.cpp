#include "stdafx.h"
#include <math.h>
#include "BaseAnimation.h"
#include "GloveAnimation.h"
#include "RawAnimation.h"

CBaseClip*  CBaseClip::NewFromFile(std::string strPath)
{
	CBaseClip* pClip;
	if(strPath.find(".glv") !=std::string::npos)
		pClip = new CGlvClip();
	if(strPath.find(".raw") !=std::string::npos)
		pClip = new CRawClip();

	pClip->LoadFromFile(strPath);
	return pClip;
}
double CBaseClip::GetMaxVariance(int iIdx)
{
	double fMin = 1000000, fMax = -1000000;
	double fMaxVariance = 0;
	for(int i = 0; i < this->GetFrameCount(); ++i)
	{
		CBaseFrame* pFrame = this->GetFrameAt(i);
		if(iIdx >= pFrame->m_arData.size())
			continue;
		double fData = pFrame->m_arData[iIdx];
		if(fData < fMin) 
			fMin = fData;
		if(fData > fMax)
			fMax = fData;
	}
	fMaxVariance = fMax-fMin;
	if(fMaxVariance <0)
		fMaxVariance = -fMaxVariance;
	return fMaxVariance;
}

double CBaseClip::GetMean(int iIdx)
{
	double fSum = 0;
	int iValidDataCount = 0;
	for(int i = 0; i < this->GetFrameCount(); ++i)
	{
		CBaseFrame* pFrame = this->GetFrameAt(i);
		if(iIdx >= pFrame->m_arData.size())
			continue;
		double fData = pFrame->m_arData[iIdx];
		fSum += fData;
		iValidDataCount ++;
	}
	if(iValidDataCount == 0)
		return 0;

	return fSum/iValidDataCount;
}
double CBaseClip::GetMaxDeviation(int iIdx)
{
	double fMean = GetMean(iIdx);
	double fMaxDeviation = 0;

	for(int i = 0; i < this->GetFrameCount(); ++i)
	{
		CBaseFrame* pFrame = this->GetFrameAt(i);
		if(iIdx >= pFrame->m_arData.size())
			continue;
		double fData = pFrame->m_arData[iIdx];
		double fDeviation = fData - fMean;
		if(fDeviation < 0)
			fDeviation = - fDeviation;
		if(fDeviation > fMaxDeviation)
			fMaxDeviation = fDeviation;
	}
	return fMaxDeviation;
}


double CBaseClip::GetStandardDeviation(int iIdx)
{
	double fMean = GetMean(iIdx);
	double fDeviationSum = 0;	
	int iValidDataCount = 0;

	for(int i = 0; i < this->GetFrameCount(); ++i)
	{
		CBaseFrame* pFrame = this->GetFrameAt(i);
		if(iIdx >= pFrame->m_arData.size())
			continue;
		double fData = pFrame->m_arData[iIdx];
		double fDeviation = fData - fMean;
		fDeviation = fDeviation * fDeviation;
		fDeviationSum += fDeviation;
		iValidDataCount ++;
	}
	if(iValidDataCount == 0)
		return 0;
	
	double fStd = fDeviationSum / iValidDataCount;
	fStd = sqrt(fStd);
	return fStd;
}

