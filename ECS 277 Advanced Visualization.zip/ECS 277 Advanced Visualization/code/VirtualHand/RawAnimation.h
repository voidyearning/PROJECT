#pragma once
#include <vector>
#include <string>
#include "BaseAnimation.h"

enum E_ABDUCTION_TYPE
{
		E_THUMB_INDEX, E_INDEX_MID, E_MID_RING, E_RING_PINKY
};

#define HAND_SKEL_DOF_THUMB_ROLL  0
#define HAND_SKEL_DOF_THUMB_ABD  1
#define HAND_SKEL_DOF_THUMB_VIRTUAL  2
#define HAND_SKEL_DOF_THUMB_FLEX_PROX  3
#define HAND_SKEL_DOF_THUMB_FLEX_DIST  4

#define HAND_SKEL_DOF_INDEX_ABD_PALM  5
#define HAND_SKEL_DOF_INDEX_FLEX_PALM  6
#define HAND_SKEL_DOF_INDEX_ABD  7
#define HAND_SKEL_DOF_INDEX_FLEX_PROX  8
#define HAND_SKEL_DOF_INDEX_FLEX_MID  9
#define HAND_SKEL_DOF_INDEX_FLEX_DIST  10

#define HAND_SKEL_DOF_MID_ABD_PALM  11
#define HAND_SKEL_DOF_MID_FLEX_PALM  12
#define HAND_SKEL_DOF_MID_ABD  13
#define HAND_SKEL_DOF_MID_FLEX_PROX  14
#define HAND_SKEL_DOF_MID_FLEX_MID  15
#define HAND_SKEL_DOF_MID_FLEX_DIST  16

#define HAND_SKEL_DOF_RING_ABD_PALM  17
#define HAND_SKEL_DOF_RING_FLEX_PALM  18
#define HAND_SKEL_DOF_RING_ABD  19
#define HAND_SKEL_DOF_RING_FLEX_PROX  20
#define HAND_SKEL_DOF_RING_FLEX_MID  21
#define HAND_SKEL_DOF_RING_FLEX_DIST  22

#define HAND_SKEL_DOF_PINKY_ABD_PALM  23
#define HAND_SKEL_DOF_PINKY_FLEX_PALM  24
#define HAND_SKEL_DOF_PINKY_ABD  25
#define HAND_SKEL_DOF_PINKY_FLEX_PROX  26
#define HAND_SKEL_DOF_PINKY_FLEX_MID  27
#define HAND_SKEL_DOF_PINKY_FLEX_DIST  28

#define HAND_SKEL_DOF_WRIST_FLEX  29
#define HAND_SKEL_DOF_WRIST_ABD  30
#define HAND_SKEL_DOF_DATA_SIZE  31

class CRawFrame : public CBaseFrame
{
public:
	CRawFrame();
	CRawFrame(const std::vector<float>& arData);
	static CRawFrame GetEmptyFrame(int iDataNum = 31);
	float GetRotationAngle(int iKinIndex, bool bLeft = true);
	void SetRotationAngle(int iKinIndex, float fRotationAngle, bool bLeft = true);
	float GetAbductionJiajiao(E_ABDUCTION_TYPE eType, bool bLeft = true);
	void SetAbductionJiajiao(E_ABDUCTION_TYPE eType, float fAbdSensor, bool bLeft = true);
	bool operator == (const CRawFrame& frame);
	CRawFrame operator+(const CRawFrame& frame);
	CRawFrame operator-(const CRawFrame& frame);
	CRawFrame operator/(float fDiv);
	CRawFrame operator*(float fMul);

	float DistanceTo(CRawFrame& frmRaw);
	float DistanceToThumb(CRawFrame& frmRaw);
	float DistanceToThumbHD(CRawFrame& frmRaw);
	void ZeroWristRotations();
	void ZeroFingerFlex();
	void SuppressOverbend(bool bLeft, float fIndexExt=30, float fMidExt=30, float fRingExt=30, float fPinkyExt = 30);
	void SuppressOverbendSigmoid(bool bLeft, int iDOFIndex, float fMin, float fMax);
	void RangeFilter(bool bLeft);
	void CheckRange(bool bLeft);
	void SaveToFile(std::string strPath);
	static CRawFrame InterpolateBetween(CRawFrame& frmBeg, CRawFrame& frmEnd, float fCoeff);

	void SaveToBvhConsistentWithBody(bool bLeft, std::ofstream& fout);
	CRawFrame SwapHandness() const;

	void CalError(CRawFrame frmTruth, float& fMaxErr, int& iMaxIdx, float& fMeanErr, float& fStdErr);  
	static void CalError(CRawFrame frmSample, CRawFrame frmTruth, float& fMaxErr, int& iMaxIdx, float& fMeanErr, float& fStdErr); 

	//xtreme fast
	CRawFrame xfast_calibrate_finger_flex(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmFist, CRawFrame frmFist_gt, 
		CRawFrame frmOverbend, CRawFrame frmOverbend_gt, 
		bool bLeft = true);

	CRawFrame xfast_calibrate_finger_abd(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmSpread, CRawFrame frmSpread_gt, 
		bool bLeft = true);

	CRawFrame xfast_calibrate_thumb(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmFist, CRawFrame frmFist_gt,
		CRawFrame frmSpread, CRawFrame frmSpread_gt, 
		bool bLeft = true);
};
class CRawClip : public CBaseClip
{
public:
	std::vector<CRawFrame> m_arFrame;
	void SaveToBvh(std::string strPath, std::string strBvhHeader);
	void SaveToBvhConsistentWithBody(bool bLeft, std::string strPath, std::string strBvhHeader);
	void SaveToFile(std::string strPath);
	void LoadFromFile(std::string strPath);
	int GetFrameCount();
	CBaseFrame* GetFrameAt(int iFrmIdx);	
	virtual void SetFrameAt(int iFrmIdx, CBaseFrame*);
	virtual CRawFrame GetAveragePose();
	void MergeWith(const CRawClip& clipToMerge);
	bool HasFrame(const CRawFrame& frame);
	virtual CBaseClip* GetSubClip(int iBegIdx, int iEndIdx);
	CRawClip CalculateIKAccuracy(IK_FINGER_TOUCHING_TYPE eTouchingType, bool bLeft);
	void ZeroWristRotations();
	void ZeroProxFlex();
	void ZeroFingerFlex();
	void SuppressOverbend(bool bLeft, float fIndexExt=30, float fMidExt=30, float fRingExt=30, float fPinkyExt = 30);
	void SuppressOverbendSigmoid(bool bLeft, int iDOFIndex, float fMin, float fMax);
	void SuppressOverbendSigmoid(bool bLeft);
	void Rescale(int iFingerIndex, int iFixedMergeInFrameIdx, int iRescaledFrameIdx); 
	CRawClip SwapHandness() const;
	void ReinforceRelation(bool bLeft = true);
	float AvgVelocity(int iDOF);

	void ItpFinger(int iBeg, int iEnd, int iFinger);
	void CorrectStandardSpreadOutThumb(bool bLeft, float fFlatAbd_r, float fSpreadAbd_r);
	void CorrectBetweenThumb(bool bLeft, CRawFrame frmFlat, CRawFrame frmFlex);
	void RangeFilter(bool bLeft);
	void EliminateRedundancy();
	void EliminateInputRedundancy(float fGranularity = 1);
	void EliminateOutputRedundancy(float fGranularity = 5);
	void EliminateThumbRedundancy(float fGranularity = 1);
	void EliminateThumbRedundancyHD(float fGranularity = 1);
	static void EliminateThumbRedundancy(CRawClip& clipSample, CRawClip& clipGroundTruth, float fGranularity = 1);
	static void EliminateThumbRedundancyHD(CRawClip& clipSample, CRawClip& clipGroundTruth, float fGranularity = 1);
	static void EliminateIndexAbdRedundancy(CRawClip& clipSample, CRawClip& clipGroundTruth, float fGranularity =1);
	static void EliminatePinkyAbdRedundancy(CRawClip& clipSample, CRawClip& clipGroundTruth, float fGranularity =1);
	static CRawClip ExtractThumbHD(CRawClip clipSample, CRawClip clipGroundTruth, int iDOF);
	static CRawClip ExtractThumbNoRedundancyHD(CRawClip clipSample, CRawClip clipGroundTruth, int iDOF, float fGranularity = 1);
	void CheckInputVariance(float fGranularity = 1);
	void ExportRotation(int iDOFIndex, std::string strPath);
	void ExportRawWithTarget(bool bLeft, std::string strPath);

	void AddExtrapolationTr1D();

	//testing
	virtual STATIC_GAPS FindUnchaningData(int iConsecutiveThreshold = 3);
	CRawClip GetReorderedClipByThumb_no_redundancy();//not implemented
	//IK stablize
	std::vector<int> GetKNearestThumb(CRawFrame frmRaw, int iK = 1, bool bHD = 1);

	//xtreme fast
	CRawClip xfast_calibrate_finger_flex(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmFist, CRawFrame frmFist_gt, 
		CRawFrame frmOverbend, CRawFrame frmOverbend_gt, 
		bool bLeft = true);

	CRawClip xfast_calibrate_finger_abd(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmSpread, CRawFrame frmSpread_gt, 
		CRawClip clipIM0, bool bLeft = true);

	CRawClip xfast_calibrate_im_abd(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmSpread, CRawFrame frmSpread_gt, 
		CRawClip clipIM0, bool bLeft = true);

	CRawClip xfast_calibrate_thumb(CRawFrame frmFlat, CRawFrame frmFlat_gt, 
		CRawFrame frmFist, CRawFrame frmFist_gt,
		CRawFrame frmSpread, CRawFrame frmSpread_gt, 
		bool bLeft = true);

	CRawClip xfast_calibrate_ik(CRawClip clipThisOrig, CRawClip clipIndexOrig, CRawClip clipIndex2Orig, std::string strFileLog, bool bLeft = true);

	//clipInput should be xfast_finger_flex/abd calibrated
	CRawClip xfast_im0_correction(CRawClip clipInput, bool bLeft = true);
};

