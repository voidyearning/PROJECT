#pragma once
#include "CRenderer.h"
#include "GloveSkeleton.h"
#include "ProbAnimation.h"

class CProbFrameRenderer : public COpenGLRenderer
{
public:
	CProbFrameRenderer();
	CProbFrameRenderer(CHandSkeletonKin* pHand);

	CKinematicPoint m_ptRenderRangeMin;
	CKinematicPoint m_ptRenderRangeMax;
	CKinematicPoint m_ptRenderRangeStep;

	double m_fProbColorMapBlue;
	double m_fProbColorMapRed;
	double m_fRenderValve;
	double m_fRenderSize;
	CProbFrame m_probFrame;
	CHandSkeletonKin* m_pHand;
	bool m_bRenderOriginal;

	void Render();
	void RenderBoundary();
	void RenderRange();
	void RenderOriginal();

	static CKinematicPoint Scalar2RGB(double v,double vmin,double vmax);
};