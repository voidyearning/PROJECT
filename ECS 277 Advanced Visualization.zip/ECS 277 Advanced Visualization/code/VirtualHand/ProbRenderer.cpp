#include "stdafx.h"
#include "ProbRenderer.h"
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glaux.h>
#include <gl/glut.h>
/*
   Return a RGB colour value given a scalar v in the range [vmin,vmax]
   In this case each colour component ranges from 0 (no contribution) to
   1 (fully saturated), modifications for other ranges is trivial.
   The colour is clipped at the end of the scales if v is outside
   the range [vmin,vmax]
   typedef struct {
      double r,g,b;
   } COLOUR;
*/
CKinematicPoint CProbFrameRenderer::Scalar2RGB(double v,double vmin,double vmax)
{
	CKinematicPoint c(1.0, 1.0, 1.0);
	double dv;

   if (v < vmin)
      v = vmin;
   if (v > vmax)
      v = vmax;
   dv = vmax - vmin;

   if (v < (vmin + 0.25 * dv)) 
   {
	   c.m_fX = 0;
	   c.m_fY = 4 * (v - vmin) / dv;
   } 
   else if (v < (vmin + 0.5 * dv))
   {
	   c.m_fX = 0;
	   c.m_fZ = 1 + 4 * (vmin + 0.25 * dv - v) / dv;
   } 
   else if (v < (vmin + 0.75 * dv)) 
   {
	   c.m_fX = 4 * (v - vmin - 0.5 * dv) / dv;
	   c.m_fZ = 0;
   } 
   else 
   {
	   c.m_fY = 1 + 4 * (vmin + 0.75 * dv - v) / dv;
	   c.m_fZ = 0;
   }

   return(c);
}


CProbFrameRenderer::CProbFrameRenderer()
{
	m_ptRenderRangeMin = CKinematicPoint(-20, -10, -8);
	m_ptRenderRangeMax = CKinematicPoint(-10, 15, 10);
	m_ptRenderRangeStep = CKinematicPoint(1, 1, 1);
	m_fRenderSize = 1;
	m_fProbColorMapBlue = 100;
	m_fProbColorMapRed = 0;
	m_fRenderValve = 100;
	m_pHand = NULL;
}
CProbFrameRenderer::CProbFrameRenderer(CHandSkeletonKin* pHand)
{
	m_ptRenderRangeMin = CKinematicPoint(-20, -10, -8);
	m_ptRenderRangeMax = CKinematicPoint(-10, 15, 10);
	m_ptRenderRangeStep = CKinematicPoint(1, 1, 1);
	m_fRenderSize = 1;
	m_fProbColorMapBlue = 100;
	m_fProbColorMapRed = 0;
	m_fRenderValve = 100;
	m_pHand = pHand;
	m_probFrame.m_pHand = pHand;
}
void CProbFrameRenderer::Render()
{
	glPushMatrix();
	glRotated(m_probFrame.m_fWristAbd, 0.0, 1.0, 0.0);
	glRotated(m_probFrame.m_fWristFlex, 0.0, 0.0, 1.0);

	if(m_bRenderOriginal)
		RenderOriginal();
	else
		RenderRange();
	glPopMatrix();
}

void CProbFrameRenderer::RenderBoundary()
{
	glColor3f(88, 88, 88);
		//upper face
		glBegin(GL_LINE_LOOP);
		glVertex3f(m_ptRenderRangeMin.m_fX, m_ptRenderRangeMax.m_fY, m_ptRenderRangeMin.m_fZ);//lub
		glVertex3f(m_ptRenderRangeMin.m_fX, m_ptRenderRangeMax.m_fY, m_ptRenderRangeMax.m_fZ);//luf
		glVertex3f(m_ptRenderRangeMax.m_fX, m_ptRenderRangeMax.m_fY, m_ptRenderRangeMax.m_fZ);//ruf
		glVertex3f(m_ptRenderRangeMax.m_fX, m_ptRenderRangeMax.m_fY, m_ptRenderRangeMin.m_fZ);//rub
		glEnd();

		//lower face
		glBegin(GL_LINE_LOOP);
		glVertex3f(m_ptRenderRangeMin.m_fX, m_ptRenderRangeMin.m_fY, m_ptRenderRangeMin.m_fZ);//llb
		glVertex3f(m_ptRenderRangeMin.m_fX, m_ptRenderRangeMin.m_fY, m_ptRenderRangeMax.m_fZ);//llf
		glVertex3f(m_ptRenderRangeMax.m_fX, m_ptRenderRangeMin.m_fY, m_ptRenderRangeMax.m_fZ);//rlf
		glVertex3f(m_ptRenderRangeMax.m_fX, m_ptRenderRangeMin.m_fY, m_ptRenderRangeMin.m_fZ);//rlb
		glEnd();

		//4 poles
		glBegin(GL_LINES);
		glVertex3f(m_ptRenderRangeMin.m_fX, m_ptRenderRangeMax.m_fY, m_ptRenderRangeMin.m_fZ);//lb
		glVertex3f(m_ptRenderRangeMin.m_fX, m_ptRenderRangeMin.m_fY, m_ptRenderRangeMin.m_fZ);

		glVertex3f(m_ptRenderRangeMin.m_fX, m_ptRenderRangeMax.m_fY, m_ptRenderRangeMax.m_fZ);//lf
		glVertex3f(m_ptRenderRangeMin.m_fX, m_ptRenderRangeMin.m_fY, m_ptRenderRangeMax.m_fZ);

		
		glVertex3f(m_ptRenderRangeMax.m_fX, m_ptRenderRangeMax.m_fY, m_ptRenderRangeMax.m_fZ);//rf
		glVertex3f(m_ptRenderRangeMax.m_fX, m_ptRenderRangeMin.m_fY, m_ptRenderRangeMax.m_fZ);

		
		glVertex3f(m_ptRenderRangeMax.m_fX, m_ptRenderRangeMax.m_fY, m_ptRenderRangeMin.m_fZ);//rb
		glVertex3f(m_ptRenderRangeMax.m_fX, m_ptRenderRangeMin.m_fY, m_ptRenderRangeMin.m_fZ);
		glEnd();
}
void CProbFrameRenderer::RenderOriginal()
{	
	glPointSize(m_fRenderSize);
	glBegin(GL_POINTS);
	for(int i = 0; i < m_probFrame.m_arProbData.size(); ++i)
	{
		CProbData pd = m_probFrame.m_arProbData[i];
		if(pd.m_dProb > m_fRenderValve)
					continue;
		//CKinematicPoint clr = Scalar2RGB(pd.m_dProb, m_fProbValveMin, m_fProbValveMax); 0-1 prob
		CKinematicPoint clr = Scalar2RGB(-pd.m_dProb, -m_fProbColorMapBlue, -m_fProbColorMapRed); //neg log		
		glColor3f(clr.m_fX, clr.m_fY, clr.m_fZ);

		glVertex3f(pd.m_ptPos.m_fX, pd.m_ptPos.m_fY, pd.m_ptPos.m_fZ);
		//glPushMatrix();
		//glTranslatef(pd.m_ptPos.m_fX, pd.m_ptPos.m_fY, pd.m_ptPos.m_fZ);
		//glutSolidSphere(m_fRenderSize, 5, 5);
		//glPopMatrix();
	}
	glEnd();
}
void CProbFrameRenderer::RenderRange()
{	
	glPointSize(m_fRenderSize);
	glBegin(GL_POINTS);
	for(double x = m_ptRenderRangeMin.m_fX; x <= m_ptRenderRangeMax.m_fX; x = x + m_ptRenderRangeStep.m_fX)
	{
		for(double y = m_ptRenderRangeMin.m_fY; y <= m_ptRenderRangeMax.m_fY; y = y + m_ptRenderRangeStep.m_fY)
		{
			for(double z = m_ptRenderRangeMin.m_fZ; z <= m_ptRenderRangeMax.m_fZ; z = z + m_ptRenderRangeStep.m_fZ)
			{
				double dProb = m_probFrame.GetRoughProbAt(CKinematicPoint(x, y, z));
				if(dProb > m_fRenderValve)
					continue;

				//CKinematicPoint clr = Scalar2RGB(dProb, m_fProbValveMin, m_fProbValveMax);
				CKinematicPoint clr = Scalar2RGB(-dProb, -m_fProbColorMapBlue, -m_fProbColorMapRed);
				/*float fc =  1;
				if(m_fProbColorMapBlue -m_fProbColorMapRed)
					fc = (m_fProbColorMapBlue - dProb) / (m_fProbColorMapBlue -m_fProbColorMapRed);
				CKinematicPoint clr(fc, fc, fc);*/

				glColor3f(clr.m_fX, clr.m_fY, clr.m_fZ);

				//glPushMatrix();
				glVertex3f(x, y, z);
				//glTranslatef(x, y, z);
				//glutSolidSphere(m_fRenderSize, 5, 5);
				//glPopMatrix();
			}
		}
	}
	glEnd();
}