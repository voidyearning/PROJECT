// GPRCalibrationCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "GPRCalibrationCtrl.h"
#include "GloveUtil.h"
#include "MatlabUtil.h"


// CGPRCalibrationCtrl dialog

IMPLEMENT_DYNAMIC(CGPRCalibrationCtrl, CDialog)

CGPRCalibrationCtrl::CGPRCalibrationCtrl(CWnd* pParent /*=NULL*/)
	: CDialog(CGPRCalibrationCtrl::IDD, pParent)
{

}

CGPRCalibrationCtrl::~CGPRCalibrationCtrl()
{
}

void CGPRCalibrationCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CGPRCalibrationCtrl, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_LMCGPR_DIR, &CGPRCalibrationCtrl::OnBnClickedButtonBrowseLmcgprDir)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_LMCGPR_MODEL, &CGPRCalibrationCtrl::OnBnClickedButtonLoadLmcgprModel)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_SPGPS_DIR, &CGPRCalibrationCtrl::OnBnClickedButtonBrowseSpgpsDir)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_SPGPS_MODEL, &CGPRCalibrationCtrl::OnBnClickedButtonLoadSpgpsModel)
END_MESSAGE_MAP()


// CGPRCalibrationCtrl message handlers

void CGPRCalibrationCtrl::OnBnClickedButtonBrowseLmcgprDir()
{
	CString strPath = GloveUtil::ShowFolderDlg(L"Home directory of LMC-GPR");
	GetDlgItem(IDC_EDIT_LMCGPR_DIR)->SetWindowText(strPath);
}

void CGPRCalibrationCtrl::OnBnClickedButtonLoadLmcgprModel()
{
	CString strPath;
	GetDlgItem(IDC_EDIT_LMCGPR_DIR)->GetWindowText(strPath);
	MatlabUtil::Load_full(GloveUtil::ToChar(strPath));
}

void CGPRCalibrationCtrl::OnBnClickedButtonBrowseSpgpsDir()
{
	CString strPath = GloveUtil::ShowFolderDlg(L"Home directory of SPGPs");
	GetDlgItem(IDC_EDIT_SPGPS_DIR)->SetWindowText(strPath);
}

void CGPRCalibrationCtrl::OnBnClickedButtonLoadSpgpsModel()
{
	CString strPath;
	GetDlgItem(IDC_EDIT_SPGPS_DIR)->GetWindowText(strPath);
	MatlabUtil::Load_fitc(GloveUtil::ToChar(strPath));
}
