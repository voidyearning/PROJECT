void UpdateJointPositionsFromRotations();
void InitJacobian();
void UpdateJacobian();
void InitJacobianPseudoInv();
void UpdateJacobianPseudoInv();
void ReachGoalOneStep();
void ReachGoal();
