#include "stdafx.h"
#include "matlabWrapper.h"
#include "windows.h"

void TestMatlab()
{
	Engine* pMatlabEngine = NULL;
	mxArray *pMatrix = NULL, *r = NULL;
	char buffer[301];
	double poly[2][2] = {1, -2, 0, 5};
	double dtest = poly[0][1];//should be -2

	if(!(pMatlabEngine = engOpen(NULL)))
		return;

	pMatrix = mxCreateDoubleMatrix(2, 2, mxREAL);
	mxSetClassName(pMatrix, "JJt");
	memcpy((char*)mxGetPr(pMatrix), (char*)poly, 4*sizeof(double));
	engPutVariable(pMatlabEngine, "JJt", pMatrix);
	engOutputBuffer(pMatlabEngine, buffer, 300);
	engEvalString(pMatlabEngine, "JJt=inv(JJt)");
	mxArray * mxResult = engGetVariable(pMatlabEngine, "JJt");
	engClose(pMatlabEngine);
	memcpy((char*)poly, (char*)mxGetPr(mxResult), 4*sizeof(double));
	mxDestroyArray(pMatrix);
	double dtest2 = poly[0][1];//should be 0.4
	MessageBoxA(NULL, buffer+1, "example2", MB_OK);
	return;
}