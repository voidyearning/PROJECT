#include "stdafx.h"
#include <math.h>
#include "matlabWrapper.h"
#include "skeletonCtrl.h"
extern Engine* g_pMatlabEngine;
extern int g_iJointNum;
extern double g_fRootPos[3];
extern double g_fGoalPos[3];
extern double g_arJointRotations[5];
extern double g_arLinkLengths[5];
extern double g_mxJointPositions[6][3];
extern double g_mxJacobian[3][5];
extern double g_mxJacobianPseudoInv[5][3];
double g_fK = 0.035;
double g_fK2 = 1/0.035;

#include <vector>
struct PPOS
{
	double X;
	double Y;
	double Z;
};
std::vector<PPOS> g_vGhostPos;
std::vector<PPOS> g_vGhostPosJ1;
std::vector<PPOS> g_vGhostPosJ2;
std::vector<PPOS> g_vGhostPosJ3;
std::vector<PPOS> g_vGhostPosJ4;
std::vector<PPOS> g_vGhostPosJ5;
bool g_bGhost = false;

int	main_window;
float eye[3];
float lookat[3];

#define CB_DEPTH_BUFFER 0
#define CB_ACTION_BUTTON 1
#define CB_RESET 2

GLfloat step = 0;
#define METERS 7
float gX, gY;
double px[6],py[6];
int winWidth,winHeight;     // window (x,y) size
bool showGrid    = true;
float pixPerMeter = 100.0;
double seye[3] = {0.5,0.5,10};
double at[3]  = {0.5,0.5,0};
double up[3]  = {0.0,1.0,0.0};


int g_iCount = 0;
void myCallback(int iID)
{
	g_iCount ++;
	ReachGoalOneStep();
	
	//keep track of ghost
	PPOS pos;
	pos.X = g_mxJointPositions[5][0];
	pos.Y = g_mxJointPositions[5][1];
	pos.Z = g_mxJointPositions[5][2];
	g_vGhostPos.push_back(pos);

	pos.X = g_mxJointPositions[0][0];
	pos.Y = g_mxJointPositions[0][1];
	pos.Z = g_mxJointPositions[0][2];
	g_vGhostPosJ1.push_back(pos);

	pos.X = g_mxJointPositions[1][0];
	pos.Y = g_mxJointPositions[1][1];
	pos.Z = g_mxJointPositions[1][2];
	g_vGhostPosJ2.push_back(pos);

	pos.X = g_mxJointPositions[2][0];
	pos.Y = g_mxJointPositions[2][1];
	pos.Z = g_mxJointPositions[2][2];
	g_vGhostPosJ3.push_back(pos);

	pos.X = g_mxJointPositions[3][0];
	pos.Y = g_mxJointPositions[3][1];
	pos.Z = g_mxJointPositions[3][2];
	g_vGhostPosJ4.push_back(pos);

	pos.X = g_mxJointPositions[4][0];
	pos.Y = g_mxJointPositions[4][1];
	pos.Z = g_mxJointPositions[4][2];
	g_vGhostPosJ5.push_back(pos);

	if(g_iCount < 100)
		glutTimerFunc(50, myCallback, 31);
	else 
		g_iCount = 0;
}

void reset() {
  showGrid    = true;
  pixPerMeter = 100.0;
  winWidth = winHeight = (int)(pixPerMeter*METERS);
}


void setCamera() {
  glViewport(0,0, winWidth,winHeight);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(-winWidth /2/pixPerMeter*.9, winWidth /2/pixPerMeter*.9,
	         -winHeight/2/pixPerMeter*.9, winHeight/2/pixPerMeter*.9, 9, 11);
}
void drawCoordGrid() {
  glBegin(GL_LINES);
  glLineWidth(2);
  glColor3f(0,0,0);
  glVertex2d(-3,2);
  glVertex2d(4,2);
  glEnd();
}

extern void drawArm();
void drawArm()
{
  glColor3f(.1f,.5f,.1f);
  //glLineWidth(5);

  //glTranslatef(.8,1.5,0);
  //drawCuboid(0,0,0,0.2,0.5,0.2);  
  for(int i = 0; i < 5; ++i)
  {
	  //joint
	  glTranslatef(g_mxJointPositions[i][0] * g_fK, g_mxJointPositions[i][1] * g_fK, 0);
	  glutSolidSphere(0.05, 9, 9);
	  glTranslatef(-g_mxJointPositions[i][0] * g_fK, -g_mxJointPositions[i][1] * g_fK, 0);

	  /*glBegin(GL_POINTS);
	  glVertex3f(g_mxJointPositions[i][0] * g_fK, g_mxJointPositions[i][1] * g_fK, 0);
	  glEnd();*/

	  //link
	  glBegin(GL_LINES);
	  glVertex3f(g_mxJointPositions[i][0] * g_fK, g_mxJointPositions[i][1] * g_fK, 0);
	  glVertex3f(g_mxJointPositions[i+1][0] * g_fK, g_mxJointPositions[i+1][1] * g_fK, 0);
	  glEnd();
  }

  if(true)
  {
	  glColor3f(1.0f, .5f, .5f);
	  glBegin(GL_LINE_STRIP);
	  for(int i = 0; i < g_vGhostPos.size(); ++i)
		  glVertex3f(g_vGhostPos[i].X * g_fK, g_vGhostPos[i].Y * g_fK, 0);
	  glEnd();

	  glColor3f(.5f, .8f, .5f);
	  for(int i = 0; i < g_vGhostPos.size(); ++i)
	  {
		  glBegin(GL_LINE_STRIP);
		  glVertex3f(g_vGhostPosJ1[i].X * g_fK, g_vGhostPosJ1[i].Y * g_fK, 0);
		  glVertex3f(g_vGhostPosJ2[i].X * g_fK, g_vGhostPosJ2[i].Y * g_fK, 0);
		  glVertex3f(g_vGhostPosJ3[i].X * g_fK, g_vGhostPosJ3[i].Y * g_fK, 0);
		  glVertex3f(g_vGhostPosJ4[i].X * g_fK, g_vGhostPosJ4[i].Y * g_fK, 0);
		  glVertex3f(g_vGhostPosJ5[i].X * g_fK, g_vGhostPosJ5[i].Y * g_fK, 0);
		  glVertex3f(g_vGhostPos[i].X * g_fK, g_vGhostPos[i].Y * g_fK, 0);
		  glEnd();
	  }
  }
  glFlush();
}



void normalize(float v[3])
{
	float l = v[0]*v[0] + v[1]*v[1] + v[2]*v[2];
	l = 1 / (float)sqrt(l);

	v[0] *= l;
	v[1] *= l;
	v[2] *= l;
}

void crossproduct(float a[3], float b[3], float res[3])
{
	res[0] = (a[1] * b[2] - a[2] * b[1]);
	res[1] = (a[2] * b[0] - a[0] * b[2]);
	res[2] = (a[0] * b[1] - a[1] * b[0]);
}

float length(float v[3])
{
	return (float)sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
}


void myGlutIdle(void)
{
	// make sure the main window is active
	if (glutGetWindow() != main_window)
		glutSetWindow(main_window);

	// if you have moving objects, you can do that here

	// just keep redrawing the scene over and over
	glutPostRedisplay();
}


// mouse handling functions for the main window
// left mouse translates, middle zooms, right rotates
// keep track of which button is down and where the last position was
int cur_button = -1;
int last_x;
int last_y;

// catch mouse up/down events
void myGlutMouse(int button, int state, int x, int y)
{
	if (state == GLUT_DOWN)
		cur_button = button;
	else
	{
		if (button == cur_button)
			cur_button = -1;
	}

	last_x = x;
	last_y = y;

	
  gX = ((float)(x))/winWidth * METERS - 3;
  gY = (-((float)(y))/winHeight * METERS)+ 4;

  // Leave the following call in place.  It tells GLUT that
  // we've done something, and that the window needs to be
  // re-drawn.  GLUT will call display().
  //	
	if(state == GLUT_DOWN)
	{
		g_fGoalPos[0] = gX * g_fK2;
		g_fGoalPos[1] = gY * g_fK2;
		g_vGhostPos.clear();
		g_vGhostPosJ1.clear();
		g_vGhostPosJ2.clear();
		g_vGhostPosJ3.clear();
		g_vGhostPosJ4.clear();
		g_vGhostPosJ5.clear();
		glutTimerFunc(50, myCallback, 31);
	}
	glutPostRedisplay();

}

void myGlutMotion(int x, int y)
{
	// the change in mouse position
	int dx = x-last_x;
	int dy = y-last_y;

	float scale, len, theta;
	float neye[3], neye2[3];
	float f[3], r[3], u[3];

	switch(cur_button)
	{
	case GLUT_LEFT_BUTTON:

		break;

	case GLUT_MIDDLE_BUTTON:
		break;

	case GLUT_RIGHT_BUTTON:

		break;
	}


	last_x = x;
	last_y = y;

	glutPostRedisplay();
}


void myGlutKeyboard(unsigned char key, int x, int y)
{
	switch(key)
	{
	// quit
	case 27: 
	case 'q':
	case 'Q':
		exit(0);
		break;
	}

	glutPostRedisplay();
}

void myGlutReshape(int	x, int y)
{
	int tx, ty, tw, th;
	GLUI_Master.get_viewport_area(&tx, &ty, &tw, &th);
	glViewport(tx, ty, tw, th);

	glutPostRedisplay();
}


void myGlutDisplay(	void )
{
  setCamera();
  glClearColor(.90f,.90f, .9f,1.f);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  gluLookAt(seye[0],seye[1],seye[2],  at[0],at[1],at[2],  up[0],up[1],up[2]);
  glColor3f(1.0f, 1.0f, 0.0f);
  glColor3f(0.0f, 0.0f, 0.0f);
  glPointSize(10);
  glColor3f(1.0,0,0);
  glBegin(GL_POINTS);
  glVertex2f(gX,gY);
  glEnd();
  drawArm();
  glFlush();
  glutSwapBuffers();
}

void glui_cb(int control)
{
	switch(control)
	{
	case CB_DEPTH_BUFFER:
	case CB_ACTION_BUTTON:
		break;
	}

	glutPostRedisplay();
}


int _tmain(int argc, _TCHAR* argv[])
{
	if(!(g_pMatlabEngine = engOpen(NULL)))
		return 0;

	UpdateJointPositionsFromRotations();
	reset();
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowPosition (0, 0);
	glutInitWindowSize(winWidth,winHeight);
	main_window = glutCreateWindow("IK Canvas");
	glutDisplayFunc(myGlutDisplay);
	GLUI_Master.set_glutReshapeFunc(myGlutReshape);
	GLUI_Master.set_glutIdleFunc(myGlutIdle);
	GLUI_Master.set_glutKeyboardFunc(myGlutKeyboard);
	GLUI_Master.set_glutMouseFunc(myGlutMouse);
	glutTimerFunc(50, myCallback, 31);
	glutMotionFunc(myGlutMotion);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_COLOR_MATERIAL);
	glutMainLoop();
}
















