#include "stdafx.h"
#include "skeletonCtrl.h"
#include <math.h>

extern void drawArm();

extern Engine* g_pMatlabEngine = NULL;
extern int g_iJointNum = 5;
extern double g_fRootPos[3] = {0, 0, 0};
extern double g_fGoalPos[3] = {0, 0, 0};
extern double g_arJointRotations[5] = {5, 5, 5, 5, 5};
extern double g_arLinkLengths[5] = {14, 27, 22, 7, 8};
extern double g_mxJointPositions[6][3] = {0, 0, 0, 14, 0, 0, 41, 0, 0, 63, 0, 0, 70, 0, 0, 78, 0, 0};
extern double g_mxJacobian[3][5] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
extern double g_mxJacobianPseudoInv[5][3] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

void UpdateJointPositionsFromRotations()
{
	double fBase[3] = {0, 0, 0};
	for(int i = 0; i < g_iJointNum; ++i)
	{
		double fRotation = g_arJointRotations[i];
		double fLength = g_arLinkLengths[i];

		double fPosition[3] = {cos(fRotation) * fLength, sin(fRotation) * fLength, 0};
		fPosition[0] = fPosition[0] + fBase[0];
		fPosition[1] = fPosition[1] + fBase[1];
		fPosition[2] = fPosition[2] + fBase[2];

		g_mxJointPositions[i+1][0] = fPosition[0];
		g_mxJointPositions[i+1][1] = fPosition[1];
		g_mxJointPositions[i+1][2] = fPosition[2];

		fBase[0] = fPosition[0];
		fBase[1] = fPosition[1];
		fBase[2] = fPosition[2];
	}
}

void InitJacobian()
{
	for(int i = 0; i < 3; ++ i)
		for(int j = 0; j < 5; ++ j)
			g_mxJacobian[i][j] = 0;
}
void UpdateJacobian()
{
	//set Jacobian to zeros
	InitJacobian();

	//get end effect position
	double fEndPos[3] = {0, 0, 0};
	fEndPos[0] = g_mxJointPositions[5][0];
	fEndPos[1] = g_mxJointPositions[5][1];
	fEndPos[2] = g_mxJointPositions[5][2];

	//calculate (E - P)
	double mxE2P[5][3] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	for(int i = 0; i < 5; ++i)
	{
		double fJointPos[3] = {0, 0, 0};
		fJointPos[0] = g_mxJointPositions[i][0];
		fJointPos[1] = g_mxJointPositions[i][1];
		fJointPos[2] = g_mxJointPositions[i][2];

		mxE2P[i][0] = fEndPos[0] - fJointPos[0];
		mxE2P[i][1] = fEndPos[1] - fJointPos[1];
		mxE2P[i][2] = fEndPos[2] - fJointPos[2];
	}

	//calculate Jacobian
	for(int i = 0; i < 5; ++i)
	{
		double fRotationAxis[3] = {0, 0, 1};//a
		
		double fE2P[3] = {0, 0, 0};//b
		fE2P[0] = mxE2P[i][0];
		fE2P[1] = mxE2P[i][1];
		fE2P[2] = mxE2P[i][2];

		//cross product a x b = (a1b2 - a2b1, a2b0 - a0b2, a0b1 - a1b0)
		g_mxJacobian[0][i] = fRotationAxis[1] * fE2P[2] - fRotationAxis[2] * fE2P[1];
		g_mxJacobian[1][i] = fRotationAxis[2] * fE2P[0] - fRotationAxis[0] * fE2P[2];
		g_mxJacobian[2][i] = fRotationAxis[0] * fE2P[1] - fRotationAxis[1] * fE2P[0];
	}
}


void InitJacobianPseudoInv()
{
	for(int i = 0; i < 5; ++ i)
		for(int j = 0; j < 3; ++ j)
			g_mxJacobianPseudoInv[i][j] = 0;
}
void UpdateJacobianPseudoInv()
{
	InitJacobianPseudoInv();

	//Jacobian without z
	double fJacobian[2][5] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	for(int i = 0; i < 2; ++i)
		for(int j = 0; j < 5; ++j)
			fJacobian[i][j] = g_mxJacobian[i][j];

	//Jacobian transpose
	double fJacobianTrans[5][2] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	for(int i = 0; i < 2; ++i)
		for(int j = 0; j < 5; ++j)
			fJacobianTrans[j][i] = fJacobian[i][j];

	//multiplication JJ'
	double fJJt[2][2] = {0, 0, 0, 0};
	for(int i = 0; i < 2; ++ i)
		for(int j = 0; j < 2; ++j)
			for(int k = 0; k < 5; ++k)
				fJJt[i][j] += fJacobian[i][k] * fJacobianTrans[k][j];

	//inverse of JJ' - call matlab
	double fJJt_inv[2][2] = {0, 0, 0, 0};	
	mxArray *pMxJJt = mxCreateDoubleMatrix(2, 2, mxREAL);
	mxSetClassName(pMxJJt, "JJt");
	memcpy((char*)mxGetPr(pMxJJt), (char*)fJJt, 4*sizeof(double));
	engPutVariable(g_pMatlabEngine, "JJt", pMxJJt);
	char buffer[200];
	engOutputBuffer(g_pMatlabEngine, buffer, 200);
	engEvalString(g_pMatlabEngine, "JJt=inv(JJt)");
	mxArray * pMxJJt_inv = engGetVariable(g_pMatlabEngine, "JJt");
	memcpy((char*)fJJt_inv, (char*)mxGetPr(pMxJJt_inv), 4*sizeof(double));
	mxDestroyArray(pMxJJt);
	mxDestroyArray(pMxJJt_inv);

	//multiplication J' * dJJt_inv
	for(int i = 0; i < 5; ++i)
		for(int j = 0; j < 2; ++j)
			for(int k = 0; k < 2; ++k)
				g_mxJacobianPseudoInv[i][j] += fJacobianTrans[i][k] * fJJt_inv[k][j];
}

void Visualize()
{
	//wangyy drawArm();
}

void ReachGoalOneStep()
{
	UpdateJointPositionsFromRotations();

	//get end effector position
	double fEndPos[3] = {0, 0, 0};
	fEndPos[0] = g_mxJointPositions[5][0];
	fEndPos[1] = g_mxJointPositions[5][1];
	fEndPos[2] = g_mxJointPositions[5][2];

	double fDeltaPos[3] = {0, 0, 0};
	fDeltaPos[0] = g_fGoalPos[0] - fEndPos[0];
	fDeltaPos[1] = g_fGoalPos[1] - fEndPos[1];
	fDeltaPos[2] = g_fGoalPos[2] - fEndPos[2];
	double fDeltaDist = sqrt(fDeltaPos[0]*fDeltaPos[0] + fDeltaPos[1] * fDeltaPos[1]);

	double fK = 0.2;
	//calculate Jacobian and pseudo inverse
	UpdateJacobian();
	UpdateJacobianPseudoInv();

	//calculate delta angle from delta s
	fDeltaPos[0] = fK * fDeltaPos[0];
	fDeltaPos[1] = fK * fDeltaPos[1];
	fDeltaPos[2] = fK * fDeltaPos[2];

	//delta angle = J_plus * V
	double fDeltaAngle[5] = {0, 0, 0, 0, 0};
	for(int i = 0; i < 5; ++i)
		for(int k = 0; k < 3; ++k)
			fDeltaAngle[i] += g_mxJacobianPseudoInv[i][k] * fDeltaPos[k];
		
	//update rotations
	for(int i = 0; i < 5; ++i)
		g_arJointRotations[i] += fDeltaAngle[i];

	//update position and visualize
	UpdateJointPositionsFromRotations();
}
void ReachGoal()
{
	UpdateJointPositionsFromRotations();
	Visualize();

	//get end effector position
	double fEndPos[3] = {0, 0, 0};
	fEndPos[0] = g_mxJointPositions[5][0];
	fEndPos[1] = g_mxJointPositions[5][1];
	fEndPos[2] = g_mxJointPositions[5][2];

	double fDeltaPos[3] = {0, 0, 0};
	fDeltaPos[0] = g_fGoalPos[0] - fEndPos[0];
	fDeltaPos[1] = g_fGoalPos[1] - fEndPos[1];
	fDeltaPos[2] = g_fGoalPos[2] - fEndPos[2];
	double fDeltaDist = sqrt(fDeltaPos[0]*fDeltaPos[0] + fDeltaPos[1] * fDeltaPos[1]);

	double fK = 0.1;
	int iCount = 0;
	while(fDeltaDist > 0.01)
	{
		ReachGoalOneStep();
		
		//recalculate current end effector position
		fEndPos[0] = g_mxJointPositions[5][0];
		fEndPos[1] = g_mxJointPositions[5][1];
		fEndPos[2] = g_mxJointPositions[5][2];

		fDeltaPos[0] = g_fGoalPos[0] - fEndPos[0];
		fDeltaPos[1] = g_fGoalPos[1] - fEndPos[1];
		fDeltaPos[2] = g_fGoalPos[2] - fEndPos[2];
		fDeltaDist = sqrt(fDeltaPos[0]*fDeltaPos[0] + fDeltaPos[1] * fDeltaPos[1]);

		//convergence control
		iCount ++;		
		if(iCount > 3000)
			break;
	}
	if(iCount > 3000)
		return;
}
/*
void ReachGoal()
{
	UpdateJointPositionsFromRotations();
	Visualize();

	//get end effector position
	double fEndPos[3] = {0, 0, 0};
	fEndPos[0] = g_mxJointPositions[5][0];
	fEndPos[1] = g_mxJointPositions[5][1];
	fEndPos[2] = g_mxJointPositions[5][2];

	double fDeltaPos[3] = {0, 0, 0};
	fDeltaPos[0] = g_fGoalPos[0] - fEndPos[0];
	fDeltaPos[1] = g_fGoalPos[1] - fEndPos[1];
	fDeltaPos[2] = g_fGoalPos[2] - fEndPos[2];
	double fDeltaDist = sqrt(fDeltaPos[0]*fDeltaPos[0] + fDeltaPos[1] * fDeltaPos[1]);

	double fK = 0.1;
	int iCount = 0;
	while(fDeltaDist > 0.01)
	{
		//calculate Jacobian and pseudo inverse
		UpdateJacobian();
		UpdateJacobianPseudoInv();

		//calculate delta angle from delta s
		fDeltaPos[0] = fK * fDeltaPos[0];
		fDeltaPos[1] = fK * fDeltaPos[1];
		fDeltaPos[2] = fK * fDeltaPos[2];

		//delta angle = J_plus * V
		double fDeltaAngle[5] = {0, 0, 0, 0, 0};
		for(int i = 0; i < 5; ++i)
			for(int k = 0; k < 3; ++k)
				fDeltaAngle[i] += g_mxJacobianPseudoInv[i][k] * fDeltaPos[k];
		
		//update rotations
		for(int i = 0; i < 5; ++i)
			g_arJointRotations[i] += fDeltaAngle[i];

		//update position and visualize
		UpdateJointPositionsFromRotations();
		Visualize();
		//wangyy zhe ge di fang ke bu ke yi ting yi ting
		
		//recalculate current end effector position
		fEndPos[0] = g_mxJointPositions[5][0];
		fEndPos[1] = g_mxJointPositions[5][1];
		fEndPos[2] = g_mxJointPositions[5][2];

		fDeltaPos[0] = g_fGoalPos[0] - fEndPos[0];
		fDeltaPos[1] = g_fGoalPos[1] - fEndPos[1];
		fDeltaPos[2] = g_fGoalPos[2] - fEndPos[2];
		fDeltaDist = sqrt(fDeltaPos[0]*fDeltaPos[0] + fDeltaPos[1] * fDeltaPos[1]);

		//convergence control
		iCount ++;		
		if(iCount > 3000)
			break;
	}
	if(iCount > 3000)
		return;
}*/