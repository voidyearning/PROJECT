package wangUI;

import javax.media.opengl.GL;

public interface wangGLDrawListener {

	public void onDraw(GL gl);
}
