package wangUI;

import java.util.HashMap;

import javax.media.opengl.GL;
import javax.vecmath.Matrix4d;
import javax.vecmath.Point3d;
import javax.vecmath.Tuple3d;
import javax.vecmath.Vector3d;

import mrl.motion.data.FootContactDetection;
import mrl.motion.data.HumanInertia;
import mrl.motion.data.Motion;
import mrl.motion.data.SkeletonData;
import mrl.motion.data.SkeletonData.Joint;
import mrl.motion.viewer.SWTViewableCanvas;

import org.eclipse.swt.widgets.Composite;

import wang.WAMCMotionFrame;
import wang.WASFSkeleton;
import wang.WAmcFrame;
import wang.WASFJoint;
import wang.WAmcFile;

public abstract class wangMotionAnimator extends wangViewableCanvas{
	
	public static boolean drawDarkBorder = false;
	protected Vector3d skeletonColor = new Vector3d(0.8, 0.8, 0.8);
//	protected Vector3d skeletonColor = new Vector3d(0.9, 0.4, 0.4);
	protected Vector3d footColor = null;
//	protected Vector3d footColor = new Vector3d(0.4, 0.9, 0.4);
	protected Vector3d headColor = null;
	protected double scale = 1;
	
	protected Point3d extraPoint;
	protected boolean showExtraPoint = true;
	
	protected double boneThickness = 1.5;
	protected Vector3d clearColor = new Vector3d(1, 1, 1);
	
	protected int animationIndex;
	
	protected boolean drawBox = true;

	public wangMotionAnimator(Composite parent) {
		super(parent);
	}
	
	public void setClearColor(Vector3d clearColor) {
		this.clearColor = clearColor;
	}

	public double getScale() {
		return scale;
	}
	
	public void setBoneThickness(double boneThickness) {
		this.boneThickness = boneThickness;
	}

	public void setScale(double scale) {
		this.scale = scale;
	}

	public Vector3d getSkeletonColor() {
		return skeletonColor;
	}

	public void setSkeletonColor(Vector3d skeletonColor) {
		this.skeletonColor = skeletonColor;
	}

	public void setExtraPoint(Point3d extraPoint) {
		this.extraPoint = extraPoint;
	}
	
	public int getAnimationIndex() {
		return animationIndex;
	}

	public void setAnimationIndex(int animationIndex) {
		this.animationIndex = animationIndex;
	}

	@Override
	protected void drawObjects() {
		gl.glClearColor((float)backgroundColor, (float)backgroundColor, (float)backgroundColor, 1);
//		gl.glClearColor((float)clearColor.x, (float)clearColor.y, (float)clearColor.z, 1);
		drawPlane();
		
		gl.glEnable(GL.GL_DEPTH_TEST);
		gl.glLineWidth(3);
		gl.glPushMatrix();
		gl.glScaled(scale, scale, scale);
		
		drawObjectsImpl();
		
		gl.glPopMatrix();
	}
	
	protected abstract void drawObjectsImpl();
	
	
	protected void drawMotionByBox(SkeletonData skeletonData, Motion motion){
		HashMap<String, Matrix4d> transMap = Motion.getTransformData(skeletonData, motion);
		for (Joint joint : skeletonData.values()){
			if (joint.parent == null) continue;
			Matrix4d m = transMap.get(joint.parent.name);
			if (m == null) continue;
			gl.glPushMatrix();
			
			boolean isRoot = joint == skeletonData.root;
			gl.glMultMatrixd(new double[]{
					m.m00, m.m10, m.m20, m.m30,
					m.m01, m.m11, m.m21, m.m31,
					m.m02, m.m12, m.m22, m.m32,
					m.m03, m.m13, m.m23, m.m33,
			}, 0);
			
			boolean pass = (isRoot && joint.length > 0) || (joint.name.equals("pelvis") && joint.length > 0) ;
			pass |= HumanInertia.isPass(joint.name);
			if (!pass && (joint.length != 0)){
				HumanInertia inertia = HumanInertia.get(joint.parent.name);
				if (inertia != null && inertia.mass > 0){
					Point3d t = new Point3d(joint.transition);
					t.scale(0.5);
					Matrix4d rotMatrix = new Matrix4d();
					rotMatrix.set(inertia.rotation);
					
					if (joint.name.equals("Head")){
//						rotMatrix.setIdentity();
//						gl.glTranslated(t.x, t.y, t.z);
						t.scale(0);
//						t.scale(-1);
						rotMatrix.invert();
//						rotMatrix.rotZ(Math.toRadians(90));
					} else if (joint.parent.name.equals("Spine1")){
						t.scale(0.7/0.5);
					}
					gl.glTranslated(t.x, t.y, t.z);
					
					gl.glMultMatrixd(new double[]{
							rotMatrix.m00, rotMatrix.m10, rotMatrix.m20, rotMatrix.m30,
							rotMatrix.m01, rotMatrix.m11, rotMatrix.m21, rotMatrix.m31,
							rotMatrix.m02, rotMatrix.m12, rotMatrix.m22, rotMatrix.m32,
							rotMatrix.m03, rotMatrix.m13, rotMatrix.m23, rotMatrix.m33,
					}, 0);
					Vector3d s = inertia.inertiaSize;
					gl.glScaled(s.x,s.y,s.z);
					glut.glutSolidCube(1);
					
					if (!isShadowMode){
						if (drawDarkBorder){
							gl.glDisable(GL.GL_LIGHTING);
							gl.glDisable(GL.GL_BLEND);
							gl.glLineWidth(0.5f);
							gl.glColor3d(0.2, 0.2, 0.2);
							glut.glutWireCube(1.01f);
							gl.glColor3d(0.85, 0.85, 0.85);
							gl.glEnable(GL.GL_LIGHTING);
							gl.glEnable(GL.GL_BLEND);
						} else {
							gl.glLineWidth(2);
							gl.glDisable(GL.GL_LIGHTING);
							glut.glutWireCube(1.01f);
							gl.glEnable(GL.GL_LIGHTING);
						}
					}
				}
			}
			
			gl.glPopMatrix();
		}
	}
	
	protected void drawMotion(SkeletonData skeletonData, Motion motion, boolean drawShadow)
	{
		if (motion == null) return;
		
		/*if (drawBox)
		{
			if (drawShadow)
			{
				setupShadow();
				drawMotionByBox(skeletonData, motion);
				unsetupShadow();
				gl.glColor4d(skeletonColor.x, skeletonColor.y, skeletonColor.z, 1);
				drawMotionByBox(skeletonData, motion);
			} else 
			{
				gl.glColor4d(skeletonColor.x, skeletonColor.y, skeletonColor.z, 1);
				drawMotionByBox(skeletonData, motion);
			}
		} 
		else  */
		{
			if (drawShadow)
			{
				setupShadow();
				drawBone(skeletonData.root, motion, true);
				unsetupShadow();
				gl.glColor4d(skeletonColor.x, skeletonColor.y, skeletonColor.z, 1);
				drawBone(skeletonData.root, motion, true);
			} 
			else 
			{
				drawBone(skeletonData.root, motion, true);
			}
		}
	}
	
	protected void drawBone(Joint joint, Motion motion, boolean isRoot)
	{
		gl.glPushMatrix();
		
		boolean isFoot = (motion.isLeftFootContact && FootContactDetection.isLeftFoot(joint.name)) || (motion.isRightFootContact && FootContactDetection.isRightFoot(joint.name));
		if (isFoot && !isShadowMode && footColor != null)
		{
			gl.glColor3d(footColor.x, footColor.y, footColor.z);
		}
		boolean isHead = (headColor != null) && FootContactDetection.isHead(joint.name);
		if (isHead && !isShadowMode)
		{
			gl.glColor3d(headColor.x, headColor.y, headColor.z);
		}
		
		Matrix4d m = motion.get(joint.name);		
		if (motion.isRotateFirst && m != null)
		{
			gl.glMultMatrixd(new double[]{
					m.m00, m.m10, m.m20, m.m30,
					m.m01, m.m11, m.m21, m.m31,
					m.m02, m.m12, m.m22, m.m32,
					m.m03, m.m13, m.m23, m.m33,
			}, 0);
		}
		
		boolean pass = (isRoot && joint.length > 0) || (joint.name.equals("pelvis") && joint.length > 0) ;
		if (!pass && (joint.length != 0))
		{
			Point3d b0 = new Point3d();
			Point3d b1 = new Point3d(joint.transition);
			drawLine(b0, b1, boneThickness);
			gl.glTranslated(joint.transition.x, joint.transition.y, joint.transition.z);
			glut.glutSolidSphere((boneThickness + 0.05)/scale, 20, 20);
		}
		
		if (!motion.isRotateFirst && m != null)
		{
			if (isRoot || joint.name.equals("pelvis"))
			{
				gl.glMultMatrixd(new double[]{
						m.m00, m.m10, m.m20, m.m30,
						m.m01, m.m11, m.m21, m.m31,
						m.m02, m.m12, m.m22, m.m32,
						m.m03, m.m13, m.m23, m.m33,
				}, 0);
			} 
			else 
			{
				gl.glMultMatrixd(new double[]{
						m.m00, m.m10, m.m20, m.m30,
						m.m01, m.m11, m.m21, m.m31,
						m.m02, m.m12, m.m22, m.m32,
						0, 0, 0, m.m33,
				}, 0);
			}
		}
		
		if (isFoot && !isShadowMode)
		{
			gl.glColor3d(skeletonColor.x, skeletonColor.y, skeletonColor.z);
		}
		if (isHead && !isShadowMode)
		{
			gl.glColor3d(skeletonColor.x, skeletonColor.y, skeletonColor.z);
		}
		
		for (Joint child : joint.children)
		{
			drawBone(child, motion, false);
		}
		gl.glPopMatrix();
		
	}
	protected void drawAmcInAmc(WAMCMotionFrame amcFrame, WASFSkeleton asf)
	{
		gl.glColor4d(skeletonColor.x, skeletonColor.y, skeletonColor.z, 1);
		WASFJoint [] arJoint = asf.GetAllJoints();
		for(WASFJoint joint : arJoint)
		{
			String strKey = joint.m_strName;
			WAMCMotionFrame.WAMCLinkPos posLink = amcFrame.m_mapWorldPos.get(strKey);
			Point3d posParentW = new Point3d(posLink.m_vPos);
			Point3d posChildW = new Point3d(posLink.m_vPosEnd);

			/*gl.glPushMatrix();
			gl.glTranslated(posParentW.x, posParentW.y, posParentW.z);
			glut.glutSolidSphere((boneThickness + 0.05)/scale, 20, 20);
			gl.glPopMatrix();
			
			gl.glPushMatrix();
			gl.glTranslated(posChildW.x, posChildW.y, posChildW.z);
			glut.glutSolidSphere((boneThickness + 0.05)/scale, 20, 20);
			gl.glPopMatrix();*/
			
			drawLineCube(posChildW, posParentW);
		}		
	}
	
	protected void drawAmcInAsf(WAMCMotionFrame amcFrame, WASFSkeleton asf)
	{
		asf.ApplyAmcRotation(amcFrame);
		gl.glColor4d(skeletonColor.x, skeletonColor.y, skeletonColor.z, 1);
		WASFJoint [] arJoint = asf.GetAllJoints();
		for(WASFJoint joint : arJoint)
		{
			Point3d posParentW = new Point3d(joint.m_vPosWorld);
			Point3d posChildW = new Point3d(joint.m_vEndPosWorld);

			gl.glPushMatrix();
			gl.glTranslated(posParentW.x, posParentW.y, posParentW.z);
			glut.glutSolidSphere((boneThickness + 0.05)/scale, 20, 20);
			gl.glPopMatrix();
			
			gl.glPushMatrix();
			gl.glTranslated(posChildW.x, posChildW.y, posChildW.z);
			glut.glutSolidSphere((boneThickness + 0.05)/scale, 20, 20);
			gl.glPopMatrix();
			
			drawLine(posChildW, posParentW);
		}		
	}
	protected void drawAsf(WASFSkeleton asf)
	{
		gl.glColor4d(skeletonColor.x, skeletonColor.y, skeletonColor.z, 1);
		WASFJoint [] arJoint = asf.GetAllJoints();
		for(WASFJoint jtChild : arJoint)
		{
			if(jtChild.m_strName.indexOf("root")>=0)
				continue;
			
			Point3d posChildW = new Point3d(jtChild.m_vPosWorld);
			Point3d posParentW = new Point3d(jtChild.m_jtParent.m_vPosWorld);

			gl.glPushMatrix();
			gl.glTranslated(posParentW.x, posParentW.y, posParentW.z);
			glut.glutSolidSphere((boneThickness + 0.05)/scale, 20, 20);
			gl.glPopMatrix();
			drawLine(posChildW, posParentW);
		}		
	}
	
	protected void glNormal(Tuple3d n){
		gl.glNormal3d(n.x, n.y, n.z);
	}
	protected void glVertex(Tuple3d n, Tuple3d base){
		gl.glVertex3d(n.x - base.x, n.y - base.y, n.z - base.z);
	}
	protected void glNormalInverse(Vector3d normal){
		gl.glNormal3d(-normal.x, -normal.y, -normal.z);
	}
	
	protected void drawLine(Point3d p0, Point3d p1){
		drawLine(p0, p1, boneThickness);
	}
	
	protected void drawLine(Point3d p0, Point3d p1, double radius){
		gl.glPushMatrix();
		Vector3d v = new Vector3d();
		v.sub(p1, p0);
		double len = v.length();
		Vector3d base = new Vector3d(0, 0, 1);
		Vector3d cross = new Vector3d();
		cross.cross(base, v);
		if (Double.isNaN(cross.x)){
			cross = new Vector3d(0, 1, 0);
		}
		double angle = base.angle(v);
		gl.glTranslated(p0.x, p0.y, p0.z);
		gl.glRotated(Math.toDegrees(angle), cross.x, cross.y, cross.z);
		glut.glutSolidCylinder(radius/scale, len, 20, 20);
		gl.glPopMatrix();
	}
	protected void drawLineCube(Point3d p0, Point3d p1){
		gl.glPushMatrix();
		Vector3d v = new Vector3d();
		v.sub(p1, p0);
		double len = v.length();
		Vector3d base = new Vector3d(0, 0, 1);
		Vector3d cross = new Vector3d();
		cross.cross(base, v);
		if (Double.isNaN(cross.x)){
			cross = new Vector3d(0, 1, 0);
		}
		double angle = base.angle(v);
		gl.glTranslated((p0.x+p1.x)/2, (p0.y+p1.y)/2, (p0.z+p1.z)/2);
		gl.glRotated(Math.toDegrees(angle), cross.x, cross.y, cross.z);
		gl.glScaled(10, 10, len);
		glut.glutSolidCube(1);
		gl.glPopMatrix();
	}

	@Override
	protected void init() {
		eye = new Vector3d(9.520614748512969, 33.17744437502335, -118.75228792662163);
		center = new Vector3d(2.0815837310808516, 17.552613310215943, 0.43831337277316645);
		upVector = new Vector3d(0.030228875954434634, 0.9921753292113596, -0.12113765377807954);
		Vector3d diff = new Vector3d();
		diff.sub(center, eye);	
		diff.scale(2.5);
		diff.y = 5;
		eye.add(diff);
	}
	
	@Override
	protected void initBasic(){
		gl.glEnable(GL.GL_DEPTH_TEST);
		gl.glEnable(GL.GL_NORMALIZE);
		gl.glEnable(GL.GL_SMOOTH);
		gl.glEnable(GL.GL_LIGHTING);
		float ambient = 0.2f;
		float diffuse = 0.6f;
		float spec = 0.7f;
		float[] ambientLight = { ambient, ambient, ambient, 1.0f };
		float[] diffuseLight = { diffuse, diffuse, diffuse, 1.0f };
		float[] specular = { spec, spec, spec, 1 };
		float[] position = { 15, 15, 15, 1 };
		gl.glLightfv(GL.GL_LIGHT0, GL.GL_AMBIENT, ambientLight, 0);
		gl.glLightfv(GL.GL_LIGHT0, GL.GL_DIFFUSE, diffuseLight, 0);
		gl.glLightfv(GL.GL_LIGHT0, GL.GL_SPECULAR, specular, 0);
		gl.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION, position, 0);
		gl.glEnable(GL.GL_LIGHT0);
		gl.glEnable(GL.GL_COLOR_MATERIAL);
		gl.glColorMaterial(GL.GL_FRONT, GL.GL_AMBIENT_AND_DIFFUSE);
		gl.glMateriali(GL.GL_FRONT, GL.GL_SHININESS, 32);
		
		gl.glShadeModel(GL.GL_SMOOTH);
	}

}
