package wangUI;

//This is a wrapper of wangMultiCharacterViewer (by using its as IMP)
//This inherits wangAnimationPlayer, 
//which is the frame, it has API and IMP for mouse and key response, play button
import javax.vecmath.Vector3d;

import mrl.motion.data.MotionData;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import wang.WAMCMotion;
import wang.WAmcFile;

public class wangMultiCharacterNavigator extends wangAnimationPlayer{
	
	public static Vector3d basicColor = new Vector3d(0.8, 0.8, 0.8);
	public static Vector3d selectedColor = new Vector3d(1, 0.8, 0.7);
	
	private wangMultiCharacterViewer viewer;

	public wangMultiCharacterNavigator(Composite parent) {
		this(parent, true);
	}
	public wangMultiCharacterNavigator(Composite parent, boolean bigButton) {
		super(parent, bigButton);
	}

	@Override
	protected wangMotionAnimator createMotionViewer(Composite parent) {
		viewer = new wangMultiCharacterViewer(parent);
		Vector3d[] colorList = new Vector3d[16];
		for (int i = 0; i < colorList.length; i++) {
			colorList[i] = basicColor;
		}
		colorList[0] = selectedColor;
		colorList[0] = new Vector3d(1, 0.8, 0.7);
		colorList[1] = new Vector3d(0.7, 1, 0.8);
		colorList[2] = new Vector3d(0.6, 0.6, 1);
		
		//wangyi
		colorList[3] = new Vector3d(1, 0.8, 0.7);
		colorList[4] = new Vector3d(0.7, 1, 0.8);
		colorList[5] = new Vector3d(0.6, 0.6, 1);
		colorList[6] = new Vector3d(1, 0.8, 0.7);
		colorList[7] = new Vector3d(0.7, 1, 0.8);
		colorList[8] = new Vector3d(0.6, 0.6, 1);
		viewer.setSkeletonColorList(colorList);

		return viewer;
	}
	public void setskeletonColorList(Vector3d [] colorList)
	{
		viewer.setSkeletonColorList(colorList);
	}
	public wangMultiCharacterViewer getViewer() {
		return viewer;
	}

	public Vector3d[] getColorList() {
		return viewer.getSkeletonColorList();
	}
	
	public void setMotionDataList(MotionData[] motionDataList){
		MotionData.adjustKnot(motionDataList);
		setFPS(motionDataList[0].framerate);
		int maxFrame = MotionData.maxFrame(motionDataList);
		setMaxFrame(maxFrame);
		viewer.setMotionDataList(motionDataList);
	}
	public void setAMCMotionList(WAMCMotion[] arAmcList)
	{
		//w: slow down
		//setFPS(120);
		setFPS(60);
		int iMaxFrame = 0;
		for(WAMCMotion amc : arAmcList)
		{
			if(amc.m_arFrame.size() > iMaxFrame)
				iMaxFrame = amc.m_arFrame.size();
		}
		setMaxFrame(iMaxFrame);
		viewer.setAmcList(arAmcList);
	}
	public WAMCMotion[] getAMCMotionList()
	{
		return viewer.getAmcList();
	}
	
	public static void openMotionData(MotionData[] motionDataList, double scale){
		final Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(2, false));
		
		final wangMultiCharacterNavigator navigator = new wangMultiCharacterNavigator(shell);
		navigator.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		
		navigator.viewer.setScale(scale);
		navigator.viewer.skeletonColor = new Vector3d(0.8, 0.8, 0.8);
		
		navigator.setMotionDataList(motionDataList);
		
		navigator.viewer.eye = new Vector3d(-121.80955051855364, 47.828390134752624, 29.85532196662258);
		navigator.viewer.center = new Vector3d(2.7325483582816688, 20.29166452107147, 11.701930660868829);
		navigator.viewer.upVector = new Vector3d(0.3243748441825436, 0.9452422181149468, 0.036029287457299365);
		
		shell.setText("Motion Navigator");
		shell.setSize(1400, 1000);
		shell.setMaximized(true);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
