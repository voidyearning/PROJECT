package wangDeep;

public class wangHammingDistance implements Comparable<wangHammingDistance>
{
	public int m_iHammingDistance;
	public int m_iIdx;
	@Override
	public int compareTo(wangHammingDistance o) 
	{
		//ascending order
		return m_iHammingDistance - o.m_iHammingDistance;
	}
}
