package wangDeep;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import javax.vecmath.Vector3d;

import wang.WAMCMotion;
import wang.WASFSkeleton;
import wang.WRawFile;
import wang.wangChannelSelector;


public class wangMotionDB 
{	
	ArrayList<wangMotionSequence> m_arSequenceAll = null;
	ArrayList<wangMotionSegment> m_arSegmentRec = null;
	ArrayList<wangMotionSegment> m_arSegment = new ArrayList<wangMotionSegment>();
	boolean m_bManualSegDB = false;
	
	public void LoadFrom(String strPath, boolean bManualSegDB)
	{
		m_bManualSegDB = bManualSegDB;
		String strDirPath = strPath + "wangCMUDBauto.Directory.txt";
		if(bManualSegDB)
			strDirPath = strPath + "PABBGDMSE.Directory.txt";
		
		wangCSVParser csvDir = new wangCSVParser();
		csvDir.LoadFromFile(strDirPath);
		
		String strSigPath = strPath + "deepSig160.bitop";
		wangCSVParser csvSig = new wangCSVParser();
		csvSig.LoadFromFile(strSigPath);
		
		int iDBSize = csvDir.m_arRecord.size();
		for(int i = 0; i < iDBSize; ++i)
		{
			wangMotionSegment segment = new wangMotionSegment();
			
			segment.m_iId = i;
			segment.m_strPath = ConvertToAMCPath(csvDir.m_arRecord.get(i).get(0), bManualSegDB);
			segment.m_ds.UpdateFrom(csvSig.m_arRecord.get(i));	
			segment.m_db = this;
			m_arSegment.add(segment);
		}
	}	
	
	void LoadReonstructedSegmentFrom(String strRecPath)
	{
		if(m_arSegment == null || m_arSegment.size() == 0)
			return;
		
		m_arSegmentRec = new ArrayList<wangMotionSegment>();
		wangCSVParser csvSig = new wangCSVParser();
		csvSig.LoadFromFile(strRecPath);
		
		int iDBSize = csvSig.m_arRecord.size();
		for(int i = 0; i < iDBSize; ++i)
		{
			wangMotionSegment segment = new wangMotionSegment();
			
			segment.m_iId = i;
			segment.m_strPath = m_arSegment.get(i).m_strPath;
			segment.m_ds.UpdateFrom(csvSig.m_arRecord.get(i));	
			segment.m_db = this;
			m_arSegmentRec.add(segment);
		}		
	}
	
	
	public static String ConvertToAMCPath(String strDirPath, boolean bManualSegDB)
	{
		String strAmcPath = new String(strDirPath);
		strAmcPath = strAmcPath.replace("K:","C:\\wangyi");
		strAmcPath = strAmcPath.replace(".raw", ".amc");
		if(bManualSegDB)
		{
			strAmcPath = strAmcPath.replace("SegmentDBLocalRaw", "ManualDB");			
		}
		else//whole DB
		{
			strAmcPath = strAmcPath.replace("SegmentDBLocalRawAuto", "SegmentDB");
		}
        return strAmcPath;		
	}
	
	public static String ConvertToASFPath(String strDirPath)
	{
		int iSep = strDirPath.lastIndexOf("\\");
		int iUnderscore = strDirPath.indexOf("_", iSep+1);
		String strSubjectId = strDirPath.substring(iSep+1, iUnderscore);
		String strASFPath = "C:\\wangyi\\research\\CMUDB\\ASF\\" + strSubjectId + ".asf";
		return strASFPath;
	}
	
	public static String ConvertToCategory(String strDirPath)
	{
		int iSlashLast = strDirPath.lastIndexOf("\\");
		int iSlashPre = strDirPath.lastIndexOf("\\", iSlashLast-1);
		return strDirPath.substring(iSlashPre+1, iSlashLast);
	}
	
	public void PreCompute()
	{
		/*/from .bidist file ===============================================
		String strDistPath = "";
		WCSVParser csvDist = new WCSVParser();
		csvDist.LoadFromFile(strDistPath);
		
		for(int q = 0; q < csvDist.m_arRecord.size(); ++ q)
		{
			ArrayList<String> record = csvDist.m_arRecord.get(q);
			WHammingDistance [] arHammingDistance = new WHammingDistance[record.size()]; 
			for(int r = 0; r < record.size(); ++ r)
			{
				WHammingDistance hd = new WHammingDistance();
				hd.m_iHammingDistance = Integer.valueOf(record.get(r));
				hd.m_iIdx = r;
				arHammingDistance[r] = hd;
			}
			Arrays.sort(arHammingDistance);
			
			WMotionSegment segQ = m_arSegment.get(q);
			segQ.m_arPreComputeResult = arHammingDistance;
		}*/	
		
		for(int q = 0; q < m_arSegment.size(); ++ q)
		{
			wangMotionSegment segQ = m_arSegment.get(q);
			wangHammingDistance [] arHammingDistance = new wangHammingDistance[m_arSegment.size()]; 
			for(int r = 0; r < m_arSegment.size(); ++ r)
			{
				wangMotionSegment segR = m_arSegment.get(r);
				wangHammingDistance hd = new wangHammingDistance();
				hd.m_iHammingDistance = wangDeepSignature.GetHammingDistance(segQ.m_ds, segR.m_ds);
				hd.m_iIdx = r;
				arHammingDistance[r] = hd;
			}
			Arrays.sort(arHammingDistance);
			segQ.m_arPreComputeResult = arHammingDistance;
		}
	}
	public wangHammingDistance[] Retrieve(int iIdx, wangChannelSelector cs)
	{
		wangMotionSegment segQ = m_arSegment.get(iIdx);

		//return precomputed results
		if(segQ.m_arPreComputeResult != null)
			return segQ.m_arPreComputeResult;

		//retrieve in runtime
		wangHammingDistance [] arHammingDistance = new wangHammingDistance [m_arSegment.size()];
		for(int i = 0; i < m_arSegment.size(); ++ i)
		{
			wangMotionSegment segR = m_arSegment.get(i);
			wangHammingDistance hd = new wangHammingDistance();
			hd.m_iHammingDistance = wangDeepSignature.GetHammingDistance(segQ.m_ds, segR.m_ds, cs);
			hd.m_iIdx = i;
			arHammingDistance[i] = hd;
		}
		Arrays.sort(arHammingDistance);
		return arHammingDistance;
	}
	
	//reconstruction related ====================================================
	public wangHammingDistance[] GetReconstructInfo(int iIdx, wangChannelSelector cs)
	{
		if(m_arSegmentRec == null || m_arSegmentRec.size() == 0)
		{
			String strRecPath = "C:\\wangyi\\research\\multimodality\\experiments\\11.3.LocalizedDataAutoSeg\\result\\formaya\\lookup\\wangGibbsDS160Rec.bitop";
			LoadReonstructedSegmentFrom(strRecPath);			
		}
		
		//1. search using the reconstructed signature
		wangMotionSegment segQ = m_arSegmentRec.get(iIdx);
		wangHammingDistance [] arHammingDistance = new wangHammingDistance [m_arSegment.size()];
		for(int i = 0; i < m_arSegment.size(); ++ i)
		{
			wangMotionSegment segR = m_arSegment.get(i);
			wangHammingDistance hd = new wangHammingDistance();
			hd.m_iHammingDistance = wangDeepSignature.GetHammingDistance(segQ.m_ds, segR.m_ds, cs);
			hd.m_iIdx = i;
			arHammingDistance[i] = hd;
		}
		Arrays.sort(arHammingDistance);		
		return arHammingDistance;
	}
	public WAMCMotion[] GetReconstructAMC(int iIdx, wangChannelSelector cs, boolean bDTW)
	{
		wangChannelSelector csLA = new wangChannelSelector(true, false, false, false, false);
		wangHammingDistance [] arHammingDistance = GetReconstructInfo(iIdx, cs);
		//2. replace the iIdx with other left arm movement
		int iDemoSize = 8;
		WAMCMotion [] arAMC = new WAMCMotion [iDemoSize];
		wangMotionSegment segQ = m_arSegment.get(iIdx);
		WAMCMotion amcQ = segQ.GetAMC();
		for(int i = 0; i < iDemoSize; ++ i)
		{
			wangHammingDistance hd = arHammingDistance[i];
			wangMotionSegment segR = m_arSegment.get(hd.m_iIdx);
			WAMCMotion amcR = segR.GetAMC();
			WAMCMotion amcQClone = new WAMCMotion(amcQ);
			//search use the cs specified channel deep code, 
			//but only replace left arm
			if(bDTW)
				amcQClone.ReplaceChannelFromDTW(amcR, csLA);
			else 
				amcQClone.ReplaceChannelFrom(amcR, csLA);
			arAMC[i] = amcQClone;
		}
		return arAMC;		
	}
	public float EvaluateReconstructionAll()
	{
		float fErr = 0;		
    	wangChannelSelector csAll = new wangChannelSelector(true, true, true, true, true);   
    	wangChannelSelector csLa = new wangChannelSelector(true, false, false, false, false);  
    	int iSize = m_arSegment.size();
    	for(int iIdx = 0; iIdx < iSize; ++ iIdx)
    	{
    		WAMCMotion [] arAMCRec = GetReconstructAMC(iIdx, csAll, false);
		 
			WAMCMotion amcSample = m_arSegment.get(iIdx).GetAMC();
			WAMCMotion amcRec = arAMCRec[1];//0 is itself, 1 is the closest
			fErr += amcRec.DistanceTo_SameLength(amcSample, csLa);
		}
    	fErr = fErr / iSize; //average over the number of clips
    	fErr = fErr / 6; //average over the number of dofs
		return fErr;
	}
	
	//sequence related===========================================================
	public ArrayList<wangMotionSequence> GetSequenceAll()
	{
		if(m_arSequenceAll == null)
		{
			m_arSequenceAll = new ArrayList<wangMotionSequence>();
			wangMotionSegment segmentLast = m_arSegment.get(0);
			String strBasePath = wangMotionSequence.GetSequencePath(segmentLast.m_strPath);
			wangMotionSequence sequence = new wangMotionSequence(strBasePath);
			sequence.m_iSequenceIndex = 0;
			for(int i = 0; i < m_arSegment.size(); ++i)
			{
				wangMotionSegment seg = m_arSegment.get(i);
				strBasePath = wangMotionSequence.GetSequencePath(seg.m_strPath);
				//if from the same segment, add to sequence
				if(sequence.m_strBasePath.equals(strBasePath))
				{
					sequence.m_arSeg.add(seg);
				}				
				//else, sort and add the sequence to m_arSequenceAll, then start a new sequence,
				else
				{
					//sort
					sequence.SortSequence();
					m_arSequenceAll.add(sequence);
					sequence = new wangMotionSequence(strBasePath);
					sequence.m_iSequenceIndex = m_arSequenceAll.size();
					sequence.m_arSeg.add(seg);
				}				
			}			
		}
		return m_arSequenceAll;
	}
	public ArrayList<wangSequenceInfo> RetrieveSequence(wangSequenceInfo infoQuery, boolean bFixedBeg, boolean bAverageDistance, int iThresholdBeg, int iThresholdEnd)
	{
		if(iThresholdBeg < 0)
			iThresholdBeg = 100;
		
		if(iThresholdEnd < 0)
			iThresholdEnd = 100;
		
		ArrayList<wangMotionSequence> arSequenceAll = GetSequenceAll();    
    	ArrayList<wangSequenceInfo> arSeqInfo = new ArrayList<wangSequenceInfo>();
    	for(int i = 0; i < arSequenceAll.size(); ++i)
    	{
    		wangMotionSequence seq = arSequenceAll.get(i);
    		ArrayList<wangSequenceInfo> arResultInfo;
    		if(bFixedBeg)
    		{
    			arResultInfo = seq.Retrieve2(infoQuery, this, bAverageDistance, iThresholdBeg);
    		}
    		else
    		{
    			arResultInfo = seq.Retrieve(infoQuery, this, iThresholdBeg, iThresholdEnd);
    		}
    		arSeqInfo.addAll(arResultInfo);
    	}
    	Collections.sort(arSeqInfo);
    	return arSeqInfo;
	}
}
