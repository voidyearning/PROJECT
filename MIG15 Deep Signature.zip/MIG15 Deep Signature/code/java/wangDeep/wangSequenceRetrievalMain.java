package wangDeep;

public class wangSequenceRetrievalMain {
	
	public static void main(String[] args) {

		String strCMUDBPath = "";
		
		wangSequenceRetrievalWnd wndAPI = new wangSequenceRetrievalWnd(strCMUDBPath);
		wndAPI.OpenShow(2000, 1500);
	}
}
