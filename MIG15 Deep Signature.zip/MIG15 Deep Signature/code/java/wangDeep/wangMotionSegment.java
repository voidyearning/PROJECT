package wangDeep;

import wang.WAMCMotion;
import wang.WASFSkeleton;

public class wangMotionSegment implements Comparable<wangMotionSegment>
{
	public int m_iId = -1;
	public String m_strPath = "";
	public wangDeepSignature m_ds = new wangDeepSignature();	
	public wangMotionDB m_db = null;
	public wangHammingDistance [] m_arPreComputeResult = null;
	
	public String GetAMCFileName()
	{
		int iSlash = m_strPath.lastIndexOf("\\");
		String strAMCFileName = m_strPath.substring(iSlash + 1);
		return strAMCFileName;
	}
	
	int GetStartFrameIndex()
	{
		String strAMCName = GetAMCFileName();
		int iSepIdx = strAMCName.indexOf('_');
		iSepIdx = strAMCName.indexOf('_', iSepIdx + 1);
		int iSepIdx2 = strAMCName.indexOf('_', iSepIdx + 1);
		String strStartFrameIdx = strAMCName.substring(iSepIdx+1, iSepIdx2);
		return Integer.valueOf(strStartFrameIdx);
	}
	public WASFSkeleton GetASF()
	{
		String strASFPath = wangMotionDB.ConvertToASFPath(m_strPath);
		WASFSkeleton asf = new WASFSkeleton();
		asf.ParseFile(strASFPath);
		return asf;
	}

	public WAMCMotion GetAMC()
	{        
		WAMCMotion amc = new WAMCMotion(GetASF());
		amc.LoadFromFile(m_strPath);
		return amc;
	}
	
	//for sorting in sequence
	@Override
	public int compareTo(wangMotionSegment o) 
	{
		int iStartIdx = GetStartFrameIndex();
		int iStartIdx2 = o.GetStartFrameIndex();
		
		return iStartIdx - iStartIdx2;
	}
}
