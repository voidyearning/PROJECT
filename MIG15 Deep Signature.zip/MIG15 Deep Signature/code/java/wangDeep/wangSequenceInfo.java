package wangDeep;

public class wangSequenceInfo implements Comparable<wangSequenceInfo>
{
	public wangSequenceInfo()
	{}
	
	public wangSequenceInfo(int iSequenceIndex, int iSegmentIndexBeg, int iSegmentIndexEnd)
	{
		m_iSequenceIndex = iSequenceIndex;
		m_iSegmentIndexBeg = iSegmentIndexBeg;
		m_iSegmentIndexEnd = iSegmentIndexEnd;
	}
	
	public int m_iSequenceIndex = -1;
	public int m_iSegmentIndexBeg = -1;
	public int m_iSegmentIndexEnd = -1;
	public int m_iDTWDistance = 0;
	
	//for sorting
	@Override
	public int compareTo(wangSequenceInfo o) 
	{
		return m_iDTWDistance - o.m_iDTWDistance;
	}
}
