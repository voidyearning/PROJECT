package wangDeep;

import java.util.ArrayList;

import javax.vecmath.Vector2d;

import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

public class wangDTW 
{
	public static Shell m_shellMain;
	public static MessageBox m_msgBox;
	public ArrayList<Vector2d> m_tr; 
	public float [][] m_D;
	
	public float GetAlignedDistance(int iRow, int iCol)
	{
		if(m_D == null)
			return -1;
		
		return m_D[iRow-1][iCol-1];
	}
	public ArrayList<Vector2d> DTW(float [][]M, int r, int c)
	{
		float [][] D = new float [r+1][c+1];
		for(int i=0; i < r+1; ++i)
			D[i][0] = Float.MAX_VALUE;
		for(int j=0; j < c+1; ++j)
			D[0][j] = Float.MAX_VALUE;
		D[0][0] = 0; 
		for(int i=1; i < r+1; ++i)
			for(int j=1; j < c+1; ++j)
			D[i][j] = M[i-1][j-1];

		int [][] phi = new int[r][c];
		for(int i = 0; i < r; ++i)
		{
			for(int j = 0; j < c; ++j)
			{
				if(D[i][j] <= D[i][j+1] && D[i][j] <= D[i+1][j])//min is D[i][j]
				{
					D[i+1][j+1] = D[i+1][j+1] + D[i][j];
					phi[i][j] = 0;
				}
				else if(D[i][j+1] <= D[i][j] && D[i][j+1] <= D[i+1][j])//min is D[i][j+1]
				{
					D[i+1][j+1] = D[i+1][j+1] + D[i][j+1];
					phi[i][j] = 1;
				}
				else if(D[i+1][j] <= D[i][j] && D[i+1][j] <= D[i][j+1])//min is D[i+1][j]
				{
					D[i+1][j+1] = D[i+1][j+1] + D[i+1][j];
					phi[i][j] = 2;
				}
			}
		}
		//result		
		m_tr = new ArrayList<Vector2d>();
		m_tr.add(new Vector2d(r-1, c-1));
		m_D = new float [r][c];
		int i = r-1;
		int j = c-1;
		while (i > 0 && j > 0)
		{
			int tb = phi[i][j];
			if (tb == 0)
			{
				i = i-1;
				j = j-1;
			}
			else if(tb == 1)
			{
			    i = i-1;
			}
			else if (tb == 2)
			{
			    j = j-1;
			}
			m_tr.add(0, new Vector2d(i,j));
	    }
		for(int I = 0; I < r; ++ I)
		{
			for(int J = 0; J < c; ++ J)
			{
				m_D[I][J] = D[I+1][J+1];
			}
		}
		return m_tr;
	}
	
	static public float subDTW(float [][] M, int iRowBeg, int iRowEnd, int iColBeg, int iColEnd)
	{
		int r = iRowEnd - iRowBeg + 1;
		int c = iColEnd - iColEnd + 1;
		float [][] D = new float [r+1][c+1];
		for(int i=0; i < r+1; ++i)
			D[i][0] = Float.MAX_VALUE;
		for(int j=0; j < c+1; ++j)
			D[0][j] = Float.MAX_VALUE;
		
		D[0][0] = 0; 
		for(int i=1; i < r+1; ++i)
			for(int j=1; j < c+1; ++j)
			D[i][j] = M[iRowBeg+i-1][iColBeg+j-1];

		int [][] phi = new int[r][c];
		for(int i = 0; i < r; ++i)
		{
			for(int j = 0; j < c; ++j)
			{
				if(D[i][j] <= D[i][j+1] && D[i][j] <= D[i+1][j])//min is D[i][j]
				{
					D[i+1][j+1] = D[i+1][j+1] + D[i][j];
					phi[i][j] = 0;
				}
				else if(D[i][j+1] <= D[i][j] && D[i][j+1] <= D[i+1][j])//min is D[i][j+1]
				{
					D[i+1][j+1] = D[i+1][j+1] + D[i][j+1];
					phi[i][j] = 1;
				}
				else if(D[i+1][j] <= D[i][j] && D[i+1][j] <= D[i][j+1])//min is D[i+1][j]
				{
					D[i+1][j+1] = D[i+1][j+1] + D[i+1][j];
					phi[i][j] = 2;
				}
			}
		}
		return D[r][c];
	}
	//return value Vector2d, x is the distance, y is the colEnd
	static public Vector2d subDTW_fixedBeg(float [][] M, int iRowBeg, int iRowEnd, int iColBeg, int iColMax)
	{
		int iCurRow = iRowBeg;
		int iCurCol = iColBeg;
		float fDistance = M[iCurRow][iCurCol];
		boolean bMarchRow = true;
		boolean bMarchCol = true;
		for(; iCurRow < iRowEnd && iCurCol < iColMax - 1; )
		{
			//decide where to move
			float fRight = M[iCurRow][iCurCol+1];
			float fDown = M[iCurRow+1][iCurCol];
			float fRightDown = M[iCurRow+1][iCurCol+1];
			
			//must constrain the flat row and col march, 
			// direct diagonal march works better
			/*if(fDown < fRightDown && fDown <= fRight && bMarchRow)
			{
				bMarchRow = false;
				bMarchCol = true;
				
				iCurRow ++;
				fDistance += fDown;
			}
			else if(fRight < fRightDown && fRight < fDown && bMarchCol)
			{
				bMarchCol = false;
				bMarchRow = true;
				
				iCurCol ++;
				fDistance += fRight;
			}
			else //if(fRightDown <= fRight && fRightDown <= fDown)
			*/{
				bMarchRow = true;
				bMarchCol = true;
				
				iCurRow ++; iCurCol ++;
				fDistance += fRightDown;
			}
			
		}
		if(Math.abs(iCurRow - iRowBeg) <= Math.abs(iRowEnd - iRowBeg)/2 ||
			Math.abs(iCurCol - iColBeg) <= Math.abs(iRowEnd - iRowBeg)/2)
			return null;
		
		if(iCurRow < iRowEnd)
			fDistance += (iRowEnd - iCurRow) * M[iCurRow][iCurCol-1];
		
		Vector2d vResult = new Vector2d(fDistance, iCurCol);
		return vResult;
	}
	//return value Vector2d, x is the distance, y is the colEnd
	static public Vector2d subDTW_fixedBeg_averageDistance(float [][] M, int iRowBeg, int iRowEnd, int iColBeg, int iColMax)
	{
		int iCurRow = iRowBeg;
		int iCurCol = iColBeg;
		float fDistance = M[iCurRow][iCurCol];
		boolean bMarchRow = true;
		boolean bMarchCol = true;
		int iCount = 1;
		for(; iCurRow < iRowEnd && iCurCol < iColMax - 1; iCount++)
		{
			//decide where to move
			float fRight = M[iCurRow][iCurCol+1];
			float fDown = M[iCurRow+1][iCurCol];
			float fRightDown = M[iCurRow+1][iCurCol+1];
			
			//must constrain the flat row and col march, 
			// direct diagonal march works better
			if(fDown < fRightDown && fDown <= fRight && bMarchRow)
			{
				bMarchRow = false;
				bMarchCol = true;
				
				iCurRow ++;
				fDistance += fDown;
			}
			else if(fRight < fRightDown && fRight < fDown && bMarchCol)
			{
				bMarchCol = false;
				bMarchRow = true;
				
				iCurCol ++;
				fDistance += fRight;
			}
			else //if(fRightDown <= fRight && fRightDown <= fDown)
			{
				bMarchRow = true;
				bMarchCol = true;
				
				iCurRow ++; iCurCol ++;
				fDistance += fRightDown;
			}
			
		}
		if(Math.abs(iCurRow - iRowBeg) <= Math.abs(iRowEnd - iRowBeg)/2 ||
			Math.abs(iCurCol - iColBeg) <= Math.abs(iRowEnd - iRowBeg)/2)
			return null;
		
		//if(iCurRow < iRowEnd)
		//	fDistance += (iRowEnd - iCurRow) * M[iCurRow][iCurCol-1];
		
		fDistance = fDistance / iCount;		
		Vector2d vResult = new Vector2d(fDistance, iCurCol);
		return vResult;
	}
	public static void Test()
	{
		int r = 20; 
		int c = 8;
		float [] [] M = new float [r][c];
		for(int i = 0; i < r; ++ i)
		{
			for(int j = 0; j < c; ++ j)
			{
				if((r-i) >=j)
					M[i][j] = i+j;
				else
					M[i][j] = Math.max(20 - i - j, 0);
			}
		}
		wangDTW dtw = new wangDTW();
		dtw.DTW(M, r, c);
		String strResult = "";
		for(int i = 0; i < dtw.m_tr.size(); ++i)
		{
			Vector2d pos = dtw.m_tr.get(i);
			strResult = strResult + "("+ String.valueOf(pos.x) + "," + String.valueOf(pos.y) + ")\r\n"; 
		}
		strResult += "\r\n\r\n";
		for(int i = 0; i < r; ++ i)
		{
			for(int j = 0; j < c; ++ j)
			{
				float d = dtw.m_D[i][j];
				strResult = strResult + String.valueOf(d) + ",";
			}
			strResult += "\r\n";
		}	
		m_msgBox = new MessageBox(m_shellMain);
		m_msgBox.setMessage(strResult);
		m_msgBox.open();
	}
}
