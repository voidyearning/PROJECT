package wangDeep;

import java.util.ArrayList;

import wang.wangChannelSelector;

public class wangDeepSignature
{	
	public int m_uLeftlimb;
	public int m_uRightlimb;
	public int m_uLeftleg;
	public int m_uRightleg;
	public int m_uTorso;
	
	public wangDeepSignature()
	{
		ClearAll();
	}
	
	public void ClearAll()
	{
		m_uLeftlimb = 0;
		m_uRightlimb = 0;
		m_uLeftleg = 0;
		m_uRightleg = 0;
		m_uTorso = 0;		
	}
	public wangDeepSignature(ArrayList<String> record)
	{
		UpdateFrom(record);		
	}
	
	public void UpdateFrom(ArrayList<String> record)
	{
		ClearAll();
		if(record == null)
			return;
		
		int iBitNum = record.size();
		int iBitEach = 32;
		for(int iBitPos = 0; iBitPos < iBitNum; ++ iBitPos)
		{
			String strBit = record.get(iBitPos);
			if(strBit.equalsIgnoreCase("0"))
				continue;

			int iBitToMove = (iBitPos) % iBitEach;
			int uBitToOr = (int) (0x00000001 << iBitToMove);
			//this bit is 1
			if(iBitPos<iBitEach)//leftlimb
			{
				m_uLeftlimb |= uBitToOr;				
			}
			else if(iBitPos<2*iBitEach)//rightlimb
			{
				m_uRightlimb |= uBitToOr;
			}
			else if(iBitPos<3*iBitEach)//leftleg
			{
				m_uLeftleg |= uBitToOr;
			}
			else if(iBitPos<4*iBitEach)//rightleg
			{
				m_uRightleg |= uBitToOr;
			}
			else//torso
			{
				m_uTorso |= uBitToOr;
			}
		}
		
	}
	
	public static int GetHammingDistance(int uBits1, int uBits2)
	{
		int x = (int) (uBits1 ^ uBits2);

		//the same pasted code in bitCount
		x = (int) ((x & 0x55555555) + ((x >> 1) & 0x55555555));//1
		x = (int) ((x & 0x33333333) + ((x >> 2) & 0x33333333));//2
		x = (int) ((x & 0x0f0f0f0f) + ((x >> 4) & 0x0f0f0f0f));//3
		x = (int) ((x & 0x00ff00ff) + ((x >> 8) & 0x00ff00ff));//4
		x = (int) ((x & 0x0000ffff) + ((x >> 16) & 0x0000ffff));//5
	   return x;
	}
	
	public static int GetHammingDistance(wangDeepSignature ds1, wangDeepSignature ds2)
	{
		int iLeftlimbDist = GetHammingDistance(ds1.m_uLeftlimb, ds2.m_uLeftlimb);
		int iRightlimbDist = GetHammingDistance(ds1.m_uRightlimb, ds2.m_uRightlimb);
		int iLeftlegDist = GetHammingDistance(ds1.m_uLeftleg, ds2.m_uLeftleg);
		int iRightlegDist = GetHammingDistance(ds1.m_uRightleg, ds2.m_uRightleg);
		int iTorsoDist = GetHammingDistance(ds1.m_uTorso, ds2.m_uTorso);
		int iDist = iLeftlimbDist + iRightlimbDist + iLeftlegDist + iRightlegDist + iTorsoDist;
		return iDist;		
	}
	
	public static int GetHammingDistance(wangDeepSignature ds1, wangDeepSignature ds2, wangChannelSelector cs)
	{
		int iLeftlimbDist = 0;
		if(cs.m_bLeftArm)
			iLeftlimbDist = GetHammingDistance(ds1.m_uLeftlimb, ds2.m_uLeftlimb);
		
		int iRightlimbDist = 0;
		if(cs.m_bRightArm)
			iRightlimbDist = GetHammingDistance(ds1.m_uRightlimb, ds2.m_uRightlimb);
		
		int iLeftlegDist = 0;
		if(cs.m_bLeftLeg)
			iLeftlegDist = GetHammingDistance(ds1.m_uLeftleg, ds2.m_uLeftleg);
		
		int iRightlegDist = 0;
		if(cs.m_bRightLeg)
			iRightlegDist = GetHammingDistance(ds1.m_uRightleg, ds2.m_uRightleg);
		
		int iTorsoDist = 0;
		if(cs.m_bTorso)
			iTorsoDist = GetHammingDistance(ds1.m_uTorso, ds2.m_uTorso);
		int iDist = iLeftlimbDist + iRightlimbDist + iLeftlegDist + iRightlegDist + iTorsoDist;
		return iDist;		
	}
	
	public int GetHammingDistance(wangDeepSignature ds)
	{
		return GetHammingDistance(this, ds);
	}

}
