package wangDeep;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class wangCSVParser 
{	
	public ArrayList< ArrayList<String> > m_arRecord = new ArrayList< ArrayList<String> > ();
	public String m_strToken = ",";
	
	public void LoadFromFile(String strPath)
	{
		m_arRecord.clear();
		try
		{
			BufferedReader br = new BufferedReader(new FileReader(strPath));
			String strLine;
			while( (strLine=br.readLine()) != null)
			{
				if(strLine.isEmpty())
				{
					continue;
				}
				ArrayList<String> record = new ArrayList<String>();
				String [] strLineRecord = strLine.split(m_strToken);
				for(String strRecord : strLineRecord)
				{
					strRecord.trim();
					if (strRecord.isEmpty())
						continue;
					record.add(strRecord);
				}
				m_arRecord.add(record);
			}
			br.close();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}		
	}
	public void SaveToFile(String strPath)
	{
		try
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter(strPath));		
			for(int i = 0; i < m_arRecord.size(); ++i)
			{
				ArrayList<String> record = m_arRecord.get(i);
				for(int j = 0; j < record.size(); ++j)
				{
					String strData = record.get(j);
					bw.write(strData);	
					if(j < record.size() -1)
						bw.write(m_strToken);
				}
				bw.newLine();
			}
			bw.flush();
			bw.close();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

}
