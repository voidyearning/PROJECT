package wangDeep;


import mrl.main.Configuration;
import wangDeep.wangDeepRetrievalWnd;

public class wangDeepRetrievalMain {

	public static void main(String[] args) {

		String strCMUDBPath = "";
		
		wangDeepRetrievalWnd wndAPI = new wangDeepRetrievalWnd(strCMUDBPath);
		wndAPI.OpenShow(1200, 800);
	}
}
