package wangDeep;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import javax.vecmath.Vector2d;

import mrl.motion.data.MotionData;
import wang.WAMCMotion;
import wang.WASFSkeleton;

public class wangMotionSequence {
	
	ArrayList<wangMotionSegment> m_arSeg = new ArrayList<wangMotionSegment>();
	String m_strBasePath = "";
	int m_iSequenceIndex = -1;
	
	wangMotionSequence()
	{}
	wangMotionSequence(String strBasePath)
	{
		m_strBasePath = strBasePath;
	}
	static float DTWAverageDistance(wangMotionSequence sq1, wangMotionSequence sq2)
	{
		if(sq1 == null || sq2 == null)
			return -1;
		
		float fResult = 0;
		int iRow = sq1.m_arSeg.size();
		int iCol = sq2.m_arSeg.size();
		if(iRow == 0 || iCol == 0)
			return -1;
		
		//initialize arDistance
		float [] [] arDistance = new float [iRow] [iCol];
		for(int r = 0; r < iRow; ++r)
		{
			wangMotionSegment segR = sq1.m_arSeg.get(r);
			for(int c = 0; c < iCol; ++c)
			{
				wangMotionSegment segC = sq2.m_arSeg.get(c);
				int iHammingDist = wangDeepSignature.GetHammingDistance(segR.m_ds, segC.m_ds);
				arDistance[r][c] = iHammingDist;
			}
		}
		wangDTW dtw = new wangDTW();
		ArrayList<Vector2d> trace = dtw.DTW(arDistance, iRow, iCol);				
		fResult = dtw.GetAlignedDistance(iRow, iCol);
		return fResult/iRow;		
	} 
	static String GetSequencePath(String strPath)
	{
		String strSeqPath = "";
		int iSepIdx = strPath.indexOf('_');
		iSepIdx = strPath.indexOf('_', iSepIdx+1);
		if(iSepIdx == -1)
			return strSeqPath;
		strSeqPath = strPath.substring(0, iSepIdx);
		return strSeqPath + ".amc";
	}
	String GetAMCName()
	{
		int iSlashIdx = m_strBasePath.lastIndexOf('\\');
		String strSub = m_strBasePath.substring(iSlashIdx+1);
		return strSub;
	}
	boolean IsSameBasePath(wangMotionSegment segment)
	{
		String strPath = GetSequencePath(segment.m_strPath);
		return strPath.equals(m_strBasePath);
	}
	void SortSequence()
	{
		Collections.sort(m_arSeg);		
	}
	public WASFSkeleton GetASF()
	{
		String strASFPath = wangMotionDB.ConvertToASFPath(m_strBasePath);
		WASFSkeleton asf = new WASFSkeleton();
		asf.ParseFile(strASFPath);
		return asf;
	}
	public WAMCMotion GetAMC()
	{        
		WAMCMotion amc = new WAMCMotion(GetASF());
		String strSeqPath = new String(m_strBasePath);
		strSeqPath = strSeqPath.replace("SegmentDB", "Motion Categories");
		amc.LoadFromFile(strSeqPath);
		return amc;
	}
	
	public ArrayList<wangSequenceInfo> Retrieve(wangSequenceInfo query, wangMotionDB db, int iThresholdBeg, int iThresholdEnd)
	{
		if(query == null || query.m_iSequenceIndex < 0)
			return null;
		
		wangMotionSequence seqQuery = db.GetSequenceAll().get(query.m_iSequenceIndex);
		float [][] mxSegDist = seqQuery.GetSegmentDistanceMatrix(this);
		
		//find local minima for beg
		boolean [] arBegMin = GetLowOrLocalMinima(mxSegDist[query.m_iSegmentIndexBeg], iThresholdBeg);
		
		//find local minima for end
		boolean [] arEndMin = GetLowOrLocalMinima(mxSegDist[query.m_iSegmentIndexEnd], iThresholdEnd);
		
		//find beg, end
		ArrayList<wangSequenceInfo> arSequenceInfo = new ArrayList<wangSequenceInfo>();
		int iSegLength = query.m_iSegmentIndexEnd - query.m_iSegmentIndexBeg;
		for(int iBeg = 0; iBeg < arBegMin.length; ++ iBeg)
		{
			if(!arBegMin[iBeg])
				continue;
			
			int iEndPreferred = iBeg + iSegLength;
			
			//forward
			wangSequenceInfo infoForward = null;
			for(int iEnd = iEndPreferred; iEnd < arEndMin.length; ++ iEnd)
			{
				if(iEnd >= arEndMin.length || iEnd < 0)
					continue; 
				
				if(!arEndMin[iEnd])
					continue;
				
				int iLength = iEnd - iBeg + 1;
				if(iLength >= iSegLength * 2 || iLength <= iSegLength / 2)
					continue;

				infoForward = new wangSequenceInfo(m_iSequenceIndex, iBeg, iEnd);
				infoForward.m_iDTWDistance = (int) wangDTW.subDTW(mxSegDist, query.m_iSegmentIndexBeg, query.m_iSegmentIndexEnd, iBeg, iEnd);
				break;
			}
			
			//backward
			wangSequenceInfo infoBackward = null;
			for(int iEnd = iEndPreferred - 1; iEnd >=0; -- iEnd)
			{
				if(iEnd >= arEndMin.length || iEnd < 0)
					continue; 
				
				if(!arEndMin[iEnd])
					continue;
				
				int iLength = iEnd - iBeg + 1;
				if(iLength >= iSegLength * 2 || iLength <= iSegLength / 2)
					continue;
				
				infoBackward = new wangSequenceInfo(m_iSequenceIndex, iBeg, iEnd);
				infoBackward.m_iDTWDistance = (int) wangDTW.subDTW(mxSegDist, query.m_iSegmentIndexBeg, query.m_iSegmentIndexEnd, iBeg, iEnd);
				break;
			}
			/*if(infoForward != null && infoBackward != null)
			{
				if(infoForward.m_iDTWDistance <= infoBackward.m_iDTWDistance)
					arSequenceInfo.add(infoForward);
				else //if(infoBackward.m_iDTWDistance < infoForward.m_iDTWDistance)
					arSequenceInfo.add(infoBackward);
			}
			*///else 
			if(infoForward != null)
				arSequenceInfo.add(infoForward);
			//else 
			if(infoBackward != null)
				arSequenceInfo.add(infoBackward);			
		}			
		return arSequenceInfo;
	}
	
	public ArrayList<wangSequenceInfo> Retrieve2(wangSequenceInfo query, wangMotionDB db, boolean bAverageDistance, int iThreshold)
	{
		if(query == null || query.m_iSequenceIndex < 0)
			return null;
		
		wangMotionSequence seqQuery = db.GetSequenceAll().get(query.m_iSequenceIndex);
		float [][] mxSegDist = seqQuery.GetSegmentDistanceMatrix(this);
		
		//find local minima for beg
		boolean [] arBegMin = GetLowOrLocalMinima(mxSegDist[query.m_iSegmentIndexBeg], iThreshold);
		
		//find beg, end
		ArrayList<wangSequenceInfo> arSequenceInfo = new ArrayList<wangSequenceInfo>();
		int iSegLength = query.m_iSegmentIndexEnd - query.m_iSegmentIndexBeg;
		for(int iBeg = 0; iBeg < arBegMin.length; ++ iBeg)
		{
			if(!arBegMin[iBeg])
				continue;

			Vector2d vResult = null;
			if(bAverageDistance)
				vResult = wangDTW.subDTW_fixedBeg_averageDistance(mxSegDist, query.m_iSegmentIndexBeg, query.m_iSegmentIndexEnd, iBeg, m_arSeg.size());
			else
				vResult = wangDTW.subDTW_fixedBeg(mxSegDist, query.m_iSegmentIndexBeg, query.m_iSegmentIndexEnd, iBeg, m_arSeg.size());
				
			if(vResult == null)
				continue;
			wangSequenceInfo info = new wangSequenceInfo(m_iSequenceIndex, iBeg, (int)vResult.y);
			info.m_iDTWDistance = (int)vResult.x;
			arSequenceInfo.add(info);	
		}			
		return arSequenceInfo;
	}
	public static boolean [] GetLowOrLocalMinima(float[] arData, float iThreshold)
	{
		boolean [] arResult = new boolean[arData.length];
		
		float fMinData = Float.MAX_VALUE;
		for(int i = 0; i < arData.length; ++ i)
		{
			//record the min value
			if(arData[i] < fMinData)
				fMinData = arData[i];
			
			//check local minima
			arResult[i] = true;
			if(i>0)
			{
				if(arData[i] > arData[i-1]) 
					arResult[i] = false;
			}
			if(i<arData.length-1)
			{
				if(arData[i] > arData[i+1])
					arResult[i] = false;
			}
		}
		for(int i = 0; i < arData.length; ++i)
		{
			if(arData[i] > iThreshold)
				arResult[i] = false;
		}
		
		return arResult;
	}
	
	public float [][] GetSegmentDistanceMatrix(wangMotionSequence seq)
	{
		float [][] mxSegDist = new float[m_arSeg.size()][seq.m_arSeg.size()];
		for(int r = 0; r < m_arSeg.size(); ++ r)
		{
			wangMotionSegment segR = m_arSeg.get(r);
			for(int c = 0; c < seq.m_arSeg.size(); ++c)
			{
				wangMotionSegment segC = seq.m_arSeg.get(c);
				int iDist = wangDeepSignature.GetHammingDistance(segR.m_ds, segC.m_ds);
				mxSegDist[r][c] = iDist;
			}
		}
		return mxSegDist;
	}
	//wangMotionSequence GetSubSequence(int iStartIdx, int iEndIdx)
	//bool IsOverlap(CSequence sq);
	//int GetDuration();
	//bool operator < (CSequence& sq);

}
