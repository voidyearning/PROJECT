package wangDeep;

import wang.WAMCMotion;
import wang.WASFSkeleton;
import wang.WRawFile;
import wang.wangChannelSelector;
import wangUI.wangMultiCharacterNavigator;

import java.io.File;

import javax.swing.JFileChooser;
import javax.vecmath.Matrix4d;

import java.util.ArrayList;
import java.util.HashMap;

import javax.vecmath.Vector3d;

import mrl.main.Configuration;
import mrl.motion.annotation.MotionAnnotation.MotionAnnValueGetter;
import mrl.motion.data.Motion;
import mrl.motion.data.MotionData;
import mrl.motion.data.parser.BVHParser;
import mrl.motion.data.parser.BVHWriter;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Text;

public class wangDeepRetrievalWnd
{
	public static boolean m_bShowGood = false;
	public static Shell m_shellMain;
	private Display m_displayMain;
	
	//UI
	public Label m_lbDBSegments;
	public List m_lstDBSegments;
	public Label m_lbSegQ;
	public Button m_btnRetrieve; 	
	public Button m_btnReconstruct;
	public Button m_btnReconstructDTW;
	
	//mask
	public Button m_btnRelevantLA;
	public Button m_btnRelevantRA;
	public Button m_btnRelevantLL;
	public Button m_btnRelevantRL;
	public Button m_btnRelevantTS;
	public Button m_btnExportScene;
	public Text m_txTag;
	
	public wangMultiCharacterNavigator m_ctrlMotionPlayer;
	public Label m_lbResults;
	//public Table m_tblResults;
	public Text m_txSegQIdx;
	public Text m_txSegQName;
	public Button m_checkShowGood;
	public Text m_txAnno;
	
	//db
	wangMotionDB m_db;
	wangMotionSegment m_segQ;
	wangHammingDistance[] m_arActiveRetrieval = null;
	
	public wangDeepRetrievalWnd(String strCMUDBPath)
	{
		m_displayMain = new Display();
		m_shellMain = new Shell(m_displayMain);
		m_shellMain.setText("Yingying!");
		
		InitializeUI();
	} 
	public void LoadDB(boolean bManualSeg)
	{
		m_db = new wangMotionDB();
		String strBasePath = "C:\\wangyi\\research\\multimodality\\experiments\\10.3.LocalizedDataAutoSeg\\result\\formaya\\lookup\\";
		if(bManualSeg)
			strBasePath = "C:\\wangyi\\research\\multimodality\\experiments\\10.1.LocalizedData\\result\\formaya\\lookup\\";
		m_db.LoadFrom(strBasePath, bManualSeg);
		UpdateDBToList();
	}
	
	public void UpdateDBToList()
	{
		if(m_db == null || m_lstDBSegments == null)
			return;

		m_lstDBSegments.removeAll();
		for(int i = 0; i < m_db.m_arSegment.size(); ++ i)
		{
			wangMotionSegment seg = m_db.m_arSegment.get(i);
			String strListName = String.valueOf(i) + ".   " + seg.GetAMCFileName();
			m_lstDBSegments.add(strListName);
		}
	}
	public void UpdateQueryToLabel()
	{
		int iSelectedSegmentIdx = m_lstDBSegments.getSelectionIndex();
		if (iSelectedSegmentIdx < 0 || iSelectedSegmentIdx >= m_db.m_arSegment.size())
		{
			m_segQ = null;
			m_txSegQIdx.setText("");
			m_txSegQName.setText("");
		}
		else
		{
			m_segQ = m_db.m_arSegment.get(iSelectedSegmentIdx);					
			wangMotionSegment [] arSeg = new wangMotionSegment [1];
			arSeg[0] = m_segQ;
			PlaySegments(arSeg);
			
			String strInfo = "Query: " + String.valueOf(m_segQ.m_iId) + ".   " + 
					m_segQ.GetAMCFileName() + 
					"       Folder: " + wangMotionDB.ConvertToCategory(m_segQ.m_strPath);
			m_lbSegQ.setText(strInfo);
			m_txSegQIdx.setText(String.valueOf(m_segQ.m_iId));
			m_txSegQName.setText(m_segQ.GetAMCFileName());
		}
	}
	public void UpdateResultsToLabel(wangHammingDistance [] arHamming)
	{
		int iDemoSize = 15;
		String strResultInfo = "Results:\r\n";
		for(int i = 0; i < iDemoSize; ++ i)
		{
			wangHammingDistance hd = arHamming[i];
			String strRank = String.valueOf(i+1);
			String strId = String.valueOf(hd.m_iIdx);
			String strName = m_db.m_arSegment.get(hd.m_iIdx).GetAMCFileName();
			String strHd = String.valueOf(hd.m_iHammingDistance);
			strResultInfo += strRank + ".   " + strId + ".   " + strName + "   " + strHd + "\r\n";			
		}	
		m_lbResults.setText(strResultInfo);
	}
	

    public void InitializeUI() 
	{
    	//layout
    	FormLayout formLO = new FormLayout();
    	formLO.marginHeight = 10;
    	formLO.marginWidth = 10;
    	m_shellMain.setLayout(formLO);
    	
    	//db label ================================================================
    	FormData formDBLabel = new FormData(90, 22);
    	m_lbDBSegments = new Label(m_shellMain, SWT.LEFT);
    	m_lbDBSegments.setText("DB Segments");
    	m_lbDBSegments.setLayoutData(formDBLabel);
    	
    	//query index and name ================================================================
    	FormData formQueryIdText = new FormData(90, 22);
    	formQueryIdText.top = new FormAttachment(m_lbDBSegments, 0, SWT.TOP);
    	formQueryIdText.left = new FormAttachment(m_lbDBSegments, 0, SWT.RIGHT);
    	this.m_txSegQIdx = new Text(m_shellMain, SWT.LEFT);
    	m_txSegQIdx.setText("");
    	m_txSegQIdx.setLayoutData(formQueryIdText);
    	m_txSegQIdx.addListener(SWT.KeyUp, new Listener()
    	{
    		public void handleEvent(Event event)
    		{
    			try
    			{
    				int iIdx = Integer.valueOf(m_txSegQIdx.getText());
    				if (iIdx < 0 || iIdx >= m_db.m_arSegment.size())
    				{
    					m_segQ = null;
    					m_txSegQIdx.setText("");
    					m_lstDBSegments.setSelection(-1);
    					m_txSegQName.setText("");
    				}
    				else
    				{
    					m_lstDBSegments.setSelection(iIdx);
    					m_segQ = m_db.m_arSegment.get(iIdx);					
    					wangMotionSegment [] arSeg = new wangMotionSegment [1];
    					arSeg[0] = m_segQ;
    					PlaySegments(arSeg);
    					
    					String strInfo = "Query: " + String.valueOf(m_segQ.m_iId) + ".   " + 
    							m_segQ.GetAMCFileName() + 
    							"       Folder: " + wangMotionDB.ConvertToCategory(m_segQ.m_strPath);
    					m_lbSegQ.setText(strInfo);
    					m_txSegQName.setText(m_segQ.GetAMCFileName());
    				}    				
    			}
    			catch(Exception e){}
    		}
    	});
    	
    	FormData formQueryNameText = new FormData(90, 22);
    	formQueryNameText.top = new FormAttachment(m_lbDBSegments, 0, SWT.TOP);
    	formQueryNameText.left = new FormAttachment(m_txSegQIdx, 2, SWT.RIGHT);
    	this.m_txSegQName = new Text(m_shellMain, SWT.LEFT);
    	m_txSegQName.setText("");
    	m_txSegQName.setLayoutData(formQueryNameText);
    	m_txSegQName.addListener(SWT.KeyUp, new Listener()
    	{
    		public void handleEvent(Event event)
    		{
    			try
    			{
    				String strName = m_txSegQName.getText();
    				for(int i = 0; i < m_db.m_arSegment.size(); ++i)
    				{
    					wangMotionSegment seg = m_db.m_arSegment.get(i);
    					if(seg.GetAMCFileName().startsWith(strName))
    					{
    						m_lstDBSegments.setSelection(i);
        					m_segQ = seg;					
        					wangMotionSegment [] arSeg = new wangMotionSegment [1];
        					arSeg[0] = m_segQ;
        					PlaySegments(arSeg);
        					String strInfo = "Query: " + String.valueOf(m_segQ.m_iId) + ".   " + 
        							m_segQ.GetAMCFileName() + 
        							"       Folder: " + wangMotionDB.ConvertToCategory(m_segQ.m_strPath);
        					m_lbSegQ.setText(strInfo);
        					m_txSegQIdx.setText(String.valueOf(i));
        					return;
    					}
    				}
    				
    				m_segQ = null;
    				m_txSegQIdx.setText("");
    				m_lstDBSegments.setSelection(-1);
    			}
    			catch(Exception e){}
    		}
    	});
    	
 			
    	//db list =================================================================
       	FormData formDBList = new FormData(280, 500);    
       	formDBList.top = new FormAttachment(m_lbDBSegments, 0, SWT.BOTTOM);
       	formDBList.left = new FormAttachment(m_lbDBSegments, 0, SWT.LEFT);
       	//formDBList.right = new FormAttachment(m_txSegQIdx, 0, SWT.RIGHT);
       	m_lstDBSegments = new List(m_shellMain, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
       	m_lstDBSegments.setLayoutData(formDBList);
       	m_lstDBSegments.addListener(SWT.Selection,  new Listener()
		{
			public void handleEvent(Event event)
			{
				UpdateQueryToLabel();
			}
		});
       	
    	//retrieve button ========================================================
    	FormData formRetrieveBtn = new FormData(180, 25);
    	formRetrieveBtn.top = new FormAttachment(m_lstDBSegments, 2, SWT.BOTTOM);
    	formRetrieveBtn.left = new FormAttachment(m_lstDBSegments, 0, SWT.LEFT);	
    	formRetrieveBtn.right = new FormAttachment(m_lstDBSegments, 0, SWT.RIGHT);
    	m_btnRetrieve = new Button(m_shellMain, SWT.PUSH);
    	m_btnRetrieve.setLayoutData(formRetrieveBtn);
    	m_btnRetrieve.setText("Retrieve");
    	m_btnRetrieve.addListener(SWT.Selection, new Listener() 
		{
			@Override
			public void handleEvent(Event event)
			{				
				RetrieveSegments(m_segQ.m_iId);
			}
		}); 
    	
    	//reconstruction button ========================================================
    	FormData formRecBtn = new FormData(180, 25);
    	formRecBtn.top = new FormAttachment(m_btnRetrieve, 2, SWT.BOTTOM);
    	formRecBtn.left = new FormAttachment(m_btnRetrieve, 0, SWT.LEFT);	
    	formRecBtn.right = new FormAttachment(m_btnRetrieve, 0, SWT.RIGHT);
    	m_btnReconstruct = new Button(m_shellMain, SWT.PUSH);
    	m_btnReconstruct.setLayoutData(formRecBtn);
    	m_btnReconstruct.setText("Reconstruct");
    	m_btnReconstruct.addListener(SWT.Selection, new Listener() 
		{
			@Override
			public void handleEvent(Event event)
			{				
				ReconstructSegments(m_segQ.m_iId);
			}
		}); 
    	
    	m_btnReconstructDTW = new Button(m_shellMain, SWT.CHECK);
    	/*FormData formRecDTWBtn = new FormData(180, 25);
    	formRecDTWBtn.top = new FormAttachment(m_btnReconstruct, 2, SWT.BOTTOM);
    	formRecDTWBtn.left = new FormAttachment(m_btnReconstruct, 0, SWT.LEFT);	
    	formRecDTWBtn.right = new FormAttachment(m_btnReconstruct, 0, SWT.RIGHT);
    	m_btnReconstructDTW = new Button(m_shellMain, SWT.CHECK);
    	m_btnReconstructDTW.setLayoutData(formRecDTWBtn);
    	m_btnReconstructDTW.setText("DTW");*/
    	    
    	
    	//query info ==============================================================
    	FormData formSegQLabel = new FormData(600, 22);
    	formSegQLabel.left = new FormAttachment(m_lstDBSegments, 2, SWT.RIGHT);
    	m_lbSegQ = new Label(m_shellMain, SWT.LEFT);
    	m_lbSegQ.setText("Query:");
    	m_lbSegQ.setLayoutData(formSegQLabel);
    	
    	//anno extra ==============================================================
    	FormData formAnno = new FormData(200, 22);
    	formAnno.left = new FormAttachment(m_lbSegQ, 2, SWT.RIGHT);
    	m_txAnno = new Text(m_shellMain, SWT.LEFT);
    	m_txAnno.setText("");
    	m_txAnno.setLayoutData(formAnno);
    	
		//motion viewer ===========================================================
		FormData formMotionPlayer = new FormData(1600, 550);
		formMotionPlayer.top = new FormAttachment(m_lstDBSegments, 0, SWT.TOP);
		formMotionPlayer.left = new FormAttachment(m_lstDBSegments, 2, SWT.RIGHT);
		//formMotionPlayer.bottom = new FormAttachment(m_btnRetrieve, 0, SWT.BOTTOM);
		m_ctrlMotionPlayer = new wangMultiCharacterNavigator(m_shellMain);	
		m_ctrlMotionPlayer.setLayoutData(formMotionPlayer);
		m_ctrlMotionPlayer.setGoStartAfterPlay(false);
		m_ctrlMotionPlayer.setStartFromZero(true);	
		//color
		Vector3d[] colorList = new Vector3d[15];
		colorList[0] = new Vector3d(0.9, 0.7, 0);//wooden color
		//colorList[0] = new Vector3d(1, 0.8, 0.7);
		for (int i = 1; i < 8; i++)
			colorList[i] = new Vector3d(0.7, 1, 0.8);//green //Vector3d(0.6, 0.6, 1);
		for (int i = 8; i < colorList.length; ++ i)
			colorList[i] = new Vector3d(1, 0.8, 0.7);
		m_ctrlMotionPlayer.setskeletonColorList(colorList);		

    	//result table ============================================================
    	FormData formResultLabel = new FormData(700, 300);
    	formResultLabel.top = new FormAttachment(m_ctrlMotionPlayer, 10, SWT.BOTTOM);
    	formResultLabel.left = new FormAttachment(m_ctrlMotionPlayer, 2, SWT.LEFT);
    	//formResultLabel.bottom = new FormAttachment(m_ctrlMotionPlayer, 0, SWT.BOTTOM);
    	m_lbResults = new Label(m_shellMain, SWT.TOP);
    	m_lbResults.setText("Results:\r\n ");
    	m_lbResults.setLayoutData(formResultLabel);
    	
    	//mask check ==============================================================
    	FormData formLABtn = new FormData(100, 25);
    	formLABtn.top = new FormAttachment(m_lbResults, 2, SWT.BOTTOM);
    	formLABtn.left = new FormAttachment(m_lbResults, 0, SWT.LEFT);
    	m_btnRelevantLA = new Button(m_shellMain, SWT.CHECK);
    	m_btnRelevantLA.setLayoutData(formLABtn);
    	m_btnRelevantLA.setText("Left Arm");
    	m_btnRelevantLA.setSelection(true);
    	
    	FormData formRABtn = new FormData(100, 25);
    	formRABtn.top = new FormAttachment(m_btnRelevantLA, 0, SWT.TOP);
    	formRABtn.left = new FormAttachment(m_btnRelevantLA, 2, SWT.RIGHT);
    	m_btnRelevantRA = new Button(m_shellMain, SWT.CHECK);
    	m_btnRelevantRA.setLayoutData(formRABtn);
    	m_btnRelevantRA.setText("Right Arm");
    	m_btnRelevantRA.setSelection(true);
    	
    	FormData formLLBtn = new FormData(100, 25);
    	formLLBtn.top = new FormAttachment(m_btnRelevantRA, 0, SWT.TOP);
    	formLLBtn.left = new FormAttachment(m_btnRelevantRA, 2, SWT.RIGHT);
    	m_btnRelevantLL = new Button(m_shellMain, SWT.CHECK);
    	m_btnRelevantLL.setLayoutData(formLLBtn);
    	m_btnRelevantLL.setText("Left Leg");
    	m_btnRelevantLL.setSelection(true);
    	
    	FormData formRLBtn = new FormData(100, 25);
    	formRLBtn.top = new FormAttachment(m_btnRelevantLL, 0, SWT.TOP);
    	formRLBtn.left = new FormAttachment(m_btnRelevantLL, 2, SWT.RIGHT);
    	m_btnRelevantRL = new Button(m_shellMain, SWT.CHECK);
    	m_btnRelevantRL.setLayoutData(formRLBtn);
    	m_btnRelevantRL.setText("Right Leg");
    	m_btnRelevantRL.setSelection(true);
    	
    	FormData formTSBtn = new FormData(100, 25);
    	formTSBtn.top = new FormAttachment(m_btnRelevantRL, 0, SWT.TOP);
    	formTSBtn.left = new FormAttachment(m_btnRelevantRL, 2, SWT.RIGHT);
    	m_btnRelevantTS = new Button(m_shellMain, SWT.CHECK);
    	m_btnRelevantTS.setLayoutData(formTSBtn);
    	m_btnRelevantTS.setText("Torso");
    	m_btnRelevantTS.setSelection(true);

    	FormData formExportBtn = new FormData(200, 25);
    	formExportBtn.top = new FormAttachment(m_btnRelevantTS, 0, SWT.TOP);
    	formExportBtn.left = new FormAttachment(m_btnRelevantTS, 2, SWT.RIGHT);
    	m_btnExportScene = new Button(m_shellMain, SWT.PUSH);
    	m_btnExportScene.setLayoutData(formExportBtn);
    	m_btnExportScene.setText("Export Reconstruction");
    	m_btnExportScene.addListener(SWT.Selection, new Listener() 
		{
			@Override
			public void handleEvent(Event event)
			{				
				//FastExportScene();
				ExportReconstruction();
			}
		});
    	
    	FormData formTag = new FormData(100, 25);
    	formTag.top = new FormAttachment(m_btnRelevantTS, 0, SWT.TOP);
    	formTag.left = new FormAttachment(m_btnExportScene, 2, SWT.RIGHT);
    	m_txTag = new Text(m_shellMain, SWT.LEFT);
    	m_txTag.setLayoutData(formTag);
		
    	//check box smooth ===============================================================
    	FormData formShowCheck = new FormData(300, 50);
    	formShowCheck.top = new FormAttachment(m_txAnno, 0, SWT.TOP);
    	formShowCheck.left = new FormAttachment(m_txAnno, 2, SWT.RIGHT);
    	formShowCheck.bottom = new FormAttachment(m_txAnno, 0, SWT.BOTTOM);
    	
    	m_checkShowGood = new Button(m_shellMain, SWT.CHECK);
    	m_checkShowGood.setText("Smooth Model");
    	m_checkShowGood.setLayoutData(formShowCheck);	
    	m_checkShowGood.addListener(SWT.Selection, new Listener() 
    	{
    		@Override
    		public void handleEvent(Event event)
    		{				
    			m_bShowGood = !m_bShowGood;
    		}
    	}); 

		CreateMenu();			
	}
    public void ExportReconstruction()
    {
    	//create the folder
    	int iIdx = m_lstDBSegments.getSelectionIndex(); 
    	String strDir = "C:\\wangyi\\research\\multimodality\\result\\reconstruct\\" + String.valueOf(iIdx) + "\\";
    	File file = new File(strDir);
		file.mkdirs();	
		
    	//export the file and maya config
    	WAMCMotion[] arAMC = m_ctrlMotionPlayer.getAMCMotionList();
		String strConfigName = strDir + String.valueOf(iIdx) + "_config.txt";
		String [] arToExport = new String[arAMC.length]; 
    	for(int i = 0; i < arAMC.length; ++i)
    	{
    		String strAMCName = strDir+"\\"+arAMC[i].GetAMCName() + "_rk" +String.valueOf(i) + ".amc";
    		arAMC[i].SaveToFileCMU(strAMCName);
    		arToExport[i] = strAMCName;
    	}   
    	wangHelper.ExportMayaConfig(strConfigName, arToExport);
    }
    public void FastExportScene()
    {
    	//create the folder
    	int iIdx = m_lstDBSegments.getSelectionIndex(); 
    	String strDir = "data\\Multimodal\\" + String.valueOf(iIdx);
    	File file = new File(strDir);
		file.mkdirs();	
		
    	//export the file
    	WAMCMotion[] arAMC = m_ctrlMotionPlayer.getAMCMotionList();
    	for(int i = 0; i < arAMC.length; ++i)
    	{
    		arAMC[i].SaveToFileCMU(strDir+"\\"+arAMC[i].GetAMCName() + ".rk" +String.valueOf(i) + ".amc" );
    	}     	
    }
    public void ReconstructSegments(int iIdx)
    {
    	int iDemoSize = 8;
    	wangChannelSelector cs = new wangChannelSelector(m_btnRelevantLA.getSelection(), m_btnRelevantRA.getSelection(),
    			m_btnRelevantLL.getSelection(), m_btnRelevantRL.getSelection(), m_btnRelevantTS.getSelection());
    	m_arActiveRetrieval = m_db.GetReconstructInfo(iIdx, cs);	
		UpdateResultsToLabel(m_arActiveRetrieval);
		//to motion player
		//WAMCMotion [] arAMCPlay = new WAMCMotion [2*iDemoSize +1];
		WAMCMotion [] arAMCPlay = new WAMCMotion [iDemoSize];
		arAMCPlay[0] = m_db.m_arSegment.get(iIdx).GetAMC();
		arAMCPlay[0].Relocate(new Vector3d(0, 0, 0));		

		WAMCMotion [] arAMCRec = m_db.GetReconstructAMC(iIdx, cs, m_btnReconstructDTW.getSelection());
		for (int i = 1; i < arAMCRec.length; ++i)
		{
			WAMCMotion amcSample = m_db.m_arSegment.get(m_arActiveRetrieval[i].m_iIdx).GetAMC();
			WAMCMotion amcRec = arAMCRec[i];
			
			//arAMCPlay[i+1] = amcSample;
			//arAMCPlay[i+iDemoSize+1] = amcRec;
			arAMCPlay[i] = amcRec;
			
			//amcSample.Relocate(new Vector3d(150 * (i+1), 0, 0));
			//amcRec.Relocate(new Vector3d(150 * (i+1), 0, 500));
			amcRec.Relocate(new Vector3d(150 * i, 0, 0));
		}
		m_ctrlMotionPlayer.setAMCMotionList(arAMCPlay);      	
    }
    public void RetrieveSegments(int iIdx)
    {
    	//int iDemoSize = 15;
    	int iDemoSize = 7;
    	wangChannelSelector cs = new wangChannelSelector(m_btnRelevantLA.getSelection(), m_btnRelevantRA.getSelection(),
    			m_btnRelevantLL.getSelection(), m_btnRelevantRL.getSelection(), m_btnRelevantTS.getSelection());
    	m_arActiveRetrieval = m_db.Retrieve(iIdx, cs);	
		UpdateResultsToLabel(m_arActiveRetrieval);
		//to motion player
		wangMotionSegment [] arSegment = new wangMotionSegment [iDemoSize+1];
		arSegment[0] = m_db.m_arSegment.get(iIdx);
		for(int i = 0; i < iDemoSize; ++ i)
		{
			//arSegment[i+1] = m_db.m_arSegment.get(m_arActiveRetrieval[i].m_iIdx);
			arSegment[i+1] = m_db.m_arSegment.get(m_arActiveRetrieval[i+1].m_iIdx);
		}
		PlaySegments(arSegment);    	
    }
    public void PlaySegments(wangMotionSegment [] arSegment)
    {
    	if(arSegment == null)
    		return;
    	
		WAMCMotion [] arAMCList = new WAMCMotion[arSegment.length];
		for (int i = 0; i < arAMCList.length; ++i)
		{
			WAMCMotion amc = arSegment[i].GetAMC();
			//amc.Relocate(new Vector3d(150 * i, 0, 0));
			float x = 150 *(i%10);
			int z = 150*i/10;
			amc.Relocate(new Vector3d(x, 0, z));
			arAMCList[i] = amc;
		}
		m_ctrlMotionPlayer.setAMCMotionList(arAMCList);
    }
	protected void CreateMenu() 
	{
		Menu bar = new Menu (m_shellMain, SWT.BAR);
		m_shellMain.setMenuBar (bar);
		{
			//load db
			MenuItem fileItem1 = new MenuItem(bar, SWT.PUSH);
			fileItem1.setText("Load DB");
			fileItem1.addSelectionListener(new SelectionAdapter()
			{
				public void widgetSelected(SelectionEvent e)
				{
					LoadDB(false);
				}
			});
			
			//load db - manual
			MenuItem fileItemLoadManual = new MenuItem(bar, SWT.PUSH);
			fileItemLoadManual.setText("Load DB - 2");
			fileItemLoadManual.addSelectionListener(new SelectionAdapter()
			{
				public void widgetSelected(SelectionEvent e)
				{
					LoadDB(true);
				}
			});
			
			//load amc
			MenuItem fileItem2 = new MenuItem(bar, SWT.PUSH);
			fileItem2.setText("Load AMC");
			fileItem2.addSelectionListener(new SelectionAdapter() 
			{
				public void widgetSelected(SelectionEvent e)
				{
					LoadAMC();
				}
			});
			
			//splice naive 2
			MenuItem fileItem3 = new MenuItem(bar, SWT.PUSH);
			fileItem3.setText("Test Bvh");
			fileItem3.addSelectionListener(new SelectionAdapter() 
			{
				public void widgetSelected(SelectionEvent e)
				{ 
					String strFilePath1 = "C:\\wangyi\\research\\disney\\Fighting\\Fighting\\workspace-dump\\MotionLibrary\\data\\Splice\\Loco\\runLong120FPS.137.45.8.500_Take_001.bvh";
					File fileGestBvh1 = new File(strFilePath1);
					MotionData gestMotionData1 = new BVHParser().parse(fileGestBvh1);
					MotionData gestMotionDataLocal1 = WRawFile.ToLocal(gestMotionData1);
					
					String strFilePath2 = "C:\\wangyi\\research\\disney\\Fighting\\Fighting\\workspace-dump\\MotionLibrary\\data\\Splice\\Loco\\walkLong120FPS.442.20.10.160_Take_001.bvh";
					File fileGestBvh2 = new File(strFilePath2);
					MotionData gestMotionData2 = new BVHParser().parse(fileGestBvh2);
					MotionData gestMotionDataLocal2 = WRawFile.ToLocal(gestMotionData2);
					
					MotionData[] motionDataList = new MotionData[4];
					motionDataList[0] = gestMotionData1;				
					motionDataList[1] = gestMotionDataLocal1;					
					motionDataList[2] = gestMotionData2;				
					motionDataList[3] = gestMotionDataLocal2;
					m_ctrlMotionPlayer.setMotionDataList(motionDataList);
					m_ctrlMotionPlayer.startAnimation(); 
				}
			});

			
			MenuItem macroItem = new MenuItem (bar, SWT.CASCADE);
			macroItem.setText ("M&acro");
			Menu macroSubMenu = new Menu (m_shellMain, SWT.DROP_DOWN);
			macroItem.setMenu (macroSubMenu);
			{
				//export results
				MenuItem exportItem = new MenuItem(macroSubMenu, SWT.PUSH);
				exportItem.setText("Test ASF Parser");
				exportItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 	
						WASFSkeleton.test();
					}
				});
				
				//show group
				MenuItem showGroupItem = new MenuItem(macroSubMenu, SWT.PUSH);
				showGroupItem.setText("Load Hand BVH");
				showGroupItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{
						String strFilePath1 = "C:\\wangyi\\research\\multimodality\\asf amc maya importer\\spreadOut_S.bvh";
						File fileGestBvh1 = new File(strFilePath1);
						MotionData gestMotionData1 = new BVHParser().parse(fileGestBvh1);
						//MotionData gestMotionDataLocal1 = WRawFile.ToLocal(gestMotionData1);
						
						MotionData[] motionDataList = new MotionData[1];
						motionDataList[0] = gestMotionData1;				
						//motionDataList[1] = gestMotionDataLocal1;	
						m_ctrlMotionPlayer.setMotionDataList(motionDataList);
						m_ctrlMotionPlayer.startAnimation(); 
						
					}
				});
				
				//clear group
				MenuItem clearGroupItem = new MenuItem(macroSubMenu, SWT.PUSH);
				clearGroupItem.setText("Test Amc");
				clearGroupItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
						WASFSkeleton asf = new WASFSkeleton();
						asf.m_fScale = 3;
						asf.ParseFile("C:\\wangyi\\research\\CMUDB\\asf\\test.asf");
						WAMCMotion amc = new WAMCMotion(asf);
						amc.LoadFromFile("C:\\wangyi\\research\\CMUDB\\asf\\test.amc");
						WAMCMotion [] arAmcList = new WAMCMotion[1];
						arAmcList[0] = amc;
						m_ctrlMotionPlayer.setAMCMotionList(arAmcList);
						m_ctrlMotionPlayer.startAnimation(); 
					}
				});
				
				//export group
				MenuItem exportGroupItem = new MenuItem(macroSubMenu, SWT.PUSH);
				exportGroupItem.setText("test human amc");
				exportGroupItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
						WASFSkeleton asf = new WASFSkeleton();
						asf.m_fScale = 7;
						asf.ParseFile("C:\\wangyi\\research\\CMUDB\\18.asf");
						WAMCMotion amc = new WAMCMotion(asf);
						WASFSkeleton.m_asf = asf;
						amc.LoadFromFile("C:\\wangyi\\research\\CMUDB\\18_01.amc");
						amc.Relocate(new Vector3d(100, 150, 0));
						WAMCMotion [] arAmcList = new WAMCMotion[1];
						arAmcList[0] = amc;
						m_ctrlMotionPlayer.setAMCMotionList(arAmcList);
					}
				});
				MenuItem styleItem = new MenuItem(macroSubMenu, SWT.PUSH);
				styleItem.setText("Clone Test");
				styleItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
						WASFSkeleton asf = new WASFSkeleton();
						asf.m_fScale = 7;
						asf.ParseFile("C:\\wangyi\\research\\CMUDB\\18.asf");
						
						WAMCMotion amc = new WAMCMotion(asf);
						amc.LoadFromFile("C:\\wangyi\\research\\CMUDB\\18_01.amc");
						amc.Relocate(new Vector3d(0, 150, 0));
						
						WASFSkeleton asf2 = new WASFSkeleton();
						asf2.m_fScale = 7;
						asf2.ParseFile("C:\\wangyi\\research\\CMUDB\\18.asf");
						WAMCMotion amc2 = new WAMCMotion(asf2);
						amc2.LoadFromFile("C:\\wangyi\\research\\CMUDB\\18_01.amc");
						amc2.Relocate(new Vector3d(250, 150, 0));
								

						WAMCMotion amcClone = new WAMCMotion(amc);
						amcClone.Relocate(new Vector3d(500, 150, 0));
						
						WAMCMotion [] arAmcList = new WAMCMotion[3];
						arAmcList[0] = amc;
						arAmcList[1] = amc2;
						arAmcList[2] = amcClone;
						m_ctrlMotionPlayer.setAMCMotionList(arAmcList);
					}
				});
				MenuItem crowdsItem = new MenuItem(macroSubMenu, SWT.PUSH);
				crowdsItem.setText("Test DTW");
				crowdsItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
						wangDTW.m_shellMain = m_shellMain;
						wangDTW.Test();
					}
				});				
				MenuItem crowdsItem2 = new MenuItem(macroSubMenu, SWT.PUSH);
				crowdsItem2.setText("Test AMC Export");
				crowdsItem2.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{
						WASFSkeleton asf = new WASFSkeleton();
						asf.m_fScale = 7;
						asf.ParseFile("C:\\wangyi\\research\\CMUDB\\18.asf");
						WAMCMotion amc = new WAMCMotion(asf);
						amc.LoadFromFile("C:\\wangyi\\research\\CMUDB\\18_01.amc");
						amc.SaveToFileCMU("C:\\wangyi\\research\\CMUDB\\18_01.exp.amc");
					}
				});
				MenuItem apiItem = new MenuItem(macroSubMenu, SWT.PUSH);
				apiItem.setText("Evaluate");
				apiItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 		
						float fErr = m_db.EvaluateReconstructionAll();
						String strEvalResult = "Evaluation of Reconstruction:\r\nAverage Error: ";
						strEvalResult += String.valueOf(fErr);
						m_lbResults.setText(strEvalResult);
					}
				});
				
				MenuItem eItem = new MenuItem(macroSubMenu, SWT.PUSH);
				eItem.setText("Empty");
				eItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{}
				});
				
				MenuItem eItem2 = new MenuItem(macroSubMenu, SWT.PUSH);
				eItem2.setText("Empty");
				eItem2.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{}
				});
			}
			
			//export for maya rendering
			MenuItem fileItemExportConfigPair = new MenuItem(bar, SWT.PUSH);
			fileItemExportConfigPair.setText("Export MAYA Config - 2");
			fileItemExportConfigPair.addSelectionListener(new SelectionAdapter() 
			{
				public void widgetSelected(SelectionEvent e)
				{
					wangHelper.ExportMayaConfigInPair(m_arActiveRetrieval, m_db);
				}
			});
			
			//export for maya rendering
			MenuItem fileItemExportConfigBatch = new MenuItem(bar, SWT.PUSH);
			fileItemExportConfigBatch.setText("Export MAYA Config - 10");
			fileItemExportConfigBatch.addSelectionListener(new SelectionAdapter() 
			{
				public void widgetSelected(SelectionEvent e)
				{
					wangHelper.ExportMayaConfigBatch(m_arActiveRetrieval, m_db, m_txAnno.getText());
				}
			});
			
			//create db folder structure
			MenuItem fileItemDBFolder = new MenuItem(bar, SWT.PUSH);
			fileItemDBFolder.setText("DB Folder");
			fileItemDBFolder.addSelectionListener(new SelectionAdapter() 
			{
				public void widgetSelected(SelectionEvent e)
				{
					JFileChooser jfc = new JFileChooser();
					jfc.setDialogTitle("Select DB base path for folder generation");
					jfc.setDialogType(JFileChooser.OPEN_DIALOG);
					jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					int res = jfc.showOpenDialog(null);
					if (res == JFileChooser.APPROVE_OPTION) 
					{
					   File dir = jfc.getSelectedFile();
					   String strBase = dir.getAbsolutePath();
					   wangHelper.CreateDBFolderStructure(strBase);	
					}				
				}
			});
		}	
	}
	
	public void LoadAMC()
	{	
		FileDialog dlg = new FileDialog(m_shellMain, SWT.OPEN);
		dlg.setText("Open AMC File");
		String [] arFilterExt = {"*.amc", "*.asf"};
		dlg.setFilterExtensions(arFilterExt);
		String strAMCPath = dlg.open();
		
		if(strAMCPath == null || strAMCPath == "")
			return;
		
		String strASFPath = wangMotionDB.ConvertToASFPath(strAMCPath);
		WASFSkeleton asf = new WASFSkeleton();
		asf.ParseFile(strASFPath);
		
		WAMCMotion amc = new WAMCMotion(asf);
		amc.LoadFromFile(strAMCPath);
		WAMCMotion [] arAmcList = new WAMCMotion[1];
		arAmcList[0] = amc;
		m_ctrlMotionPlayer.setAMCMotionList(arAmcList);
		m_ctrlMotionPlayer.startAnimation(); 
		
	}
	
	public void OpenShow(int width, int height)
	{
		m_shellMain.pack();
		m_shellMain.open();
		while(!m_shellMain.isDisposed())
		{
			if(!m_displayMain.readAndDispatch())
			{
				m_displayMain.sleep();
			}
		}
		m_displayMain.dispose();		
	}

}