package wangDeep;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class wangHelper 
{
	public static void CreateDBFolderStructure(String strBase)
	{
		//Interaction with Enviroment
		File file = new File(strBase + "\\Interaction with Enviroment\\path with obstacles");
		file.mkdirs();	
		file = new File(strBase + "\\Interaction with Enviroment\\playground");
		file.mkdirs();	
		file = new File(strBase + "\\Interaction with Enviroment\\uneven terrain");
		file.mkdirs();	
		
		//Locomotion
		file = new File(strBase + "\\Locomotion\\jumping");
		file.mkdirs();
		file = new File(strBase + "\\Locomotion\\running");
		file.mkdirs();
		file = new File(strBase + "\\Locomotion\\varied");
		file.mkdirs();
		file = new File(strBase + "\\Locomotion\\walking");
		file.mkdirs();
		
		//Physical Activities & Sports
		file = new File(strBase + "\\Physical Activities & Sports\\acrobatics");
		file.mkdirs();
		file = new File(strBase + "\\Physical Activities & Sports\\basketball");
		file.mkdirs();
		file = new File(strBase + "\\Physical Activities & Sports\\boxing");
		file.mkdirs();
		file = new File(strBase + "\\Physical Activities & Sports\\dance");
		file.mkdirs();
		file = new File(strBase + "\\Physical Activities & Sports\\general excercise and stretching");
		file.mkdirs();
		file = new File(strBase + "\\Physical Activities & Sports\\gymnastics");
		file.mkdirs();
		file = new File(strBase + "\\Physical Activities & Sports\\martial arts");
		file.mkdirs();
		file = new File(strBase + "\\Physical Activities & Sports\\soccer");
		file.mkdirs();
		
		//Situations & Scenarios
		file = new File(strBase + "\\Situations & Scenarios\\common behaviors and expressions");
		file.mkdirs();
		file = new File(strBase + "\\Situations & Scenarios\\communication gestures and signals");
		file.mkdirs();
		file = new File(strBase + "\\Situations & Scenarios\\cross-category variety");
		file.mkdirs();
		file = new File(strBase + "\\Situations & Scenarios\\pantomime");
		file.mkdirs();		
	}
	public static void ExportMayaConfigInPair(wangHammingDistance[] arRet, wangMotionDB db)
	{
		if(arRet == null)
			return;
		
		String strDBName = "MayaConfigInPairAutoDB";
		wangHammingDistance[] arToExport = new wangHammingDistance[2];
		arToExport[0] = arRet[0];
		int iCaseNum = 7;
		for(int i = 0; i < iCaseNum; ++ i)
		{
			arToExport[1] = arRet[i];
			exportMayaConfig(arToExport, db, strDBName, String.valueOf(i+1), "");
		}
	}
	
	public static void ExportMayaConfigBatch(wangHammingDistance[] arRet, wangMotionDB db, String strAnno)
	{
		if(arRet == null)
			return;
		
		String strDBName = "MayaConfigBatchAutoDB";
		int iCasesInBatch = 12;
		wangHammingDistance[] arToExport = new wangHammingDistance[iCasesInBatch];
		for(int i = 0; i < iCasesInBatch; ++i)
		{
			arToExport[i] = arRet[i];
		}
		exportMayaConfig(arToExport, db, strDBName, "", strAnno);
	}
	
	static void exportMayaConfig(wangHammingDistance[] arToExport, wangMotionDB db, String strDBName, String strSerialNum, String strAnno)
	{
		if(arToExport == null || db == null)
			return;
		
		String strPrefix = "Config_File:\r\nASF_route: K:\\research\\CMUDB\\ASF\r\nColors(0=red,1=blue,2=green)\r\n";
		String strPath = db.m_arSegment.get(arToExport[0].m_iIdx).m_strPath;
		strPath = strPath.replace("SegmentDB", strDBName);
		int iDot = strPath.lastIndexOf(".");
		strPath = strPath.substring(0, iDot);
		strPath = strPath + "_" + strAnno + "_config" + strSerialNum + ".txt";
		try
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter(strPath));	
			bw.write(strPrefix);
			bw.write("NumberOfAMCFiles: ");
			bw.write(String.valueOf(arToExport.length));
			bw.write("\r\n");
			for (int i = 0; i < arToExport.length; ++i)
			{ 
				String strAmcPath = db.m_arSegment.get(arToExport[i].m_iIdx).m_strPath;
				strAmcPath = strAmcPath.replace("C:\\wangyi", "K:");
				bw.write("AMC_FILE");
				bw.write(String.valueOf(i+1));
				if(i==0)
					bw.write("(Target)");
            	bw.write(": ");
            	bw.write(strAmcPath);
            	bw.write(" ");
            	if(i==0)
            		bw.write("1");
            	else
            		bw.write("2");
            	bw.write("\r\n");
			}
            bw.flush();
            bw.close();
		}catch(Exception e)
		{}
	}
	
	public static void ExportMayaConfig(String strConfigName, String[] arToExport)
	{
		if(arToExport == null)
			return;
		
		String strPrefix = "Config_File:\r\nASF_route: K:\\research\\CMUDB\\ASF\r\nColors(0=red,1=blue,2=green)\r\n";
		try
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter(strConfigName));	
			bw.write(strPrefix);
			bw.write("NumberOfAMCFiles: ");
			bw.write(String.valueOf(arToExport.length));
			bw.write("\r\n");
			for (int i = 0; i < arToExport.length; ++i)
			{ 
				String strAmcPath = arToExport[i];
				strAmcPath = strAmcPath.replace("C:\\wangyi", "K:");
				bw.write("AMC_FILE");
				bw.write(String.valueOf(i+1));
				if(i==0)
					bw.write("(Target)");
            	bw.write(": ");
            	bw.write(strAmcPath);
            	bw.write(" ");
            	if(i==0)
            		bw.write("1");
            	else
            		bw.write("2");
            	bw.write("\r\n");
			}
            bw.flush();
            bw.close();
		}catch(Exception e)
		{}
	}
}
