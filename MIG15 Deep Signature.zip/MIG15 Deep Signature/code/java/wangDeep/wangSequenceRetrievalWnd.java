package wangDeep;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JFileChooser;
import javax.vecmath.Vector3d;

import mrl.motion.data.MotionData;
import mrl.motion.data.parser.BVHParser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Text;

import wang.WAMCMotion;
import wang.WASFSkeleton;
import wang.WRawFile;
import wang.wangChannelSelector;
import wangUI.wangMultiCharacterNavigator;

public class wangSequenceRetrievalWnd {

	public static boolean m_bShowGood = false;
	public static Shell m_shellMain;
	private Display m_displayMain;
	
	//UI
	public List m_lstSequence;
	public List m_lstSegment;
	public Label m_lbSequence;
	public Label m_lbSegment;
	
	//mask
	public Button m_btnRelevantLA;
	public Button m_btnRelevantRA;
	public Button m_btnRelevantLL;
	public Button m_btnRelevantRL;
	public Button m_btnRelevantTS;
	
	//retrieval
	public Text m_txSegIdxBeg;
	public Text m_txSegIdxEnd;
	public Button m_btnRetrieve;
	public Text m_txThresholdBeg;
	public Text m_txThresholdEnd;
	public Button m_checkRetrieveFixedBeg;
	public Button m_checkAverageDistance;
	public wangSequenceInfo m_query;
	public ArrayList<wangSequenceInfo> m_arSeqInfo;

	public wangMultiCharacterNavigator m_ctrlMotionPlayer;
	public Button m_checkShowGood;
	
	//result
	public Label m_lbSeqResult;
	
	//db
	wangMotionDB m_db;
	public wangSequenceRetrievalWnd(String strCMUDBPath)
	{
		m_displayMain = new Display();
		m_shellMain = new Shell(m_displayMain);
		m_shellMain.setText("Yingying!");
		
		InitializeUI();
	} 
	public void InitializeUI() 
	{
    	//layout
    	FormLayout formLO = new FormLayout();
    	formLO.marginHeight = 10;
    	formLO.marginWidth = 10;
    	m_shellMain.setLayout(formLO);
    	
    	//sequence label=================================================================
    	FormData formDBLabel = new FormData(100, 22);
    	m_lbSequence = new Label(m_shellMain, SWT.LEFT);
    	m_lbSequence.setText("Sequences:");
    	m_lbSequence.setLayoutData(formDBLabel);
    	
    	//sequence list =================================================================
       	FormData formDBList = new FormData(100, 500);    
       	formDBList.top = new FormAttachment(m_lbSequence, 0, SWT.BOTTOM);
       	formDBList.left = new FormAttachment(m_lbSequence, 0, SWT.LEFT);
       	m_lstSequence = new List(m_shellMain, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
       	m_lstSequence.setLayoutData(formDBList);
       	m_lstSequence.addListener(SWT.Selection,  new Listener()
		{
			public void handleEvent(Event event)
			{
				//update the segments info of the selected sequence
				LoadSegments();
			}
		});
       	
       	//segment label ========================================================
    	FormData formSegLabel = new FormData(150, 22);
    	formSegLabel.top = new FormAttachment(m_lbSequence, 0, SWT.TOP);
    	formSegLabel.left = new FormAttachment(m_lstSequence, 2, SWT.RIGHT);
    	m_lbSequence = new Label(m_shellMain, SWT.LEFT);
    	m_lbSequence.setLayoutData(formSegLabel);
    	m_lbSequence.setText("Segments:");
    	
    	//segment list ========================================================
    	FormData formSegmentList = new FormData(150, 500);
    	formSegmentList.top = new FormAttachment(m_lstSequence, 0, SWT.TOP);
    	formSegmentList.left = new FormAttachment(m_lstSequence, 2, SWT.RIGHT);
    	m_lstSegment = new List(m_shellMain, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
    	m_lstSegment.setLayoutData(formSegmentList);
    	m_lstSegment.addListener(SWT.Selection, new Listener() 
		{
			@Override
			public void handleEvent(Event event)
			{				
				int iSegIdx = m_lstSegment.getSelectionIndex();
				if(iSegIdx == -1)
					return;
				
				int iSeqIdx = m_lstSequence.getSelectionIndex();
				if(iSeqIdx == -1)
					return;
				
				wangMotionSequence seq = m_db.GetSequenceAll().get(iSeqIdx);
				wangMotionSegment seg = seq.m_arSeg.get(iSegIdx);
				wangMotionSegment[] arSeg = new wangMotionSegment[1];
				arSeg[0] = seg;
				PlaySegments(arSeg);
			}
		}); 
    	
    	//retrieval ===============================================================
    	FormData formSegBegTxt = new FormData(30, 22);
    	formSegBegTxt.top = new FormAttachment(m_lstSequence, 2, SWT.BOTTOM);
    	formSegBegTxt.left = new FormAttachment(m_lstSequence, 0, SWT.LEFT);
    	m_txSegIdxBeg = new Text(m_shellMain, SWT.LEFT);
    	m_txSegIdxBeg.setLayoutData(formSegBegTxt);
    	
    	FormData formSegEndTxt = new FormData(30, 22);
    	formSegEndTxt.top = new FormAttachment(m_lstSequence, 2, SWT.BOTTOM);
    	formSegEndTxt.left = new FormAttachment(m_txSegIdxBeg, 10, SWT.RIGHT);
    	m_txSegIdxEnd = new Text(m_shellMain, SWT.LEFT);
    	m_txSegIdxEnd.setLayoutData(formSegEndTxt);
    	
    	FormData formRetrieveBtn = new FormData(70, 22);
    	formRetrieveBtn.top = new FormAttachment(m_lstSequence, 2, SWT.BOTTOM);
    	formRetrieveBtn.left = new FormAttachment(m_txSegIdxEnd, 10, SWT.RIGHT);
    	m_btnRetrieve = new Button(m_shellMain, SWT.PUSH);
    	m_btnRetrieve.setLayoutData(formRetrieveBtn);
    	m_btnRetrieve.setText("Retrieve");
    	m_btnRetrieve.addListener(SWT.Selection, new Listener() 
		{
			@Override
			public void handleEvent(Event event)
			{				
				RetrieveSequence();
			}
		}); 
    	FormData formThresholdBegTxt = new FormData(30, 22);
    	formThresholdBegTxt.top = new FormAttachment(m_txSegIdxBeg, 2, SWT.BOTTOM);
    	formThresholdBegTxt.left = new FormAttachment(m_lstSequence, 0, SWT.LEFT);
    	m_txThresholdBeg = new Text(m_shellMain, SWT.LEFT);
    	m_txThresholdBeg.setLayoutData(formThresholdBegTxt);
    	
    	FormData formThresholdEndTxt = new FormData(30, 22);
    	formThresholdEndTxt.top = new FormAttachment(m_txThresholdBeg, 0, SWT.TOP);
    	formThresholdEndTxt.left = new FormAttachment(m_txThresholdBeg, 10, SWT.RIGHT);
    	m_txThresholdEnd = new Text(m_shellMain, SWT.LEFT);
    	m_txThresholdEnd.setLayoutData(formThresholdEndTxt);
    	
    	FormData formFixedBegCheck = new FormData(90, 22);
    	formFixedBegCheck.top = new FormAttachment(m_txThresholdBeg, 0, SWT.TOP);
    	formFixedBegCheck.left = new FormAttachment(m_txThresholdEnd, 10, SWT.RIGHT);
    	m_checkRetrieveFixedBeg = new Button(m_shellMain, SWT.CHECK);
    	m_checkRetrieveFixedBeg.setLayoutData(formFixedBegCheck);
    	m_checkRetrieveFixedBeg.setText("Fix Beg Only");
    	m_checkRetrieveFixedBeg.setSelection(true);

    	FormData formAverageDistanceCheck = new FormData(100, 22);
    	formAverageDistanceCheck.top = new FormAttachment(m_txThresholdBeg, 0, SWT.TOP);
    	formAverageDistanceCheck.left = new FormAttachment(m_checkRetrieveFixedBeg, 10, SWT.RIGHT);
    	m_checkAverageDistance = new Button(m_shellMain, SWT.CHECK);
    	m_checkAverageDistance.setText("Average Distance");
    	m_checkAverageDistance.setLayoutData(formAverageDistanceCheck);
    	    	    	    	
    	//motion viewer ===========================================================
    	FormData formMotionPlayer = new FormData(700, 600);
    	formMotionPlayer.top = new FormAttachment(m_lstSegment, 0, SWT.TOP);
    	formMotionPlayer.left = new FormAttachment(m_lstSegment, 2, SWT.RIGHT);
    	formMotionPlayer.bottom = new FormAttachment(m_lstSegment, 0, SWT.BOTTOM);
    	m_ctrlMotionPlayer = new wangMultiCharacterNavigator(m_shellMain);	
    	m_ctrlMotionPlayer.setLayoutData(formMotionPlayer);
    	m_ctrlMotionPlayer.setGoStartAfterPlay(false);
    	m_ctrlMotionPlayer.setStartFromZero(true);	
    	//color
    	Vector3d[] colorList = new Vector3d[15];
    	colorList[0] = new Vector3d(0.9, 0.7, 0);//wooden color
    	//colorList[0] = new Vector3d(1, 0.8, 0.7);
    	for (int i = 1; i < 6; i++)
    		colorList[i] = new Vector3d(0.7, 1, 0.8);//green //Vector3d(0.6, 0.6, 1);
    	for (int i = 6; i < colorList.length; ++ i)
    		colorList[i] = new Vector3d(1, 0.8, 0.7);
    	m_ctrlMotionPlayer.setskeletonColorList(colorList);		
    	    
    	//mask check ==============================================================
    	FormData formLABtn = new FormData(100, 25);
    	formLABtn.top = new FormAttachment(m_ctrlMotionPlayer, 2, SWT.BOTTOM);
    	formLABtn.left = new FormAttachment(m_ctrlMotionPlayer, 0, SWT.LEFT);
    	m_btnRelevantLA = new Button(m_shellMain, SWT.CHECK);
    	m_btnRelevantLA.setLayoutData(formLABtn);
    	m_btnRelevantLA.setText("Left Arm");
    	m_btnRelevantLA.setSelection(true);
    	
    	FormData formRABtn = new FormData(100, 25);
    	formRABtn.top = new FormAttachment(m_btnRelevantLA, 0, SWT.TOP);
    	formRABtn.left = new FormAttachment(m_btnRelevantLA, 2, SWT.RIGHT);
    	m_btnRelevantRA = new Button(m_shellMain, SWT.CHECK);
    	m_btnRelevantRA.setLayoutData(formRABtn);
    	m_btnRelevantRA.setText("Right Arm");
    	m_btnRelevantRA.setSelection(true);
    	
    	FormData formLLBtn = new FormData(100, 25);
    	formLLBtn.top = new FormAttachment(m_btnRelevantRA, 0, SWT.TOP);
    	formLLBtn.left = new FormAttachment(m_btnRelevantRA, 2, SWT.RIGHT);
    	m_btnRelevantLL = new Button(m_shellMain, SWT.CHECK);
    	m_btnRelevantLL.setLayoutData(formLLBtn);
    	m_btnRelevantLL.setText("Left Leg");
    	m_btnRelevantLL.setSelection(true);
    	
    	FormData formRLBtn = new FormData(100, 25);
    	formRLBtn.top = new FormAttachment(m_btnRelevantLL, 0, SWT.TOP);
    	formRLBtn.left = new FormAttachment(m_btnRelevantLL, 2, SWT.RIGHT);
    	m_btnRelevantRL = new Button(m_shellMain, SWT.CHECK);
    	m_btnRelevantRL.setLayoutData(formRLBtn);
    	m_btnRelevantRL.setText("Right Leg");
    	m_btnRelevantRL.setSelection(true);
    	
    	FormData formTSBtn = new FormData(100, 25);
    	formTSBtn.top = new FormAttachment(m_btnRelevantRL, 0, SWT.TOP);
    	formTSBtn.left = new FormAttachment(m_btnRelevantRL, 2, SWT.RIGHT);
    	m_btnRelevantTS = new Button(m_shellMain, SWT.CHECK);
    	m_btnRelevantTS.setLayoutData(formTSBtn);
    	m_btnRelevantTS.setText("Torso");
    	m_btnRelevantTS.setSelection(true);

    	//check box ===============================================================
		FormData formShowCheck = new FormData(300, 25);
		formShowCheck.top = new FormAttachment(m_btnRelevantTS, 0, SWT.TOP);
		formShowCheck.left = new FormAttachment(m_btnRelevantTS, 2, SWT.RIGHT);
		m_checkShowGood = new Button(m_shellMain, SWT.CHECK);
		m_checkShowGood.setText("Show Good?");
		m_checkShowGood.setLayoutData(formShowCheck);	
		m_checkShowGood.addListener(SWT.Selection, new Listener() 
		{
			@Override
			public void handleEvent(Event event)
			{				
				m_bShowGood = !m_bShowGood;
			}
		}); 
		
		//result ===================================================================		
		FormData formResultTxt = new FormData(280, 600);
		formResultTxt.top = new FormAttachment(m_ctrlMotionPlayer, 0, SWT.TOP);
    	formResultTxt.left = new FormAttachment(m_ctrlMotionPlayer, 3, SWT.RIGHT);
    	m_lbSeqResult = new Label(m_shellMain, SWT.TOP | SWT.LEFT);
    	m_lbSeqResult.setLayoutData(formResultTxt);
		CreateMenu();			
	}
	
	protected void CreateMenu() 
	{
		Menu bar = new Menu (m_shellMain, SWT.BAR);
		m_shellMain.setMenuBar (bar);
		{
			//load db
			MenuItem fileItem1 = new MenuItem(bar, SWT.PUSH);
			fileItem1.setText("Load Sequences");
			fileItem1.addSelectionListener(new SelectionAdapter()
			{
				public void widgetSelected(SelectionEvent e)
				{
					LoadSequences();
				}
			});
			MenuItem macroItem = new MenuItem (bar, SWT.CASCADE);
			macroItem.setText ("M&acro");
			Menu macroSubMenu = new Menu (m_shellMain, SWT.DROP_DOWN);
			macroItem.setMenu (macroSubMenu);
			{
				//Load AMC
				MenuItem exportItem = new MenuItem(macroSubMenu, SWT.PUSH);
				exportItem.setText("Load AMC");
				exportItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
						LoadAMC();
					}
				});
				
				//export result of sequence search
				MenuItem showGroupItem = new MenuItem(macroSubMenu, SWT.PUSH);
				showGroupItem.setText("Export Sequence Search - Simplified");
				showGroupItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{
						//just dump txt in result label to files
						String strText = m_lbSeqResult.getText();
						int iLineSep = strText.indexOf("\r\n");
						String strTitle = strText.substring(0, iLineSep);
						String strDir = "data\\Multimodal\\SequenceRetrieval\\";
				    	File file = new File(strDir);
						file.mkdirs();	
						
						try
						{
							BufferedWriter bw = new BufferedWriter(new FileWriter(strDir + strTitle + ".txt"));	
							bw.write("Fixed Beg Only: " + String.valueOf(m_checkRetrieveFixedBeg.getSelection()));
							bw.write("\r\n");
							bw.write("Average Distance: " + String.valueOf(m_checkAverageDistance.getSelection()));
							bw.write("\r\n");
							bw.write("\r\n");
							bw.write(strText);
							bw.flush();
				            bw.close();
						}catch(Exception ex)
						{} 						
					}
				});
				
				//
				MenuItem clearGroupItem = new MenuItem(macroSubMenu, SWT.PUSH);
				clearGroupItem.setText("Empty");
				clearGroupItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
						
					}
				});
				
				//
				MenuItem exportGroupItem = new MenuItem(macroSubMenu, SWT.PUSH);
				exportGroupItem.setText("Empty");
				exportGroupItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
						
					}
				});
				MenuItem styleItem = new MenuItem(macroSubMenu, SWT.PUSH);
				styleItem.setText("Empty");
				styleItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
						
					}
				});
			}
			//create db folder structure
			MenuItem fileItemDBFolder = new MenuItem(bar, SWT.PUSH);
			fileItemDBFolder.setText("DB Folder");
			fileItemDBFolder.addSelectionListener(new SelectionAdapter() 
			{
				public void widgetSelected(SelectionEvent e)
				{
					JFileChooser jfc = new JFileChooser();
					jfc.setDialogTitle("Select DB base path for folder generation");
					jfc.setDialogType(JFileChooser.OPEN_DIALOG);
					jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					int res = jfc.showOpenDialog(null);
					if (res == JFileChooser.APPROVE_OPTION) 
					{
					   File dir = jfc.getSelectedFile();
					   String strBase = dir.getAbsolutePath();
					   wangHelper.CreateDBFolderStructure(strBase);	
					}				
				}
			});
		}	
	}
	public void LoadSequences()
	{
		m_db = new wangMotionDB();
		String strBasePath = "C:\\wangyi\\research\\multimodality\\experiments\\10.3.LocalizedDataAutoSeg\\result\\formaya\\lookup\\";
		m_db.LoadFrom(strBasePath, false);
		
		//put info into the sequence list
		m_lstSequence.removeAll();
		ArrayList<wangMotionSequence> arSequence = m_db.GetSequenceAll();
		for(int i = 0; i < arSequence.size(); ++ i)
		{
			wangMotionSequence seq = arSequence.get(i);
			String strSeq = String.valueOf(seq.m_iSequenceIndex);
			strSeq += ". " + seq.GetAMCName();
			m_lstSequence.add(strSeq);
		}		
	}
	public void LoadSegments()
	{
		int iSelIdx = m_lstSequence.getSelectionIndex();
		if(iSelIdx == -1)
			return;
		
		wangMotionSequence seq = m_db.GetSequenceAll().get(iSelIdx);
		
		//put info into the segment list
		m_lstSegment.removeAll();
		for(int i = 0; i < seq.m_arSeg.size(); ++i)
		{
			wangMotionSegment seg = seq.m_arSeg.get(i);
			String strSeg = String.valueOf(i);
			strSeg += ". " + seg.GetAMCFileName();
 			m_lstSegment.add(strSeg);
		}
		m_lstSegment.setSelection(-1);
		wangMotionSequence [] arSeq = new wangMotionSequence[1];
		arSeq[0] = seq;
		PlaySequences(arSeq);
	}
    public void RetrieveSequence()
    {
    	ArrayList<wangMotionSequence> arSequenceAll = m_db.GetSequenceAll();       	
    	int iSequenceIndex = m_lstSequence.getSelectionIndex();
    	if(iSequenceIndex < 0 || iSequenceIndex >= arSequenceAll.size())
    		return;    	
    	
    	wangMotionSequence seqQuery = arSequenceAll.get(iSequenceIndex);
    	String strSegIndexBeg = m_txSegIdxBeg.getText();
    	int iSegIndexBeg = -1;
    	if(strSegIndexBeg.isEmpty())
    		iSegIndexBeg = 0;
    	else 
    		iSegIndexBeg = Integer.valueOf(strSegIndexBeg);
    	
    	String strSegIndexEnd = m_txSegIdxEnd.getText();
    	int iSegIndexEnd = -1; 
    	if(strSegIndexEnd.isEmpty())
    		iSegIndexEnd = seqQuery.m_arSeg.size()-1;
    	else
    		iSegIndexEnd = Integer.valueOf(strSegIndexEnd);
    	
    	if(iSegIndexBeg > iSegIndexEnd ||
    		iSegIndexBeg < 0 || iSegIndexEnd >= seqQuery.m_arSeg.size())
    		return;
    	
    	//check the retrieval method
    	boolean bFixedBeg = m_checkRetrieveFixedBeg.getSelection();
    	boolean bAverageDistance = m_checkAverageDistance.getSelection();
    	String strThresholdBeg = m_txThresholdBeg.getText();
    	int iThresholdBeg = -1;
    	if(!strThresholdBeg.isEmpty())
    		iThresholdBeg = Integer.valueOf(strThresholdBeg);
    	
    	String strThresholdEnd = m_txThresholdEnd.getText();
    	int iThresholdEnd = -1;
    	if(!strThresholdEnd.isEmpty())
    		iThresholdEnd = Integer.valueOf(strThresholdEnd);
    	
    	m_query = new wangSequenceInfo(iSequenceIndex, iSegIndexBeg, iSegIndexEnd); 
    	m_arSeqInfo = m_db.RetrieveSequence(m_query, bFixedBeg, bAverageDistance, iThresholdBeg, iThresholdEnd);
    	
    	//update result to UI
    	String strResultInfo = "Query: (" + String.valueOf(m_query.m_iSequenceIndex) + ",  " + 
    							String.valueOf(m_query.m_iSegmentIndexBeg) + ",  " + 
    							String.valueOf(m_query.m_iSegmentIndexEnd) + ")\r\n\r\nResults:\r\n";

    	for(int i = 0; i < Math.min(30, m_arSeqInfo.size()); ++ i)
    	{
    		wangSequenceInfo info = m_arSeqInfo.get(i);
    		strResultInfo += "Rank " + String.valueOf(i+1) + ": (" + String.valueOf(info.m_iSequenceIndex) + ",  " + 
    						String.valueOf(info.m_iSegmentIndexBeg) + ",  " + 
    						String.valueOf(info.m_iSegmentIndexEnd) + ")   Dist:" +  
    						String.valueOf(info.m_iDTWDistance) + "\r\n";
    	}
    	m_lbSeqResult.setText(strResultInfo);
    }
	
	public void PlaySequences(wangMotionSequence [] arSequence)
	{
		if(arSequence == null)
			return;
		
		WAMCMotion [] arAMCList = new WAMCMotion[arSequence.length];
		for(int i = 0; i < arSequence.length; ++i)
		{
			WAMCMotion amc = arSequence[i].GetAMC();
			amc.Relocate(new Vector3d(150*i, 0, 0));
			arAMCList[i] = amc;
		}
		m_ctrlMotionPlayer.setAMCMotionList(arAMCList);
	}
    public void PlaySegments(wangMotionSegment [] arSegment)
    {
    	if(arSegment == null)
    		return;
    	
		WAMCMotion [] arAMCList = new WAMCMotion[arSegment.length];
		for (int i = 0; i < arAMCList.length; ++i)
		{
			WAMCMotion amc = arSegment[i].GetAMC();
			amc.Relocate(new Vector3d(150 * i, 0, 0));
			arAMCList[i] = amc;
		}
		m_ctrlMotionPlayer.setAMCMotionList(arAMCList);
    }	
	
	public void LoadAMC()
	{	
		FileDialog dlg = new FileDialog(m_shellMain, SWT.OPEN);
		dlg.setText("Open AMC File");
		String [] arFilterExt = {"*.amc", "*.asf"};
		dlg.setFilterExtensions(arFilterExt);
		String strAMCPath = dlg.open();
		
		if(strAMCPath == null || strAMCPath == "")
			return;
		
		String strASFPath = wangMotionDB.ConvertToASFPath(strAMCPath);
		WASFSkeleton asf = new WASFSkeleton();
		asf.ParseFile(strASFPath);
		
		WAMCMotion amc = new WAMCMotion(asf);
		amc.LoadFromFile(strAMCPath);
		WAMCMotion [] arAmcList = new WAMCMotion[1];
		arAmcList[0] = amc;
		m_ctrlMotionPlayer.setAMCMotionList(arAmcList);
		m_ctrlMotionPlayer.startAnimation(); 
		
	}
	
	public void OpenShow(int width, int height)
	{
		m_shellMain.pack();
		m_shellMain.open();
		while(!m_shellMain.isDisposed())
		{
			if(!m_displayMain.readAndDispatch())
			{
				m_displayMain.sleep();
			}
		}
		m_displayMain.dispose();		
	}

}
