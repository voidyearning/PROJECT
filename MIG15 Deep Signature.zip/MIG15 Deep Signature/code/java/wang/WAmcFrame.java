package wang;

public class WAmcFrame
{
    float m_root1; 
    float m_root2; 
    float m_root3; 
    float m_root4; 
    float m_root5; 
    float m_root6;
    
    float m_lowerback1; 
    float m_lowerback2; 
    float m_lowerback3;
    
    float m_upperback1; 
    float m_upperback2;
    float m_upperback3;
    
    float m_thorax1;
    float m_thorax2;
    float m_thorax3;
    
    float m_lowerneck1;
    float m_lowerneck2; 
    float m_lowerneck3;
    
    float m_upperneck1; 
    float m_upperneck2;
    float m_upperneck3;
    
    float m_head1;
    float m_head2;
    float m_head3;

    float m_rclavicle1;
    float m_rclavicle2;
    
    float m_rhumerus1;
    float m_rhumerus2;
    float m_rhumerus3;
    
    float m_rradius;
    float m_rwrist;
    float m_rhand1;
    float m_rhand2;
    float m_rfingers;
    float m_rthumb1;
    float m_rthumb2;

    float m_lclavicle1;
    float m_lclavicle2;

    float m_lhumerus1;
    float m_lhumerus2;
    float m_lhumerus3;
    
    float m_lradius;
    float m_lwrist;
    float m_lhand1;
    float m_lhand2;
    float m_lfingers;
    float m_lthumb1;
    float m_lthumb2;

    float m_rfemur1;
    float m_rfemur2;
    float m_rfemur3;
    
    float m_rtibia;
    float m_rfoot1;
    float m_rfoot2;
    float m_rtoes;

    float m_lfemur1;
    float m_lfemur2;
    float m_lfemur3;
    
    float m_ltibia;
    float m_lfoot1;
    float m_lfoot2;
    float m_ltoes;

	public void PopulateFromLine(String strLine)
	{
		String [] lineData = strLine.split(" ");
		try{
        //body======================================
        if (lineData[0].equalsIgnoreCase("root"))
        {
            m_root1 = Float.valueOf(lineData[1]);
            m_root2 = Float.valueOf(lineData[2]);
            m_root3 = Float.valueOf(lineData[3]);
            m_root4 = Float.valueOf(lineData[4]);
            m_root5 = Float.valueOf(lineData[5]);
            m_root6 = Float.valueOf(lineData[6]);
        }
        else if (lineData[0].equalsIgnoreCase("lowerback"))
        {
            m_lowerback1 = Float.valueOf(lineData[1]);
            m_lowerback2 = Float.valueOf(lineData[2]);
            m_lowerback3 = Float.valueOf(lineData[3]);
        }
        else if (lineData[0].equalsIgnoreCase("upperback"))
        {
            m_upperback1 = Float.valueOf(lineData[1]);
            m_upperback2 = Float.valueOf(lineData[2]);
            m_upperback3 = Float.valueOf(lineData[3]);
        }
        else if (lineData[0].equalsIgnoreCase("thorax"))
        {
            m_thorax1 = Float.valueOf(lineData[1]);
            m_thorax2 = Float.valueOf(lineData[2]);
            m_thorax3 = Float.valueOf(lineData[3]);
        }
        else if (lineData[0].equalsIgnoreCase("lowerneck"))
        {
            m_lowerneck1 = Float.valueOf(lineData[1]);
            m_lowerneck2 = Float.valueOf(lineData[2]);
            m_lowerneck3 = Float.valueOf(lineData[3]);
        }
        else if (lineData[0].equalsIgnoreCase("upperneck"))
        {
            m_upperneck1 = Float.valueOf(lineData[1]);
            m_upperneck2 = Float.valueOf(lineData[2]);
            m_upperneck3 = Float.valueOf(lineData[3]);
        }
        else if (lineData[0].equalsIgnoreCase("head"))
        {
            m_head1 = Float.valueOf(lineData[1]);
            m_head2 = Float.valueOf(lineData[2]);
            m_head3 = Float.valueOf(lineData[3]);
        }
        //right arm==================================
        else if (lineData[0].equalsIgnoreCase("rclavicle"))
        {
            m_rclavicle1 = Float.valueOf(lineData[1]);
            m_rclavicle2 = Float.valueOf(lineData[2]);
        }
        else if (lineData[0].equalsIgnoreCase("rhumerus"))
        {
            m_rhumerus1 = Float.valueOf(lineData[1]);
            m_rhumerus2 = Float.valueOf(lineData[2]);
            m_rhumerus3 = Float.valueOf(lineData[3]);
        }
        else if (lineData[0].equalsIgnoreCase("rradius"))
        {
            m_rradius = Float.valueOf(lineData[1]);
        }
        else if (lineData[0].equalsIgnoreCase("rwrist"))
        {
            m_rwrist = Float.valueOf(lineData[1]);
        }
        else if (lineData[0].equalsIgnoreCase("rhand"))
        {
            m_rhand1 = Float.valueOf(lineData[1]);
            m_rhand2 = Float.valueOf(lineData[2]);
        }
        else if (lineData[0].equalsIgnoreCase("rfingers"))
        {
            m_rfingers = Float.valueOf(lineData[1]);
        }
        else if (lineData[0].equalsIgnoreCase("rthumb"))
        {
            m_rthumb1 = Float.valueOf(lineData[1]);
            m_rthumb2 = Float.valueOf(lineData[2]);
        }
        //left arm====================================
        else if (lineData[0].equalsIgnoreCase("lclavicle"))
        {
            m_lclavicle1 = Float.valueOf(lineData[1]);
            m_lclavicle2 = Float.valueOf(lineData[2]);
        }
        else if (lineData[0].equalsIgnoreCase("lhumerus"))
        {
            m_lhumerus1 = Float.valueOf(lineData[1]);
            m_lhumerus2 = Float.valueOf(lineData[2]);
            m_lhumerus3 = Float.valueOf(lineData[3]);
        }
        else if (lineData[0].equalsIgnoreCase("lradius"))
        {
            m_lradius = Float.valueOf(lineData[1]);
        }
        else if (lineData[0].equalsIgnoreCase("lwrist"))
        {
            m_lwrist = Float.valueOf(lineData[1]);
        }
        else if (lineData[0].equalsIgnoreCase("lhand"))
        {
            m_lhand1 = Float.valueOf(lineData[1]);
            m_lhand2 = Float.valueOf(lineData[2]);
        }
        else if (lineData[0].equalsIgnoreCase("lfingers"))
        {
            m_lfingers = Float.valueOf(lineData[1]);
        }
        else if (lineData[0].equalsIgnoreCase("lthumb"))
        {
            m_lthumb1 = Float.valueOf(lineData[1]);
            m_lthumb2 = Float.valueOf(lineData[2]);
        }
        //right leg====================================
        else if (lineData[0].equalsIgnoreCase("rfemur"))
        {
            m_rfemur1 = Float.valueOf(lineData[1]);
            m_rfemur2 = Float.valueOf(lineData[2]);
            m_rfemur3 = Float.valueOf(lineData[3]);
        }
        else if (lineData[0].equalsIgnoreCase("rtibia"))
        {
            m_rtibia = Float.valueOf(lineData[1]);
        }
        else if (lineData[0].equalsIgnoreCase("rfoot"))
        {
            m_rfoot1 = Float.valueOf(lineData[1]);
            m_rfoot2 = Float.valueOf(lineData[2]);
        }
        else if (lineData[0].equalsIgnoreCase("rtoes"))
        {
            m_rtoes = Float.valueOf(lineData[1]);
        }
        //left leg=====================================
        else if (lineData[0].equalsIgnoreCase("lfemur"))
        {
            m_lfemur1 = Float.valueOf(lineData[1]);
            m_lfemur2 = Float.valueOf(lineData[2]);
            m_lfemur3 = Float.valueOf(lineData[3]);
        }
        else if (lineData[0].equalsIgnoreCase("ltibia"))
        {
            m_ltibia = Float.valueOf(lineData[1]);
        }
        else if (lineData[0].equalsIgnoreCase("lfoot"))
        {
            m_lfoot1 = Float.valueOf(lineData[1]);
            m_lfoot2 = Float.valueOf(lineData[2]);
        }
        else if (lineData[0].equalsIgnoreCase("ltoes"))
        {
            m_ltoes = Float.valueOf(lineData[1]);
        }
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	public String GetLine()
	{
		String strLine = "root ";
        strLine += String.valueOf(m_root1) + " " + String.valueOf(m_root2) + " " + String.valueOf(m_root3) 
        		+ " " + String.valueOf(m_root4) + " " + String.valueOf(m_root5) + " " + String.valueOf(m_root6) + "\r\n";
        strLine += "lowerback ";
        strLine += String.valueOf(m_lowerback1) + " " + String.valueOf(m_lowerback2) + " " + String.valueOf(m_lowerback3) + "\r\n";
        strLine += "upperback ";
        strLine += String.valueOf(m_upperback1) + " " + String.valueOf(m_upperback2) + " " + String.valueOf(m_upperback3) + "\r\n";
        strLine += "thorax ";
        strLine += String.valueOf(m_thorax1) + " " + String.valueOf(m_thorax2) + " " + String.valueOf(m_thorax3) + "\r\n";
        strLine += "lowerneck ";
        strLine += String.valueOf(m_lowerneck1) + " " + String.valueOf(m_lowerneck2) + " " + String.valueOf(m_lowerneck3) + "\r\n";
        strLine += "upperneck ";
        strLine += String.valueOf(m_upperneck1) + " " + String.valueOf(m_upperneck2) + " " + String.valueOf(m_upperneck3) + "\r\n";
        strLine += "head ";
        strLine += String.valueOf(m_head1) + " " + String.valueOf(m_head2) + " " + String.valueOf(m_head3) + "\r\n";
        strLine += "rclavicle ";
        strLine += String.valueOf(m_rclavicle1) + " " + String.valueOf(m_rclavicle2) + "\r\n";
        strLine += "rhumerus ";
        strLine += String.valueOf(m_rhumerus1) + " " + String.valueOf(m_rhumerus2) + " " + String.valueOf(m_rhumerus3) + "\r\n";
        strLine += "rradius ";
        strLine += String.valueOf(m_rradius) + "\r\n";
        strLine += "rwrist ";
        strLine += String.valueOf(m_rwrist) + "\r\n";
        strLine += "rhand ";
        strLine += String.valueOf(m_rhand1) + " " + String.valueOf(m_rhand2) + "\r\n";
        strLine += "rfingers ";
        strLine += String.valueOf(m_rfingers) + "\r\n";
        strLine += "rthumb ";
        strLine += String.valueOf(m_rthumb1) + " " + String.valueOf(m_rthumb2) + "\r\n";
        strLine += "lclavicle ";
        strLine += String.valueOf(m_lclavicle1) + " " + String.valueOf(m_lclavicle2) + "\r\n";
        strLine += "lhumerus ";
        strLine += String.valueOf(m_lhumerus1) + " " + String.valueOf(m_lhumerus2) + " " + String.valueOf(m_lhumerus3) + "\r\n";
        strLine += "lradius ";
        strLine += String.valueOf(m_lradius) + "\r\n";
        strLine += "lwrist ";
        strLine += String.valueOf(m_lwrist) + "\r\n";
        strLine += "lhand ";
        strLine += String.valueOf(m_lhand1) + " " + String.valueOf(m_lhand2) + "\r\n";
        strLine += "lfingers ";
        strLine += String.valueOf(m_lfingers) + "\r\n";
        strLine += "lthumb ";
        strLine += String.valueOf(m_lthumb1) + " " + String.valueOf(m_lthumb2) + "\r\n";
        strLine += "rfemur ";
        strLine += String.valueOf(m_rfemur1) + " " + String.valueOf(m_rfemur2) + " " + String.valueOf(m_rfemur3) + "\r\n";
        strLine += "rtibia ";
        strLine += String.valueOf(m_rtibia) + "\r\n";
        strLine += "rfoot ";
        strLine += String.valueOf(m_rfoot1) + " " + String.valueOf(m_rfoot2) + "\r\n";
        strLine += "rtoes ";
        strLine += String.valueOf(m_rtoes) + "\r\n";
        strLine += "lfemur ";
        strLine += String.valueOf(m_lfemur1) + " " + String.valueOf(m_lfemur2) + " " + String.valueOf(m_lfemur3) + "\r\n";
        strLine += "ltibia ";
        strLine += String.valueOf(m_ltibia) + "\r\n";
        strLine += "lfoot ";
        strLine += String.valueOf(m_lfoot1) + " " + String.valueOf(m_lfoot2) + "\r\n";
        strLine += "ltoes ";
        strLine += String.valueOf(m_ltoes) + "\r\n";
        return strLine;
	}
};

