package wang;
import static java.lang.Math.atan2;

import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import javax.vecmath.Matrix4d;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

import mrl.main.Configuration;
import mrl.motion.annotation.MotionAnnotation.MotionAnnValueGetter;
import mrl.motion.data.Motion;
import mrl.motion.data.MotionData;
import mrl.motion.data.MotionTransform;
import mrl.motion.data.MultiCharacterFolder;
import mrl.motion.data.MultiCharacterFolder.MultiCharacterFiles;
import mrl.motion.data.parser.BVHParser;
import mrl.motion.viewer.BaseApplication;
import mrl.motion.viewer.MotionIntervalSelector;
import mrl.motion.viewer.MotionListViewer.MotionListGetter;
import mrl.motion.viewer.MultiCharacterBVHListViewer.MultiFileMotionGetter;
import mrl.motion.viewer.MultiCharacterNavigator;
import mrl.util.FilterUtil;
import mrl.util.MathUtil;
import mrl.util.ObjectSerializer;
import mrl.util.Pair;
import mrl.widget.ObjectPropertyPanel;
import mrl.widget.dockable.DockableTabFolder;
import mrl.widget.dockable.SashFormContainer;
import mrl.widget.dockable.SashFormContainer.DockingPosition;
import mrl.widget.table.FilterableTable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;



public class WAmcFile 
{
	
	public ArrayList<WAmcFrame> m_arFrame;
	public WAmcFile()
	{
		m_arFrame = new ArrayList<WAmcFrame>();
	}
	public void LoadFromFile(String strPath)
	{
		m_arFrame.clear();
		
		try{			
			BufferedReader br = new BufferedReader(new FileReader(strPath));
			String strLine;
			int iFrameCount = 1;
			WAmcFrame amcFrame = new WAmcFrame();
			while( (strLine=br.readLine()) != null)
			{
				if (strLine.isEmpty())
					continue;
				
				String strFrameCount = String.valueOf(iFrameCount);
				if (strLine.startsWith(strFrameCount))
				{
					if(iFrameCount > 1)
					{
						m_arFrame.add(amcFrame);
						amcFrame = new WAmcFrame();
					}
					iFrameCount = iFrameCount + 1;
				}
				else
				{
					amcFrame.PopulateFromLine(strLine);
				}
			}
			//the last one
			m_arFrame.add(amcFrame);
		}catch(Exception e)
		{}
	}
	public void SaveToFile(String strPath)
	{
		try
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter(strPath));	
			bw.write("#!OML:ASF F:\\VICON\\USERDATA\\INSTALL\\rory3\\rory3.ASF");
			bw.write("\r\n");
			bw.write(":FULLY-SPECIFIED\r\n:DEGREES\r\n");
			int iFrameCount = m_arFrame.size();
			for (int i = 0; i < m_arFrame.size(); ++i)
			{ 
				String strFrameCount = String.valueOf(i+1);
				bw.write(strFrameCount);			
            	bw.write("\r\n");
            	bw.write(m_arFrame.get(i).GetLine());
			}
            bw.flush();
            bw.close();
		}catch(Exception e)
		{}
	}
	
	public void ZeroTranslation()
    {
		WAmcFrame amcFrameBaseOriginal = m_arFrame.get(0);
        Vector3d vTransOriginal = new Vector3d(-amcFrameBaseOriginal.m_root1, -amcFrameBaseOriginal.m_root2, -amcFrameBaseOriginal.m_root3);       
        for(int i = 0; i < m_arFrame.size(); ++i)
        {
        	WAmcFrame amcFrame = m_arFrame.get(i);
            Vector3d vTrans = new Vector3d(amcFrame.m_root1, amcFrame.m_root2, amcFrame.m_root3); 
            vTrans.add(vTransOriginal);
            amcFrame.m_root1 = (float)vTrans.x; amcFrame.m_root2 = (float)vTrans.y; amcFrame.m_root3 = (float)vTrans.z;
            m_arFrame.set(i, amcFrame);
        }
    }
	public void ToLocal()
	{
		WAmcFrame amcFrameOriginal = m_arFrame.get(0);
        Vector3d vRotOriginal = new Vector3d(-amcFrameOriginal.m_root5, amcFrameOriginal.m_root4, amcFrameOriginal.m_root6);
        Vector3d vTransOriginal = new Vector3d(-amcFrameOriginal.m_root2, amcFrameOriginal.m_root1, amcFrameOriginal.m_root3);
        Matrix4d mxRootOriginal = MathUtil.eulerToMatrixZXY(vRotOriginal);
        mxRootOriginal.setTranslation(vTransOriginal);
        mxRootOriginal.invert();
        
        Transform(mxRootOriginal);		
	}
	public void ToLocalOrientation()
	{
		WAmcFrame amcFrameOriginal = m_arFrame.get(0);
        Vector3d vRotOriginal = new Vector3d(-amcFrameOriginal.m_root5, amcFrameOriginal.m_root4, amcFrameOriginal.m_root6);
        Vector3d vTransOriginal = new Vector3d(0, amcFrameOriginal.m_root1, amcFrameOriginal.m_root3);
        Matrix4d mxRootOriginal = MathUtil.eulerToMatrixZXY(vRotOriginal);
        mxRootOriginal.setTranslation(vTransOriginal);
        
        Vector3d vFront = new Vector3d(0,0,1);
        mxRootOriginal.transform(vFront);
        vFront.x = 0;
        double fY = vFront.angle(new Vector3d(0,0,1));
        fY = fY * 180 / Math.PI;
        if(vFront.y > 0) fY = - fY;
        
        vRotOriginal = new Vector3d(fY, 0, 0);
        mxRootOriginal = MathUtil.eulerToMatrixZXY(vRotOriginal);
        mxRootOriginal.setTranslation(vTransOriginal);
        mxRootOriginal.invert();
        Transform(mxRootOriginal);			
	}
	/*this is tricky: mathutil supports here-zxy order which in maya corresponds to maya-yxz
	 * amc uses maya-xyz, here should be here-zyx order
	 * note that zxy is right-hand coordinate, zyx is left-hand, thus the ty and ry need to negate
	 * MathUtil.eulerToMatrixZXY and MathUtil.matrixToEulerZXY really should be named more generally
	 * like eulerToMatrix312, it only indicates the order in the vector (right-hand), name does not matter*/
	public void Transform(Matrix4d mxTransform)
	{
		//z -> z
		//y -> x
		//x -> y
        for(int i = 0; i < m_arFrame.size(); ++i)
        {
        	WAmcFrame amcFrame = m_arFrame.get(i);

            Vector3d vRot = new Vector3d(-amcFrame.m_root5, amcFrame.m_root4, amcFrame.m_root6); 
            Matrix4d mxRoot = MathUtil.eulerToMatrixZXY(vRot);  
            Vector3d vTrans = new Vector3d(-amcFrame.m_root2, amcFrame.m_root1, amcFrame.m_root3);  
            mxRoot.setTranslation(vTrans);
            Matrix4d mxRootNew = new Matrix4d(mxTransform);
            mxRootNew.mul(mxRoot);            
            vRot = MathUtil.matrixToEulerZXY(mxRootNew); 
            vTrans = MathUtil.getTranslation(mxRootNew);
            amcFrame.m_root4 = (float)vRot.y; amcFrame.m_root5 = -(float)vRot.x; amcFrame.m_root6 = (float)vRot.z;  
            amcFrame.m_root1 = (float)vTrans.y; amcFrame.m_root2 = - (float)vTrans.x; amcFrame.m_root3 = (float)vTrans.z;  
             
            m_arFrame.set(i, amcFrame);
        }
    }
}

