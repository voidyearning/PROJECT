package wang;

import java.util.ArrayList;

import javax.vecmath.Matrix4d;
import javax.vecmath.Vector3d;


public class WASFJoint
{
	public int m_iId = -1;
	public String m_strName = "";
	public Vector3d m_vDirection = new Vector3d();
	public float m_fLength = 0;
	public String m_strAxis = "";
	public Vector3d m_vAxis = new Vector3d();
	public ArrayList<WASFDOF> m_arDOF = new ArrayList<WASFDOF>();
	public boolean m_bEnd = true;
	//tree structure link
	public WASFJoint m_jtParent = null;
	public ArrayList<WASFJoint> m_arChilden = new ArrayList<WASFJoint>();
	public Matrix4d m_mxAxisLocal = new Matrix4d();
	public Vector3d m_vLengthDirLocal = new Vector3d();

	public Vector3d m_vPosWorld = new Vector3d();
	public Vector3d m_vEndPosWorld = new Vector3d();
	public Matrix4d m_mxRotWorld = null;

	public void Clone(WASFJoint jointSrc)
	{
		m_iId = jointSrc.m_iId;
		m_strName = jointSrc.m_strName;
		m_vDirection = new Vector3d(jointSrc.m_vDirection);
		m_fLength = jointSrc.m_fLength;
		m_strAxis = jointSrc.m_strAxis;
		m_vAxis = new Vector3d(jointSrc.m_vAxis);
		m_arDOF = new ArrayList<WASFDOF>();
		for(WASFDOF dofSrc : jointSrc.m_arDOF)
		{
			m_arDOF.add(new WASFDOF(dofSrc));			
		}
		m_bEnd = jointSrc.m_bEnd;		
		m_mxAxisLocal = new Matrix4d(jointSrc.m_mxAxisLocal);
		m_vLengthDirLocal = new Vector3d(jointSrc.m_vLengthDirLocal);
		m_vPosWorld = new Vector3d();//new Vector3d(jointSrc.m_vPosWorld);
		m_vEndPosWorld = new Vector3d();//new Vector3d(jointSrc.m_vEndPosWorld);
		m_mxRotWorld = null;//new Matrix4d(jointSrc.m_mxRotWorld);
		
	}
	public String ToString()
	{
		String strJoint = "\tbegin\r\n";
		strJoint += "\t\tid " + String.valueOf(m_iId) + "\r\n";
		strJoint += "\t\tname " + m_strName + "\r\n";
		strJoint += "\t\t direction " + String.valueOf(m_vDirection.x) + " " + 
				String.valueOf(m_vDirection.y) + " " + String.valueOf(m_vDirection.z) + "\r\n";
		strJoint += "\t\t length " + String.valueOf(m_fLength) + "\r\n";
		strJoint += "\t\t axis " + String.valueOf(m_vAxis.x) + " " + 
				String.valueOf(m_vAxis.y) + " " + String.valueOf(m_vAxis.z) + " " + m_strAxis;
		strJoint += "\r\n\tend\r\n";
		return strJoint;
	}
	
	public Matrix4d GetAxisMatrixW()
	{
		if(m_mxRotWorld == null)
		{
			Matrix4d mxAxis = new Matrix4d();
			mxAxis.setIdentity();
		
			Matrix4d mxRotX = new Matrix4d();
			mxRotX.rotX(m_vAxis.x * Math.PI / 180);
			Matrix4d mxRotY = new Matrix4d();
			mxRotY.rotY(m_vAxis.y * Math.PI / 180);
			Matrix4d mxRotZ = new Matrix4d();
			mxRotZ.rotZ(m_vAxis.z * Math.PI / 180);
			
			mxAxis.mul(mxRotZ);
			mxAxis.mul(mxRotY);
			mxAxis.mul(mxRotX);
			
			m_mxRotWorld = mxAxis;
		}
		return m_mxRotWorld;
	}
	
	public Vector3d GetLengthDirW()
	{
		Vector3d vLengthDirW = new Vector3d(m_vDirection);
		vLengthDirW.normalize();
		vLengthDirW.scale(m_fLength);
		return vLengthDirW;
	}
};
