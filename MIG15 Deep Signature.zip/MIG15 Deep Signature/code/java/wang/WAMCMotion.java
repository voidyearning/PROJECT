package wang;

import static java.lang.Math.atan2;

import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import javax.vecmath.Matrix4d;
import javax.vecmath.Point3d;
import javax.vecmath.Vector2d;
import javax.vecmath.Vector3d;

import wangDeep.wangDTW;





public class WAMCMotion
{
	public ArrayList<WAMCMotionFrame> m_arFrame;
	public WASFSkeleton m_asfSkeleton;
	public String m_strPath = "";
	
	public WAMCMotion(WASFSkeleton asfSkeleton)
	{
		m_arFrame = new ArrayList<WAMCMotionFrame>();
		m_asfSkeleton = asfSkeleton;
	}
	public WAMCMotion(WAMCMotion amc)
	{
		Clone(amc);
	}
	public void LoadFromFile(String strPath)
	{
		m_arFrame.clear();
		m_strPath = strPath;
		
		try{			
			BufferedReader br = new BufferedReader(new FileReader(strPath));
			String strLine;
			int iFrameCount = 1;
			WAMCMotionFrame amcFrame = new WAMCMotionFrame(m_asfSkeleton);
			while( (strLine=br.readLine()) != null)
			{
				if (strLine.isEmpty())
					continue;
				
				String strFrameCount = String.valueOf(iFrameCount);
				if (strLine.startsWith(strFrameCount))
				{
					if(iFrameCount > 1)
					{
						m_arFrame.add(amcFrame);
						amcFrame = new WAMCMotionFrame(m_asfSkeleton);
					}
					iFrameCount = iFrameCount + 1;
				}
				else
				{
					amcFrame.PopulateFromLine(strLine, m_asfSkeleton);
				}
			}
			//the last one
			m_arFrame.add(amcFrame);
		}catch(Exception e)
		{}
		PopulateJointWorldPosition();
	}
	public void SaveToFileCMU(String strPath)
	{
		try
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter(strPath));	
			bw.write("#!OML:ASF F:\\VICON\\USERDATA\\INSTALL\\rory3\\rory3.ASF\r\n");
			bw.write(":FULLY-SPECIFIED\r\n");
			bw.write(":DEGREES\r\n");
			for(int i = 0; i < m_arFrame.size(); ++i)
			{
				bw.write(String.valueOf(i+1));
				bw.write("\r\n");
				bw.write(m_arFrame.get(i).ToStringCMU(m_asfSkeleton.m_fScale));
			}
			bw.flush();
            bw.close();
		}catch(Exception e)
		{} 
		
	}

	public void Relocate(Vector3d vPosStartNew)
	{
		if(m_arFrame.size() == 0)
			return;
		
		String strRootName = m_asfSkeleton.m_jtRoot.m_strName;
		Matrix4d mxRootStartOriginal = m_arFrame.get(0).m_mapTransform.get(strRootName);
		Vector3d vPosStartOriginal = new Vector3d(mxRootStartOriginal.m03, mxRootStartOriginal.m13, mxRootStartOriginal.m23);
		vPosStartNew.y = vPosStartOriginal.y;
		for(int i = 0; i < m_arFrame.size(); ++ i)
		{
			WAMCMotionFrame amcFrame = m_arFrame.get(i);
			Matrix4d mxRoot = amcFrame.m_mapTransform.get(strRootName);
			Vector3d vPos = new Vector3d(mxRoot.m03, mxRoot.m13, mxRoot.m23);
			vPos.sub(vPosStartOriginal);
			vPos.add(vPosStartNew);
			mxRoot.setTranslation(vPos);
			amcFrame.m_mapTransform.put(strRootName, mxRoot);			
		}
		PopulateJointWorldPosition();
	}
	
	public void PopulateJointWorldPosition()
	{
		for(WAMCMotionFrame frmAMC : m_arFrame)
		{
			frmAMC.PopulateWorldPosition(m_asfSkeleton);
		}
	}
	
	
	//fIdxNormal is [0,1]
	public WAMCMotionFrame GetFrameAt(float fIdxNormal)
	{
		if(fIdxNormal < 0 || fIdxNormal > 1 || m_arFrame.size() == 0)
			return null;
		
		float fIdx = fIdxNormal * (m_arFrame.size() - 1);
		int iLowIdx = (int)fIdx;
		int iHighIdx = iLowIdx + 1;
		float fRatio = fIdx - iLowIdx;
		if(fRatio == 0)
			return m_arFrame.get(iLowIdx);
		
		//linear blend between iLowIdx and iHighIdx
		return WAMCMotionFrame.Blend(m_arFrame.get(iLowIdx), m_arFrame.get(iHighIdx), fRatio);
	}
	public float[][] GetDistanceMatrixR(WAMCMotion amcSrc)
	{
		if(amcSrc.m_arFrame == null || amcSrc.m_arFrame.size() == 0)
			return null;
		
		float [][] M = new float[m_arFrame.size()][amcSrc.m_arFrame.size()];
		for(int i = 0; i < m_arFrame.size(); ++ i)
		{
			for(int j = 0; j < amcSrc.m_arFrame.size(); ++j)
			{
				M[i][j] = m_arFrame.get(i).DistanceTo(amcSrc.m_arFrame.get(j));
			}
		}
		return M;		
	}
	public void ReplaceChannelFrom(WAMCMotion amcSrc, wangChannelSelector cs)
	{
		if(amcSrc.m_arFrame == null || amcSrc.m_arFrame.size() == 0)
			return;
		
		for(int i = 0; i < m_arFrame.size(); ++ i)
		{
			WAMCMotionFrame frmDest = m_arFrame.get(i);
			float fSrc = i / (float)(m_arFrame.size() -1);
			WAMCMotionFrame frmSrc = amcSrc.GetFrameAt(fSrc);
			frmDest.ReplaceChannelFrom(frmSrc, cs);				
		}
		PopulateJointWorldPosition();		
	}
	public float DistanceTo_DifferentLength(WAMCMotion amcSrc, wangChannelSelector cs)
	{
		if(amcSrc.m_arFrame == null || amcSrc.m_arFrame.size() == 0)
			return 0;
			
		float fErr = 0;
		for(int i = 0; i < m_arFrame.size(); ++ i)
		{
			WAMCMotionFrame frmDest = m_arFrame.get(i);
			float fSrc = i / (float)(m_arFrame.size() -1);
			WAMCMotionFrame frmSrc = amcSrc.GetFrameAt(fSrc);
			fErr += frmDest.DistanceTo(frmSrc, cs);				
		}
		fErr = fErr / m_arFrame.size();
		return fErr;
	}
	public float DistanceTo_SameLength(WAMCMotion amcSrc, wangChannelSelector cs)
	{
		if(amcSrc.m_arFrame == null || amcSrc.m_arFrame.size() == 0 ||
			m_arFrame.size() != amcSrc.m_arFrame.size())
			return 0;
			
		float fErr = 0;
		for(int i = 0; i < m_arFrame.size(); ++ i)
		{
			WAMCMotionFrame frmDest = m_arFrame.get(i);
			WAMCMotionFrame frmSrc = amcSrc.m_arFrame.get(i);
			fErr += frmDest.DistanceTo(frmSrc, cs);				
		}
		fErr = fErr / m_arFrame.size();
		return fErr;
	}

	public void ReplaceChannelFromDTW(WAMCMotion amcSrc, wangChannelSelector cs)
	{
		if(amcSrc.m_arFrame == null || amcSrc.m_arFrame.size() == 0)
			return;
		
		//align
		wangDTW dtw = new wangDTW();
		ArrayList<Vector2d> trace = dtw.DTW(GetDistanceMatrixR(amcSrc), m_arFrame.size(), amcSrc.m_arFrame.size());		
		//replace
		int iLastDestIdx = -1;
		int iLastDestCount = 1;
		int iLastSrcIdx = -1;
		//x is row, y is column
		for(int i = 0; i < trace.size(); ++i)
		{
			Vector2d posAlign = trace.get(i);
			WAMCMotionFrame frmDest = m_arFrame.get((int) posAlign.x);
			WAMCMotionFrame frmSrc = amcSrc.m_arFrame.get((int) posAlign.y);
			
			if((int)posAlign.x == iLastDestIdx)//horizontal line
			{
				iLastDestCount ++;
				frmDest.MergeChannelFrom(frmSrc, 1-(float)(1.0/iLastDestCount), cs);
			}
			else 
			{
				if ((int)posAlign.y == iLastSrcIdx)//vertical line
					frmSrc = m_arFrame.get((int) posAlign.x-1);
				
				frmDest.ReplaceChannelFrom(frmSrc, cs);	
				iLastDestCount = 1;
			}
			iLastDestIdx = (int) posAlign.x;
			iLastSrcIdx = (int) posAlign.y;
		}
		//head, copy from dest, not src, in case been merged
		Vector2d posAlignFirst = trace.get(0);
		WAMCMotionFrame frmSrc = m_arFrame.get((int)posAlignFirst.x);
		for(int i = 0; i < posAlignFirst.x; ++i)
		{
			WAMCMotionFrame frmDest = m_arFrame.get(i);
			frmDest.ReplaceChannelFrom(frmSrc, cs);				
		}
		//tail, copy from dest, not src, in case been merged
		Vector2d posAlignLast = trace.get(trace.size()-1);
		frmSrc = m_arFrame.get((int)posAlignLast.x);
		for(int i = (int) posAlignLast.x+1; i < m_arFrame.size(); ++i)
		{
			WAMCMotionFrame frmDest = m_arFrame.get(i);
			frmDest.ReplaceChannelFrom(frmSrc, cs);	
		}
		PopulateJointWorldPosition();		
	}

	public void Clone(WAMCMotion amcSrc)
	{
		m_strPath = amcSrc.m_strPath;
		m_asfSkeleton = new WASFSkeleton();
		m_asfSkeleton.Clone(amcSrc.m_asfSkeleton);
		m_arFrame = new ArrayList<WAMCMotionFrame>();
		for(WAMCMotionFrame amcFrameSrc : amcSrc.m_arFrame)
		{
			WAMCMotionFrame amcFrameDest = new WAMCMotionFrame(amcFrameSrc);
			amcFrameDest.PopulateWorldPosition(m_asfSkeleton);
			m_arFrame.add(amcFrameDest);
		}
	}
	public String GetAMCName()
	{
		if(m_strPath == null || m_strPath == "")
			return "";
		
		int iExt = m_strPath.lastIndexOf('.');
		int iSlash = m_strPath.lastIndexOf('\\');
		return m_strPath.substring(iSlash+1, iExt);
	}
}

