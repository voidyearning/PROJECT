package wang;
import static java.lang.Math.atan2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import javax.vecmath.Matrix4d;
import javax.vecmath.Vector3d;

import mrl.util.MathUtil;


public class WAMCMotionFrame 
{
	public class WAMCLinkPos
	{
		public Vector3d m_vPos;
		public Vector3d m_vPosEnd;
		public WAMCLinkPos(Vector3d vPos, Vector3d vPosEnd)
		{
			m_vPos = vPos;
			m_vPosEnd = vPosEnd;
		}
	}
	
	public HashMap<String, Matrix4d> m_mapTransform = new HashMap<String, Matrix4d>();	
	public HashMap<String, WAMCLinkPos> m_mapWorldPos = new HashMap<String, WAMCLinkPos>();
	
	public WAMCMotionFrame()
	{}
	public WAMCMotionFrame(WAMCMotionFrame frmSrc)
	{
		Clone(frmSrc);
	}
	
	public float DistanceTo(WAMCMotionFrame amcFrame)
	{
		float fDist = 0;
		for(String strKey : m_mapTransform.keySet())
		{
			//ignore the following
			if(strKey == "root" ||
				strKey == "rwrist" || strKey == "rhand" || strKey == "rfingers" || strKey == "rthumb" ||
				strKey == "lwrist" || strKey == "lhand" || strKey == "lfingers" || strKey == "lthumb" ||
				strKey == "rfoot" || strKey == "rtoes" || strKey == "lfoot" || strKey == "ltoes")
				continue;
			
			Matrix4d mxRot1 = m_mapTransform.get(strKey);
			Vector3d vRot1 = MathUtil.matrixToEulerZXY(mxRot1);
			Matrix4d mxRot2 = amcFrame.m_mapTransform.get(strKey);
			Vector3d vRot2 = MathUtil.matrixToEulerZXY(mxRot2);
			vRot1.sub(vRot2);
			fDist += vRot1.length();
		}
		return fDist;
	}
	public float DistanceTo(WAMCMotionFrame amcFrame, wangChannelSelector cs)
	{
		/*//Please pay attention that the following keys are ignored in DistanceTo function
		 * thus should be ignored here
		if(strKey == "root" ||
			strKey == "rwrist" || strKey == "rhand" || strKey == "rfingers" || strKey == "rthumb" ||
			strKey == "lwrist" || strKey == "lhand" || strKey == "lfingers" || strKey == "lthumb" ||
			strKey == "rfoot" || strKey == "rtoes" || strKey == "lfoot" || strKey == "ltoes")
			continue;*/
		ArrayList<String> arKey = new ArrayList<String>();
		if(cs.m_bLeftArm)
		{
			arKey.add("lclavicle");
			arKey.add("lhumerus");
			arKey.add("lradius");
			//arKey.add("lwrist");
			//arKey.add("lhand");
			//arKey.add("lfingers");
			//arKey.add("lthumb");
		}		
		if(cs.m_bRightArm)
		{
			arKey.add("rclavicle");
			arKey.add("rhumerus");
			arKey.add("rradius");
			//arKey.add("rwrist");
			//arKey.add("rhand");
			//arKey.add("rfingers");
			//arKey.add("rthumb");
		}		
		if(cs.m_bLeftLeg)
		{
			arKey.add("lfemur");
			arKey.add("ltibia");
			//arKey.add("lfoot");
			//arKey.add("ltoes");
		}		
		if(cs.m_bRightLeg)
		{
			arKey.add("rfemur");
			arKey.add("rtibia");
			//arKey.add("rfoot");
			//arKey.add("rtoes");
		}		
		if(cs.m_bTorso)
		{
			//arKey.add("root");
			arKey.add("lowerback");
			arKey.add("upperback");
			arKey.add("thorax");
			arKey.add("lowerneck");
			arKey.add("upperneck");
			arKey.add("head");
		}	

		float fDist = 0;
		for(String strKey : arKey)
		{	
			Matrix4d mxRot1 = m_mapTransform.get(strKey);
			Vector3d vRot1 = MathUtil.matrixToEulerZXY(mxRot1);
			Matrix4d mxRot2 = amcFrame.m_mapTransform.get(strKey);
			Vector3d vRot2 = MathUtil.matrixToEulerZXY(mxRot2);
			vRot1.sub(vRot2);
			fDist += vRot1.length();
		}
		return fDist;	
	}
	
	public WAMCMotionFrame(WASFSkeleton asfSkeleton)
	{
		for(String strName : asfSkeleton.m_mapJoint.keySet())
		{
			Matrix4d mxIdentity = new Matrix4d();
			mxIdentity.setIdentity();
			m_mapTransform.put(strName, mxIdentity);
		}
	}
	public void PopulateFromLine(String strLine, WASFSkeleton asfSkeleton)
	{
		if (strLine.startsWith(":") || strLine.startsWith("#"))
			return;
		
		String [] lineData = strLine.split(" ");
		try{
			String strName = lineData[0];
			Matrix4d mxTransform = new Matrix4d();
        	mxTransform.setIdentity();
        	WASFJoint joint = asfSkeleton.m_mapJoint.get(strName);
        	
	        Vector3d vRot = new Vector3d();
	        if (lineData[0].equalsIgnoreCase("root"))
	        {
	            float fTransX = Float.valueOf(lineData[1]) * asfSkeleton.m_fScale;
	            float fTransY = Float.valueOf(lineData[2]) * asfSkeleton.m_fScale;
	            float fTransZ = Float.valueOf(lineData[3]) * asfSkeleton.m_fScale;
	            
	            //rot z
	            Matrix4d mxRot = new Matrix4d();
	            vRot.z = Float.valueOf(lineData[6]);
	            vRot.z = (float) (vRot.z * Math.PI / 180.0);
	            mxRot.rotZ(vRot.z);
	            mxTransform.mul(mxRot);
	            
	            //rot y
	            mxRot = new Matrix4d();
	            vRot.y = Float.valueOf(lineData[5]);
	            vRot.y = (float) (vRot.y * Math.PI / 180.0);
	            mxRot.rotY(vRot.y);
	            mxTransform.mul(mxRot);
	            
	            //rot x
	            mxRot = new Matrix4d();
	            vRot.x = Float.valueOf(lineData[4]);
	            vRot.x = (float) (vRot.x * Math.PI / 180.0);
	            mxRot.rotX(vRot.x);
	            mxTransform.mul(mxRot);
	            
	            //translation
	            mxTransform.setTranslation(new Vector3d(fTransX, fTransY, fTransZ));
	        }
	        else
	        {
	        	for(int d = joint.m_arDOF.size()-1; d >=0 ; --d)
	        	{
	        		WASFDOF dof = joint.m_arDOF.get(d);
	        		float fRot = Float.valueOf(lineData[d+1]);
	        		fRot = (float) (fRot * Math.PI / 180.0);
	        		Matrix4d mxRot = new Matrix4d();
	        		mxRot.setIdentity();
	        		if(dof.m_strDOF.equalsIgnoreCase("rx"))
	        		{
	        			 mxRot.rotX(fRot);
	        		}
	        		if(dof.m_strDOF.equalsIgnoreCase("ry"))
	        		{
	        			mxRot.rotY(fRot);
	        		}
	        		if(dof.m_strDOF.equalsIgnoreCase("rz"))
	        		{
	        			mxRot.rotZ(fRot);
	        		}
	        		mxTransform.mul(mxRot);
	        	}
	        }
			m_mapTransform.put(strName, mxTransform);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public String ToStringCMU(float fScale)
	{ 		
		if(fScale<=1)
			fScale = 1;
		String strCMU = "root ";
		Matrix4d mxRoot = m_mapTransform.get("root");
		Vector3d vRootTrans = new Vector3d(mxRoot.m03, mxRoot.m13, mxRoot.m23);
		Vector3d vRoot = MatrixToEulerZYX(mxRoot);
		strCMU += String.valueOf(vRootTrans.x/fScale) + " " + String.valueOf(vRootTrans.y/fScale) + " " + String.valueOf(vRootTrans.z/fScale) + " ";
		strCMU += String.valueOf(vRoot.x) + " " + String.valueOf(vRoot.y) + " " + String.valueOf(vRoot.z) + "\r\n";
		
 		Vector3d vLowerback = MatrixToEulerZYX(m_mapTransform.get("lowerback"));
 		strCMU += "lowerback " + String.valueOf(vLowerback.x) + " " + String.valueOf(vLowerback.y) + " " + String.valueOf(vLowerback.z) + "\r\n";
        Vector3d vUpperback = MatrixToEulerZYX(m_mapTransform.get("upperback"));
        strCMU += "upperback " + String.valueOf(vUpperback.x) + " " + String.valueOf(vUpperback.y) + " " + String.valueOf(vUpperback.z) + "\r\n";
        Vector3d vThorax = MatrixToEulerZYX(m_mapTransform.get("thorax"));
        strCMU += "thorax " + String.valueOf(vThorax.x) + " " + String.valueOf(vThorax.y) + " " + String.valueOf(vThorax.z) + "\r\n";
        
        Vector3d vLowerneck = MatrixToEulerZYX(m_mapTransform.get("lowerneck"));
        strCMU += "lowerneck " + String.valueOf(vLowerneck.x) + " " + String.valueOf(vLowerneck.y) + " " + String.valueOf(vLowerneck.z) + "\r\n";
        Vector3d vUpperneck = MatrixToEulerZYX(m_mapTransform.get("upperneck"));
        strCMU += "upperneck " + String.valueOf(vUpperneck.x) + " " + String.valueOf(vUpperneck.y) + " " + String.valueOf(vUpperneck.z) + "\r\n";
        Vector3d vHead = MatrixToEulerZYX(m_mapTransform.get("head"));
        strCMU += "head " + String.valueOf(vHead.x) + " " + String.valueOf(vHead.y) + " " + String.valueOf(vHead.z) + "\r\n";
        
        Vector3d vRclavicle = MatrixToEulerZYX(m_mapTransform.get("rclavicle"));
        strCMU += "rclavicle " + String.valueOf(vRclavicle.y) + " " + String.valueOf(vRclavicle.z) + "\r\n";
        Vector3d vRhumerus = MatrixToEulerZYX(m_mapTransform.get("rhumerus"));
        strCMU += "rhumerus " + String.valueOf(vRhumerus.x) + " " + String.valueOf(vRhumerus.y) + " " + String.valueOf(vRhumerus.z) + "\r\n";
        Vector3d vRradius = MatrixToEulerZYX(m_mapTransform.get("rradius"));
        strCMU += "rradius " + String.valueOf(vRradius.x) + "\r\n";
        Vector3d vRwrist = MatrixToEulerZYX(m_mapTransform.get("rwrist"));
        strCMU += "rwrist " + String.valueOf(vRwrist.y) + "\r\n";
        Vector3d vRhand = MatrixToEulerZYX(m_mapTransform.get("rhand"));
        strCMU += "rhand " + String.valueOf(vRhand.x) + " " + String.valueOf(vRhand.z) + "\r\n";
        Vector3d vRfingers = MatrixToEulerZYX(m_mapTransform.get("rfingers"));
        strCMU += "rfingers " + String.valueOf(vRfingers.x) + "\r\n";
        Vector3d vRthumb = MatrixToEulerZYX(m_mapTransform.get("rthumb"));
        strCMU += "rthumb " + String.valueOf(vRthumb.x) + " " + String.valueOf(vRthumb.z) + "\r\n";
        
		Vector3d vLclavicle = MatrixToEulerZYX(m_mapTransform.get("lclavicle"));
		strCMU += "lclavicle " + String.valueOf(vLclavicle.y) + " " + String.valueOf(vLclavicle.z) + "\r\n";
        Vector3d vLhumerus = MatrixToEulerZYX(m_mapTransform.get("lhumerus"));
        strCMU += "lhumerus " + String.valueOf(vLhumerus.x) + " " + String.valueOf(vLhumerus.y) + " " + String.valueOf(vLhumerus.z) + "\r\n";
        Vector3d vLradius = MatrixToEulerZYX(m_mapTransform.get("lradius"));
        strCMU += "lradius " + String.valueOf(vLradius.x) + "\r\n";
        Vector3d vLwrist = MatrixToEulerZYX(m_mapTransform.get("lwrist"));
        strCMU += "lwrist " + String.valueOf(vLwrist.y) + "\r\n";
        Vector3d vLhand = MatrixToEulerZYX(m_mapTransform.get("lhand"));
        strCMU += "lhand " + String.valueOf(vLhand.x) + " " + String.valueOf(vLhand.z) + "\r\n";
        Vector3d vLfingers = MatrixToEulerZYX(m_mapTransform.get("lfingers"));
        strCMU += "lfingers " + String.valueOf(vLfingers.x) + "\r\n";
        Vector3d vLthumb = MatrixToEulerZYX(m_mapTransform.get("lthumb"));
        strCMU += "lthumb " + String.valueOf(vLthumb.x) + " " + String.valueOf(vLthumb.z) + "\r\n";
        
		Vector3d vRfemur = MatrixToEulerZYX(m_mapTransform.get("rfemur"));
		strCMU += "rfemur " + String.valueOf(vRfemur.x) + " " + String.valueOf(vRfemur.y) + " " + String.valueOf(vRfemur.z) + "\r\n";
        Vector3d vRtibia = MatrixToEulerZYX(m_mapTransform.get("rtibia"));
        strCMU += "rtibia " + String.valueOf(vRtibia.x) + "\r\n";
        Vector3d vRfoot = MatrixToEulerZYX(m_mapTransform.get("rfoot"));
        strCMU += "rfoot " + String.valueOf(vRfoot.x) + " " + String.valueOf(vRfoot.z) + "\r\n";
        Vector3d vRtoes = MatrixToEulerZYX(m_mapTransform.get("rtoes"));
        strCMU += "rtoes " + String.valueOf(vRtoes.x) + "\r\n";
        
		Vector3d vLfemur = MatrixToEulerZYX(m_mapTransform.get("lfemur"));
		strCMU += "lfemur " + String.valueOf(vLfemur.x) + " " + String.valueOf(vLfemur.y) + " " + String.valueOf(vLfemur.z) + "\r\n";
        Vector3d vLtibia = MatrixToEulerZYX(m_mapTransform.get("ltibia"));
        strCMU += "ltibia " + String.valueOf(vLtibia.x) + "\r\n";
        Vector3d vLfoot = MatrixToEulerZYX(m_mapTransform.get("lfoot"));
        strCMU += "lfoot " + String.valueOf(vLfoot.x) + " " + String.valueOf(vLfoot.z) + "\r\n";
        Vector3d vLtoes = MatrixToEulerZYX(m_mapTransform.get("ltoes"));
        strCMU += "ltoes " + String.valueOf(vLtoes.x) + "\r\n";
        return strCMU;
	}	
	//according to EulerAngles.pdf, works perfectly
	public static Vector3d MatrixToEulerZYX(Matrix4d mxTransform)
	{
		Vector3d euler = new Vector3d();
		euler.y = - Math.asin(mxTransform.m20);
		euler.x = atan2(mxTransform.m21, mxTransform.m22);
		euler.z = atan2(mxTransform.m10, mxTransform.m00);
		euler.scale(180/Math.PI);
		return euler;
	}
	public void PopulateWorldPosition(WASFSkeleton asf)
	{
		asf.ApplyAmcRotation(this);
		for(String strKey : m_mapTransform.keySet())
		{
			WASFJoint joint = asf.m_mapJoint.get(strKey);
			WAMCLinkPos posLink = new WAMCLinkPos(joint.m_vPosWorld, joint.m_vEndPosWorld);
			m_mapWorldPos.put(strKey, posLink);
		}
	}

	public void Clone(WAMCMotionFrame frmSrc)
	{
		m_mapTransform.clear();
		Set<Entry<String, Matrix4d>> setAll = frmSrc.m_mapTransform.entrySet();
		for(Entry<String, Matrix4d> e : setAll)
		{
			String strKey = e.getKey();
			Matrix4d mxValue = new Matrix4d(e.getValue());
			m_mapTransform.put(strKey, mxValue);
		}	
	}
	public static WAMCMotionFrame Blend(WAMCMotionFrame frmBeg, WAMCMotionFrame frmEnd, float fRatio)
	{
		WAMCMotionFrame frmBlended = new WAMCMotionFrame();
		for(String strKey : frmBeg.m_mapTransform.keySet())
		{
			Matrix4d mxBeg = frmBeg.m_mapTransform.get(strKey);
			Matrix4d mxEnd = frmEnd.m_mapTransform.get(strKey);
			
			Matrix4d mxBlended = MathUtil.interpolate(mxBeg, mxEnd, fRatio);
			frmBlended.m_mapTransform.put(strKey, mxBlended);
		}
		return frmBlended;
	}

	public void ReplaceChannelFrom(WAMCMotionFrame frmSrc, wangChannelSelector cs)
	{
		if(cs.m_bLeftArm)
		{
			m_mapTransform.put("lclavicle", new Matrix4d(frmSrc.m_mapTransform.get("lclavicle")));
			m_mapTransform.put("lhumerus", new Matrix4d(frmSrc.m_mapTransform.get("lhumerus")));
			m_mapTransform.put("lradius", new Matrix4d(frmSrc.m_mapTransform.get("lradius")));
			m_mapTransform.put("lwrist", new Matrix4d(frmSrc.m_mapTransform.get("lwrist")));
			m_mapTransform.put("lhand", new Matrix4d(frmSrc.m_mapTransform.get("lhand")));
			m_mapTransform.put("lfingers", new Matrix4d(frmSrc.m_mapTransform.get("lfingers")));
			m_mapTransform.put("lthumb", new Matrix4d(frmSrc.m_mapTransform.get("lthumb")));
		}
		
		if(cs.m_bRightArm)
		{
			m_mapTransform.put("rclavicle", new Matrix4d(frmSrc.m_mapTransform.get("rclavicle")));
			m_mapTransform.put("rhumerus", new Matrix4d(frmSrc.m_mapTransform.get("rhumerus")));
			m_mapTransform.put("rradius", new Matrix4d(frmSrc.m_mapTransform.get("rradius")));
			m_mapTransform.put("rwrist", new Matrix4d(frmSrc.m_mapTransform.get("rwrist")));
			m_mapTransform.put("rhand", new Matrix4d(frmSrc.m_mapTransform.get("rhand")));
			m_mapTransform.put("rfingers", new Matrix4d(frmSrc.m_mapTransform.get("rfingers")));
			m_mapTransform.put("rthumb", new Matrix4d(frmSrc.m_mapTransform.get("rthumb")));			
		}
		
		if(cs.m_bLeftLeg)
		{
			m_mapTransform.put("lfemur", new Matrix4d(frmSrc.m_mapTransform.get("lfemur")));
			m_mapTransform.put("ltibia", new Matrix4d(frmSrc.m_mapTransform.get("ltibia")));
			m_mapTransform.put("lfoot", new Matrix4d(frmSrc.m_mapTransform.get("lfoot")));
			m_mapTransform.put("ltoes", new Matrix4d(frmSrc.m_mapTransform.get("ltoes")));
		}
		
		if(cs.m_bRightLeg)
		{
			m_mapTransform.put("rfemur", new Matrix4d(frmSrc.m_mapTransform.get("rfemur")));
			m_mapTransform.put("rtibia", new Matrix4d(frmSrc.m_mapTransform.get("rtibia")));
			m_mapTransform.put("rfoot", new Matrix4d(frmSrc.m_mapTransform.get("rfoot")));
			m_mapTransform.put("rtoes", new Matrix4d(frmSrc.m_mapTransform.get("rtoes")));
		}
		
		if(cs.m_bTorso)
		{
			//m_mapTransform.put("root", new Matrix4d(frmSrc.m_mapTransform.get("root")));
			m_mapTransform.put("lowerback", new Matrix4d(frmSrc.m_mapTransform.get("lowerback")));
			m_mapTransform.put("upperback", new Matrix4d(frmSrc.m_mapTransform.get("upperback")));
			m_mapTransform.put("thorax", new Matrix4d(frmSrc.m_mapTransform.get("thorax")));
			m_mapTransform.put("lowerneck", new Matrix4d(frmSrc.m_mapTransform.get("lowerneck")));
			m_mapTransform.put("upperneck", new Matrix4d(frmSrc.m_mapTransform.get("upperneck")));
			m_mapTransform.put("head", new Matrix4d(frmSrc.m_mapTransform.get("head")));
		}
	}
	
	public void MergeChannelFrom(WAMCMotionFrame frmSrc, float fRatio, wangChannelSelector cs)
	{
		if(cs.m_bLeftArm)
		{
			m_mapTransform.put("lclavicle", MathUtil.interpolate(m_mapTransform.get("lclavicle"), frmSrc.m_mapTransform.get("lclavicle"), fRatio));
			m_mapTransform.put("lhumerus", MathUtil.interpolate(m_mapTransform.get("lhumerus"), frmSrc.m_mapTransform.get("lhumerus"), fRatio));
			m_mapTransform.put("lradius", MathUtil.interpolate(m_mapTransform.get("lradius"), frmSrc.m_mapTransform.get("lradius"), fRatio));
			m_mapTransform.put("lwrist", MathUtil.interpolate(m_mapTransform.get("lwrist"), frmSrc.m_mapTransform.get("lwrist"), fRatio));
			m_mapTransform.put("lhand", MathUtil.interpolate(m_mapTransform.get("lhand"), frmSrc.m_mapTransform.get("lhand"), fRatio));
			m_mapTransform.put("lfingers", MathUtil.interpolate(m_mapTransform.get("lfingers"), frmSrc.m_mapTransform.get("lfingers"), fRatio));
			m_mapTransform.put("lthumb", MathUtil.interpolate(m_mapTransform.get("lthumb"), frmSrc.m_mapTransform.get("lthumb"), fRatio));
		}
		
		if(cs.m_bRightArm)
		{
			m_mapTransform.put("rclavicle", MathUtil.interpolate(m_mapTransform.get("rclavicle"), frmSrc.m_mapTransform.get("rclavicle"), fRatio));
			m_mapTransform.put("rhumerus", MathUtil.interpolate(m_mapTransform.get("rhumerus"), frmSrc.m_mapTransform.get("rhumerus"), fRatio));
			m_mapTransform.put("rradius", MathUtil.interpolate(m_mapTransform.get("rradius"), frmSrc.m_mapTransform.get("rradius"), fRatio));
			m_mapTransform.put("rwrist", MathUtil.interpolate(m_mapTransform.get("rwrist"), frmSrc.m_mapTransform.get("rwrist"), fRatio));
			m_mapTransform.put("rhand", MathUtil.interpolate(m_mapTransform.get("rhand"), frmSrc.m_mapTransform.get("rhand"), fRatio));
			m_mapTransform.put("rfingers", MathUtil.interpolate(m_mapTransform.get("rfingers"), frmSrc.m_mapTransform.get("rfingers"), fRatio));
			m_mapTransform.put("rthumb", MathUtil.interpolate(m_mapTransform.get("rthumb"), frmSrc.m_mapTransform.get("rthumb"), fRatio));			
		}
		
		if(cs.m_bLeftLeg)
		{
			m_mapTransform.put("lfemur", MathUtil.interpolate(m_mapTransform.get("lfemur"), frmSrc.m_mapTransform.get("lfemur"), fRatio));
			m_mapTransform.put("ltibia", MathUtil.interpolate(m_mapTransform.get("ltibia"), frmSrc.m_mapTransform.get("ltibia"), fRatio));
			m_mapTransform.put("lfoot", MathUtil.interpolate(m_mapTransform.get("lfoot"), frmSrc.m_mapTransform.get("lfoot"), fRatio));
			m_mapTransform.put("ltoes", MathUtil.interpolate(m_mapTransform.get("ltoes"), frmSrc.m_mapTransform.get("ltoes"), fRatio));
		}
		
		if(cs.m_bRightLeg)
		{
			m_mapTransform.put("rfemur", MathUtil.interpolate(m_mapTransform.get("rfemur"), frmSrc.m_mapTransform.get("rfemur"), fRatio));
			m_mapTransform.put("rtibia", MathUtil.interpolate(m_mapTransform.get("rtibia"), frmSrc.m_mapTransform.get("rtibia"), fRatio));
			m_mapTransform.put("rfoot", MathUtil.interpolate(m_mapTransform.get("rfoot"), frmSrc.m_mapTransform.get("rfoot"), fRatio));
			m_mapTransform.put("rtoes", MathUtil.interpolate(m_mapTransform.get("rtoes"), frmSrc.m_mapTransform.get("rtoes"), fRatio));
		}
		
		if(cs.m_bTorso)
		{
			m_mapTransform.put("root", MathUtil.interpolate(m_mapTransform.get("root"), frmSrc.m_mapTransform.get("root"), fRatio));
			m_mapTransform.put("lowerback", MathUtil.interpolate(m_mapTransform.get("lowerback"), frmSrc.m_mapTransform.get("lowerback"), fRatio));
			m_mapTransform.put("upperback", MathUtil.interpolate(m_mapTransform.get("upperback"), frmSrc.m_mapTransform.get("upperback"), fRatio));
			m_mapTransform.put("thorax", MathUtil.interpolate(m_mapTransform.get("thorax"), frmSrc.m_mapTransform.get("thorax"), fRatio));
			m_mapTransform.put("lowerneck", MathUtil.interpolate(m_mapTransform.get("lowerneck"), frmSrc.m_mapTransform.get("lowerneck"), fRatio));
			m_mapTransform.put("upperneck", MathUtil.interpolate(m_mapTransform.get("upperneck"), frmSrc.m_mapTransform.get("upperneck"), fRatio));
			m_mapTransform.put("head", MathUtil.interpolate(m_mapTransform.get("head"), frmSrc.m_mapTransform.get("head"), fRatio));
		}
	}

}
