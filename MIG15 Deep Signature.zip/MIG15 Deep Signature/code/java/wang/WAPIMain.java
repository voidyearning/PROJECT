package wang;

import mrl.main.Configuration;
import wang.WAPIWnd;

public class WAPIMain {

	public static void main(String[] args) {

		String strCMUDBPath = "";
		
		WAPIWnd wndAPI = new WAPIWnd(strCMUDBPath);
		wndAPI.OpenShow(1000, 1000);
	}
}
