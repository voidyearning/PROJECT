package wang;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import javax.vecmath.Matrix4d;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

import mrl.main.Configuration;
import mrl.motion.annotation.MotionAnnotation.MotionAnnValueGetter;
import mrl.motion.data.Motion;
import mrl.motion.data.MotionData;
import mrl.motion.data.MotionTransform;
import mrl.motion.data.MultiCharacterFolder;
import mrl.motion.data.MultiCharacterFolder.MultiCharacterFiles;
import mrl.motion.data.parser.BVHParser;
import mrl.motion.viewer.BaseApplication;
import mrl.motion.viewer.MotionIntervalSelector;
import mrl.motion.viewer.MotionListViewer.MotionListGetter;
import mrl.motion.viewer.MultiCharacterBVHListViewer.MultiFileMotionGetter;
import mrl.motion.viewer.MultiCharacterNavigator;
import mrl.util.FilterUtil;
import mrl.util.MathUtil;
import mrl.util.ObjectSerializer;
import mrl.util.Pair;
import mrl.widget.ObjectPropertyPanel;
import mrl.widget.dockable.DockableTabFolder;
import mrl.widget.dockable.SashFormContainer;
import mrl.widget.dockable.SashFormContainer.DockingPosition;
import mrl.widget.table.FilterableTable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;

public class WRawFile 
{	
	public ArrayList< ArrayList<Double> > m_arContent = new ArrayList< ArrayList<Double> > ();
	public void LoadFromFile(String strPath)
	{
		m_arContent.clear();
		try
		{
			BufferedReader br = new BufferedReader(new FileReader(strPath));
			String strLine;
			while( (strLine=br.readLine()) != null)
			{
				if(strLine.isEmpty())
				{
					continue;
				}
				ArrayList<Double> content = new ArrayList<Double>();
				int iBeg = 0; 
				int iEnd;
				while( (iEnd=strLine.indexOf(' ', iBeg)) != -1)
				{
					String strData = strLine.substring(iBeg, iEnd);
					double fData = Double.parseDouble(strData);
					content.add(fData);
					iBeg = iEnd + 1;					
				}
				iEnd = strLine.length();
				String strData = strLine.substring(iBeg, iEnd);
				if (strData != null)
				{
					double fData = Double.parseDouble(strData);
					content.add(fData);	
				}
				m_arContent.add(content);
			}
			br.close();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}		
	}
	public void SaveToFile(String strPath)
	{
		try
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter(strPath));		
			for(int i = 0; i < m_arContent.size(); ++i)
			{
				ArrayList<Double> content = m_arContent.get(i);
				for(int j = 0; j < content.size(); ++j)
				{
					String strData = String.valueOf(content.get(j));
					bw.write(strData);	
					bw.write(" ");
				}
				bw.newLine();
			}
			bw.flush();
			bw.close();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	public static MotionData ToLocal(MotionData originalMotionData)
    {
        Motion motionBaseOriginal = originalMotionData.motionList.get(10);
        Matrix4d mxHipsOriginal = motionBaseOriginal.get("Hips");
        mxHipsOriginal.invert();
       
        MotionData resultMotionData = new MotionData(originalMotionData);
        for(int i = 0; i < resultMotionData.motionList.size(); ++i)
        {
            Motion resultMotion = resultMotionData.motionList.get(i);   
            Matrix4d mxHips = resultMotion.get("Hips");
            Matrix4d mxHipsNew = new Matrix4d(mxHipsOriginal);//new Matrix4d(mxYN);
            mxHipsNew.mul(mxHips);
            resultMotion.put("Hips", mxHipsNew); 
            resultMotionData.motionList.set(i, resultMotion);
        }
        return resultMotionData;
    }
	public void TransformeToLocal()
	{		
	}
}
