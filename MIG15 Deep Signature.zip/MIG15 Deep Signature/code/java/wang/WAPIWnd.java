package wang;


import wangUI.wangMultiCharacterNavigator;
import java.io.File;
import javax.vecmath.Matrix4d;
import java.util.ArrayList;
import java.util.HashMap;
import javax.vecmath.Vector3d;

import mrl.motion.annotation.MotionAnnotation.MotionAnnValueGetter;
import mrl.motion.data.Motion;
import mrl.motion.data.MotionData;
import mrl.motion.data.parser.BVHParser;
import mrl.motion.data.parser.BVHWriter;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class WAPIWnd
{	
	public Shell m_shellMain;
	private Display m_displayMain;
	
	//UI
	public String m_strCMUDBPath; 
	public Button m_btnProcess; 
	
	public wangMultiCharacterNavigator m_ctrlMotionDataViewer;	
	
	public WAPIWnd(String strCMUDBPath)
	{
		m_displayMain = new Display();
		m_shellMain = new Shell(m_displayMain);
		m_shellMain.setText("Yingying!");
		
		m_strCMUDBPath = strCMUDBPath; 
		InitializeUI();
	} 

    public void InitializeUI() 
	{
    	//layout
    	FormLayout formLO = new FormLayout();
    	formLO.marginHeight = 10;
    	formLO.marginWidth = 10;
    	m_shellMain.setLayout(formLO);
    	
    	//button process
    	FormData formDataBtn = new FormData(300, 22);
		m_btnProcess = new Button(m_shellMain, SWT.PUSH);
		m_btnProcess.setLayoutData(formDataBtn);
		m_btnProcess.setText("Process");
		m_btnProcess.addListener(SWT.Selection, new Listener() 
		{
			@Override
			public void handleEvent(Event event)
			{	
				WRawFile rawFile = new WRawFile();
				rawFile.LoadFromFile("c:\\toDel\\16_08_0_101.raw");
				rawFile.SaveToFile("c:\\toDel\\16_08_0_101.wokao.raw");
				File file = new File("c:\\wangyi\\woshit");
				try
				{
					file.mkdir();
				}
				catch(Exception e){}
			}
		}); 
		
		//motion viewer
		FormData formDataViewer = new FormData(1000, 600);
		m_ctrlMotionDataViewer = new wangMultiCharacterNavigator(m_shellMain);	
		m_ctrlMotionDataViewer.setLayoutData(formDataViewer);
		m_ctrlMotionDataViewer.setGoStartAfterPlay(false);
		m_ctrlMotionDataViewer.setStartFromZero(true);	
		CreateMenu();		
	}
	protected void CreateMenu() 
	{
		Menu bar = new Menu (m_shellMain, SWT.BAR);
		m_shellMain.setMenuBar (bar);
		{
			//splice naive 1
			MenuItem fileItem1 = new MenuItem(bar, SWT.PUSH);
			fileItem1.setText("&A&1\tCtrl+1");
			fileItem1.addSelectionListener(new SelectionAdapter() 
			{
				public void widgetSelected(SelectionEvent e)
				{ 
					String strFilePath1 = "C:\\wangyi\\research\\disney\\Fighting\\Fighting\\workspace-dump\\MotionLibrary\\data\\Splice\\Loco\\runLong120FPS.137.45.8.500_Take_001.bvh";
					File fileGestBvh1 = new File(strFilePath1);
					MotionData gestMotionData1 = new BVHParser().parse(fileGestBvh1);
					MotionData gestMotionDataLocal1 = WRawFile.ToLocal(gestMotionData1);
					
					String strFilePath2 = "C:\\wangyi\\research\\disney\\Fighting\\Fighting\\workspace-dump\\MotionLibrary\\data\\Splice\\Loco\\walkLong120FPS.442.20.10.160_Take_001.bvh";
					File fileGestBvh2 = new File(strFilePath2);
					MotionData gestMotionData2 = new BVHParser().parse(fileGestBvh2);
					MotionData gestMotionDataLocal2 = WRawFile.ToLocal(gestMotionData2);
					
					MotionData[] motionDataList = new MotionData[4];
					motionDataList[0] = gestMotionData1;				
					motionDataList[1] = gestMotionDataLocal1;					
					motionDataList[2] = gestMotionData2;				
					motionDataList[3] = gestMotionDataLocal2;
					m_ctrlMotionDataViewer.setMotionDataList(motionDataList);
					m_ctrlMotionDataViewer.startAnimation(); 
				}
			});
			
			//splice naive 2
			MenuItem fileItem2 = new MenuItem(bar, SWT.PUSH);
			fileItem2.setText("&B&2\tCtrl+2");
			fileItem2.addSelectionListener(new SelectionAdapter()
			{
				public void widgetSelected(SelectionEvent e)
				{ 
					WAmcFile amcFile = new WAmcFile();
					String strPath = "C:\\wangyi\\research\\playground\\01_01_102_237.amc";
					amcFile.LoadFromFile(strPath);
					amcFile.ToLocal();
					strPath += ".local.amc";
					amcFile.SaveToFile(strPath);
				}
			});
			
			MenuItem macroItem = new MenuItem (bar, SWT.CASCADE);
			macroItem.setText ("M&acro");
			Menu macroSubMenu = new Menu (m_shellMain, SWT.DROP_DOWN);
			macroItem.setMenu (macroSubMenu);
			{
				//export results
				MenuItem exportItem = new MenuItem(macroSubMenu, SWT.PUSH);
				exportItem.setText("Test ASF Parser");
				exportItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 	
						WASFSkeleton.test();
					}
				});
				
				//show group
				MenuItem showGroupItem = new MenuItem(macroSubMenu, SWT.PUSH);
				showGroupItem.setText("Load Hand BVH");
				showGroupItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{
						String strFilePath1 = "C:\\wangyi\\research\\multimodality\\asf amc maya importer\\spreadOut_S.bvh";
						File fileGestBvh1 = new File(strFilePath1);
						MotionData gestMotionData1 = new BVHParser().parse(fileGestBvh1);
						//MotionData gestMotionDataLocal1 = WRawFile.ToLocal(gestMotionData1);
						
						MotionData[] motionDataList = new MotionData[1];
						motionDataList[0] = gestMotionData1;				
						//motionDataList[1] = gestMotionDataLocal1;	
						m_ctrlMotionDataViewer.setMotionDataList(motionDataList);
						m_ctrlMotionDataViewer.startAnimation(); 
						
					}
				});
				
				//clear group
				MenuItem clearGroupItem = new MenuItem(macroSubMenu, SWT.PUSH);
				clearGroupItem.setText("Test Amc");
				clearGroupItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
						WASFSkeleton asf = new WASFSkeleton();
						asf.m_fScale = 3;
						asf.ParseFile("C:\\wangyi\\research\\CMUDB\\asf\\test.asf");
						WAMCMotion amc = new WAMCMotion(asf);
						amc.LoadFromFile("C:\\wangyi\\research\\CMUDB\\asf\\test.amc");
						WAMCMotion [] arAmcList = new WAMCMotion[1];
						arAmcList[0] = amc;
						m_ctrlMotionDataViewer.setAMCMotionList(arAmcList);
						
						WAmcFile amcFile = new WAmcFile();
						amcFile.LoadFromFile("C:\\wangyi\\research\\CMUDB\\18_01.amc");	
						WAmcFile[] arAmcFile = new WAmcFile[1];
						arAmcFile[0] = amcFile;
						//m_ctrlMotionDataViewer.setAmcFileList(arAmcFile);
						m_ctrlMotionDataViewer.startAnimation(); 
					}
				});
				
				//export group
				MenuItem exportGroupItem = new MenuItem(macroSubMenu, SWT.PUSH);
				exportGroupItem.setText("test human amc");
				exportGroupItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
						WAMCMotion [] arAmcList = new WAMCMotion[10];
						for (int i = 0; i < 10; ++i)
						{
							WASFSkeleton asf = new WASFSkeleton();
							asf.m_fScale = 7;
							asf.ParseFile("C:\\wangyi\\research\\CMUDB\\18.asf");
							WAMCMotion amc = new WAMCMotion(asf);
							WASFSkeleton.m_asf = asf;
							amc.LoadFromFile("C:\\wangyi\\research\\CMUDB\\18_01.amc");
							amc.Relocate(new Vector3d(100 * i, 0, 0));
							arAmcList[i] = amc;
						}
						m_ctrlMotionDataViewer.setAMCMotionList(arAmcList);
					}
				});
				
				//API
				//export group
				MenuItem styleItem = new MenuItem(macroSubMenu, SWT.PUSH);
				styleItem.setText("Jog Style Show");
				styleItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
					}
				});
				
				//crowds
				MenuItem crowdsItem = new MenuItem(macroSubMenu, SWT.PUSH);
				crowdsItem.setText("Crowds Show - 3 groups");
				crowdsItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
					}
				});
				
				MenuItem crowdsItem2 = new MenuItem(macroSubMenu, SWT.PUSH);
				crowdsItem2.setText("Crowds Show - 1 big group");
				crowdsItem2.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 
					}
				});
				
				//API
				//export group
				MenuItem apiItem = new MenuItem(macroSubMenu, SWT.PUSH);
				apiItem.setText("API");
				apiItem.addSelectionListener(new SelectionAdapter()
				{
					public void widgetSelected(SelectionEvent e)
					{ 		
					}
				});
			}
		}	
	}
	 
	public void OpenShow(int width, int height)
	{
		m_shellMain.pack();
		m_shellMain.open();
		while(!m_shellMain.isDisposed())
		{
			if(!m_displayMain.readAndDispatch())
			{
				m_displayMain.sleep();
			}
		}
		m_displayMain.dispose();		
	}

}
