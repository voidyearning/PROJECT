package wang;

import java.io.File;
import java.util.ArrayList;

public class WFileTraverser
{
	public static ArrayList<String> m_filelist = new ArrayList<String>();
	public static void main(String[] args) throws Exception
	{
		String filePath = "C:\\toDel";
	    GetFiles(filePath);
	    
	    //System.out.println("new start===========================");
	    //for(int i = 0; i < m_filelist.size(); ++i)
	    //	System.out.println(m_filelist.get(i));
	} 

	static void GetFiles(String filePath)
	{
		File root = new File(filePath);
		File[] files = root.listFiles();
		for(File file:files)
		{    
			if(file.isDirectory())
			{
				GetFiles(file.getAbsolutePath());
				System.out.println("Dir:"+file.getName());
			}
			else
			{
				m_filelist.add(file.getAbsolutePath());
				System.out.println("File:"+file.getName());
			}    
		}
	}
	
	static void BatchProcessFilesAmc(String strSrcPath, String strDestPath)
	{
		File root = new File(strSrcPath);
		File[] files = root.listFiles();
		for(File file:files)
		{    
			if(file.isDirectory())
			{
				String strDirName = file.getName();	
				String strDestDir = strDestPath + "\\" + strDirName;
				File destDir = new File(strDestDir);
				try
				{
					if (!destDir.isDirectory())
						destDir.mkdir();
				}catch(Exception e)
				{}
				BatchProcessFilesAmc(file.getAbsolutePath(), strDestDir);
			}
			else
			{
				String strFileName = file.getName();
				if(strFileName.indexOf(".amc")==-1)
					continue;
				
				WAmcFile torsoAmcFile = new WAmcFile();
				String strSrcFile = file.getAbsolutePath();
				torsoAmcFile.LoadFromFile(strSrcFile);
				torsoAmcFile.ToLocalOrientation();
				//torsoAmcFile.ToLocal();
				String strDestFile = strDestPath + "\\" + strFileName;
				torsoAmcFile.SaveToFile(strDestFile);
			}    
		}
	}
}