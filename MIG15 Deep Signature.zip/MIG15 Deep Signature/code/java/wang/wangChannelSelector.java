package wang;

public class wangChannelSelector {
	public boolean m_bLeftArm = true;
	public boolean m_bRightArm = true;
	public boolean m_bLeftLeg = true;
	public boolean m_bRightLeg = true;
	public boolean m_bTorso = true;
	
	public wangChannelSelector(boolean bLA, boolean bRA, boolean bLL, boolean bRL, boolean bTS)
	{
		m_bLeftArm = bLA; 
		m_bRightArm = bRA;
		m_bLeftLeg = bLL;
		m_bRightLeg = bRL;
		m_bTorso = bTS;
	}
}
