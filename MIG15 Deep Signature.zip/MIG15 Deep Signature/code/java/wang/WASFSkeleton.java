package wang;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import javax.vecmath.Matrix4d;
import javax.vecmath.Vector3d;

import mrl.motion.data.MotionData;
        
class WASFDOF
{
	public String m_strDOF = "";
    public float m_fLimitMin = 0;
    public float m_fLimitMax = 0;
    
    public WASFDOF()
    {
    	
    }
    public WASFDOF(String strDOF)
    {
    	m_strDOF = strDOF;
    }
    public WASFDOF(String strDOF, float fLimitMin, float fLimitMax)
    {
    	m_strDOF = strDOF;
    	m_fLimitMin = fLimitMin;
    	m_fLimitMax = fLimitMax;
    }
    public WASFDOF(WASFDOF dofSrc)
    {
    	m_strDOF = dofSrc.m_strDOF;
    	m_fLimitMin = dofSrc.m_fLimitMin;
    	m_fLimitMax = dofSrc.m_fLimitMax;
    }
};


public class WASFSkeleton
{
	public float m_fScale = 7;
	public WASFJoint m_jtRoot = new WASFJoint();
    public HashMap<String, WASFJoint> m_mapJoint = new HashMap<String, WASFJoint>();
    public float m_fMass = 1;
    public float m_fLength = 1;
    public String m_strAngle = "deg";
    public String m_strDoc = "";
    public String m_strHierarchy = "";
    public int m_iActiveFrameIdx = -1;
    
    public static WASFSkeleton m_asf = null;
    
    public static WASFSkeleton getInstance()
    {
    	if (m_asf == null)
    	{
    		m_asf = new WASFSkeleton();
    		m_asf.ParseFile("C:\\wangyi\\research\\CMUDB\\ASF\\test.asf");
    	}
    	return m_asf;
    }
    public void Reset()
    {
        m_jtRoot = new WASFJoint();
        m_mapJoint = new HashMap<String, WASFJoint>();
        m_fMass = 1;
        m_fLength = 1;
        m_strAngle = "deg";
        m_strDoc = "";
        m_strHierarchy = "";
        m_fScale = 7;
        m_iActiveFrameIdx = -1;
    }
    public void Clone(WASFSkeleton asfSrc)
    {
    	Reset();
        m_fMass = asfSrc.m_fMass;
        m_fLength = asfSrc.m_fLength;
        m_strAngle = asfSrc.m_strAngle;
        m_strDoc = asfSrc.m_strDoc;
        m_strHierarchy = asfSrc.m_strHierarchy;
        m_fScale = asfSrc.m_fScale;
        m_iActiveFrameIdx = asfSrc.m_iActiveFrameIdx;
        WASFJoint[] jointAll = asfSrc.GetAllJoints();
        for(WASFJoint jointSrc : jointAll)
        {
        	WASFJoint jointDest = new WASFJoint();
        	jointDest.Clone(jointSrc);
        	m_mapJoint.put(jointSrc.m_strName, jointDest);
        }        
        //after all the joints are there, construct the father-children tree
        for(WASFJoint jointSrc : jointAll)
        {
        	WASFJoint jointDest = m_mapJoint.get(jointSrc.m_strName);
        	if(jointSrc.m_jtParent!=null)
        	{
        		if(jointSrc.m_jtParent.m_strName.equalsIgnoreCase("root"))
        			jointDest.m_jtParent = m_jtRoot;
        		else
        			jointDest.m_jtParent = m_mapJoint.get(jointSrc.m_jtParent.m_strName);
        	}
        	for(WASFJoint jtChildSrc : jointSrc.m_arChilden)
        	{
        		WASFJoint jtChildDest = m_mapJoint.get(jtChildSrc.m_strName);
        		jointDest.m_arChilden.add(jtChildDest);
        	}
        	m_mapJoint.put(jointSrc.m_strName, jointDest);
        }  
        m_jtRoot = m_mapJoint.get("root");
        ConstructASFSkeleton();
    }
    
    public WASFJoint[] GetAllJoints()
    {
    	WASFJoint [] arJoint = m_mapJoint.values().toArray(new WASFJoint[m_mapJoint.values().size()]);
    	return arJoint;
    }
    
    public int ParseUnits(ArrayList<String> arLines, int iCur)
    {    	
        while(true)
        {
            String strLine = arLines.get(iCur);
            strLine = strLine.trim();
            if (strLine.startsWith(":units"))
            {
                iCur = iCur+1;
                continue;
            }
            String [] arWords = strLine.split(" ");
            if (arWords[0].startsWith("mass"))
            {
                m_fMass = Float.parseFloat(arWords[1]);
            }
            else if (arWords[0].startsWith("length"))
            {
                m_fLength = Float.parseFloat(arWords[1]) * m_fScale;
            }
            else if (arWords[0].startsWith("angle"))
            {
                 m_strAngle = arWords[1];
            }
            else if (arWords[0].startsWith(":"))
            {
                return iCur;
            }
            iCur = iCur+1;
        }
    }
            
    public int ParseDoc(ArrayList<String> arLines, int iCur)
    {
        m_strDoc = "";
        while (true)
        {
            String strLine = arLines.get(iCur);
            strLine = strLine.trim();
            if (strLine.startsWith(":documentation"))
            {
                iCur = iCur+1;
                continue;     
            }
            if (strLine.startsWith(":"))
            {
                return iCur;
            }
            m_strDoc = m_strDoc + strLine+"\r\n";
            iCur=iCur+1;
        }
    }

    public int ParseRoot(ArrayList<String> arLines, int iCur)
    {
        m_jtRoot = new WASFJoint();
        m_jtRoot.m_strName = "root";
        m_mapJoint.put(m_jtRoot.m_strName, m_jtRoot);
        while (true)
        {
            String strLine = arLines.get(iCur);
            strLine = strLine.trim();
            if (strLine.startsWith(":root"))
            {
                iCur = iCur+1;
                continue;
            }
            if (strLine.startsWith(":"))
            {
                return iCur;
            }
            String [] arWords = strLine.split(" ");
            if (arWords[0].startsWith("order"))
            {
                m_jtRoot.m_arDOF.clear();
                for(int i = 1; i < arWords.length; ++i)
                {
                	m_jtRoot.m_arDOF.add(new WASFDOF(arWords[i]));
                }
            }
            if (arWords[0].startsWith("axis"))
            {
                m_jtRoot.m_strAxis = arWords[1];
            }
            if (arWords[0].startsWith("position"))
            {
                m_jtRoot.m_vPosWorld.x = Float.parseFloat(arWords[1]);
                m_jtRoot.m_vPosWorld.y = Float.parseFloat(arWords[2]);
                m_jtRoot.m_vPosWorld.z = Float.parseFloat(arWords[3]);
            }
            if (arWords[0].startsWith("orientation"))
            {
                m_jtRoot.m_vAxis.x = Float.parseFloat(arWords[1]);
                m_jtRoot.m_vAxis.y = Float.parseFloat(arWords[2]);
                m_jtRoot.m_vAxis.z = Float.parseFloat(arWords[3]);
            }
            iCur=iCur+1;
        }
    }

    public int ParseJoint(ArrayList<String> arLines, int iCur)
    {
        WASFJoint joint = new WASFJoint();
        while (true)
        {
            String strLine = arLines.get(iCur);
            strLine = strLine.trim();
            if (strLine.startsWith("begin"))
            {
                iCur = iCur + 1;
                continue;
            }
            if (strLine.startsWith("end"))
            {
                m_mapJoint.put(joint.m_strName, joint);
                return iCur;
            }
            String [] arWords = strLine.split(" ");
            if (arWords[0].startsWith("id"))
            {
                joint.m_iId = Integer.parseInt(arWords[1]);
            }
            if (arWords[0].startsWith("name"))
            {
                joint.m_strName = arWords[1];
            }
            if (arWords[0].startsWith("direction"))
            {
                joint.m_vDirection.x = Float.parseFloat(arWords[1]);
                joint.m_vDirection.y = Float.parseFloat(arWords[2]);
                joint.m_vDirection.z = Float.parseFloat(arWords[3]);
            }
            if (arWords[0].startsWith("length"))
            {
                joint.m_fLength = Float.parseFloat(arWords[1]) * m_fScale;
            }
            if (arWords[0].startsWith("axis"))
            {
                joint.m_vAxis.x = Float.parseFloat(arWords[1]);
                joint.m_vAxis.y = Float.parseFloat(arWords[2]);
                joint.m_vAxis.z = Float.parseFloat(arWords[3]);
                joint.m_strAxis = arWords[arWords.length-1];
            }
            if (arWords[0].startsWith("dof"))
            {
                for (int d = 1; d < arWords.length; ++ d)
                {
                    WASFDOF dof = new WASFDOF();
                    dof.m_strDOF = arWords[d];
                    joint.m_arDOF.add(dof);
                }
            }
            if (arWords[0].startsWith("limits"))
            {
                String strMin = arWords[1];
                strMin = strMin.substring(1);
                String strMax = arWords[2];
                strMax = strMax.substring(0, strMax.length()-1);
                int d = 0;
                while (true)
                {
                    joint.m_arDOF.get(d).m_fLimitMin = Float.parseFloat(strMin);
                    joint.m_arDOF.get(d).m_fLimitMax = Float.parseFloat(strMax);
                    d = d + 1;
                    iCur = iCur + 1;
                    strLine = arLines.get(iCur);
                    strLine = strLine.trim();
                    if (strLine.startsWith("end"))
                    {
                        iCur = iCur - 1;
                        break;
                    }
                    arWords = strLine.split(" ");
                    strMin = arWords[0];
                    strMin = strMin.substring(1);
                    strMax = arWords[1];
                    strMax = strMax.substring(0, strMax.length()-1);
                }
            }
            iCur=iCur+1;
        }
    }
        
    public int ParseBonedata(ArrayList<String> arLines, int iCur)
    {
        while (true)
        {
            String strLine = arLines.get(iCur);
            strLine = strLine.trim();
            if (strLine.startsWith(":bonedata"))
            {
                iCur = iCur + 1;
                continue;
            }
            if (strLine.startsWith(":"))
            {
                return iCur;
            }
            String [] arWords = strLine.split(" ");
            while (arWords[0].startsWith("begin"))
            {
                iCur = ParseJoint(arLines, iCur);
                iCur = iCur + 1;
                strLine = arLines.get(iCur);
                strLine = strLine.trim();
                arWords = strLine.split(" ");
            }
            if (!arWords[0].startsWith("begin"))
            {
                iCur = iCur - 1;
            }
            iCur = iCur + 1;
        }
    }

    public int ParseHierarchy(ArrayList<String> arLines, int iCur)
    {
        m_strHierarchy = "";
        String strLine = arLines.get(iCur);
        strLine = strLine.trim(); 
        if (strLine.startsWith(":hierarchy"))
        {
            iCur = iCur + 1;
            strLine = arLines.get(iCur);
            strLine = strLine.trim();
        }
        if (strLine.startsWith("begin"))
        {
            iCur = iCur + 1;
            strLine = arLines.get(iCur);
            strLine = strLine.trim();
        }
        while (! strLine.startsWith("end"))
        {
            m_strHierarchy = m_strHierarchy+strLine + "\r\n";
            String [] arWords = strLine.split(" ");
            String strParentName = arWords[0];
            WASFJoint jtParent = m_mapJoint.get(strParentName);
            jtParent.m_bEnd = false;
            
            for (int iChild = 1; iChild < arWords.length; ++ iChild)
            {
            	String strChildName = arWords[iChild];
            	WASFJoint jtChild = m_mapJoint.get(strChildName);
            	jtChild.m_jtParent = jtParent;
            	jtParent.m_arChilden.add(jtChild);
            }
            iCur = iCur + 1;
            strLine = arLines.get(iCur);
            strLine = strLine.trim();
        }
        if( strLine.startsWith("end"))
        {
        	return iCur;
        }
        return iCur;
    }
    
    public void ParseASF(ArrayList<String> arLines)
    {
    	int i=0;
        while (i< arLines.size())
        {
            String strLine = arLines.get(i);
            strLine = strLine.trim();
            if (strLine.startsWith(":units"))
            {
                i = ParseUnits(arLines, i);
                strLine = arLines.get(i);
                strLine = strLine.trim();
            }
            if (strLine.startsWith(":documentation"))
            {
                i = ParseDoc(arLines, i);
                strLine = arLines.get(i);
                strLine = strLine.trim();
            }
            if (strLine.startsWith(":root"))
            {
                i = ParseRoot(arLines, i);
                strLine = arLines.get(i);
                strLine = strLine.trim();
            }
            if (strLine.startsWith(":bonedata"))
            {
                i = ParseBonedata(arLines, i);
                strLine = arLines.get(i);
                strLine = strLine.trim();
            }
            if (strLine.startsWith(":hierarchy"))
            {
                i = ParseHierarchy(arLines, i);
            }
            i = i + 1;
        }
    }

    public void ParseFile(String strASFPath)
    {
    	ArrayList<String> arLines = new ArrayList<String>();
        try
        {			
			BufferedReader br = new BufferedReader(new FileReader(strASFPath));
			String strLine;
			while( (strLine=br.readLine()) != null)
			{
				if (strLine.isEmpty())
					continue;
				
				arLines.add(strLine);
			}
			br.close();
		}
        catch(Exception e)
		{
        	System.out.println(e.getMessage());
		}        
        ParseASF(arLines);
        ConstructASFSkeleton();
    }
    
    //update world coord
    //update local transformation
    public void ConstructASFSkeleton()
    {
    	constructASFSkeleton(m_jtRoot);   
    }
    private void constructASFSkeleton(WASFJoint joint)
    {
    	//update current position
    	if (joint.m_strName.indexOf("root") >= 0)
    	{
    		//world coord is directly loaded from asf
    		//local transform is identity matrix
    		joint.m_mxAxisLocal.setIdentity();
    	}
    	else
    	{
    		Vector3d vRelCoordWorld = joint.GetLengthDirW();
    		joint.m_vPosWorld.add(joint.m_jtParent.m_vPosWorld, vRelCoordWorld);
    		
    		//axis mx relative to parent
    		Matrix4d mxAxis = joint.GetAxisMatrixW();
    		Matrix4d mxAxisInv = new Matrix4d();
    		mxAxisInv.invert(mxAxis);
    		Matrix4d mxParentAxis = joint.m_jtParent.GetAxisMatrixW();   
    		Matrix4d mxParentAxisInv = new Matrix4d();
    		mxParentAxisInv.invert(mxParentAxis);
    		joint.m_mxAxisLocal.mul(mxParentAxisInv, mxAxis);
    		
    		//bone length with direction
    		Vector3d vLengthDir = joint.GetLengthDirW();
    		mxAxisInv.transform(vLengthDir);
    		joint.m_vLengthDirLocal = vLengthDir;
    	}
    	if(joint.m_bEnd)
    		return;
    	for(WASFJoint jtChild : joint.m_arChilden)
    		constructASFSkeleton(jtChild);
    }
    
    //recalculate the world positions
    public void ApplyAmcRotation(WAMCMotionFrame amcFrame)
    {
    	Matrix4d mxAmcRoot = amcFrame.m_mapTransform.get(m_jtRoot.m_strName);
    	m_jtRoot.m_vPosWorld = new Vector3d(mxAmcRoot.m03, mxAmcRoot.m13, mxAmcRoot.m23); 
    	applyAmcRotation(amcFrame, m_jtRoot, m_jtRoot.m_mxAxisLocal);     	
    }
    /*/populate world pos to all children of joint
    void applyAmcRotation(WAMCMotionFrame amcFrame, WASFJoint joint, Matrix4d mxAxisWorld)
    {
    	for(WASFJoint jtChild : joint.m_arChilden)
    	{
    		Matrix4d mxParentWorld = new Matrix4d(mxAxisWorld);
    		
    		//x, y, z rotation in amc
    		Matrix4d mxAmcRot = null;
    		if(amcFrame == null)
    		{
    			mxAmcRot = new Matrix4d();
    			mxAmcRot.setIdentity();
    		}
    		else
    			mxAmcRot = amcFrame.m_mapTransform.get(joint.m_strName);
    		
    		if (mxAmcRot == null)
    		{
    			mxAmcRot = new Matrix4d();
    			mxAmcRot.setIdentity();
    		}
    		mxParentWorld.mul(mxAmcRot);//correct

    		Matrix4d mxChildLocal = new Matrix4d(jtChild.m_mxAxisLocal);
    		mxChildLocal.setTranslation(joint.m_vLengthDirLocal); 
  		
    		jtChild.GetAxisMatrixW();
    		mxParentWorld.mul(mxChildLocal);
    		Vector3d vPosW = new Vector3d(mxParentWorld.m03, mxParentWorld.m13, mxParentWorld.m23); 
    		joint.m_vEndPosWorld = vPosW;
    		jtChild.m_vPosWorld = vPosW;
    		applyAmcRotation(amcFrame, jtChild, mxParentWorld);
    	}
    }*/
    void applyAmcRotation(WAMCMotionFrame amcFrame, WASFJoint joint, Matrix4d mxAxisWorld)
    {
    	Matrix4d mxParentWorld = new Matrix4d(mxAxisWorld);
		
		//x, y, z rotation in amc
		Matrix4d mxAmcRot = null;
		if(amcFrame == null)
		{
			mxAmcRot = new Matrix4d();
			mxAmcRot.setIdentity();
		}
		else
			mxAmcRot = amcFrame.m_mapTransform.get(joint.m_strName);
		
		if (mxAmcRot == null)
		{
			mxAmcRot = new Matrix4d();
			mxAmcRot.setIdentity();
		}
		mxParentWorld.mul(mxAmcRot);//correct
		Matrix4d mxBone = new Matrix4d();
		mxBone.setIdentity();
		mxBone.setTranslation(joint.m_vLengthDirLocal);
		mxBone.mul(mxParentWorld, mxBone);
		Vector3d vPosW = new Vector3d(mxBone.m03, mxBone.m13, mxBone.m23);
		joint.m_vEndPosWorld = vPosW;
		
    	for(WASFJoint jtChild : joint.m_arChilden)
    	{
    		Matrix4d mxChildLocal = new Matrix4d(jtChild.m_mxAxisLocal);   
    		mxChildLocal.setTranslation(joint.m_vLengthDirLocal);
    		Matrix4d mxWorld = new Matrix4d(mxParentWorld);
    		mxWorld.mul(mxChildLocal);
    		
    		jtChild.m_vPosWorld = vPosW;
    		applyAmcRotation(amcFrame, jtChild, mxWorld);
    	}
    }
    
    public void SaveToFile(String strASFPath)
    {
    	try
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter(strASFPath));	
			bw.write(":version 1.10\r\n");
			bw.write(":name VICON");
			bw.write("units\r\n");
			bw.write("\tmass " + String.valueOf(m_fMass) + "\r\n");
			bw.write("\tlength " + String.valueOf(m_fLength/ m_fScale)  + "\r\n");
			bw.write("\tangle deg\r\n");
			bw.write(":documentation\r\n");
			bw.write(this.m_strDoc);
			bw.write(m_jtRoot.ToString());
			WASFJoint [] arJoint = m_mapJoint.values().toArray(new WASFJoint[m_mapJoint.values().size()]);
			for (int i = 0; i < arJoint.length; ++i)
			{ 
				WASFJoint joint = arJoint[i];
				bw.write(joint.ToString());	
			}
			bw.write(":hierarchy\r\n\tbegin\r\n\t\t");
			bw.write(m_strHierarchy);
			bw.write("end\r\n");
            bw.flush();
            bw.close();
		}catch(Exception e)
		{}    	
    }

    public static int test()
    {
    	String strASFPath = "C:\\wangyi\\research\\CMUDB\\ASF\\01.asf";
    	WASFSkeleton asfData = new WASFSkeleton();
    	asfData.Reset();
    	asfData.ParseFile(strASFPath);
    	asfData.SaveToFile(strASFPath + ".gen.asf");
    	
    	return 0;
    }  
}
