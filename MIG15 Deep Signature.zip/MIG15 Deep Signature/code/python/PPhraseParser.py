class PPhrase:
    def __init__(self):
        self.m_fStart=0;
        self.m_fEnd=0;
        self.m_strLexeme="";
        self.m_strHandness="";

    def PopulateFromLine(self, strLine):
        arLineItem = strLine.split(" ");
        self.m_fStart=float(arLineItem[0]);
        self.m_fEnd=float(arLineItem[1]);
        self.m_strLexeme=arLineItem[2];
        self.m_strHandness=arLineItem[3];

class PPhraseFile:
    def __init__(self):
        self.m_arPhrase=[];
        self.m_fOffset=0;
        self.m_strComment="";

    def LoadFromFile(self, strPath):
        self.m_arPhrase=[];
        self.m_fOffset=0;
        self.m_strComment="";
        phraseFile=file(strPath, 'r');
        while True:
            line=phraseFile.readline();
            if line=="":
                break;
            arLineItem=line.split(" ");
            if arLineItem[0]=="TimeOffset":
                self.m_fOffset=float(arLineItem[1]);
            elif arLineItem[0].isalpha():
                self.m_strComment=self.m_strComment+line;
            else:
                onePhrase=PPhrase();
                onePhrase.PopulateFromLine(line);
                self.m_arPhrase.append(onePhrase);

def Test():
    #lets test if it is working
    strPath = r"E:\research\multimodality\gestureDB\shakes_angry3_v3.phrase";
    #raw_input("Please indicate the phrase file:\r\n");
    phraseFile = PPhraseFile();
    phraseFile.LoadFromFile(strPath);
    iPhraseNum=len(phraseFile.m_arPhrase);
    for i in range(0,iPhraseNum):
        item=phraseFile.m_arPhrase[i];
        print item.m_fStart,item.m_fEnd,item.m_strLexeme,item.m_strHandness;
            
