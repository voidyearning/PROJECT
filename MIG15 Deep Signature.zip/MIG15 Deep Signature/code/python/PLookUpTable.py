class PMotionLookupResultItem:
    def __init__(self):
        self.m_strBvhName='';
        self.m_arBiTopState=[];
        self.m_iDifferentBitNum=0;
        self.m_iTableIdx=-1;
        
class PMotionLookupItem:
    def __init__(self):
        self.m_strBvhName='';
        self.m_arBiTopState=[];

    def GetDistance(self, iTarget):
        iDifferentBitNum=0;
        strTarget=bin(iTarget);
        strTarget=strTarget[2:];#cut the 0b
        iTargetBitNum=len(strTarget);
        iItemBitNum=len(self.m_arBiTopState);
        if iItemBitNum==0:
            return iDifferentBitNum;
        for i in range(0, iItemBitNum):
            #compare from low to high(right to left)
            iItemCursor=(iItemBitNum-1)-i;
            iItemBit=self.m_arBiTopState[iItemCursor];
            if i < iTargetBitNum:
                iTargetCursor=(iTargetBitNum-1)-i;
                iTargetBit=int(strTarget[iTargetCursor]);
            else:
                iTargetBit=0;
            if iTargetBit!=iItemBit:
                iDifferentBitNum=iDifferentBitNum+1;
        return iDifferentBitNum;

    def GetBiTopInt(self):
        iBiTopInt=0;        
        iRadix=1;
        iBiTopLen=len(self.m_arBiTopState);
        for i in range(0,iBiTopLen):
            iCursor=(iBiTopLen-1)-i;
            iBit=self.m_arBiTopState[iCursor];
            iBiTopInt=iBit*iRadix+iBiTopInt;
            iRadix=iRadix*2;
        return iBiTopInt;
        
        
class PMotionLookupTable:
    def __init__(self):
        self.m_arItem=[];

    def LoadLookupTable(self, strBiTopStatePath, strDirectoryPath):
        self.m_arItem=[];
        fileBiTopState=file(strBiTopStatePath, 'r');
        fileDirectory=file(strDirectoryPath, 'r');
        while True:
            lineBiTopState=fileBiTopState.readline();
            lineDirectory=fileDirectory.readline();
            if lineBiTopState=="" or lineDirectory=="":
                break;
            
            item=PMotionLookupItem();
            arLineDirectory=lineDirectory.split("\n");#get rid of "\r\n"
            item.m_strBvhName=arLineDirectory[0];#lineDirectory;
            arBiTopStateStr=lineBiTopState.split(",");
            iTopNum=len(arBiTopStateStr);
            for i in range(0,iTopNum):
                itembit=int(arBiTopStateStr[i]);
                item.m_arBiTopState.append(itembit);
            self.m_arItem.append(item);
        #verify            
        print "table size:", len(self.m_arItem), "items";

    def LookupMotion(self, iKeyInt):
        arLookupResult=[];
        iItemLen=len(self.m_arItem);
        iMinDistance=10000000;
        for i in range(0,iItemLen):
            item=self.m_arItem[i];
            iDistance=item.GetDistance(iKeyInt);
            itemResult=PMotionLookupResultItem();        
            itemResult.m_strBvhName=item.m_strBvhName;
            itemResult.m_arBiTopState=item.m_arBiTopState;
            itemResult.m_iTableIdx=i;
            itemResult.m_iDifferentBitNum=iDistance;
            if iDistance < iMinDistance:
                iMinDistance=iDistance;
                arLookupResult=[];
                arLookupResult.append(itemResult);
            elif iDistance == iMinDistance:
                arLookupResult.append(itemResult);
        return arLookupResult;

    #flip max iDistRange bits to check neighboring results
    def LookupMotionNear(self, iKeyInt, iDistRange):
        arLookupResult=[];
        iItemLen=len(self.m_arItem);
        for i in range(0,iItemLen):
            item=self.m_arItem[i];
            iDistance=item.GetDistance(iKeyInt);
            itemResult=PMotionLookupResultItem();        
            itemResult.m_strBvhName=item.m_strBvhName;
            itemResult.m_arBiTopState=item.m_arBiTopState;
            itemResult.m_iTableIdx=i;
            itemResult.m_iDifferentBitNum=iDistance;
            if iDistance <= iDistRange:
                arLookupResult.append(itemResult);
        return arLookupResult;

    def PlotAllTopInt(self):
        iItemLen=len(self.m_arItem);
        for i in range(0,iItemLen):
            item=self.m_arItem[i];
            print item.GetBiTopInt();        
            
        
def test():
    table=PMotionLookupTable();
    table.LoadLookupTable(r"E:\research\multimodality\experiments\5.optimize training\result\leftlimb\formaya\lookup\leftlimbOptimizationResult1.mat.bitop",\
                      r"E:\research\multimodality\experiments\5.optimize training\result\leftlimb\formaya\lookup\bvhDirectoryTestdata.cleanbvh");
    iTestKey=15618376389652713894;
    arResult=table.LookupMotion(iTestKey);
    #arResult=table.LookupMotionNear(iTestKey, 10);    
    iResultLen=len(arResult);
    print 'the motion close to bi-sequence ',bin(iTestKey), 'is:';
    for i in range(0,iResultLen):
        itemResult=arResult[i];
        print itemResult.m_iTableIdx, itemResult.m_strBvhName, itemResult.m_arBiTopState, itemResult.m_iDifferentBitNum;
    #table.PlotAllTopInt();

def test2():
    str1=bin(15618376389652713894);
    str1=str1[2:];
    strLine='1,1,0,1,1,0,0,0,1,0,1,1,1,1,1,1,1,0,0,1,1,1,1,0,1,0,0,1,0,0,1,1,1,0,1,0,0,0,0,1,1,0,0,1,1,0,0,1,0,0,0,1,0,0,0,1,1,0,1,0,0,1,1,0';
    arLine=strLine.split(',');
    str2='';
    for i in range(0,len(arLine)):
        str2=str2+arLine[i];
    print str1;
    print str2;

def test3():
    #strPathBase=raw_input("Please specify the base path:\r\n");
    #strNum=raw_input("Which training configuration do you want to use?(a number from 1~15)\r\n");
    strPathBase=r'E:\research\multimodality\experiments\5.optimize training\result\leftlimb\formaya';
    strNum='1';
    table=PMotionLookupTable();
    strBiTopPath=strPathBase+r'\lookup\leftlimbOptimizationResult'+str(strNum)+r'.mat.bitop';
    strDirectoryPath=strPathBase+r'\lookup\bvhDirectoryTestdata.cleanbvh';
    print 'table construction:', strBiTopPath, strDirectoryPath;
    table.LoadLookupTable(strBiTopPath,strDirectoryPath);
    print 'bi-top in integer:';
    table.PlotAllTopInt();
    strBiTopInt=raw_input("Please specify the motion bi-top in integer you want to lookup:\r\n");
    iBiTopInt=int(strBiTopInt);
    arResult=table.LookupMotion(iBiTopInt);
    iResultLen=len(arResult);
    print 'totally', iResultLen, 'results are:';
    for i in range(0,iResultLen):
        itemResult=arResult[i];
        print 'No.',i,'index',itemResult.m_iTableIdx,itemResult.m_strBvhName,'distance',itemResult.m_iDifferentBitNum,itemResult.m_arBiTopState; 

test3();
