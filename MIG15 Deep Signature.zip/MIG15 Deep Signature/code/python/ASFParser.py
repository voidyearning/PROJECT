__author__ = 'wangyi'
import math;
class PASFRoot:
    def __init__(self):
        self.m_arOrder=[];
        self.m_strAxis='';
        self.m_fPosX=0;
        self.m_fPosY=0;
        self.m_fPosZ=0;
        self.m_fOrtX=0;
        self.m_fOrtY=0;
        self.m_fOrtZ=0;
        
class PASFDOF:
    def __init__(self):
        self.m_strDOF="";
        self.m_fLimitMin=0;
        self.m_fLimitMax=0;
        
class PASFJoint:
    def __init__(self):
        self.m_iId=-1;
        self.m_strName='';
        self.m_fDirectionX=0;
        self.m_fDirectionY=0;
        self.m_fDirectionZ=0;
        self.m_fLength=0;
        self.m_strAxis="";
        self.m_fAxisX=0;
        self.m_fAxisY=0;
        self.m_fAxisZ=0;
        self.m_arDOF=[];
        self.m_strParentName='';
        self.m_bEnd=True;

class PASFData:
    def __init__(self):
        self.m_root=PASFRoot();
        self.m_dicJoint={};
        self.m_fMass=1.0;
        self.m_fLength=1;
        self.m_strAngle="deg";
        self.m_strDoc="";
        self.m_strHierarchy='';

    def Reset(self):
        self.m_root=PASFRoot();
        self.m_dicJoint={};
        self.m_fMass=1.0;
        self.m_fLength=1;
        self.m_strAngle="deg";
        self.m_strDoc="";
        self.m_strHierarchy='';

    def ParseUnits(self, arLines, iCur):
        while True:
            strLine=arLines[iCur];
            strLine=strLine.strip();
            if strLine.startswith(':units'):
                iCur=iCur+1;
                continue;
            arWords=strLine.split(' ');
            if arWords[0].startswith('mass'):
                self.m_fMass=float(arWords[1]);
            elif arWords[0].startswith('length'):
                self.m_fLength=float(arWords[1]);
            elif arWords[0].startswith('angle'):
                 self.m_strAngle=arWords[1];
            elif arWords[0].startswith(':'):
                return iCur;
            iCur = iCur+1;
            
    def ParseDoc(self, arLines, iCur):
        m_strDoc="";
        while True:
            strLine=arLines[iCur];
            strLine=strLine.strip();
            if strLine.startswith(':documentation'):
                iCur = iCur+1;
                continue;            
            if strLine.startswith(':'):
                return iCur;            
            self.m_strDoc=self.m_strDoc+strLine+'\r\n';
            iCur=iCur+1;

    def ParseRoot(self, arLines, iCur):
        self.m_root=PASFRoot();
        while True:
            strLine=arLines[iCur];
            strLine=strLine.strip();
            if strLine.startswith(':root'):
                iCur=iCur+1;
                continue;
            if strLine.startswith(':'):
                return iCur;
            arWords=strLine.split(' ');
            if arWords[0].startswith('order'):
                self.m_root.m_arOrder=arWords[1:];
            if arWords[0].startswith('axis'):
                self.m_root.m_strAxis=arWords[1];
            if arWords[0].startswith('position'):
                self.m_root.m_fPosX=float(arWords[1]);
                self.m_root.m_fPosY=float(arWords[2]);
                self.m_root.m_fPosZ=float(arWords[3]);
            if arWords[0].startswith('orientation'):
                self.m_root.m_fOrtX=float(arWords[1]);
                self.m_root.m_fOrtY=float(arWords[2]);
                self.m_root.m_fOrtZ=float(arWords[3]);
            iCur=iCur+1;

    def ParseJoint(self, arLines, iCur):
        joint=PASFJoint();
        while True:
            strLine=arLines[iCur];
            strLine=strLine.strip();
            if strLine.startswith('begin'):
                iCur=iCur+1;
                continue;
            if strLine.startswith('end'):
                self.m_dicJoint[joint.m_strName]=joint;
                return iCur;
            arWords=strLine.split(' ');
            if arWords[0].startswith('id'):
                joint.m_iId=int(arWords[1]);
            if arWords[0].startswith('name'):
                joint.m_strName=arWords[1];
            if arWords[0].startswith('direction'):
                joint.m_fDirectionX=float(arWords[1]);
                joint.m_fDirectionY=float(arWords[2]);
                joint.m_fDirectionZ=float(arWords[3]);
            if arWords[0].startswith('length'):
                joint.m_fLength=float(arWords[1]);
            if arWords[0].startswith('axis'):
                joint.m_fAxisX=float(arWords[1]);
                joint.m_fAxisY=float(arWords[2]);
                joint.m_fAxisZ=float(arWords[3]);
                joint.m_strAxis=arWords[-1];
            if arWords[0].startswith('dof'):
                for d in arWords[1:]:
                    dof=PASFDOF();
                    dof.m_strDOF=d;
                    joint.m_arDOF.append(dof);
            if arWords[0].startswith('limits'):
                strMin=arWords[1][1:];
                strMax=arWords[2][:-1];
                d=0;
                while True:
                    joint.m_arDOF[d].m_fLimitMin=float(strMin);
                    joint.m_arDOF[d].m_fLimitMax=float(strMax);
                    d=d+1;
                    iCur=iCur+1;
                    strLine=arLines[iCur];
                    strLine=strLine.strip();
                    if strLine.startswith('end'):
                        iCur=iCur-1;
                        break;
                    arWords=strLine.split(' ');
                    strMin=arWords[0][1:];
                    strMax=arWords[1][:-1];
            iCur=iCur+1;
        
    def ParseBonedata(self, arLines, iCur):
        while True:
            strLine=arLines[iCur];
            strLine=strLine.strip();
            if strLine.startswith(':bonedata'):
                iCur=iCur+1;
                continue;
            if strLine.startswith(':'):
                return iCur;
            arWords=strLine.split(' ');
            while arWords[0].startswith('begin'):
                iCur=self.ParseJoint(arLines, iCur);
                iCur=iCur+1;
                strLine=arLines[iCur];
                strLine=strLine.strip();
                arWords=strLine.split(' ');
            else:
                iCur=iCur-1;
            iCur=iCur+1;

    def ParseHierarchy(self, arLines, iCur):
        self.m_strHierarchy='';
        strLine=arLines[iCur];
        strLine=strLine.strip();
        if strLine.startswith(':hierarchy'):
            iCur=iCur+1;
            strLine=arLines[iCur];
            strLine=strLine.strip();
        if strLine.startswith('begin'):
            iCur=iCur+1;
            strLine=arLines[iCur];
            strLine=strLine.strip();
        while not strLine.startswith('end'):
            self.m_strHierarchy=self.m_strHierarchy+strLine+'\r\n';
            arWords=strLine.split(' ');
            strParentName=arWords[0];
            if strParentName.find('root')<=-1:
                self.m_dicJoint[strParentName].m_bEnd=False;
            for strChildName in arWords[1:]:
                self.m_dicJoint[strChildName].m_strParentName=strParentName;
            iCur=iCur+1;
            strLine=arLines[iCur];
            strLine=strLine.strip();
        else:
            return iCur;

    def ParseASF(self, strASF):
        arLines=strASF.splitlines();
        length=len(arLines);
        i=0;
        while i< length:
            strLine=arLines[i];
            strLine=strLine.strip();
            if strLine.startswith(':units'):
                i=self.ParseUnits(arLines, i);
                strLine=arLines[i];
                strLine=strLine.strip();
            if strLine.startswith(':documentation'):
                i=self.ParseDoc(arLines, i);
                strLine=arLines[i];
                strLine=strLine.strip();
            if strLine.startswith(':root'):
                i=self.ParseRoot(arLines, i);
                strLine=arLines[i];
                strLine=strLine.strip();
            if strLine.startswith(':bonedata'):
                i=self.ParseBonedata(arLines, i);
                strLine=arLines[i];
                strLine=strLine.strip();
            if strLine.startswith(':hierarchy'):
                i=self.ParseHierarchy(arLines, i);
            i=i+1;

    def ParseFile(self,strASFPath):
        asfFile=file(strASFPath, 'r');
        strASF=asfFile.read();                
        self.ParseASF(strASF);

def test():
    strASFPath=r'C:\wangyi\research\CMUDB\01.asf';
    asfData=PASFData();
    asfData.Reset();
    asfData.ParseFile(strASFPath);

#test();
