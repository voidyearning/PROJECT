class PPhase:
    def __init__(self):
        self.m_fStart=0;
        self.m_fEnd=0;
        self.m_strType="";
        self.m_strTrajectory=""
        self.m_iNum=1;
        self.m_bComplex=False;

    def PopulateFromLine(self, strLine):
        arLineItem = strLine.split(" ");
        self.m_fStart=float(arLineItem[0]);
        self.m_fEnd=float(arLineItem[1]);
        self.m_strType=arLineItem[2];
        self.m_strTrajectory=arLineItem[3];
        self.m_iNum=int(arLineItem[4]);
        self.m_bComplex=(arLineItem[5]=="true");

class PPhaseFile:
    def __init__(self):
        self.m_arPhase=[];
        self.m_fOffset=0;
        self.m_strComment="";

    def GetMajorPhase(self,fTimeStart,fTimeEnd):
        phaseResult=PPhase();
        phaseResult.m_fStart=99999999;
        phaseResult.m_fEnd=0;
        iPhaseCount=len(self.m_arPhase);
        for i in range(0,iPhaseCount):
            item=self.m_arPhase[i];
            if item.m_fStart>=fTimeStart and \
               item.m_fStart<=fTimeEnd and \
               item.m_fEnd>=fTimeStart and \
               item.m_fEnd<=fTimeEnd and \
               item.m_fStart<item.m_fEnd and \
               (item.m_strType=="stroke" or item.m_strType=="hold"):
                phaseResult.m_fStart=min(phaseResult.m_fStart,item.m_fStart); 
                phaseResult.m_fEnd=max(phaseResult.m_fEnd,item.m_fEnd);
                phaseResult.m_strType=phaseResult.m_strType+item.m_strType;
        return phaseResult;
            

    def LoadFromFile(self, strPath):
        self.m_arPhase=[];
        self.m_fOffset=0;
        self.m_strComment="";
        phaseFile=file(strPath, 'r');
        while True:
            line=phaseFile.readline();
            if line=="":
                break;
            arLineItem=line.split(" ");
            if arLineItem[0]=="TimeOffset":
                self.m_fOffset=float(arLineItem[1]);
            elif arLineItem[0].isalpha():
                self.m_strComment=self.m_strComment+line;
            else:
                onePhase=PPhase();
                onePhase.PopulateFromLine(line);
                self.m_arPhase.append(onePhase);

def Test():
    #lets test if it is working
    strPath = r"E:\research\multimodality\gestureDB\shakes_angry3_v3.phase";
    #raw_input("Please indicate the phrase file:\r\n");
    phaseFile = PPhaseFile();
    phaseFile.LoadFromFile(strPath);
    iPhaseNum=len(phaseFile.m_arPhase);
    for i in range(0,iPhaseNum):
        item=phaseFile.m_arPhase[i];
        print item.m_fStart,item.m_fEnd,item.m_strType,item.m_strTrajectory,item.m_iNum,item.m_bComplex;
