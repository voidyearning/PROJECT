import os
import fileinput
#PMotionLookup=========================================================
class PMotionLookupResultItem:
    def __init__(self):
        self.m_strBvhName='';
        self.m_arBiTopState=[];
        self.m_iDifferentBitNum=0;
        self.m_iTableIdx=-1;
        
class PMotionLookupItem:
    def __init__(self):
        self.m_strBvhName='';
        self.m_arBiTopState=[];

    def GetDistance(self, iTarget):
        iDifferentBitNum=0;
        strTarget=bin(iTarget);
        strTarget=strTarget[2:];#cut the 0b
        iTargetBitNum=len(strTarget);
        iItemBitNum=len(self.m_arBiTopState);
        if iItemBitNum==0:
            return iDifferentBitNum;
        for i in range(0, iItemBitNum):
            #compare from low to high(right to left)
            iItemCursor=(iItemBitNum-1)-i;
            iItemBit=self.m_arBiTopState[iItemCursor];
            if i < iTargetBitNum:
                iTargetCursor=(iTargetBitNum-1)-i;
                iTargetBit=int(strTarget[iTargetCursor]);
            else:
                iTargetBit=0;
            if iTargetBit!=iItemBit:
                iDifferentBitNum=iDifferentBitNum+1;
        return iDifferentBitNum;

    def GetBiTopInt(self):
        iBiTopInt=0;        
        iRadix=1;
        iBiTopLen=len(self.m_arBiTopState);
        for i in range(0,iBiTopLen):
            iCursor=(iBiTopLen-1)-i;
            iBit=self.m_arBiTopState[iCursor];
            iBiTopInt=iBit*iRadix+iBiTopInt;
            iRadix=iRadix*2;
        return iBiTopInt;
        
        
class PMotionLookupTable:
    def __init__(self):
        self.m_arItem=[];

    def LoadLookupTable(self, strBiTopStatePath, strDirectoryPath):
        self.m_arItem=[];
        fileBiTopState=file(strBiTopStatePath, 'r');
        fileDirectory=file(strDirectoryPath, 'r');
        while True:
            lineBiTopState=fileBiTopState.readline();
            lineDirectory=fileDirectory.readline();
            if lineBiTopState=="" or lineDirectory=="":
                break;
            
            item=PMotionLookupItem();
            arLineDirectory=lineDirectory.split("\n");#get rid of "\r\n"
            lineDirectory=arLineDirectory[0];
            arLineDirectory=lineDirectory.split("\r");
            item.m_strBvhName=arLineDirectory[0];#lineDirectory;
            
            arBiTopStateStr=lineBiTopState.split(",");
            iTopNum=len(arBiTopStateStr);
            for i in range(0,iTopNum):
                itembit=int(arBiTopStateStr[i]);
                item.m_arBiTopState.append(itembit);
            self.m_arItem.append(item);
        #verify            
        print "table size:", len(self.m_arItem), "items";

    def LookupMotion(self, iKeyInt):
        arLookupResult=[];
        iItemLen=len(self.m_arItem);
        iMinDistance=10000000;
        for i in range(0,iItemLen):
            item=self.m_arItem[i];
            iDistance=item.GetDistance(iKeyInt);
            itemResult=PMotionLookupResultItem();        
            itemResult.m_strBvhName=item.m_strBvhName;
            itemResult.m_arBiTopState=item.m_arBiTopState;
            itemResult.m_iTableIdx=i;
            itemResult.m_iDifferentBitNum=iDistance;
            if iDistance < iMinDistance:
                iMinDistance=iDistance;
                arLookupResult=[];
                arLookupResult.append(itemResult);
            elif iDistance == iMinDistance:
                arLookupResult.append(itemResult);
        return arLookupResult;

    #flip max iDistRange bits to check neighboring results
    def LookupMotionNear(self, iKeyInt, iDistRange):
        arLookupResult=[];
        iItemLen=len(self.m_arItem);
        for i in range(0,iItemLen):
            item=self.m_arItem[i];
            iDistance=item.GetDistance(iKeyInt);
            itemResult=PMotionLookupResultItem();        
            itemResult.m_strBvhName=item.m_strBvhName;
            itemResult.m_arBiTopState=item.m_arBiTopState;
            itemResult.m_iTableIdx=i;
            itemResult.m_iDifferentBitNum=iDistance;
            if iDistance <= iDistRange:
                arLookupResult.append(itemResult);
        return arLookupResult;

    def LookupMotionOfDist(self, iKeyInt, iDistance):
        arLookupResult=[];
        iItemLen=len(self.m_arItem);
        for i in range(0,iItemLen):
            item=self.m_arItem[i];
            itemDist=item.GetDistance(iKeyInt);
            itemResult=PMotionLookupResultItem();        
            itemResult.m_strBvhName=item.m_strBvhName;
            itemResult.m_arBiTopState=item.m_arBiTopState;
            itemResult.m_iTableIdx=i;
            itemResult.m_iDifferentBitNum=itemDist;
            if itemDist == iDistance:
                arLookupResult.append(itemResult);
        return arLookupResult;
    
    def LookupMotionKNearest(self, iKeyInt, iK):
        arLookupResult=[];
        iDistance=0;
        while len(arLookupResult) < iK:
            arLookupResult.extend(self.LookupMotionOfDist(iKeyInt,iDistance));
            iDistance=iDistance+1;
        return arLookupResult;
    
    def PlotAllTopInt(self):
        iItemLen=len(self.m_arItem);
        for i in range(0,iItemLen):
            item=self.m_arItem[i];
            print item.GetBiTopInt();

    def LookupAllKNearest(self,iK,fileLog):
        for item in self.m_arItem:
            iBiTopInt=item.GetBiTopInt();
            arResult=self.LookupMotionKNearest(iBiTopInt,iK);
            iResultLen=len(arResult);
            strResultLine="";
            for i in range(0,iK):
                resultItem=arResult[i];
                strResultLine=strResultLine+str(resultItem.m_iTableIdx)+" ";
            strResultLine=strResultLine+"\r\n";
            fileLog.write(strResultLine);
            
        
            #show all the results in one maya scene, may need a large memory
def DemoResultAll():
    #strPathBase=raw_input("Please specify the base path:\r\n");
    #strNum=raw_input("Which training configuration do you want to use?(a number from 1~15)\r\n");
    strPathBase=r'E:\research\multimodality\experiments\6.trajectory\result\formaya';
    strNum='6';
    table=PMotionLookupTable();
    strBiTopPath=strPathBase+r'\lookup\leftlimbtrOptimizationResult'+str(strNum)+r'.mat.bitop';
    strDirectoryPath=strPathBase+r'\lookup\bvhDirectoryTestdata.cleanbvh';
    fileResultLog=file(strPathBase+r'\scene\leftlimbtr'+strNum+'.all.log','w');
    print 'table construction:', strBiTopPath, strDirectoryPath;
    table.LoadLookupTable(strBiTopPath,strDirectoryPath);
    #print 'bi-top in integer:';
    #table.PlotAllTopInt();

    table.LookupAllKNearest(10,fileResultLog);
    fileResultLog.close();
    print 'log done!';

DemoResultAll();
