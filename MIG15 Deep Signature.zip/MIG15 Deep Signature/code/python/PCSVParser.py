class PCSVLine:
    def __init__(self):
        self.m_arData = [];

    def PopulateFromLine(self, strLine, strSep):
        self.m_arData = [];
        lineData = strLine.split(strSep);
        iDataCount = len(lineData);
        for i in range(0, iDataCount):
            self.m_arData.append(float(lineData[i]));

    def GetLine(self, strSep):
        iDataCount = len(self.m_arData);
        strLine = "";
        for i in range(0, iDataCount):
            strLine += str(self.m_arData[i]);
            if i < iDataCount -1:
                strLine += strSep;
        return strLine;

class PCSV:
    def __init__(self):
        self.m_arLine = [];

    def LoadFromFile(self, strPath):
        csvFile = file(strPath, 'r');
        while True:
            line = csvFile.readline();
            if line == "":
                break;
            else:
                csvLine = PCSVLine();
                csvLine.PopulateFromLine(line, ",");
                self.m_arLine.append(csvLine);

    def SaveToFile(self, strPath):
        csvFile = file(strPath, 'w');
        iLineCount = len(self.m_arLine);
        for i in range(0, iLineCount):
            csvLine = self.m_arLine[i];
            csvFile.write(csvLine.GetLine(","));
            csvFile.write("\r\n");
        csvFile.close();
	
    def ExportToFile(self, strPath):
        csvFile = file(strPath, 'w');
        iLineCount = len(self.m_arLine);
        for i in range(0, iLineCount):
            csvLine = self.m_arLine[i];
            csvFile.write(csvLine.GetLine(" "));
            csvFile.write("\r\n");
        csvFile.close();


    #for large frame, the string would be too long and be truncated by python
    def SaveToFile2(self, strPath):
        csvFile = file(strPath, 'w');
        iLineCount = len(self.m_arLine);
        for i in range(0, iLineCount):
            csvLine = self.m_arLine[i];
            iDataCount = len(csvLine.m_arData);
            for j in range(0, iDataCount):
                csvFile.write(str(csvLine.m_arData[j]));
                csvFile.write(" ");
            csvFile.write("\r\n");
        csvFile.close();	

    def PlotAll(self):
        iLineCount=len(self.m_arLine);
        for i in range(0,iLineCount):
            csvLine=self.m_arLine[i];
            strLine=csvLine.GetLine(" ");
            print strLine;
        print "total line count:", str(iLineCount);

    def GetSubClip(self, iStartIdx, iEndIdx):
        clipSub = PCSV();
        for i in range(iStartIdx, iEndIdx+1):
            clipSub.m_arLine.append(self.m_arLine[i]);
        return clipSub;
        
def Test():
    csv=PCSV();
    strPath=r'E:\research\multimodality\experiments\6.trajectory\data\synced\ShakesTired2_FingerSkel.synced.rightlimb.tr';
    csv.LoadFromFile(strPath);
    csv.PlotAll();

#Test();
