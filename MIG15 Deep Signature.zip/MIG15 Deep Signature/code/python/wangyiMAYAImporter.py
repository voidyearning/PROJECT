__author__ = 'wangyi'

import sys
sys.path.append(r'C:\wangyi\research\multimodality\asf amc maya importer')
import wangyiASFParser;
import wangyiAMCParser;
import os;
import math;
import maya.cmds as mc;

def testLoad():
    modelASF=wangyiASFParser.PASFData();
    modelASF.ParseFile(r'C:\wangyi\research\CMUDB\ASF\18.asf');
    ConstructASFSkeletonInMaya(modelASF,'c18');

    clipAMC=wangyiAMCParser.PAMCClip();
    clipAMC.LoadFromFile(r'C:\wangyi\research\CMUDB\18_01.amc');
    ImportAMCClipInMaya(clipAMC, 'c18',True,100,100);


def ConstructASFSkeletonInMaya(modelASF, strPrefix):
    #1.create root
    mc.group(empty=True, name=strPrefix, world=True);
    mc.select(strPrefix, r=True);
    mc.joint(name=strPrefix+'_root',\
             position=(modelASF.m_root.m_fPosX,modelASF.m_root.m_fPosY,modelASF.m_root.m_fPosZ),\
             relative = True,\
             orientation=(modelASF.m_root.m_fOrtX,modelASF.m_root.m_fOrtY,modelASF.m_root.m_fOrtZ),\
             rotationOrder=modelASF.m_root.m_strAxis,\
             sc=False,\
             dof='xyz');
    arLines=modelASF.m_strHierarchy.splitlines();
    for strLine in arLines:
        strLine=strLine.strip();
        if strLine=='':
            break;
        arWords=strLine.split(' ');
        strJointParentName=arWords[0];
        jointParent=wangyiASFParser.PASFJoint();
        bParentRoot=False;
        if strJointParentName.find('root')>-1:
            bParentRoot=True;
        else:
            jointParent=modelASF.m_dicJoint[strJointParentName];
         #calculate relative position
        if bParentRoot or jointParent.m_fLength==0:
            posX=0;
            posY=0;
            posZ=0;
        else:
            fLengthDirect=math.sqrt(jointParent.m_fDirectionX*jointParent.m_fDirectionX+\
                                jointParent.m_fDirectionY*jointParent.m_fDirectionY+\
                                jointParent.m_fDirectionZ*jointParent.m_fDirectionZ);
            posX=jointParent.m_fLength * jointParent.m_fDirectionX / fLengthDirect;
            posY=jointParent.m_fLength * jointParent.m_fDirectionY / fLengthDirect;
            posZ=jointParent.m_fLength * jointParent.m_fDirectionZ / fLengthDirect;

        #change to ws
        wsOrt=[];
        if bParentRoot:
            posX=modelASF.m_root.m_fPosX;
            posY=modelASF.m_root.m_fPosY;
            posZ=modelASF.m_root.m_fPosZ;
            wsOrt.append(modelASF.m_root.m_fOrtX);
            wsOrt.append(modelASF.m_root.m_fOrtY);
            wsOrt.append(modelASF.m_root.m_fOrtZ);
        else:
            wsPos=mc.xform(strPrefix+'_'+strJointParentName,query=True,translation=True,ws=True);
            wsOrt=mc.xform(strPrefix+'_'+strJointParentName,query=True,ro=True,ws=True);
            posX=posX+wsPos[0];
            posY=posY+wsPos[1];
            posZ=posZ+wsPos[2];

        for strJointName in arWords[1:]:
            jointChild=modelASF.m_dicJoint[strJointName];
            #calculate dof
            strDof='';
            for dof in jointChild.m_arDOF:
                if dof.m_strDOF.find('x')>-1 or dof.m_strDOF.find('X')>-1:
                    strDof=strDof+'x';
                if dof.m_strDOF.find('y')>-1 or dof.m_strDOF.find('Y')>-1:
                    strDof=strDof+'y';
                if dof.m_strDOF.find('z')>-1 or dof.m_strDOF.find('Z')>-1:
                    strDof=strDof+'z';

            mc.spaceLocator(name='wsLocatorParent',position=[0,0,0]);
            mc.setAttr('wsLocatorParent.rotate',wsOrt[0],wsOrt[1],wsOrt[2]);
            mc.spaceLocator(name='wsLocatorChild',position=[0,0,0]);
            mc.setAttr('wsLocatorChild.rotate',jointChild.m_fAxisX,jointChild.m_fAxisY,jointChild.m_fAxisZ);
            mc.parent('wsLocatorChild','wsLocatorParent');
            ortX=mc.getAttr('wsLocatorChild.rx');
            ortY=mc.getAttr('wsLocatorChild.ry');
            ortZ=mc.getAttr('wsLocatorChild.rz');
            mc.delete('wsLocatorChild');
            mc.delete('wsLocatorParent');

            mc.select(strPrefix+'_'+strJointParentName,r=True);
            mc.joint( name = strPrefix+'_'+strJointName,\
                      position = (posX,posY,posZ), \
                      absolute = True,\
                      orientation=(ortX,ortY,ortZ),\
                      rotationOrder = jointChild.m_strAxis, \
                      sc=False,\
                      dof = strDof);

            #create a end point
            if jointChild.m_bEnd:
                fLengthDirectEnd=math.sqrt(jointChild.m_fDirectionX*jointChild.m_fDirectionX+\
                                jointChild.m_fDirectionY*jointChild.m_fDirectionY+\
                                jointChild.m_fDirectionZ*jointChild.m_fDirectionZ);
                posEndX=jointChild.m_fLength * jointChild.m_fDirectionX / fLengthDirectEnd;
                posEndY=jointChild.m_fLength * jointChild.m_fDirectionY / fLengthDirectEnd;
                posEndZ=jointChild.m_fLength * jointChild.m_fDirectionZ / fLengthDirectEnd;
                wsPos=mc.xform(strPrefix+'_'+strJointName,query=True,translation=True,ws=True);
                posEndX=posEndX+wsPos[0];
                posEndY=posEndY+wsPos[1];
                posEndZ=posEndZ+wsPos[2];

                mc.select(strPrefix+'_'+strJointName);
                strEndName=strPrefix+'_'+strJointName+'_end';
                mc.joint(name=strEndName, \
                         position=(posEndX, posEndY, posEndZ),\
                         absolute=True,\
                         sc=False,\
                         dof='');



def ImportAMCFrameInMaya(frmAMC,strPrefix, i,bFixedLoc=False, tx=0, tz=0):
    if bFixedLoc:
        mc.setKeyframe(strPrefix+'_root', at='tx', time=i+1, value=tx);
        mc.setKeyframe(strPrefix+'_root', at='tz', time=i+1, value=tz);
    else:
        mc.setKeyframe(strPrefix+'_root', at='tx', time=i+1, value=tx+frmAMC.m_root1);
        mc.setKeyframe(strPrefix+'_root', at='tz', time=i+1, value=tz+frmAMC.m_root3);

    mc.setKeyframe(strPrefix+'_root', at='ty', time=i+1, value=frmAMC.m_root2);
    mc.setKeyframe(strPrefix+'_root', at='rx', time=i+1, value=frmAMC.m_root4);
    mc.setKeyframe(strPrefix+'_root', at='ry', time=i+1, value=frmAMC.m_root5);
    mc.setKeyframe(strPrefix+'_root', at='rz', time=i+1, value=frmAMC.m_root6);

    mc.setKeyframe(strPrefix+'_lowerback', at='rx', time=i+1, value=frmAMC.m_lowerback1);
    mc.setKeyframe(strPrefix+'_lowerback', at='ry', time=i+1, value=frmAMC.m_lowerback2);
    mc.setKeyframe(strPrefix+'_lowerback', at='rz', time=i+1, value=frmAMC.m_lowerback3);

    mc.setKeyframe(strPrefix+'_upperback', at='rx', time=i+1, value=frmAMC.m_upperback1);
    mc.setKeyframe(strPrefix+'_upperback', at='ry', time=i+1, value=frmAMC.m_upperback2);
    mc.setKeyframe(strPrefix+'_upperback', at='rz', time=i+1, value=frmAMC.m_upperback3);

    mc.setKeyframe(strPrefix+'_thorax', at='rx', time=i+1, value=frmAMC.m_thorax1);
    mc.setKeyframe(strPrefix+'_thorax', at='ry', time=i+1, value=frmAMC.m_thorax2);
    mc.setKeyframe(strPrefix+'_thorax', at='rz', time=i+1, value=frmAMC.m_thorax3);

    mc.setKeyframe(strPrefix+'_lowerneck', at='rx', time=i+1, value=frmAMC.m_lowerneck1);
    mc.setKeyframe(strPrefix+'_lowerneck', at='ry', time=i+1, value=frmAMC.m_lowerneck2);
    mc.setKeyframe(strPrefix+'_lowerneck', at='rz', time=i+1, value=frmAMC.m_lowerneck3);

    mc.setKeyframe(strPrefix+'_upperneck', at='rx', time=i+1, value=frmAMC.m_upperneck1);
    mc.setKeyframe(strPrefix+'_upperneck', at='ry', time=i+1, value=frmAMC.m_upperneck2);
    mc.setKeyframe(strPrefix+'_upperneck', at='rz', time=i+1, value=frmAMC.m_upperneck3);

    mc.setKeyframe(strPrefix+'_head', at='rx', time=i+1, value=frmAMC.m_head1);
    mc.setKeyframe(strPrefix+'_head', at='ry', time=i+1, value=frmAMC.m_head2);
    mc.setKeyframe(strPrefix+'_head', at='rz', time=i+1, value=frmAMC.m_head3);

    mc.setKeyframe(strPrefix+'_rclavicle', at='ry', time=i+1, value=frmAMC.m_rclavicle1);
    mc.setKeyframe(strPrefix+'_rclavicle', at='rz', time=i+1, value=frmAMC.m_rclavicle2);

    mc.setKeyframe(strPrefix+'_rhumerus', at='rx', time=i+1, value=frmAMC.m_rhumerus1);
    mc.setKeyframe(strPrefix+'_rhumerus', at='ry', time=i+1, value=frmAMC.m_rhumerus2);
    mc.setKeyframe(strPrefix+'_rhumerus', at='rz', time=i+1, value=frmAMC.m_rhumerus3);

    mc.setKeyframe(strPrefix+'_rradius', at='rx', time=i+1, value=frmAMC.m_rradius);

    mc.setKeyframe(strPrefix+'_rwrist', at='ry', time=i+1, value=frmAMC.m_rwrist);

    mc.setKeyframe(strPrefix+'_rhand', at='rx', time=i+1, value=frmAMC.m_rhand1);
    mc.setKeyframe(strPrefix+'_rhand', at='rz', time=i+1, value=frmAMC.m_rhand2);

    mc.setKeyframe(strPrefix+'_rfingers', at='rx', time=i+1, value=frmAMC.m_rfingers);

    mc.setKeyframe(strPrefix+'_rthumb', at='rx', time=i+1, value=frmAMC.m_rthumb1);
    mc.setKeyframe(strPrefix+'_rthumb', at='rz', time=i+1, value=frmAMC.m_rthumb2);

    mc.setKeyframe(strPrefix+'_lclavicle', at='ry', time=i+1, value=frmAMC.m_lclavicle1);
    mc.setKeyframe(strPrefix+'_lclavicle', at='rz', time=i+1, value=frmAMC.m_lclavicle2);

    mc.setKeyframe(strPrefix+'_lhumerus', at='rx', time=i+1, value=frmAMC.m_lhumerus1);
    mc.setKeyframe(strPrefix+'_lhumerus', at='ry', time=i+1, value=frmAMC.m_lhumerus2);
    mc.setKeyframe(strPrefix+'_lhumerus', at='rz', time=i+1, value=frmAMC.m_lhumerus3);

    mc.setKeyframe(strPrefix+'_lradius', at='rx', time=i+1, value=frmAMC.m_lradius);

    mc.setKeyframe(strPrefix+'_lwrist', at='ry', time=i+1, value=frmAMC.m_lwrist);

    mc.setKeyframe(strPrefix+'_lhand', at='rx', time=i+1, value=frmAMC.m_lhand1);
    mc.setKeyframe(strPrefix+'_lhand', at='rz', time=i+1, value=frmAMC.m_lhand2);

    mc.setKeyframe(strPrefix+'_lfingers', at='rx', time=i+1, value=frmAMC.m_lfingers);

    mc.setKeyframe(strPrefix+'_lthumb', at='rx', time=i+1, value=frmAMC.m_lthumb1);
    mc.setKeyframe(strPrefix+'_lthumb', at='rz', time=i+1, value=frmAMC.m_lthumb2);

    mc.setKeyframe(strPrefix+'_rfemur', at='rx', time=i+1, value=frmAMC.m_rfemur1);
    mc.setKeyframe(strPrefix+'_rfemur', at='ry', time=i+1, value=frmAMC.m_rfemur2);
    mc.setKeyframe(strPrefix+'_rfemur', at='rz', time=i+1, value=frmAMC.m_rfemur3);

    mc.setKeyframe(strPrefix+'_rtibia', at='rx', time=i+1, value=frmAMC.m_rtibia);

    mc.setKeyframe(strPrefix+'_rfoot', at='rx', time=i+1, value=frmAMC.m_rfoot1);
    mc.setKeyframe(strPrefix+'_rfoot', at='rz', time=i+1, value=frmAMC.m_rfoot2);

    mc.setKeyframe(strPrefix+'_rtoes', at='rx', time=i+1, value=frmAMC.m_rtoes);

    mc.setKeyframe(strPrefix+'_lfemur', at='rx', time=i+1, value=frmAMC.m_lfemur1);
    mc.setKeyframe(strPrefix+'_lfemur', at='ry', time=i+1, value=frmAMC.m_lfemur2);
    mc.setKeyframe(strPrefix+'_lfemur', at='rz', time=i+1, value=frmAMC.m_lfemur3);

    mc.setKeyframe(strPrefix+'_ltibia', at='rx', time=i+1, value=frmAMC.m_ltibia);

    mc.setKeyframe(strPrefix+'_lfoot', at='rx', time=i+1, value=frmAMC.m_lfoot1);
    mc.setKeyframe(strPrefix+'_lfoot', at='rz', time=i+1, value=frmAMC.m_lfoot2);

    mc.setKeyframe(strPrefix+'_ltoes', at='rx', time=i+1, value=frmAMC.m_ltoes);

def ImportAMCClipInMaya(clipAMC,strPrefix, bFixedLoc=False, tx=0, tz=0):
    iFrameNum=len(clipAMC.m_arFrame);
    for i in range(0,iFrameNum):
        frmAMC=clipAMC.m_arFrame[i];
        ImportAMCFrameInMaya(frmAMC, strPrefix, i, bFixedLoc, tx, tz);

testLoad();

