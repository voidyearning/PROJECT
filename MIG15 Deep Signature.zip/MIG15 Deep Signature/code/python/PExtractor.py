import math
import PBVHParser as bvh
import PPhraseParser as phr
import PPhaseParser as ph
import PCSVParser as csv

def TimeToFrameNum(fTime, fTimePerFrame, bStart):
    iFrameNum=0;
    if fTime<0:
        return iFrameNum;
    if fTimePerFrame<=0:
        return iFrameNum;
    if bStart:
        iFrameNum=math.ceil(fTime/fTimePerFrame);
    else:
        iFrameNum=math.floor(fTime/fTimePerFrame);    
    return iFrameNum;

def ExtractBodypartsFromBvh(subClip,strSubPath):
    #subClip.ExportLeftLimb(strSubPath+".leftLimb");
    #subClip.ExportRightLimb(strSubPath+".rightLimb");
    #subClip.ExportLimbs(strSubPath+".limbs");
    #subClip.ExportLowerBody(strSubPath+".lowerbody");
    #subClip.ExportHead(strSubPath+".head");
    subClip.SaveToFile(strSubPath+".bvh");

def Test1():
    #lets do some test first
    print 'we are here';
    strPath = r"E:\research\multimodality\gestureDB\shakes_tired2_v4.phrase";
    phraseFile = phr.PPhraseFile();
    phraseFile.LoadFromFile(strPath);
    iPhraseNum=len(phraseFile.m_arPhrase);
    for i in range(0,iPhraseNum):
        item=phraseFile.m_arPhrase[i];
        iFrameNumStart=TimeToFrameNum(item.m_fStart+phraseFile.m_fOffset,0.008333,True);
        iFrameNumEnd=TimeToFrameNum(item.m_fEnd+phraseFile.m_fOffset,0.008333,False);
        print "phrase",i,item.m_strLexeme,item.m_strHandness,":",iFrameNumStart,iFrameNumEnd;

    strPath = r"E:\research\multimodality\gestureDB\shakes_tired2_v4.phase";
    phaseFile = ph.PPhaseFile();
    phaseFile.LoadFromFile(strPath);
    iPhaseNum=len(phaseFile.m_arPhase);
    for i in range(0,iPhaseNum):
        item=phaseFile.m_arPhase[i];
        iFrameNumStart=TimeToFrameNum(item.m_fStart+phraseFile.m_fOffset,0.008333,True);
        iFrameNumEnd=TimeToFrameNum(item.m_fEnd+phraseFile.m_fOffset,0.008333,False);
        print "phase",i,":",iFrameNumStart,iFrameNumEnd;

def Test2(iWholeStartFrame,iWholeEndFrame):
    strBvhPath=r"E:\research\multimodality\gestureDB\cleanbvh\ShakesTired2_FingerSkel.bvh.clean.bvh";
    bvhClip=bvh.PBVHClip();
    bvhClip.LoadFromFile(strBvhPath);

    strPhrasePath=r"E:\research\multimodality\gestureDB\shakes_tired2_v4.phrase";
    phraseFile=phr.PPhraseFile();
    phraseFile.LoadFromFile(strPhrasePath);
    
    strPhasePath=r"E:\research\multimodality\gestureDB\shakes_tired2_v4.phase";
    phaseFile=ph.PPhaseFile();
    phaseFile.LoadFromFile(strPhasePath);
    
    bvhIdleClip=bvh.PBVHClip();
    bvhIdleClip.m_strHeader=bvhClip.m_strHeader;
    bvhIdleClip.m_fFrameTime=bvhClip.m_fFrameTime;

    #export phrases
    iPhraseNum=len(phraseFile.m_arPhrase);
    iID=0;
    iPhraseEndFrame=iWholeStartFrame;#949;
    for i in range(0,iPhraseNum):
        phraseItem=phraseFile.m_arPhrase[i];
        iPhraseStartFrame=TimeToFrameNum(phraseItem.m_fStart+phraseFile.m_fOffset,bvhClip.m_fFrameTime,True);
        #idle from (iPhraseEndFrame+1)~(iPhraseStartFrame-1)
        if (iPhraseEndFrame+1)<(iPhraseStartFrame-1):
            subClip=bvhClip.GetSubClip(iPhraseEndFrame+1,iPhraseStartFrame-1);
            bvhIdleClip.m_arFrame.extend(subClip.m_arFrame);
            strSubPath=strBvhPath+"."+str(int(i))+"."+str(int(iID))+".idle.2H."+str(int(iPhraseEndFrame+1))+"."+str(int(iPhraseStartFrame-1));
            #========================ExtractBodypartsFromBvh(subClip,strSubPath);
            iID=iID+1;            
        #gesture phrase
        iPhraseEndFrame=TimeToFrameNum(phraseItem.m_fEnd+phraseFile.m_fOffset,bvhClip.m_fFrameTime,False);
        subClip=bvhClip.GetSubClip(iPhraseStartFrame,iPhraseEndFrame);
        strSubPath=strBvhPath+"."+str(int(i))+"."+str(int(iID))+"."+phraseItem.m_strLexeme+"."+phraseItem.m_strHandness+"."+str(int(iPhraseStartFrame))+"."+str(int(iPhraseEndFrame));
        #========================ExtractBodypartsFromBvh(subClip,strSubPath);
        #stroke phase of the phrase
        phaseItem=phaseFile.GetMajorPhase(phraseItem.m_fStart,phraseItem.m_fEnd);
        if phaseItem.m_fStart>=phaseItem.m_fEnd:
            continue;
        iPhaseStartFrame=TimeToFrameNum(phaseItem.m_fStart+phraseFile.m_fOffset,bvhClip.m_fFrameTime,True);
        iPhaseEndFrame=TimeToFrameNum(phaseItem.m_fEnd+phraseFile.m_fOffset,bvhClip.m_fFrameTime,False);
        subClip=bvhClip.GetSubClip(iPhaseStartFrame,iPhaseEndFrame);
        strSubPath=strBvhPath+"."+str(int(i))+"."+str(int(iID))+"."+phraseItem.m_strLexeme+"."+phaseItem.m_strType+"."+phraseItem.m_strHandness+"."+str(int(iPhaseStartFrame))+"."+str(int(iPhaseEndFrame));
        ExtractBodypartsFromBvh(subClip,strSubPath);        
        iID=iID+1;
    else:#for loop is over, check the last idle
        subClip=bvhClip.GetSubClip(iPhraseEndFrame+1,iWholeEndFrame);
        bvhIdleClip.m_arFrame.extend(subClip.m_arFrame);
        strSubPath=strBvhPath+"."+str(int(i))+"."+str(int(iID))+".idle.2H."+str(int(iPhraseEndFrame+1))+"."+str(int(iWholeEndFrame));
        #========================ExtractBodypartsFromBvh(subClip,strSubPath);
    #========================bvhIdleClip.SaveToFile(strBvhPath+".idle.bvh");

def Test3(iWholeStartFrame,iWholeEndFrame):
    strBaseName=r"E:\research\multimodality\gestureDB\syncedtr\ShakesTired2_FingerSkel.bvh.clean.bvh";
    
    strTRPath_l=r"E:\research\multimodality\gestureDB\syncedtr\ShakesTired2_FingerSkel.synced.leftlimbtr";
    csvClip_l=csv.PCSV();
    csvClip_l.LoadFromFile(strTRPath_l);

    strTRPath_r=r"E:\research\multimodality\gestureDB\syncedtr\ShakesTired2_FingerSkel.synced.rightlimbtr";
    csvClip_r=csv.PCSV();
    csvClip_r.LoadFromFile(strTRPath_r);

    strPhrasePath=r"E:\research\multimodality\gestureDB\shakes_tired2_v4.phrase";
    phraseFile=phr.PPhraseFile();
    phraseFile.LoadFromFile(strPhrasePath);
    
    strPhasePath=r"E:\research\multimodality\gestureDB\shakes_tired2_v4.phase";
    phaseFile=ph.PPhaseFile();
    phaseFile.LoadFromFile(strPhasePath);
    
    #export phrases
    iPhraseNum=len(phraseFile.m_arPhrase);
    iID=0;
    iPhraseEndFrame=iWholeStartFrame;#949;
    for i in range(0,iPhraseNum):
        phraseItem=phraseFile.m_arPhrase[i];
        iPhraseStartFrame=TimeToFrameNum(phraseItem.m_fStart+phraseFile.m_fOffset,0.008333,True);
        #idle from last end(iPhraseEndFrame+1)~ current start(iPhraseStartFrame-1)
        if (iPhraseEndFrame+1)<(iPhraseStartFrame-1):
            subClip_l=csvClip_l.GetSubClip(iPhraseEndFrame+1,iPhraseStartFrame-1);
            subClip_r=csvClip_r.GetSubClip(iPhraseEndFrame+1,iPhraseStartFrame-1);
            strSubPath=strBaseName+"."+str(int(i))+"."+str(int(iID))+".idle.2H."+str(int(iPhraseEndFrame+1))+"."+str(int(iPhraseStartFrame-1));
            #subClip_l.ExportToFile(strSubPath+".leftlimbtr");
            #subClip_r.ExportToFile(strSubPath+".rightlimbtr");
            iID=iID+1;            
        #gesture phrase
        iPhraseEndFrame=TimeToFrameNum(phraseItem.m_fEnd+phraseFile.m_fOffset,0.008333,False);
        subClip_l=csvClip_l.GetSubClip(iPhraseStartFrame,iPhraseEndFrame);
        subClip_r=csvClip_r.GetSubClip(iPhraseStartFrame,iPhraseEndFrame);
        strSubPath=strBaseName+"."+str(int(i))+"."+str(int(iID))+"."+phraseItem.m_strLexeme+"."+phraseItem.m_strHandness+"."+str(int(iPhraseStartFrame))+"."+str(int(iPhraseEndFrame));
        #subClip_l.ExportToFile(strSubPath+".leftlimbtr");
        #subClip_r.ExportToFile(strSubPath+".rightlimbtr");
        #stroke phase of the phrase
        phaseItem=phaseFile.GetMajorPhase(phraseItem.m_fStart,phraseItem.m_fEnd);
        if phaseItem.m_fStart>=phaseItem.m_fEnd:
            continue;
        iPhaseStartFrame=TimeToFrameNum(phaseItem.m_fStart+phraseFile.m_fOffset,0.008333,True);
        iPhaseEndFrame=TimeToFrameNum(phaseItem.m_fEnd+phraseFile.m_fOffset,0.008333,False);
        subClip_l=csvClip_l.GetSubClip(iPhaseStartFrame,iPhaseEndFrame);
        subClip_r=csvClip_r.GetSubClip(iPhaseStartFrame,iPhaseEndFrame);
        strSubPath=strBaseName+"."+str(int(i))+"."+str(int(iID))+"."+phraseItem.m_strLexeme+"."+phaseItem.m_strType+"."+phraseItem.m_strHandness+"."+str(int(iPhaseStartFrame))+"."+str(int(iPhaseEndFrame));
        subClip_l.ExportToFile(strSubPath+".leftlimbtr");
        subClip_r.ExportToFile(strSubPath+".rightlimbtr");
        iID=iID+1;
    else:#for loop is over, check the last idle
        subClip_l=csvClip_l.GetSubClip(iPhraseEndFrame+1,iWholeEndFrame);
        subClip_r=csvClip_r.GetSubClip(iPhraseEndFrame+1,iWholeEndFrame);
        strSubPath=strBaseName+"."+str(int(i))+"."+str(int(iID))+".idle.2H."+str(int(iPhraseEndFrame+1))+"."+str(int(iWholeEndFrame));
        #subClip_l.ExportToFile(strSubPath+".leftlimbtr");
        #subClip_r.ExportToFile(strSubPath+".rightlimbtr");
        
#Test3(1144,10709);#angry3
Test3(949,13410);#tired       
#strBvhPath=raw_input("Main Bvh Path:\r\n");
#strPhrasePath=raw_input("phRase Path:\r\n");
#strPhasePath=raw_input("phase Path:\r\n");

#bvhClip=PBVHClip();
#bvhClip.LoadFromFile(strBvhPath);
#phraseFile=PPhraseFile();
#phraseFile.LoadFromFile(strPhrasePath);
#phaseFile=PPhaseFile();
#phaseFile.LoadFromFile(strPhasePath);



#userInput = raw_input("please indicate the subclip B-E:\r\n");
#subClipList = [];

#while userInput != "q":
#    index = userInput.split("-");
#    iStartIdx = int(index[0]);
#    iEndIdx = int(index[1]);
#    subClip = amcClip.GetSubClip(iStartIdx/4, iEndIdx/4);
#    subClip.SaveToFile(strPathRoot + userInput + ".amc");
    #export body part
#    subClip.ExportLeftLimb(strPathRoot + userInput + ".leftLimb");
#    subClip.ExportRightLimb(strPathRoot + userInput + ".rightLimb");
#    subClip.ExportLowerBody(strPathRoot + userInput + ".lowerBody");
    #next sub clip
#    userInput = raw_input("please indicate the subclip B,E:\r\n");
    
#amcClip.SaveToFile("c:\\wangyi\\test.amc");
