import os 
class PBVHFrame:
    def __init__(self):
        self.m_iDOFNum = 92;
        self.m_arData = [];

    def PopulateFromLine(self, strLine):
        self.m_arData = [];
        arData = strLine.split(" ");
        iDataCount = len(arData);
        if iDataCount > self.m_iDOFNum:
            iDataCount = self.m_iDOFNum;            
        for i in range(0, iDataCount):
            self.m_arData.append(float(arData[i]));
        
    def GetLine(self):
        strLine = "";
        iDataCount = len(self.m_arData);
        for i in range(0, iDataCount):
            strLine += str(self.m_arData[i]);
            if i < iDataCount-1:
                strLine += " ";
        return strLine;            

    def GetLeftLimb(self):#18~26
        strLine = "";
        for i in range(18, 27):
            strLine += str(self.m_arData[i]);
            if i < 26:
                strLine += " ";
        return strLine;

    def GetRightLimb(self):#48~56
        strLine = "";
        for i in range(48, 57):
            strLine += str(self.m_arData[i]);
            if i < 56:
                strLine += " ";
        return strLine;

    def GetBothLimbs(self):#leftlimb+rightlimb
        strLine="";
        for i in range(18,27):
            strLine+=str(self.m_arData[i]);
            strLine+=" ";
        for i in range(48,57):
            strLine+=str(self.m_arData[i]);
            if i < 56:
                strLine+=" ";
        return strLine;

    def GetLowerBody(self):#78~91
        strLine = "";
        for i in range(78, 92):
            strLine += str(self.m_arData[i]);
            if i < 91:
                strLine += " ";
        return strLine;

    def GetHead(self):#12~17
        strLine = "";
        for i in range(12, 18):
            strLine += str(self.m_arData[i]);
            if i < 17:
                strLine += " ";
        return strLine;
        
    
class PBVHClip:
    def __init__(self):
        self.m_arFrame = [];
        self.m_strHeader = "";
        self.m_fFrameTime = 0;
        self.m_iFrameCount = 0;        

    def LoadFromFile(self, strPath):
        self.m_arFrame = [];
        bvhFile = file(strPath, 'r');
        bData = False;
        while True:
            line = bvhFile.readline();
            if line == "":
                break;
            if bData==False:
                if line.startswith("Frames"):
                    frameCount = line.split(":");
                    self.m_iFrameCount = int(frameCount[1]);
                elif line.startswith("Frame Time"):
                    frameTime = line.split(":");
                    self.m_fFrameTime = float(frameTime[1]);
                    bData = True;
                else:
                    self.m_strHeader += line;
            else:
                bvhFrame = PBVHFrame();
                bvhFrame.PopulateFromLine(line);
                self.m_arFrame.append(bvhFrame);
            
    def SaveToFile(self, strPath):
        bvhFile = file(strPath, 'w');
        bvhFile.write(self.m_strHeader);
        bvhFile.write("Frames: "+str(int(self.m_iFrameCount))+"\r\n");
        bvhFile.write("Frame Time: "+str(self.m_fFrameTime)+"\r\n");
        iFrameCount = self.m_iFrameCount;#len(self.m_arFrame);
        for i in range(0, iFrameCount):
            bvhFrame = self.m_arFrame[i];
            line = bvhFrame.GetLine();
            bvhFile.write(line);
            bvhFile.write("\r\n");
        bvhFile.close();

    def GetSubClip(self, iStartIdx, iEndIdx):
        clipSub = PBVHClip();
        clipSub.m_strHeader=self.m_strHeader;
        clipSub.m_iFrameCount=iEndIdx-iStartIdx+1;
        clipSub.m_fFrameTime=self.m_fFrameTime;
        for i in range(iStartIdx, iEndIdx+1):
            clipSub.m_arFrame.append(self.m_arFrame[i]);
        return clipSub;

    def ExportLeftLimb(self, strPath):
        limbFile = file(strPath, 'w');
        iFrameCount = len(self.m_arFrame);
        for i in range(0, iFrameCount):
            frameBVH = self.m_arFrame[i];
            strLeftLimb = frameBVH.GetLeftLimb()
            limbFile.write(strLeftLimb);
            limbFile.write("\r\n");
        limbFile.close();


    def ExportRightLimb(self, strPath):
        limbFile = file(strPath, 'w');
        iFrameCount = len(self.m_arFrame);
        for i in range(0, iFrameCount):
            frameBVH = self.m_arFrame[i];
            strRightLimb = frameBVH.GetRightLimb();
            limbFile.write(strRightLimb);
            limbFile.write("\r\n");
        limbFile.close();

    def ExportLimbs(self, strPath):
        bothLimbFile=file(strPath,'w');
        iFrameCount=len(self.m_arFrame);
        for i in range(0,iFrameCount):
            frameBVH=self.m_arFrame[i];
            strBothLimb=frameBVH.GetBothLimbs();
            bothLimbFile.write(strBothLimb);
            bothLimbFile.write("\r\n");
        bothLimbFile.close();

    def ExportLowerBody(self, strPath):
        lowerbodyFile = file(strPath, 'w');
        iFrameCount = len(self.m_arFrame);
        for i in range(0, iFrameCount):
            frameBVH = self.m_arFrame[i];
            strLowerBody = frameBVH.GetLowerBody()
            lowerbodyFile.write(strLowerBody);
            lowerbodyFile.write("\r\n");
        lowerbodyFile.close();

    def ExportHead(self, strPath):
        headFile = file(strPath, 'w');
        iFrameCount = len(self.m_arFrame);
        for i in range(0, iFrameCount):
            frameBVH = self.m_arFrame[i];
            strHead = frameBVH.GetHead();
            headFile.write(strHead);
            headFile.write("\r\n");
        headFile.close();

def Test1():
    #let me do some cleanup work first
    strFolder = raw_input("Please indicate the bvh folder:\r\n");
    for root,dirs,files in os.walk(strFolder):
        for f in files:
            if f.find('.bvh')==-1:
                print 'not bvh',f;
                continue;
            strFilePath = root + "\\" + f;
            bvhClip = PBVHClip();
            bvhClip.LoadFromFile(strFilePath);
            bvhClip.SaveToFile(strFilePath + ".clean.bvh");
            bvhClip.ExportLeftLimb(strFilePath + ".leftlimb");
            bvhClip.ExportRightLimb(strFilePath + ".rightlimb");
            bvhClip.ExportLowerBody(strFilePath + ".lowerbody");
            bvhClip.ExportHead(strFilePath + ".head");

def Test2():
    #let's extract some subbvhclip
    strPath=r"E:\research\multimodality\gestureDB\cleanbvh\ShakesTired2_FingerSkel.bvh.clean.bvh";
    bvhClip=PBVHClip();
    bvhClip.LoadFromFile(strPath);
    subClip=bvhClip.GetSubClip(1046,1161);
    subClip.SaveToFile(strPath+".1046-1161.bvh");




