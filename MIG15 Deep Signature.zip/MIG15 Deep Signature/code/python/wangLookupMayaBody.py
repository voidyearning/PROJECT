import os
import fileinput
import maya.cmds as mc
#PMotionLookup=========================================================
class PMotionLookupResultItem:
    def __init__(self):
        self.m_strBvhName='';
        self.m_arBiTopState=[];
        self.m_iDifferentBitNum=0;
        self.m_iTableIdx=-1;
        
class PMotionLookupItem:
    def __init__(self):
        self.m_strBvhName='';
        self.m_arBiTopState=[];

    def GetDistance(self, iTarget):
        iDifferentBitNum=0;
        strTarget=bin(iTarget);
        strTarget=strTarget[2:];#cut the 0b
        iTargetBitNum=len(strTarget);
        iItemBitNum=len(self.m_arBiTopState);
        if iItemBitNum==0:
            return iDifferentBitNum;
        for i in range(0, iItemBitNum):
            #compare from low to high(right to left)
            iItemCursor=(iItemBitNum-1)-i;
            iItemBit=self.m_arBiTopState[iItemCursor];
            if i < iTargetBitNum:
                iTargetCursor=(iTargetBitNum-1)-i;
                iTargetBit=int(strTarget[iTargetCursor]);
            else:
                iTargetBit=0;
            if iTargetBit!=iItemBit:
                iDifferentBitNum=iDifferentBitNum+1;
        return iDifferentBitNum;

    def GetBiTopInt(self):
        iBiTopInt=0;        
        iRadix=1;
        iBiTopLen=len(self.m_arBiTopState);
        for i in range(0,iBiTopLen):
            iCursor=(iBiTopLen-1)-i;
            iBit=self.m_arBiTopState[iCursor];
            iBiTopInt=iBit*iRadix+iBiTopInt;
            iRadix=iRadix*2;
        return iBiTopInt;
        
        
class PMotionLookupTable:
    def __init__(self):
        self.m_arItem=[];

    def LoadLookupTable(self, strBiTopStatePath, strDirectoryPath):
        self.m_arItem=[];
        fileBiTopState=file(strBiTopStatePath, 'r');
        fileDirectory=file(strDirectoryPath, 'r');
        while True:
            lineBiTopState=fileBiTopState.readline();
            lineDirectory=fileDirectory.readline();
            if lineBiTopState=="" or lineDirectory=="":
                break;
            
            item=PMotionLookupItem();
            arLineDirectory=lineDirectory.split("\n");#get rid of "\r\n"
            lineDirectory=arLineDirectory[0];
            arLineDirectory=lineDirectory.split("\r");
            item.m_strBvhName=arLineDirectory[0];#lineDirectory;
            
            arBiTopStateStr=lineBiTopState.split(",");
            iTopNum=len(arBiTopStateStr);
            for i in range(0,iTopNum):
                itembit=int(arBiTopStateStr[i]);
                item.m_arBiTopState.append(itembit);
            self.m_arItem.append(item);
        #verify            
        print "table size:", len(self.m_arItem), "items";

    def LookupMotion(self, iKeyInt):
        arLookupResult=[];
        iItemLen=len(self.m_arItem);
        iMinDistance=10000000;
        for i in range(0,iItemLen):
            item=self.m_arItem[i];
            iDistance=item.GetDistance(iKeyInt);
            itemResult=PMotionLookupResultItem();        
            itemResult.m_strBvhName=item.m_strBvhName;
            itemResult.m_arBiTopState=item.m_arBiTopState;
            itemResult.m_iTableIdx=i;
            itemResult.m_iDifferentBitNum=iDistance;
            if iDistance < iMinDistance:
                iMinDistance=iDistance;
                arLookupResult=[];
                arLookupResult.append(itemResult);
            elif iDistance == iMinDistance:
                arLookupResult.append(itemResult);
        return arLookupResult;

    #flip max iDistRange bits to check neighboring results
    def LookupMotionNear(self, iKeyInt, iDistRange):
        arLookupResult=[];
        iItemLen=len(self.m_arItem);
        for i in range(0,iItemLen):
            item=self.m_arItem[i];
            iDistance=item.GetDistance(iKeyInt);
            itemResult=PMotionLookupResultItem();        
            itemResult.m_strBvhName=item.m_strBvhName;
            itemResult.m_arBiTopState=item.m_arBiTopState;
            itemResult.m_iTableIdx=i;
            itemResult.m_iDifferentBitNum=iDistance;
            if iDistance <= iDistRange:
                arLookupResult.append(itemResult);
        return arLookupResult;

    def LookupMotionOfDist(self, iKeyInt, iDistance):
        arLookupResult=[];
        iItemLen=len(self.m_arItem);
        for i in range(0,iItemLen):
            item=self.m_arItem[i];
            itemDist=item.GetDistance(iKeyInt);
            itemResult=PMotionLookupResultItem();        
            itemResult.m_strBvhName=item.m_strBvhName;
            itemResult.m_arBiTopState=item.m_arBiTopState;
            itemResult.m_iTableIdx=i;
            itemResult.m_iDifferentBitNum=itemDist;
            if itemDist == iDistance:
                arLookupResult.append(itemResult);
        return arLookupResult;
    
    def LookupMotionKNearest(self, iKeyInt, iK):
        arLookupResult=[];
        iDistance=0;
        while len(arLookupResult) < iK:
            arLookupResult.extend(self.LookupMotionOfDist(iKeyInt,iDistance));
            iDistance=iDistance+1;
        return arLookupResult;
    
    def PlotAllTopInt(self):
        iItemLen=len(self.m_arItem);
        for i in range(0,iItemLen):
            item=self.m_arItem[i];
            print item.GetBiTopInt();
            
class BVHData:
	def __init__(self):
		# the names of the joints
		self.jointNames = []
		# the parent index for each joint
		self.jointParents = []
		# a 3 tuple containing the joint offset
		self.jointOffset = []
		# the rotational degrees of freedom for this joint
		self.rotDOF = []
		# the rotation order of this joint
		#note that Maya uses fixed axes (i.e. the axes don't move, so an XYZ rotation
		#in a rotating frame bvh becomes an ZYX rotation in a fixed frame scheme)
		self.rotOrder = []
		# the names of all channels in the file
		self.channelNames = []
		# the current parent joint index
		self.parentStack = []
		# the current joint index
		self.currentJoint = -1
		# the number of frames
		self.numFrames = 0
		# the frames per second
		self.fps = 30
		# the actual frame data
		self.frames = []


	def reset(self):
		self.jointNames = []
		self.jointParents = []
		self.jointOffset = []
		self.rotDOF = []
		self.rotOrder = []
		self.channelNames = []
		self.parentStack = []
		self.numFrames = 0
		self.fps = 0
        	self.frames = 0

	def parseHierarchy(self, currentLine):
		ret = True
		words = self.processLine(currentLine)
		if(words[0] == "ROOT" or words[0] == "JOINT" or words[0] == "End"):
			# ignore the word Site after End in 'End Site <name>'
			if(words[0] == "End"):
				words.pop(1)

        		# get the joint name
			if(len(words) > 1):
				self.jointNames.append(words[1])
			else:
				self.jointNames.append('')

			# the joint parent
			if(len(self.parentStack) == 0):
				self.jointParents.append(-1)
			else:
				self.jointParents.append(self.parentStack[-1])
			self.currentJoint = len(self.jointNames) - 1
		elif(words[0] == '{'):
			self.parentStack.append(self.currentJoint)
		elif(words[0] == '}'):
			if(not len(self.rotDOF) == len(self.jointNames)):
				self.rotDOF.append('xyz')
				self.rotOrder.append('zyx')
			self.parentStack.pop()
		elif(words[0] == 'OFFSET'):
			self.jointOffset.append( \
					[float(words[1]), float(words[2]), float(words[3])] \
							)

		elif(words[0] == 'CHANNELS'):
			numChannels = int(words[1])
			if(len(words) - 2 == numChannels):
				ro = ''
				for c in words[2:]:
					if(c == 'Xrotation'):
						attr = 'rx'
						ro += 'x'
					elif(c == 'Yrotation'):
						attr = 'ry'
						ro += 'y'
					elif(c == 'Zrotation'):
						attr = 'rz'
						ro += 'z'
					elif(c == 'Xposition'):
						attr = 'tx'
					elif(c == 'Yposition'):
						attr = 'ty'
					elif(c == 'Zposition'):
						attr = 'tz'
					else:
						print 'Unknown channel type! ', c

					self.channelNames.append( \
							[self.jointNames[self.currentJoint], attr] \
							)
				self.rotDOF.append(ro)
				#print 'found rotations ', ro
				order = ''
				if(ro[0] == 'x'):
					if(len(ro) < 2):
						order = 'zyx'
					elif(ro[1] == 'y'):
						order = 'zyx'
					elif(ro[1] == 'z'):
						order = 'yzx'
				elif(ro[0] == 'y'):
					if(len(ro) < 2):
						order = 'zxy'
					elif(ro[1] == 'x'):
						order = 'zxy'
					elif(ro[1] == 'z'):
						order = 'xzy'
				elif(ro[0] == 'z'):
					if(len(ro) < 2):
						order = 'xyz'
					elif(ro[1] == 'x'):
						order = 'yxz'
					elif(ro[1] == 'y'):
						order = 'xyz'
				else:
					print 'Unrecognized channel order: ', ro
				self.rotOrder.append(order)
				#print 'joint order: ', order
			else:
				print 'Incorrect number of channels listed!'
		elif(words[0] == 'MOTION'):
			ret = False
		else:
			print 'Syntax Error on line ', currentLine
		return ret	

	# removes tabs and spurious characters from a line of input, and breaks
	# it up into tokens.
	def processLine(self, line):
		return filter(lambda x: not x == '', line.strip('\t\r\n').split(' '))
	    
	# parses the motion data and stores it.
	def parseMotion(self, line):
		words = self.processLine(line)
		if(words[0] == 'MOTION'):
			pass	# ignore this line, we're ok
		elif(words[0] == 'Frames:'):
			self.numFrames = int(words[1])
		elif(words[0] == 'Frame' and words[1] == 'Time:'):
			self.fps = int(1.0/float(words[2]))
		else:
			# must be a data frame.
			if(not len(words) == len(self.channelNames)):
				print 'Unrecognized line: ', line
			else:
				# convert to floats and store.
				try:
					flist = map(float, words)
				except ValueError:
					print 'Error converting values to float.'
					raise
				else:
					self.frames.append(flist)

# does the initial file parsing and returns the fileinput structure
# and the parsed hierarchy data.
def parseFile(filename):
	data = BVHData()
	f = fileinput.input(filename)
	# first line should be the HIERARCHY marcher.
	words = data.processLine(f.readline())
	if(not words[0] == 'HIERARCHY'):
		print 'Syntax error: does not appear to be a BVH file.'
		return
	else:
		# parse the hierarchy marker
		line = f.readline()
		keepGoing = data.parseHierarchy(line)

		while(keepGoing):
			line = f.readline()
			keepGoing = data.parseHierarchy(line)

		# now parse the motion data
		data.parseMotion(line)
		for line in f:
			data.parseMotion(line)
		f.close()
		return data

# builds the skeleton in maya given the parsed skeleton data.
def buildMayaSkeleton(bvh,prefix):
	# first, clear the selection.
	mc.select(cl=True)
	# create a transform node for the new hierarchy.
	mc.group(empty=True, name=prefix + 'bvhImport', world=True)
	# create the joints.
	for i in range(0, len(bvh.jointNames)):
		parent = ''
		if(bvh.jointParents[i] == -1):
			parent = prefix + 'bvhImport'
		else:
			parent = prefix + bvh.jointNames[bvh.jointParents[i]]
		# joint must be selected to become the parent.
		mc.select(parent, r=True)
		mc.joint( name = prefix + bvh.jointNames[i] \
				  , position = bvh.jointOffset[i] \
				  , relative = True \
				  , rotationOrder = bvh.rotOrder[i] \
				  , dof = bvh.rotDOF[i] \
				 )
		#get the joint IK position, draw stick connect these positions
		
# sets the key frames from the motion data
def applyFrameData(bvh,prefix):
	# for each frame
	for f in range(0, bvh.numFrames):
		ftime = f+1
		frame = bvh.frames[f]
		# for each channel
		for c in range(0, len(frame)):
			mc.setKeyframe( prefix+bvh.channelNames[c][0] \
						  , at = bvh.channelNames[c][1] \
						  , time = ftime \
						  , value = frame[c] \
					)


def loadBvhsForComparison():
    bvhFolder = raw_input("Please indicate the bvh folder:\r\n");
    iBvhCount = 0;
    for root,dirs,files in os.walk(bvhFolder):
        for f in files:
            if not f.endswith(".bvh"):
                continue;
            iBvhCount=iBvhCount+1;
            bvhPath=root+"\\"+f;
            bvh=parseFile(bvhPath);
            prefix = "w"+str(iBvhCount);
            buildMayaSkeleton(bvh, prefix);
            applyFrameData(bvh,prefix);
            #find a place for it
            iLineNum=(iBvhCount-1)/10;
            iLineOffset=(iBvhCount-1)%10;
            zbvh= - iLineNum;
            ybvh=0;
            xbvh=4-iLineOffset-0.5*((iLineNum)%2);
            #print bvhPath,"(", str(xbvh),",", str(ybvh),",", str(zbvh), ")";
            mc.select(prefix+"bvhImport",r=True);
            mc.move(xbvh,ybvh,zbvh);

def test():
    # the main script
    #filename = mc.fileDialog(directoryMask = '*.bvh')
    filename = r'E:\research\multimodality\gestureDB\cleanbvh\ShakesAngry3_FingerSkel.bvh.clean.bvh';
    if(not filename == ''):
	fileinput.close()
	bvh = parseFile(filename)
	buildMayaSkeleton(bvh, 'angry')
	applyFrameData(bvh,'angry')

    filename = r'E:\research\multimodality\gestureDB\cleanbvh\ShakesTired2_FingerSkel.bvh.clean.bvh';
    if(not filename == ''):
	fileinput.close()
	bvh = parseFile(filename)
	buildMayaSkeleton(bvh, 'tired')
	applyFrameData(bvh,'tired')

#loadBvhsForComparison();
            
def Visualize(strPath, arResult, xBase=0, yBase=0, zBase=0):
    iResultLen=len(arResult);
    iBvhCount=0;
    for i in range(0,iResultLen):
        iBvhCount=iBvhCount+1;
        item=arResult[i];
        bvhPath=strPath+'\\'+item.m_strBvhName;
        bvh=parseFile(bvhPath);
        prefix = "w"+str(iBvhCount);
        buildMayaSkeleton(bvh, prefix);
        applyFrameData(bvh,prefix);
        #find a place for it
        iLineNum=(iBvhCount-1)/10;
        iLineOffset=(iBvhCount-1)%10;
        zbvh= - iLineNum;
        ybvh=0;
        xbvh=4-iLineOffset-0.5*((iLineNum)%2);
        print bvhPath,"(", str(xbvh),",", str(ybvh),",", str(zbvh), ")";
        mc.select(prefix+"bvhImport",r=True);
        mc.move(xBase+xbvh,yBase+ybvh,zBase+zbvh);

def VisualizeBlock(strPath, arResult, countBase=0, xBase=0, yBase=0, zBase=0):
    iResultLen=len(arResult);
    iBvhCount=countBase;
    for i in range(0,iResultLen):
        iBvhCount=iBvhCount+1;
        item=arResult[i];
        bvhPath=strPath+'\\'+item.m_strBvhName;
        bvh=parseFile(bvhPath);
        prefix = "w"+str(iBvhCount);
        buildMayaSkeleton(bvh, prefix);
        applyFrameData(bvh,prefix);        
        #find a place for it
        iLineNum=(iBvhCount-countBase-1)/10;
        iLineOffset=(iBvhCount-countBase-1)%10;
        zbvh= - iLineNum;
        ybvh=0;
        xbvh=4-iLineOffset-0.5*((iLineNum)%2);
        print bvhPath,"(", str(xbvh),",", str(ybvh),",", str(zbvh), ")";
        mc.select(prefix+"bvhImport",r=True);
        mc.move(xBase+xbvh,yBase+ybvh,zBase+zbvh);
        
def Lookup():
    #strPathBase=raw_input("Please specify the base path:\r\n");
    #strNum=raw_input("Which training configuration do you want to use?(a number from 1~15)\r\n");
    strPathBase=r'E:\research\multimodality\experiments\6.trajectory\result\formaya';
    strNum='1';
    table=PMotionLookupTable();
    strBiTopPath=strPathBase+r'\lookup\leftlimbOptimizationResult'+str(strNum)+r'.mat.bitop';
    strDirectoryPath=strPathBase+r'\lookup\bvhDirectoryTestdata.cleanbvh';
    print 'table construction:', strBiTopPath, strDirectoryPath;
    table.LoadLookupTable(strBiTopPath,strDirectoryPath);
    print 'bi-top in integer:';
    table.PlotAllTopInt();
    #strBiTopInt=raw_input("Please specify the motion bi-top in integer you want to lookup:\r\n");
    strBiTopInt='12616174519356368756'#'13336609679774373324';
    iBiTopInt=int(strBiTopInt);
    arResult=table.LookupMotionKNearest(iBiTopInt,10);
    iResultLen=len(arResult);
    print 'totally', iResultLen, 'results are:';
    for i in range(0,iResultLen):
        itemResult=arResult[i];
        print 'No.',i,'index',itemResult.m_iTableIdx,itemResult.m_strBvhName,'distance',itemResult.m_iDifferentBitNum,itemResult.m_arBiTopState;
    strBvhPath=strPathBase+r'\db';
    Visualize(strBvhPath,arResult,100,100,100);

def LogResult(fileLog,arResult):
    iLen=len(arResult);
    for i in range(0,iLen):
        item=arResult[i];
        strLog=str(item.m_iTableIdx)+"."+item.m_strBvhName+":distance:"+str(item.m_iDifferentBitNum)+"\r\n";
        fileLog.write(strLog); 
    fileLog.write('\r\n');
    
#show all the results in one maya scene, may need a large memory
def DemoResultAll():
    #strPathBase=raw_input("Please specify the base path:\r\n");
    #strNum=raw_input("Which training configuration do you want to use?(a number from 1~15)\r\n");
    strPathBase=r'E:\research\multimodality\experiments\6.trajectory\result\formaya';
    strNum='1';
    table=PMotionLookupTable();
    strBiTopPath=strPathBase+r'\lookup\leftlimbOptimizationResult'+str(strNum)+r'.mat.bitop';
    strDirectoryPath=strPathBase+r'\lookup\bvhDirectoryTestdata.cleanbvh';
    fileResultLog=file(strPathBase+r'\scene\leftlimb'+strNum+'.all.log','w');
    print 'table construction:', strBiTopPath, strDirectoryPath;
    table.LoadLookupTable(strBiTopPath,strDirectoryPath);
    #print 'bi-top in integer:';
    #table.PlotAllTopInt();

    iTargetItemCount=0;
    countBase=0;
    for item in table.m_arItem:
        iBiTopInt=item.GetBiTopInt();
        arResult=table.LookupMotionKNearest(iBiTopInt,10);#find at least 10 closest to itself
        LogResult(fileResultLog,arResult);
        iResultLen=len(arResult);
        strBvhPath=strPathBase+r'\db';
        #basic block
        xBase=iTargetItemCount%10;
        xBase=xBase * 15;
        yBase=0;
        zBase=iTargetItemCount/10;
        zBase=zBase * 5;
        VisualizeBlock(strBvhPath,arResult,countBase,xBase,yBase,zBase);
        countBase+=iResultLen;
        iTargetItemCount+=1;
        #if iTargetItemCount > 10:
        #    break;
    fileResultLog.close();
    strScenePath=strPathBase+r'\scene\leftlimb'+strNum+'.all.mb';
    mc.file(rename=strScenePath);
    mc.file(save=True,type='mayaBinary');
 
 
#show all the results in one maya scene, may need a large memory
def DemoResultBatch():
    #clear all the joints
    #mc.select(all=True);
    #mc.delete();
    mc.file(f=True,new=True);
    #strPathBase=raw_input("Please specify the base path:\r\n");
    #strNum=raw_input("Which training configuration do you want to use?(a number from 1~15)\r\n");
    strPathBase=r'E:\research\multimodality\experiments\6.trajectory\result\formaya';
    strNum='15';
    table=PMotionLookupTable();
    strBiTopPath=strPathBase+r'\lookup\headOptimizationResult'+str(strNum)+r'.mat.bitop';
    strDirectoryPath=strPathBase+r'\lookup\bvhDirectoryTestdata.cleanbvh';
    strVizCursorPath=strPathBase+r'\lookup\vizCursor.txt';
    fileVizCursorRead=file(strVizCursorPath,'r');
    strCursor=fileVizCursorRead.readline();
    if strCursor=='':
        iStartId=0;
    else:
        iStartId=int(strCursor);
    fileVizCursorRead.close();
    fileResultLog=file(strPathBase+r'\scene\head'+strNum+'.'+str(iStartId)+'.log','w');
    #print 'table construction:', strBiTopPath, strDirectoryPath;
    table.LoadLookupTable(strBiTopPath,strDirectoryPath);
   
    iTargetItemCount=0;
    countBase=0;    
    print 'batch of 10 starting from ', str(iStartId);
    iItemLen=len(table.m_arItem);
    for i in range(iStartId,iItemLen):
        item=table.m_arItem[i];
        iBiTopInt=item.GetBiTopInt();
        arResult=table.LookupMotionKNearest(iBiTopInt,10);#find at least 10 closest to itself
        LogResult(fileResultLog,arResult);
        iResultLen=len(arResult);
        strBvhPath=strPathBase+r'\db';
        #basic block
        xBase=iTargetItemCount%2;
        xBase=xBase * 15;
        yBase=0;
        zBase=iTargetItemCount/2;
        xBase=xBase+(zBase%2)*5;#offset neighboring rows
        zBase=zBase * 5;
        VisualizeBlock(strBvhPath,arResult,countBase,xBase,yBase,zBase);
        countBase+=iResultLen;
        iTargetItemCount+=1;
        if iTargetItemCount >= 10:            
            fileVizCursorWrite=file(strVizCursorPath,'w');
            fileVizCursorWrite.write(str(i+1));
            fileVizCursorWrite.close();
            break;
    
    fileResultLog.close();
    print 'batch of 10 starting from ', str(iStartId);
    #save mb
    #strScenePath=strPathBase+r'\scene\lowerbody'+strNum+'.'+str(iStartId)+'.'+str(iStartId+iTargetItemCount-1)+'.mb';
    #mc.file(rename=strScenePath);
    #mc.file(save=True,type='mayaBinary');


def DemoResultCompare():
    #clear all the joints
    mc.file(f=True,new=True);
    strPathBase=r'E:\research\multimodality\experiments\6.trajectory\result\formaya';
    strDirectoryPath=strPathBase+r'\lookup\bvhDirectoryTestdata.cleanbvh';
    strVizCursorPath=strPathBase+r'\lookup\vizCursor.txt';
    fileVizCursorRead=file(strVizCursorPath,'r');
    strCursor=fileVizCursorRead.readline();
    if strCursor=='':
        iStartId=0;
    else:
        iStartId=int(strCursor);
    fileVizCursorRead.close();
    
    strBiTopPath1=strPathBase+r'\lookup\leftlimbOptimizationResult1'+r'.mat.bitop';
    table1=PMotionLookupTable();
    table1.LoadLookupTable(strBiTopPath1,strDirectoryPath);

    strBiTopPath2=strPathBase+r'\lookup\leftlimbOptimizationResult5'+r'.mat.bitop';
    table2=PMotionLookupTable();
    table2.LoadLookupTable(strBiTopPath2,strDirectoryPath);

    strBiTopPath3=strPathBase+r'\lookup\leftlimbOptimizationResult6'+r'.mat.bitop';
    table3=PMotionLookupTable();
    table3.LoadLookupTable(strBiTopPath3,strDirectoryPath);

    strBiTopPath4=strPathBase+r'\lookup\leftlimbtrOptimizationResult1'+r'.mat.bitop';
    table4=PMotionLookupTable();
    table4.LoadLookupTable(strBiTopPath4,strDirectoryPath);

    strBiTopPath5=strPathBase+r'\lookup\leftlimbtrOptimizationResult5'+r'.mat.bitop';
    table5=PMotionLookupTable();
    table5.LoadLookupTable(strBiTopPath5,strDirectoryPath);

    strBiTopPath6=strPathBase+r'\lookup\leftlimbtrOptimizationResult6'+r'.mat.bitop';
    table6=PMotionLookupTable();
    table6.LoadLookupTable(strBiTopPath6,strDirectoryPath);
   
    i=iStartId;    
    item1=table1.m_arItem[i];
    item2=table2.m_arItem[i];
    item3=table3.m_arItem[i];
    item4=table4.m_arItem[i];
    item5=table5.m_arItem[i];
    item6=table6.m_arItem[i];
        
    iBiTopInt1=item1.GetBiTopInt();
    iBiTopInt2=item2.GetBiTopInt();
    iBiTopInt3=item3.GetBiTopInt();
    iBiTopInt4=item4.GetBiTopInt();
    iBiTopInt5=item5.GetBiTopInt();
    iBiTopInt6=item6.GetBiTopInt();
        
    arResult1=table1.LookupMotionKNearest(iBiTopInt1,10)[0:10];
    arResult2=table2.LookupMotionKNearest(iBiTopInt2,10)[0:10];
    arResult3=table3.LookupMotionKNearest(iBiTopInt3,10)[0:10];
    arResult4=table4.LookupMotionKNearest(iBiTopInt4,10)[0:10];
    arResult5=table5.LookupMotionKNearest(iBiTopInt5,10)[0:10];
    arResult6=table6.LookupMotionKNearest(iBiTopInt6,10)[0:10];
        
    strBvhPath=strPathBase+r'\db';    
    countBase=0;
    VisualizeBlock(strBvhPath,arResult1,countBase,0,0,0);
    countBase+=len(arResult1);
    VisualizeBlock(strBvhPath,arResult2,countBase,0,0,5);
    countBase+=len(arResult2);
    VisualizeBlock(strBvhPath,arResult3,countBase,0,0,10);
    countBase+=len(arResult3);
    
    VisualizeBlock(strBvhPath,arResult4,countBase,12,0,0);
    countBase+=len(arResult4);
    VisualizeBlock(strBvhPath,arResult5,countBase,12,0,5);
    countBase+=len(arResult5);
    VisualizeBlock(strBvhPath,arResult6,countBase,12,0,10);
      
    print str(i), 'done!';   
    fileVizCursorWrite=file(strVizCursorPath,'w');
    fileVizCursorWrite.write(str(i+1));
    fileVizCursorWrite.close();

    #show all the results in one maya scene, may need a large memory
def DemoResultLowerbody():
    mc.file(f=True,new=True);
    strPathBase=r'E:\research\multimodality\experiments\xx\result\formaya';
    strNum='6';
    table=PMotionLookupTable();
    strBiTopPath=strPathBase+r'\lookup\lowerbodyOptimizationResult'+str(strNum)+r'.mat.bitop';
    strDirectoryPath=strPathBase+r'\lookup\bvhDirectoryTestdata.cleanbvh';
    table.LoadLookupTable(strBiTopPath,strDirectoryPath);

    listMustShow=[141,66,77,79,102,96,111,115,137,128];
    iTargetItemCount=0;
    countBase=0;    
    for i in listMustShow:
        item=table.m_arItem[i];
        iBiTopInt=item.GetBiTopInt();
        arResult=table.LookupMotionKNearest(iBiTopInt,10)[0:10];#find at least 10 closest to itself
        iResultLen=len(arResult);
        print "TARGET BITS:",item.m_arBiTopState,item.m_strBvhName;
        for j in range(0,iResultLen):
            resultItem=arResult[j];
            print j, "DIFF:",str(resultItem.m_iDifferentBitNum),"BITS:",resultItem.m_arBiTopState, resultItem.m_strBvhName;    
        strBvhPath=strPathBase+r'\db';
        #basic block
        xBase=iTargetItemCount%2;
        xBase=xBase * 15;
        yBase=0;
        zBase=iTargetItemCount/2;
        xBase=xBase+(zBase%2)*5;#offset neighboring rows
        zBase=zBase * 5;
        VisualizeBlock(strBvhPath,arResult,countBase,xBase,yBase,zBase);
        countBase+=iResultLen;
        iTargetItemCount+=1;
        if iTargetItemCount >= 15:
            break;
    
    
#Lookup();
#DemoResultBatch();
#DemoResultCompare();
DemoResultLowerbody();
