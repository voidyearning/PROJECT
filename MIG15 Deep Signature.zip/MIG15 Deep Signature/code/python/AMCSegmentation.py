__author__ = 'wangyi'

import sys
sys.path.append(r'K:\research\multimodality\asf amc maya importer')

import AMCParser;
import math;

class PVelocityFrame:
    def __init__(self):
        self.m_arVelocity=[];

    def __init__(self, arVelocity):
        self.m_arVelocity=arVelocity;

    def Add(self, velFrame):
        resultFrame=[];
        iLength=len(self.m_arVelocity);
        for i in range(0, iLength):
            resultFrame.append(self.m_arVelocity[i]+velFrame.m_arVelocity[i]);
        return resultFrame;

    def Div(self, iDenominator):
        resultFrame=[];
        iLength=len(self.m_arVelocity);
        for i in range(0, iLength):
            resultFrame.append(self.m_arVelocity[i]/iDenominator);
        return resultFrame;

    @classmethod
    def GetWeightFrame(cls):
        frmVelocityWeight=cls([]);
        frmVelocityWeight.m_arVelocity=[ 0,0,0,1,1,1, #root-6dofs-6\
                                         1,1,1, #lowerback-3dofs-9\
                                         1,1,1, #upperback-3dofs-12\
                                         1,1,1, #thorax-3dofs-15\
                                         0.1,0.1,0.1,#lowerneck-3dofs-18\
                                         0.1,0.1,0.1,#upperneck-3dofs-21\
                                         0.1,0.1,0.1,#head-3dofs-24\
                                         1,1,#rclavicle-2dofs-26\
                                         1,1,1,#rhumerus-3dofs-29\
                                         1,#rradius-1dof-30\
                                         0.01,#rwrist-1dof-31\
                                         0,0,#rhand-2dofs-33\
                                         0,#rfingers-1dof-34\
                                         0,0,#rthumb-2dofs-36\
                                         1,1,#lclavicle-2dofs-38\
                                         1,1,1,#lhumerus-3dofs-41\
                                         1,#lradius-1dof-42\
                                         0.01,#lwrist-1dof-43\
                                         0,0,#lhand-2dofs-45\
                                         0,#lfingers-1dof-46\
                                         0,0,#lthumb-2dofs-48\
                                         1,1,1,#rfemur-3dofs-51\
                                         1,#rtibia-1dof-52\
                                         0,0,#rfoot-2dofs-54\
                                         0,#rtoes-1dof-55\
                                         1,1,1,#lfemur-3dofs-58\
                                         1,#ltibia-1dof-59\
                                         0,0,#lfoot-2dofs-61\
                                         0];#ltoes-1dof-62
        return frmVelocityWeight;

    def GetWeightedVelocity(self):
        frmWeight=PVelocityFrame.GetWeightFrame();
        fVelSum=0;
        iDOFLen=len(self.m_arVelocity);
        for i in range(0, iDOFLen):
            fVel=frmWeight.m_arVelocity[i]*self.m_arVelocity[i];
            fVelSum=fVelSum+fVel;
        return fVelSum;

class PAMCSegmentation:
    def __init__(self):
        self.m_strAMCPath='';
        self.m_clipAMC=[];
        self.m_clipVel=[];

    def InitFromAMC(self, strAMCPath):
        self.m_strAMCPath=strAMCPath;
        self.m_clipAMC=AMCParser.PAMCClip();
        self.m_clipAMC.LoadFromFile(strAMCPath);
        self.PopulateVelocity();

    def Reset(self):
        self.m_strAMCPath='';
        self.m_clipAMC=[];
        self.m_clipVel=[];

    def PopulateVelocity(self,iWindow=5):
        #clear velocity
        self.m_clipVel=[];
        #recalculate
        iLength=len(self.m_clipAMC.m_arFrame);
        iHalfStep=iWindow/2;
        for i in range(0, iLength):
            arVelocityFrame=[];
            iWinStart=i-iHalfStep;
            iWinEnd=i+iHalfStep;
            #in the window of iWindow frames, center at current frame i
            for w in range(iWinStart, iWinEnd+1):
                if w >0 and w+1 < iLength:
                    curFrame=self.m_clipAMC.m_arFrame[w];
                    nextFrame=self.m_clipAMC.m_arFrame[w+1];
                    arVelocity=curFrame.SubstractABS(nextFrame);
                    velFrame=PVelocityFrame(arVelocity);
                    arVelocityFrame.append(velFrame);
            #calculate average velocity within the window
            velFrameSum=[];
            for v in range(0, len(arVelocityFrame)):
                if v==0:
                    velFrameSum=arVelocityFrame[v];
                else:
                    curVelFrame=arVelocityFrame[v];
                    velFrameSum=PVelocityFrame(velFrameSum.Add(curVelFrame));
            velocityFrame=PVelocityFrame(velFrameSum.Div(len(arVelocityFrame)));
            #window average velocity for frame i
            self.m_clipVel.append(velocityFrame);

    def GetWeightedVelocityClip(self):
        arWVClip=[];
        iFrameLen=len(self.m_clipVel);
        for i in range(0, iFrameLen):
            frmVel=self.m_clipVel[i];
            fWeightedVel=frmVel.GetWeightedVelocity();
            arWVClip.append(fWeightedVel);
        return arWVClip;

    def GetSepList(self):
        fRootHeight=self.m_clipAMC.m_arFrame[0].m_root2;
        arWVClip=self.GetWeightedVelocityClip();
        iClipLen=len(arWVClip);
        iLastSep=0;
        arSepList=[];
        for i in range(0,iClipLen):
            bLocalMinima=True;
            #left
            if i-1>0 and arWVClip[i-1]<arWVClip[i]:
                bLocalMinima=False;
            #right
            if i+1<iClipLen and arWVClip[i+1]<arWVClip[i]:
                bLocalMinima=False;
            #if it is too short && no vel peak within it
            peakValue=0;
            for p in range(iLastSep,i+1):
                if arWVClip[p] >= peakValue:
                    peakValue=arWVClip[p];
            bLongFromPrev = (i-iLastSep) > 100;
            bHasPeak=(peakValue-arWVClip[i]) > 20 and \
                     (peakValue-arWVClip[iLastSep]) > 20;
            bSmallEnough=arWVClip[i] < 10;
            bSep=bLocalMinima and bSmallEnough and bLongFromPrev;# or bHasPeak);
            if bSep:
                iLastSep=i;
                arSepList.append(i);
                print 'sep at:', i;
        return arSepList;

    def DoSegmentation(self):
        self.PopulateVelocity();
        arSepList=self.GetSepList();
        iClipCount=len(arSepList);
        for i in range(0,iClipCount):
            iStartIdx=arSepList[i];
            if i==iClipCount-1:
                iEndIdx=len(self.m_clipAMC.m_arFrame)-1;
            else:
                iEndIdx=arSepList[i+1]-1;
            subClip=self.m_clipAMC.GetSubClip(iStartIdx, iEndIdx);
            iDOT=self.m_strAMCPath.rfind('.');
            iSLASH=self.m_strAMCPath.rfind('/');
            strAMCName=self.m_strAMCPath[iSLASH+1:iDOT];
            strAMCDir=self.m_strAMCPath[0:iSLASH+1];
            strSubPath=strAMCDir+strAMCName+'_'+str(iStartIdx)+'_'+str(iEndIdx)+'.amc';
            subClip.SaveToFile(strSubPath);
            #the one from 0
            if i==0:
                iStartIdx=0;
                iEndIdx=arSepList[0]-1;
                subClip=self.m_clipAMC.GetSubClip(iStartIdx, iEndIdx);
                strSubPath=strAMCDir+strAMCName+'_'+str(iStartIdx)+'_'+str(iEndIdx)+'.amc';
                subClip.SaveToFile(strSubPath);

    def ExportVelocityClip(self,strPath):
        velFile=file(strPath, 'w');
        for velFrame in self.m_clipVel:
            for vel in velFrame.m_arVelocity:
                velFile.write(str(vel));
                velFile.write(" ");
            velFile.write("\r\n");
        velFile.close();



def TryExportVelocityClip():
    strAMCPath=raw_input("please indicate the amc file path:");
    seg=PAMCSegmentation();
    seg.InitFromAMC(strAMCPath);
    iWindow=5;
    seg.ExportVelocityClip(strAMCPath+".vel"+str(iWindow));

def TrySegmentation():
    strAMCPath=r'K:\research\CMUDB\segTest\01_07.amc';
    seg=PAMCSegmentation();
    seg.InitFromAMC(strAMCPath);
    seg.ExportVelocityClip(strAMCPath+".vel"+str(5));
    seg.DoSegmentation();

def test():
    pass;

#TryExportVelocityClip();
TrySegmentation();
#test();
