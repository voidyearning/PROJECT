%this is the demo plot of index abd
%a typical case of 
tr_cc_0 = importdata('C:\wangyi\research\glove\VirtualHandCalib\sp3\trainingset\left\7_HAND_SKEL_DOF_INDEX_ABD\0_snr.tr');
%tr_cc_0 = importdata('C:\wangyi\research\glove\VirtualHandCalib\sp2\trainingset\left\7_HAND_SKEL_DOF_INDEX_ABD\all_tr\0_snr.tr');
%tr_cc_10 = importdata('C:\wangyi\research\glove\VirtualHandCalib\sp2\trainingset\left\7_HAND_SKEL_DOF_INDEX_ABD\all_tr\10_snr.tr');
%tr_cc_20 = importdata('C:\wangyi\research\glove\VirtualHandCalib\sp2\trainingset\left\7_HAND_SKEL_DOF_INDEX_ABD\all_tr\20_snr.tr');
%tr_cc_30 = importdata('C:\wangyi\research\glove\VirtualHandCalib\sp2\trainingset\left\7_HAND_SKEL_DOF_INDEX_ABD\all_tr\30_snr.tr');
%tr_cc_40 = importdata('C:\wangyi\research\glove\VirtualHandCalib\sp2\trainingset\left\7_HAND_SKEL_DOF_INDEX_ABD\all_tr\40_snr.tr');
%tr_ik_indexTouching = importdata('C:\wangyi\research\glove\VirtualHandCalib\trainingset - deprecated\7_index_middle_abd\ik_index_touching.tr');

%tr_cc = [tr_cc_0; tr_cc_10; tr_cc_20; tr_cc_30];% tr_cc_40];
figure(2);
xlabel('s_{I\_MCP}')
ylabel('s_{M\_MCP}')
zlabel('s_{IM\_ABD}')
%title('Plot of sin(\Theta)')
%scatter3(tr_cc(:,1), tr_cc(:,2), tr_cc(:,3), 50, tr_cc(:,4), '+');
%hold on;
%scatter3(tr_ik_indexTouching(:,1), tr_ik_indexTouching(:,2), tr_ik_indexTouching(:,3), 50, tr_ik_indexTouching(:,4), '.');
hold on;
grid on;
scatter3(tr_cc_0(:,1),tr_cc_0(:,2), tr_cc_0(:,3), 50, 'k.');
%scatter3(tr_cc_10(:,1),tr_cc_10(:,2), tr_cc_10(:,3), 50, 'kx');
%scatter3(tr_cc_20(:,1),tr_cc_20(:,2), tr_cc_20(:,3), 50, 'k+');
%scatter3(tr_cc_30(:,1),tr_cc_30(:,2), tr_cc_30(:,3), 50, 'kd');
%scatter(tr_cc_10(:,1), tr_cc_10(:,2), 50, 'b+');
%scatter(tr_cc_20(:,1), tr_cc_20(:,2), 50, 'b+');
%scatter(tr_cc_30(:,1), tr_cc_30(:,2), 50, 'b+');
%scatter(tr_cc_40(:,1), tr_cc_40(:,2), 50, 'b+');
%scatter(tr_ik_indexTouching(1:83,1), tr_ik_indexTouching(1:83,2), 50, 'r.');