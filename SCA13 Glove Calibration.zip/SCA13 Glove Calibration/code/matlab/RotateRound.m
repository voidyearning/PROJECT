%this is verified to be correct
function rotated_point_pos = RotateRound(axis_point, axis_direction, point_pos, rotation_angle)
x = point_pos(1);
y = point_pos(2);
z = point_pos(3);

a = axis_point(1);
b = axis_point(2);
c = axis_point(3);

axis_direction = Normalize_vec(axis_direction);
u = axis_direction(1);
v = axis_direction(2);
w = axis_direction(3);

cosine_theta = cos(rotation_angle);
sine_theta = sin(rotation_angle);

new_x = (a*(v*v + w*w) - u*(b*v + c*w - u*x - v*y - w*z)) * (1- cosine_theta) + x*cosine_theta + (-c*v + b*w - w*y + v*z)*sine_theta;
new_y = (b*(u*u + w*w) - v*(a*u + c*w - u*x - v*y - w*z)) * (1- cosine_theta) + y*cosine_theta + (c*u - a*w + w*x - u*z)*sine_theta;
new_z = (c*(u*u + v*v) - w*(a*u + b*v - u*x - v*y - w*z)) * (1- cosine_theta) + z*cosine_theta + (-b*u + a*v - v*x + u*y)*sine_theta;

rotated_point_pos(1) = new_x;
rotated_point_pos(2) = new_y;
rotated_point_pos(3) = new_z;
end