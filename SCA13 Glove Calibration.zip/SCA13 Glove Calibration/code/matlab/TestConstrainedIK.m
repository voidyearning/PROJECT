function result = TestConstrainedIK()

%initialization
Goal_global_pos = [9, -5, 5];
Root_pos = zeros(1,3);
Root_pos(1,:) = [0, 0, 0];
%finger===================================================================
thumb_joint_num = 5;
thumb_joint_angle = zeros(1, 5);
A=0.25;B=-0.375;
thumb_joint_angle(1,:) = [ pi * (0 /180), pi * (-15 /180), ...%x, abd
    pi * (A*0+B*(-15)) /180, pi * (-15 /180),...%virtual, flex
    pi * (-15 /180)];%flex
thumb_joint_local_axis=[1,0,0; 0,1,0; %x, abd
    1,0,0; 0,0,1;
    0,0,1];
thumb_joint_local_pos=[0,0,0;0,0,3.5;
    1.75,0,0;1.75,0,0;
    3.6,0,0; 3,0,0];

thumb_joint_weight = [2,1,1,1,1];
thumb_joint_constraints = [1, pi*(-15/180), pi*(-15/180);
    1, pi*(0/180), pi*(0/180);
    0.1, pi*(0/180), pi*(20/180);
    0.1, pi*(-100/180), pi*(10/180);
    0.1, pi*(-100/180), pi*(5/180)];

[thumb_joint_global_pos, thumb_joint_global_axis]=GetGlobalJointPosAndAxis(Root_pos, thumb_joint_num, thumb_joint_angle, thumb_joint_local_axis, thumb_joint_local_pos);
VisualizeIK3D(thumb_joint_global_pos, thumb_joint_num);

%thumb_joint_global_pos
thumb_joint_angle
[thumb_joint_angle, thumb_joint_global_pos, thumb_joint_global_axis] = SolveJointRotation3DWithCombinedConstraints_virtualThumb(A, B,...
    Root_pos, thumb_joint_num, thumb_joint_angle, thumb_joint_local_axis, thumb_joint_local_pos, ...
    thumb_joint_weight, thumb_joint_constraints, ...
    Goal_global_pos, 1);
%[thumb_joint_angle, thumb_joint_global_pos, thumb_joint_global_axis] = SolveJointRotation3DWithWeight(Root_pos, thumb_joint_num, thumb_joint_angle, thumb_joint_local_axis, thumb_joint_local_pos, thumb_joint_weight, Goal_global_pos, 1);

thumb_joint_angle
thumb_joint_global_pos;
A*thumb_joint_angle(1)+B*thumb_joint_angle(2)

end