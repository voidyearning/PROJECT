function TestConvex()
% Create the data.
n = 50;
X = randn(n,3);
% Plot the points.
plot3(X(:,1),X(:,2),X(:,3),'ko','markerfacecolor','k');
% Compute the convex hull.
C = convhulln(X)
% Plot the convex hull.
hold on
for i = 1:size(C,1)
   j = C(i,[1 2 3 1])
   patch(X(j,1),X(j,2),X(j,3),rand,'FaceAlpha',0.6);
end
% Modify the view.
%view(3), axis equal off tight vis3d; camzoom(1.2)
%colormap(spring)
%rotate3d on
end
