%verified to be correct
%including the end effector pos, Joint_local_pos(1) is always(0,0,0,1)'
function [Joint_global_pos, Joint_global_axis] = GetGlobalJointPosAndAxis(Root_pos, Joint_num, Joint_angle, Joint_local_axis, Joint_local_pos)
%initialize rotation matrix that can map local(0,0,0,1)' to base_pos
rotation_matrix_l2g = [1, 0, 0, Root_pos(1);
                       0, 1, 0, Root_pos(2);
                       0, 0, 1, Root_pos(3);
                       0, 0, 0, 1];
%initialize
global_pos_temp = zeros(4, Joint_num+1);
global_pos_temp(1,1) = Root_pos(1);
global_pos_temp(2,1) = Root_pos(2);
global_pos_temp(3,1) = Root_pos(3);
global_pos_temp(4,1) = 1;

global_axis_temp = zeros(4, Joint_num+1);
global_axis_temp(1,1) = Joint_local_axis(1,1);
global_axis_temp(2,1) = Joint_local_axis(1,2);
global_axis_temp(3,1) = Joint_local_axis(1,3);
global_axis_temp(4,1) = 1;

local_pos_to_parent = zeros(4, 1);
local_axis_end_pos_to_parent = zeros(4, 1);
for i=1:Joint_num
    %get local rotation matrix
    local_angle_to_parent = Joint_angle(i);   
    local_axis_to_parent = Joint_local_axis(i,:);    
    local_rotation_matrix = GetLocalRotationMatrix(...
        local_axis_to_parent, local_angle_to_parent);
    
    %rotate joint pos in local
    local_pos_to_parent(1,1) = Joint_local_pos(i+1,1);
    local_pos_to_parent(2,1) = Joint_local_pos(i+1,2);
    local_pos_to_parent(3,1) = Joint_local_pos(i+1,3);
    local_pos_to_parent(4,1) = 1;
   
    rotated_local_pos_to_parent = ...
        local_rotation_matrix * local_pos_to_parent;  

    %transform it to global
    global_pos_temp(:,i+1) = rotation_matrix_l2g * rotated_local_pos_to_parent;  
    
     %rotate axis end pos in local
    if i < Joint_num
        next_local_axis_to_parent = Joint_local_axis(i+1,:);
        local_axis_end_pos_to_parent(1,1) = local_pos_to_parent(1,1) + next_local_axis_to_parent(1);
        local_axis_end_pos_to_parent(2,1) = local_pos_to_parent(2,1) + next_local_axis_to_parent(2);
        local_axis_end_pos_to_parent(3,1) = local_pos_to_parent(3,1) + next_local_axis_to_parent(3);
        local_axis_end_pos_to_parent(4,1) = 1;
        rotated_local_axis_end_pos_to_parent = local_rotation_matrix * local_axis_end_pos_to_parent;
    
        global_axis_end_pos = rotation_matrix_l2g * rotated_local_axis_end_pos_to_parent;
        global_axis_temp(:,i+1) = global_axis_end_pos - global_pos_temp(:,i+1);
    end
    
    %update global matrix, move to child joint in chain
    local_translation_matrix = [1, 0, 0, local_pos_to_parent(1);
                                0, 1, 0, local_pos_to_parent(2);
                                0, 0, 1, local_pos_to_parent(3);
                                0, 0, 0, 1];
    rotation_matrix_l2g = rotation_matrix_l2g * local_rotation_matrix * local_translation_matrix;
end
%convert to output format
Joint_global_pos = zeros(Joint_num+1, 3);
Joint_global_pos(1,:) = Root_pos;
for i=1:Joint_num
    Joint_global_pos(i+1,1) = global_pos_temp(1,i+1);
    Joint_global_pos(i+1,2) = global_pos_temp(2,i+1);
    Joint_global_pos(i+1,3) = global_pos_temp(3,i+1);
end

Joint_global_axis = zeros(Joint_num, 3);
for i=1:Joint_num
    Joint_global_axis(i,1) = global_axis_temp(1,i);
    Joint_global_axis(i,2) = global_axis_temp(2,i);
    Joint_global_axis(i,3) = global_axis_temp(3,i);
end

end