function TestDelaunayn()

x=[1,2,3,1];
y=[0,1,0,1];
z=[1,2,4,5];
X=[x(:),y(:),z(:)];
toSearch=[1,1,5];
TES=delaunayn(X)
tetramesh(TES,X);
hold
%scatter(toSearch(1),toSearch(2),toSearch(3),50);
hold off
camorbit(20,0)
[t,P]=tsearchn(X,TES,toSearch)
simplexIdx=TES(t,:)
simplexVertice=X(simplexIdx,:)
end