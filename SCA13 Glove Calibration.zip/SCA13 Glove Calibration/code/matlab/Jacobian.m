%E - current end effector position (x, y, z)
%R - rotation axis of joint i [(x, y, z); (x, y, z); ....(x, y, z) ]
%P - position of joint i [(x, y, z); (x, y, z); ....(x, y, z) ]
%I - number of joint
function J = Jacobian(E, R, P, I)

% Allocate Jacobian.
J = zeros(3, I);

%vector from joint to end effector
E_P = zeros(I, 3);
for i=1:I
    E_P(i,:) = E - P(i,:);
end

%cross product with rotation axis
for i=1:I
    A = R(i,:);%rotation axis
    B = E_P(i,:);%joint to end effector;
    cross_product = cross(A, B);    
    %(a2b3 ? a3b2, a3b1 ? a1b3, a1b2 ? a2b1)
    J(1, i) = cross_product(1);
    J(2, i) = cross_product(2);
    J(3, i) = cross_product(3);
end
end
