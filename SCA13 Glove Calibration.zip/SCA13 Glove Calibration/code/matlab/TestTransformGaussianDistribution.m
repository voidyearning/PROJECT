function TestTransformGaussianDistribution()

%initialization
Root_pos = zeros(1,3);
Root_pos(1,:) = [0, 0, 0];
%finger===================================================================
J_resolution = pi * (1/180)
Joint_num = 3;
Joint_local_axis=[1,0,0; 0,1,0; %x, abd
    1,0,0];
Joint_local_pos=[0,0,0;0,0,3.5;
    1.75,0,0;1.75,0,0];
Joint_local_angle = [ pi * (-30 /180), pi * (-90 /180), ...%x, abd
    pi * (-30) /180];%flex
[Joint_global_pos, Joint_global_axis] = ...
    GetGlobalJointPosAndAxis(Root_pos, Joint_num, Joint_local_angle, Joint_local_axis, Joint_local_pos);
 VisualizeIK3D(Joint_global_pos, Joint_num);
 hold on;


J_mean1 = Joint_local_angle(1);
J_variance1 = pi * (15 /180);
J_input_range1 = J_mean1 - J_variance1 : J_resolution : ...
        J_mean1 + J_variance1;
J_output_range1 = Gaussian(J_mean1, J_variance1, J_input_range1);
J_range_num1 = size(J_input_range1, 2);

J_mean2 = Joint_local_angle(2);
J_variance2 = pi * (60 /180);
J_input_range2 = J_mean2 - J_variance2 : J_resolution : ...
        J_mean2 + J_variance2;
J_output_range2 = Gaussian(J_mean2, J_variance2, J_input_range2);
J_range_num2 = size(J_input_range2, 2);
 
J_mean3 = Joint_local_angle(3);
J_variance3 = pi * (100 /180);
J_input_range3 = (J_mean3 - J_variance3) : J_resolution : ...
        (J_mean3 + J_variance3);
J_output_range3 = Gaussian(J_mean3, J_variance3, J_input_range3);
J_range_num3 = size(J_input_range3, 2);

J_local_angle = [0, 0, 0];
J_global_output = zeros(J_range_num1 * J_range_num2 * J_range_num3, 4);
count = 1;
max_p = 0;
for i = 1:J_range_num1
    J_local_angle(1) = J_input_range1(i);
    for j = 1:J_range_num2
        J_local_angle(2) = J_input_range2(j);
        for k = 1:J_range_num3
            J_local_angle(3) = J_input_range3(k);
            [Joint_global_pos, Joint_global_axis] = ...
                GetGlobalJointPosAndAxis(Root_pos, Joint_num, J_local_angle, Joint_local_axis, Joint_local_pos);
            J_global_output(count, 1) =  Joint_global_pos(4,1);
            J_global_output(count, 2) =  Joint_global_pos(4,2);
            J_global_output(count, 3) =  Joint_global_pos(4,3);
            J_global_output(count, 4) =  J_output_range1(i) * ...
                J_output_range2(j) * J_output_range3(k);
            if J_global_output(count, 4) > max_p
                max_p = J_global_output(count, 4);
            end
            count = count + 1;
        end
    end
end
x=linspace(1,1000,1000);
y=linspace(1,1000,1000);
z=linspace(1,1000,1000);

r=linspace(0,1,1000);
g=linspace(0,1,1000);
b=linspace(0,1,1000);
%scatter3(x,y,z,3,[r' g' b']);

r = J_global_output(:,4) / max_p;
g = J_global_output(:,4) / max_p;
b = J_global_output(:,4) / max_p;
c = [r g b]
for p = 1:(count-1)
scatter3(J_global_output(p,1), J_global_output(p,2), ...
    J_global_output(p,3), 35, c(p,:), 'filled');
end
%mesh(J_global_output(:,1), J_global_output(:,2), ...
 %   J_global_output(:,3),J_global_output(:,4));
end