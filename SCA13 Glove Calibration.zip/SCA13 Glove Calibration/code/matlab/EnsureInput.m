function [Root_pos, Joint_num, Joint_angle, Joint_local_axis, Joint_local_pos] = EnsureInput(Root_pos, Joint_num, Joint_angle, Joint_local_axis, Joint_local_pos)
Root_pos = [Root_pos(1,1), Root_pos(1,2), Root_pos(1,3)];

Joint_angle_temp = zeros(1, Joint_num);
Joint_local_axis_temp = zeros(Joint_num, 3);
Joint_local_pos_temp = zeros(Joint_num+1, 3);

Joint_local_pos_temp(1,1)=Joint_local_pos(1,1);
Joint_local_pos_temp(1,2)=Joint_local_pos(1,2);
Joint_local_pos_temp(1,3)=Joint_local_pos(1,3);
for i=1:Joint_num
    Joint_angle_temp(i)=Joint_angle(1,i);
    Joint_local_axis_temp(i,1)=Joint_local_axis(i,1);
    Joint_local_axis_temp(i,2)=Joint_local_axis(i,2);
    Joint_local_axis_temp(i,3)=Joint_local_axis(i,3);
    Joint_local_pos_temp(i+1,1)=Joint_local_pos(i+1,1);
    Joint_local_pos_temp(i+1,2)=Joint_local_pos(i+1,2);
    Joint_local_pos_temp(i+1,3)=Joint_local_pos(i+1,3);
end
Joint_angle = Joint_angle_temp;
Joint_local_axis = Joint_local_axis_temp;
Joint_local_pos = Joint_local_pos_temp;
end