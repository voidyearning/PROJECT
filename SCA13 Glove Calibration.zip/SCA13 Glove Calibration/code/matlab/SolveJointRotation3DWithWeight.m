%all rotations are absolute
function [Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3DWithWeight(Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos, Joint_weight, Goal_global_pos, bShowStep)

%calculate joint pos from rotation angles
[Joint_global_pos, Joint_global_axis] = GetGlobalJointPosAndAxis(Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos);
if bShowStep>0
    VisualizeIK3D(Joint_global_pos, Joint_num);
end

Joint_angle = Joint_init_angle;

Cur_global_pos = Joint_global_pos(Joint_num+1, :);
delta_S = Goal_global_pos - Cur_global_pos;
dist_S = sqrt(delta_S(1) * delta_S(1) + delta_S(2) * delta_S(2) + delta_S(3) * delta_S(3));

%k is the step length
k = 0.1;
sCount = 0;
while dist_S > 0.01
    %Jacobian and pseudo inverse
    J = Jacobian(Cur_global_pos, Joint_global_axis, Joint_global_pos, Joint_num);
    %this is incorrect: J = WeightedJacobian(Cur_global_pos, Joint_global_axis, Joint_global_pos, Joint_num, Joint_weight);
    J_plus = PseudoInverseJacobian3D(J, Joint_num);
    
    %calculate delta angle from delta s
    delta_S = k * delta_S;
    V = delta_S';
    delta_angle = J_plus * V;
    delta_angle = delta_angle'
    delta_angle = Joint_weight .* delta_angle
   
    %update joint angle & end effector position
    %I think this is a bug
    %Joint_angle = Joint_angle + Joint_weight.*delta_angle; 
    Joint_angle = Joint_angle + delta_angle;
    
    [Joint_global_pos, Joint_global_axis] = GetGlobalJointPosAndAxis(Root_pos, Joint_num, Joint_angle, Joint_local_axis, Joint_local_pos);
    
    %visualize the animation step
    if bShowStep>0
        VisualizeIK3D(Joint_global_pos, Joint_num);
    end
    
    %recalculate current end effector position
    Cur_global_pos = Joint_global_pos(Joint_num+1, :);
    delta_S = Goal_global_pos - Cur_global_pos;
    dist_S = sqrt(delta_S(1) * delta_S(1) + delta_S(2) * delta_S(2) + delta_S(3) * delta_S(3));
    
    %convergence control
    sCount = sCount + 1;
    if sCount > 3000
        break;
    end
end

if bShowStep>0
	VisualizeIK3D(Joint_global_pos, Joint_num);
end
end