function result = TestMultiFrames()

%initialization
Root_pos = zeros(1,3);
Root_pos(1,:) = [0, 0, 0];
%finger===================================================================
Joint_num = 5;
Joint_local_axis=[1,0,0; 0,1,0; %x, abd
    1,0,0; 0,0,1;
    0,0,1];
Joint_local_pos=[0,0,0;0,0,3.5;
    1.75,0,0;1.75,0,0;
    3.6,0,0; 3,0,0];

Joint_free = [0;0;0;0;0];
Joint_init_gain = [1;1;1;1;1];

Joint_init_offset = [0;0;0;0;0];

Sensor_of_frames = [ pi * (0 /180), pi * (0 /180);
    pi * (-15 /180), pi * (-15 /180);
    pi * (0) /180, pi * (0) /180;
    pi * (-15 /180), pi * (-15 /180);
    pi * (-15 /180), pi * (-15 /180)];%flex

Goal_of_frames = [6, 6; -5, -5; 5, 5];

[concatenated_g_o] = ...
    embeded_SolveJointRotation3D(Root_pos, Joint_num, 2, Joint_free, ...
    Joint_local_axis, Joint_local_pos, Joint_init_gain, ...
    Joint_init_offset, Sensor_of_frames, Goal_of_frames);

for i=1:2
    Joint_offset = concatenated_g_o(2*Joint_num*i-2*Joint_num+1:2*Joint_num*i-Joint_num, 1);
    Joint_gain = concatenated_g_o(2*Joint_num*i-Joint_num+1:2*Joint_num*i, 1);
    Sensor_reading = Sensor_of_frames(:, i);
    Joint_angle = Joint_gain.* Sensor_reading + Joint_offset
end


%for comparision purpose
Goal_global_pos = [6, -5, 5];
thumb_joint_angle = [ pi * (0 /180), pi * (-15 /180), ...%x, abd
    pi * (0) /180, pi * (-15 /180),...%virtual, flex
    pi * (-15 /180)];%flex
[thumb_joint_angle, thumb_joint_global_pos, thumb_joint_global_axis] = ...
    SolveJointRotation3D(Root_pos, Joint_num, thumb_joint_angle, ...
    Joint_local_axis, Joint_local_pos, Goal_global_pos, 0);

thumb_joint_angle

end