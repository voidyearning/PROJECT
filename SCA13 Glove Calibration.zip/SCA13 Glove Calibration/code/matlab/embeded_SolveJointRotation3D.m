%all rotations are absolute
%Joint_init_gain = (g1;g2;...), Joint_num rows
%Joint_init_offset = (o1;o2;...), Joint_num rows
%Sensor_of frames = (Joint_num, Frame_num)
%Goal_of_frames = (3, Frame_num)
%Joint_free = 1 is free, 0 is bounded by g*s+o
function [concatenated_g_o] = ...
    embeded_SolveJointRotation3D(Root_pos, Joint_num, Frame_num, ...
    Joint_free, Joint_local_axis, Joint_local_pos, ...
    Joint_init_gain, Joint_init_offset, Sensor_of_frames, Goal_of_frames)

concatenated_goal = zeros(3 * Frame_num, 1);
concatenated_end = zeros(3 * Frame_num, 1);
concatenated_delta = zeros(3 * Frame_num, 1);
concatenated_g_o = zeros(2 * Joint_num * Frame_num, 1);
concatenated_global_axis = zeros(3*Frame_num, Joint_num); 
concatenated_global_pos = zeros(3*Frame_num, Joint_num+1);
dist_S = 0;

%for each frame, calculate joint pos from rotation angles
for i=1:Frame_num
    Sensor_reading = Sensor_of_frames(:, i);
    Joint_init_angle = Joint_init_gain.* Sensor_reading + Joint_init_offset;
    [Joint_global_pos, Joint_global_axis] = GetGlobalJointPosAndAxis(...
        Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos);
    
    concatenated_goal(3*i-2:3*i, 1) = Goal_of_frames(:, i);    
    concatenated_end(3*i-2:3*i, 1) = Joint_global_pos(Joint_num+1, :);
    
    concatenated_delta(3*i-2:3*i, 1) = concatenated_goal(3*i-2:3*i, 1) ...
        - concatenated_end(3*i-2:3*i, 1);
    
    concatenated_g_o(2*Joint_num*i-2*Joint_num+1:2*Joint_num*i-Joint_num, 1) = Joint_init_offset;
    concatenated_g_o(2*Joint_num*i-Joint_num+1:2*Joint_num*i, 1) = Joint_init_gain;
    
    concatenated_global_axis(3*i-2:3*i,:) = Joint_global_axis';
    concatenated_global_pos(3*i-2:3*i,:) = Joint_global_pos';
    
    dist_S = dist_S + sqrt(concatenated_delta(3*i-2, 1)*concatenated_delta(3*i-2, 1)+...
        concatenated_delta(3*i-1,1) * concatenated_delta(3*i-1, 1) + ...
        concatenated_delta(3*i,1) * concatenated_delta(3*i, 1));
end

dist_S = dist_S / Frame_num;
delta_S = concatenated_delta;
%k is the step length
k = 0.1;
sCount = 0;
while dist_S > 0.01
    %Jacobian and pseudo inverse
    concatenated_J = concatenated_Jacobian(concatenated_end,...
    concatenated_global_axis, concatenated_global_pos, ...
    Joint_num, Joint_free, Frame_num, Sensor_of_frames);    
    concatenated_J_plus = concatenated_PseudoInverseJacobian3D(concatenated_J);
    
    %calculate delta angle from delta s
    delta_S = k * delta_S;
    delta_g_o = concatenated_J_plus * delta_S;
    concatenated_g_o = concatenated_g_o + delta_g_o;
    
    %unify g_o
    average_o = zeros(Joint_num, 1);
    average_g = zeros(Joint_num, 1);
    for i=1:Frame_num
        average_o = average_o + ...
            concatenated_g_o(2*Joint_num*i-2*Joint_num+1:2*Joint_num*i-Joint_num, 1);
        average_g = average_g + ...
            concatenated_g_o(2*Joint_num*i-Joint_num+1:2*Joint_num*i, 1);
    end
    average_o = average_o ./ Frame_num;
    average_g = average_g ./ Frame_num;
    
    %for each frame, calculate joint pos from rotation angles
    dist_S = 0;
    for i=1:Frame_num
        current_joint_base = 2*Joint_num*i-2*Joint_num;
        for j=1:Joint_num
            if Joint_free(j) == 0
                concatenated_g_o(current_joint_base + j, 1) = average_o(j);
                concatenated_g_o(current_joint_base + j + Joint_num, 1) = average_g(j);
            end
        end
        Joint_offset = concatenated_g_o(2*Joint_num*i-2*Joint_num+1:2*Joint_num*i-Joint_num, 1);
        Joint_gain = concatenated_g_o(2*Joint_num*i-Joint_num+1:2*Joint_num*i, 1);
        Sensor_reading = Sensor_of_frames(:, i);
        Joint_angle = Joint_gain.* Sensor_reading + Joint_offset;
        
        [Joint_global_pos, Joint_global_axis] = GetGlobalJointPosAndAxis(...
        Root_pos, Joint_num, Joint_angle, Joint_local_axis, Joint_local_pos);
        
        concatenated_end(3*i-2:3*i, 1) = Joint_global_pos(Joint_num+1, :);    
        concatenated_delta(3*i-2:3*i, 1) = concatenated_goal(3*i-2:3*i, 1)...
            - concatenated_end(3*i-2:3*i, 1);
        
        concatenated_global_axis(3*i-2:3*i,:) = Joint_global_axis';
        concatenated_global_pos(3*i-2:3*i,:) = Joint_global_pos';
    
        dist_S = dist_S + sqrt(concatenated_delta(3*i-2, 1)*concatenated_delta(3*i-2, 1)+...
        concatenated_delta(3*i-1, 1) * concatenated_delta(3*i-1, 1) + ...
        concatenated_delta(3*i, 1) * concatenated_delta(3*i, 1));
    end
    
    %recalculate distance
    dist_S = dist_S / Frame_num;
    delta_S = concatenated_delta;
    
    %convergence control
    sCount = sCount + 1;
    if sCount > 3000
        break;
    end
end
concatenated_g_o


end