%verified to be correct
function local_rotation_matrix = GetLocalRotationMatrix(axis_axis, rotation_angle)
     
u = axis_axis(1);
v = axis_axis(2);
w = axis_axis(3);

cosine_theta = cos(rotation_angle);
sine_theta = sin(rotation_angle);

if u==1 && v==0 && w==0
    local_rotation_matrix = [1, 0, 0, 0;
                             0, cosine_theta, -sine_theta, 0;
                             0, sine_theta, cosine_theta, 0;
                             0, 0, 0, 1];
end

if u==0 && v==1 && w==0
    local_rotation_matrix = [cosine_theta, 0, sine_theta, 0;
                             0, 1, 0, 0;
                             -sine_theta, 0, cosine_theta, 0;
                             0, 0, 0, 1];
end

if u==0 && v==0 && w==1
    local_rotation_matrix = [cosine_theta, -sine_theta, 0, 0;
                             sine_theta, cosine_theta, 0, 0;
                             0, 0, 1, 0;
                             0, 0, 0, 1];
end