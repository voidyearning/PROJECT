%this is verified to be correct
function rotation_matrix = GetRotationMatrix(axis_point, axis_direction, rotation_angle)
a = axis_point(1);
b = axis_point(2);
c = axis_point(3);

axis_direction = Normalize_vec(axis_direction);
u = axis_direction(1);
v = axis_direction(2);
w = axis_direction(3);

cosine_theta = cos(rotation_angle);
sine_theta = sin(rotation_angle);

rotation_matrix = [u*u+(v*v+w*w)*cosine_theta, u*v*(1-cosine_theta)-w*sine_theta, u*w*(1-cosine_theta)+v*sine_theta, (a*(v*v+w*w)-u*(b*v+c*w))*(1-cosine_theta)+(b*w-c*v)*sine_theta;
                   u*v*(1-cosine_theta)+w*sine_theta, v*v+(u*u+w*w)*cosine_theta, v*w*(1-cosine_theta)-u*sine_theta, (b*(u*u+w*w)-v*(a*u+c*w))*(1-cosine_theta)+(c*u-a*w)*sine_theta;
                   u*w*(1-cosine_theta)-v*sine_theta, v*w*(1-cosine_theta)+u*sine_theta, w*w+(u*u+v*v)*cosine_theta, (c*(u*u+v*v)-w*(a*u+b*v))*(1-cosine_theta)+(a*v-b*u)*sine_theta;
                   0                                , 0                                , 0                         ,  1                                                             ]


end