function TestDelaunay3()
d = [-1 1];
[x,y,z] = meshgrid(d,d,d);  % A cube
x = [x(:);0];
y = [y(:);0];
z = [z(:);0];
v = [1;2;3;4;5;6;7;8;9;10;11;12];
% [x,y,z] are corners of a cube plus the center.
Tes = delaunay3(x,y,z)
X = [x(:) y(:) z(:)]
tetramesh(Tes,X);hold on
%camorbit(20,0);

toSearch=[1,1,0.5]
scatter3(toSearch(1), toSearch(2), toSearch(3), 50, 'bo');
hold off;
[t,P]=tsearchn(X,Tes,toSearch)
simplexIdx=Tes(t,:)
simplexVertice=[X(simplexIdx,:),v(simplexIdx)]
end