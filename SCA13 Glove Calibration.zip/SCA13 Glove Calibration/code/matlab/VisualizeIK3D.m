function VisualizeIK3D(Joint_pos, Joint_num)

X = Joint_pos(:,1);
X = X';

Y = Joint_pos(:,2);
Y = Y';

Z = Joint_pos(:,3);
Z = Z';

hold on
plot3(X, Y, Z, '-cs');
xlabel('X')
ylabel('Y')
zlabel('Z')
%grid on
axis square

%root
plot3(Joint_pos(1, 1), Joint_pos(1, 2), Joint_pos(1, 3), 'ks', 'MarkerEdgeColor','k', 'MarkerFaceColor','k');
%end position
plot3(Joint_pos(Joint_num+1, 1), Joint_pos(Joint_num+1, 2), Joint_pos(Joint_num+1, 3), 'ks', 'MarkerEdgeColor','r', 'MarkerFaceColor','r');
end