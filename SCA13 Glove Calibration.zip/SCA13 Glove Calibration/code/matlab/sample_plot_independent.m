%this is the demo plot of index mid flex
%a typical case of 
tr_fk_fist = importdata('C:\wangyi\research\glove\VirtualHandCalib\trainingset\5_index_mid_flex\fk-fist.tr');
tr_fk_flat = importdata('C:\wangyi\research\glove\VirtualHandCalib\trainingset\5_index_mid_flex\fk-flat.tr');
tr_fk_extFlex = importdata('C:\wangyi\research\glove\VirtualHandCalib\trainingset\5_index_mid_flex\fk-extFlex.tr');
tr_fk_spread = importdata('C:\wangyi\research\glove\VirtualHandCalib\trainingset\5_index_mid_flex\fk-spread.tr');
tr_ik_indexTouching = importdata('C:\wangyi\research\glove\VirtualHandCalib\trainingset\5_index_mid_flex\ik-index-touching.tr');

tr_fk = [tr_fk_fist; tr_fk_flat; tr_fk_extFlex; tr_fk_spread];
scatter(tr_fk(:, 1), tr_fk(:,2), 50, 'b+');
%scatter(tr_fk_fist(:,1), tr_fk_fist(:,2), 50, 'b+');
hold on;
%scatter(tr_fk_flat(:,1), tr_fk_flat(:,2), 50, 'b+');
%scatter(tr_fk_extFlex(:,1), tr_fk_extFlex(:,2), 50, 'b+');
%scatter(tr_fk_spread(:,1), tr_fk_spread(:,2), 50, 'b+');
scatter(tr_ik_indexTouching(1:83,1), tr_ik_indexTouching(1:83,2), 50, 'r.');