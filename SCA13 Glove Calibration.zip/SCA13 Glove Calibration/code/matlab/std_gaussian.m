function output = std_gaussian(delta_to_mean, variance)
output=(1/(variance*sqrt(2*pi))).*exp(-delta_to_mean.*delta_to_mean/(2*variance*variance));
end