%J is the input Jacobian
%J_plus is the pseudo inverse of Jacobian
function J_plus = concatenated_PseudoInverseJacobian3D(J)
%allocate pseudo inverse
J_trans = J';
JJ = J * J_trans;
JJ_inverse = inv(JJ);
J_plus = J_trans * JJ_inverse;
end