function normalized_vec = Normalize_vec(vec)
ele_num = size(vec);
ele_num = ele_num(2);
vec_length = 0;
for i =1:ele_num
    vec_length = vec_length + vec(i)*vec(i);
end
vec_length = sqrt(vec_length);
normalized_vec = vec / vec_length;
end