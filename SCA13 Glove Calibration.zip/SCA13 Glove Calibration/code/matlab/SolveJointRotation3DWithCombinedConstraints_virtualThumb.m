%all rotations are absolute
function [Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3DWithCombinedConstraints_virtualThumb(A, B, Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos, Joint_weight, Joint_constraints, Goal_global_pos, bShowStep)
%calculate joint pos from rotation angles
[Joint_global_pos, Joint_global_axis] = GetGlobalJointPosAndAxis(Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos);
if bShowStep>0
    VisualizeIK3D(Joint_global_pos, Joint_num);
end

Joint_angle = Joint_init_angle;
alpha_stiffness = Joint_constraints(:,1);
desired_angle = Joint_constraints(:,2) + Joint_constraints(:,3);
desired_angle = desired_angle ./ 2;
I_x = eye(Joint_num);
numerator = 3.* desired_angle.*desired_angle;%experiment shows that his might be not needed

Cur_global_pos = Joint_global_pos(Joint_num+1, :);
delta_S = Goal_global_pos - Cur_global_pos;
dist_S = sqrt(delta_S(1) * delta_S(1) + delta_S(2) * delta_S(2) + delta_S(3) * delta_S(3));

%k is the step length
k = 0.1;
sCount = 0;
while dist_S > 0.01
    %Jacobian and pseudo inverse
    J = Jacobian(Cur_global_pos, Joint_global_axis, Joint_global_pos, Joint_num);
    
    %hard code for the virtual joint
    J(1,3) = A*J(1,1) + B*J(1,2);
    J(2,3) = A*J(2,1) + B*J(2,2);
    J(3,3) = A*J(3,1) + B*J(3,2);
    J_plus = PseudoInverseJacobian3D(J, Joint_num);
    
    %calculate delta angle from delta s
    delta_S = k * delta_S;
    V = delta_S';
    delta_angle = J_plus * V
    
    %calculate the constraint control term
    constraint_c = (Joint_angle' - desired_angle);
    for c=1:Joint_num
        if constraint_c(c) < 0.0000001
            constraint_c(c) = 0;
        end
    end
    z = alpha_stiffness .* constraint_c;%./ numerator;
    z(3) = A*z(1)+B*z(2);%for the virtual joint in thumb
    constraint_term = (J_plus * J - I_x)*z;
    delta_angle = delta_angle + constraint_term;
    
    delta_angle = delta_angle';
    %update joint angle & end effector position
    Joint_angle_temp = Joint_angle;
    Joint_angle = Joint_angle + delta_angle;
    for ag=1:Joint_num
        if Joint_angle(ag) < Joint_constraints(ag,2) || Joint_angle(ag) > Joint_constraints(ag,3)
            Joint_angle(ag) = Joint_angle_temp(ag) + Joint_weight(ag).*delta_angle(ag);
        end
    end    
    [Joint_global_pos, Joint_global_axis] = GetGlobalJointPosAndAxis(Root_pos, Joint_num, Joint_angle, Joint_local_axis, Joint_local_pos);
    
    %visualize the animation step
    if bShowStep>0
        VisualizeIK3D(Joint_global_pos, Joint_num);
    end
    
    %recalculate current end effector position
    Cur_global_pos = Joint_global_pos(Joint_num+1, :);
    delta_S = Goal_global_pos - Cur_global_pos;
    dist_S = sqrt(delta_S(1) * delta_S(1) + delta_S(2) * delta_S(2) + delta_S(3) * delta_S(3));
    
    %convergence control
    sCount = sCount + 1;
    if sCount > 3000
        break;
    end
end
if bShowStep>0
	VisualizeIK3D(Joint_global_pos, Joint_num);
end
end