%initialization
Root_pos = zeros(1,3);
Root_pos(1,:) = [0, 0, 0];
%finger===================================================================
J_resolution = pi * (1/180)
Joint_num = 3;
Joint_local_axis=[1,0,0; 0,1,0; %x, abd
    1,0,0];
Joint_local_pos=[0,0,0;0,0,3.5;
    1.75,0,0;1.75,0,0];
Joint_init_angle = [ pi * (-30 /180), pi * (-90 /180), ...%x, abd
    pi * (-30) /180];%flex
Joint_std = [pi * (3/180), pi*(3/180), pi*(3/180)];

Joint_constraints = [1, pi*(-15/180), pi*(-15/180);
    1, pi*(0/180), pi*(0/180);
    0.1, pi*(0/180), pi*(20/180)];

[Joint_global_pos, Joint_global_axis] = ...
    GetGlobalJointPosAndAxis(Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos);
 VisualizeIK3D(Joint_global_pos, Joint_num);
 hold on;
 
 Goal_global_pos = Joint_global_pos(Joint_num+1, :);
 [P_orig] = POS_Probability_DLS_WithConstraints(Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos, Joint_constraints, Joint_std, Goal_global_pos)
 
 P_sum = 0;
 P_max = 0;
for x = -10:10
    for y = -10: 10
        for z = -10:10
            Goal_global_pos = [x, y, z];
            [P_pos] = POS_Probability_DLS_WithConstraints(Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos, Joint_constraints, Joint_std, Goal_global_pos)
            P_sum = P_sum + P_pos;
            if P_pos > P_max
                P_max = P_pos;
            end
        end
    end
end
P_sum
P_max
P_orig
