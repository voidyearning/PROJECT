function output = std_gaussian(mean, variance, input)
output=(variance/sqrt(2*pi)).*exp(-(input-mean).*(input-mean)/(2*variance*variance));
end