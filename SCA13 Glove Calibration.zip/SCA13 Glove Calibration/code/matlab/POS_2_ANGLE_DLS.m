function [Joint_angle] = POS_2_ANGLE_DLS(Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos, Goal_global_pos)
[Joint_global_pos, Joint_global_axis] = GetGlobalJointPosAndAxis(Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos);
Cur_global_pos = Joint_global_pos(Joint_num+1, :);
delta_S = Goal_global_pos - Cur_global_pos;
dist_S = sqrt(delta_S(1) * delta_S(1) + delta_S(2) * delta_S(2) + delta_S(3) * delta_S(3));
J = Jacobian(Cur_global_pos, Joint_global_axis, Joint_global_pos, Joint_num); 
J_DLS = J_DampedLeastSquare(J, Joint_num, dist_S);
V = delta_S';
delta_angle = J_DLS * V;
delta_angle = delta_angle';
Joint_angle = Joint_init_angle + delta_angle;   
end