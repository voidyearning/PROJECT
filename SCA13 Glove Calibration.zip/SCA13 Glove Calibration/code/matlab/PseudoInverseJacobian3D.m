%J is the input Jacobian
%J_plus is the pseudo inverse of Jacobian
function J_plus = PseudoInverseJacobian3D(J, Joint_num)
%allocate pseudo inverse
J_plus = zeros(Joint_num, 3);

J_trans = J';
JJ = J * J_trans;
JJ_inverse = inv(JJ);
J_plus = J_trans * JJ_inverse;
end