%concatenated_end = (3*Frame_num,1)
%concatenated_global_axis = (3*Frame_num, Joint_num)
%concatenated_global_pos = (3*Frame_num, Joint_num+1)
%Sensor_of_frames = (Joint_num, Frame_num)
function concatenated_J = concatenated_Jacobian(concatenated_end, ...
    concatenated_global_axis, concatenated_global_pos, ...
    Joint_num, Joint_free, Frame_num, Sensor_of_frames)

% Allocate Jacobian.
concatenated_J = zeros(3*Frame_num, 2*Joint_num*Frame_num);
J = zeros(3, Joint_num);

E = zeros(3);
R = zeros(Joint_num, 3);
P = zeros(Joint_num+1, 3);
I = Joint_num;
averaged_J = zeros(3, Joint_num);
averaged_sensored_J = zeros(3, Joint_num);
for i=1:Frame_num
   E = concatenated_end(3*i-2:3*i, 1)';
   R = concatenated_global_axis((3*i-2):3*i,:)';
   P = concatenated_global_pos((3*i-2):3*i,:)';
   W = Sensor_of_frames(:,i);
   
   J = Jacobian(E, R, P, I);
   averaged_J = averaged_J + J;
   
   Sensored_J = WeightedJacobian(E, R, P, I, W);
   averaged_sensored_J = averaged_sensored_J + Sensored_J;
   
   concatenated_J((3*i-2):3*i,(2*Joint_num*i-2*Joint_num+1):2*Joint_num*i-Joint_num) = J;
   concatenated_J((3*i-2):3*i,(2*Joint_num*i-Joint_num+1):(2*Joint_num*i)) = Sensored_J;
end

%I should NOT make the Jacobian unique
%delta_d is not the same, even Jacobian are the same
%averaged_J = averaged_J./Frame_num;
%averaged_sensored_J = averaged_sensored_J./Frame_num;
%for i=1:Frame_num
%    current_joint_base = 2*Joint_num*i-2*Joint_num;
%    for j=1:Joint_num
%        if Joint_free(j) == 0
%            concatenated_J((3*i-2):3*i, current_joint_base + j) = averaged_J(:, j);
%            concatenated_J((3*i-2):3*i, current_joint_base + j + Joint_num) = averaged_sensored_J(:, j);
%        end
%    end
%end

end