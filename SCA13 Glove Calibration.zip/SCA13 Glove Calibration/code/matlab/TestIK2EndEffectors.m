function TestIK2EndEffectors()

Goal_global_pos = [9, -5, 5];
Root_pos = zeros(1,3);
Root_pos(1,:) = [0, 0, 0];
%finger===================================================================
finger_joint_num = 6;
finger_joint_angle = zeros(1, 6);
finger_joint_angle(1,:) = [ pi * (-15 /180), pi * (0 /180), ...%in palm abd, flex
    pi * (15 /180), pi * (-15 /180),...%abd, flex
    pi * (-15 /180), pi * (-15 /180)];%flex, flex
finger_joint_local_axis=[0,1,0; 0,0,1; %in palm
    0,1,0; 0,0,1;
    0,0,1; 0,0,1];
finger_joint_local_pos=[0,0,0;0,0,0;
    7.2,0,0;0,0,0;
    4.5,0,0; 2.6,0,0; 2.2,0,0];
finger_joint_weight = [0,0,1,1,1,1];
finger_joint_constraints = [1, pi*(-15/180), pi*(-15/180);
    1, pi*(0/180), pi*(0/180);
    0.1, pi*(0/180), pi*(20/180);
    0.1, pi*(-100/180), pi*(10/180);
    0.1, pi*(-100/180), pi*(5/180);
    0.1, pi*(-90/180), pi*(0/180)];

[finger_joint_global_pos, finger_joint_global_axis]=GetGlobalJointPosAndAxis(Root_pos, finger_joint_num, finger_joint_angle, finger_joint_local_axis, finger_joint_local_pos);
VisualizeIK3D(finger_joint_global_pos, finger_joint_num);

%[finger_joint_angle, finger_joint_global_pos, finger_joint_global_axis] = SolveJointRotation3D(Root_pos, finger_joint_num, finger_joint_angle, finger_joint_local_axis, finger_joint_local_pos, Goal_global_pos, 0);
%[finger_joint_angle, finger_joint_global_pos, finger_joint_global_axis] = SolveJointRotation3DWithWeight(Root_pos, finger_joint_num, finger_joint_angle, finger_joint_local_axis, finger_joint_local_pos, finger_joint_weight, Goal_global_pos, 0);
%[finger_joint_angle, finger_joint_global_pos, finger_joint_global_axis] = SolveJointRotation3DWithRangeConstraints(Root_pos, finger_joint_num, finger_joint_angle, finger_joint_local_axis, finger_joint_local_pos, finger_joint_constraints, Goal_global_pos, 0);
[finger_joint_angle, finger_joint_global_pos, finger_joint_global_axis] = SolveJointRotation3DWithCombinedConstraints(Root_pos, finger_joint_num, finger_joint_angle, finger_joint_local_axis, finger_joint_local_pos, finger_joint_weight, finger_joint_constraints, Goal_global_pos, 0);
finger_joint_angle * 180 /pi;
%[finger_joint_global_pos, finger_joint_global_axis]=GetGlobalJointPosAndAxis(Root_pos, finger_joint_num, finger_joint_angle, finger_joint_local_axis, finger_joint_local_pos);
VisualizeIK3D(finger_joint_global_pos, finger_joint_num);

%thumb=====================================================================
thumb_joint_num = 7;
thumb_joint_angle = [  pi * (-45 /180), pi * (45 /180), pi * (0 /180),...%thumb root abd, roll, flex,
    pi * (-45 /180), pi * (-45 /180),...%abd, flex
    pi * (-45 /180), pi * (-45 /180)];%flex, flex
thumb_joint_local_axis=[0,1,0; 1,0,0; 0,0,1; 
    0,1,0; 0,0,1;
    0,0,1; 0,0,1];
thumb_joint_local_pos=[0,0,0;0,0,0;0,0,0;
    2,0,0;0,0,0;
    4,0,0; 3.5,0,0; 2.9,0,0];
thumb_joint_weight = [0,0,0,1,1,1,1];

[thumb_joint_global_pos, thumb_joint_global_axis]=GetGlobalJointPosAndAxis(Root_pos, thumb_joint_num, thumb_joint_angle, thumb_joint_local_axis, thumb_joint_local_pos);
VisualizeIK3D2(thumb_joint_global_pos, thumb_joint_num);

%[thumb_joint_angle, thumb_joint_global_pos, thumb_joint_global_axis] = SolveJointRotation3D(Root_pos, thumb_joint_num, thumb_joint_angle, thumb_joint_local_axis, thumb_joint_local_pos, Goal_global_pos, 0);
[thumb_joint_angle, thumb_joint_global_pos, thumb_joint_global_axis] = SolveJointRotation3DWithWeight(Root_pos, thumb_joint_num, thumb_joint_angle, thumb_joint_local_axis, thumb_joint_local_pos, thumb_joint_weight, Goal_global_pos, 0);

%[thumb_joint_global_pos, thumb_joint_global_axis]=GetGlobalJointPosAndAxis(Root_pos, thumb_joint_num, thumb_joint_angle, thumb_joint_local_axis, thumb_joint_local_pos);
VisualizeIK3D2(thumb_joint_global_pos, thumb_joint_num);



%[Joint_global_pos, Joint_global_axis]=GetGlobalJointPosAndAxis(Root_pos, Joint_num, Joint_angle, Joint_local_axis, Joint_local_pos);
%VisualizeIK3D(Joint_global_pos, Joint_num);

%check error
%Cur_global_pos = Joint_global_pos(Joint_num+1, :)
%delta_S = Goal_global_pos - Cur_global_pos
%dist_S = sqrt(delta_S(1) * delta_S(1) + delta_S(2) * delta_S(2))
end