function [Joint_angle] = POS_2_ANGLE_JPlus(Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos, Goal_global_pos)
[Joint_global_pos, Joint_global_axis] = GetGlobalJointPosAndAxis(Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos);
Cur_global_pos = Joint_global_pos(Joint_num+1, :);
delta_S = Goal_global_pos - Cur_global_pos;
J = Jacobian(Cur_global_pos, Joint_global_axis, Joint_global_pos, Joint_num); 
J_plus = PseudoInverseJacobian3D(J, Joint_num);    
V = delta_S';
delta_angle = J_plus * V;
Joint_angle = Joint_init_angle + delta_angle;   
end