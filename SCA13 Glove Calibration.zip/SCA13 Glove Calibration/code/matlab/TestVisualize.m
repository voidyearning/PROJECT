function TestVisualize()

X = [1,2,3];
Y = [4,5,6];
Z = [7,8,9];

hold on
plot3(X, Y, Z, '-cs');
xlabel('X')
ylabel('Y')
zlabel('Z')
end