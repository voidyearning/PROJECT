imported_data = importdata('C:\wangyi\research\glove\VirtualHandCalib\cross couple sampling\c\index_abd_trdata.txt')
leftFlex = imported_data(:,1);
rightFlex = imported_data(:,2);
abdSensor = imported_data(:,3);
realAbd = imported_data(:,4);
scatter3(leftFlex,rightFlex,abdSensor, 50, '+');
xlabel('leftFlexSensor');
ylabel('rightFlexSensor');
zlabel('abdSensor');
hold on;