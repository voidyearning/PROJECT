function [P_pos] = POS_Probability_DLS_WithConstraints(Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos, Joint_constraints, Joint_std, Goal_global_pos)
[Joint_angle] = POS_2_ANGLE_DLS(Root_pos, Joint_num, Joint_init_angle, Joint_local_axis, Joint_local_pos, Goal_global_pos);
delta_joint_angle = Joint_angle - Joint_init_angle;

%calculate joint probability
P_pos = 1;
for i=1:Joint_num
    std = Joint_std(i);    
    delta = delta_joint_angle(i);
    %radian to degree
    std = (std * 180) / pi;
    delta = (delta * 180) / pi;
    
    coef = std * sqrt(2 * pi);
    coef = 1 / coef;
    gs = - delta * delta;
    gs = gs / (2 * std * std);
    gs = exp(gs);
    P_ang = coef * gs;
    
    %pp = std_gaussian(delta, std);
    %assert(pp == P_ang);
    
    if P_ang > 1
        P_ang = 1;
    end
    
    %min angle constraints
    angle_min = Joint_constraints(i, 2); 
    if Joint_angle(i) < angle_min
        P_min = std_gaussian(angle_min - Joint_angle(i), 0.05);
        if P_ang > P_min
            P_ang = P_min
        end
    end 
    %max
    angle_max = Joint_constraints(i, 3);
    if Joint_angle(i) > angle_max
        P_max = std_gaussian(Joint_angle(i) - angle_max, 0.05);
        if P_ang > P_max
            P_ang = P_max
        end
    end
   
    P_pos = P_pos * P_ang;     
end
 
 %range constaints
chain_length = 0;
for i = 1:Joint_num+1
    this_length = sqrt(Joint_local_pos(i, 1) * Joint_local_pos(i, 1) + ...
        Joint_local_pos(i, 2) * Joint_local_pos(i, 2) + Joint_local_pos(i, 3) * Joint_local_pos(i, 3));
    chain_length = chain_length + this_length;
end
goal_length = sqrt(Goal_global_pos(1)*Goal_global_pos(1) + ...
    Goal_global_pos(2)*Goal_global_pos(2) + Goal_global_pos(3) * Goal_global_pos(3));
if goal_length > chain_length
    P_length = std_gaussian(goal_length - chain_length, 0.01);
    if P_pos > P_length
    P_pos = P_length;
    end
end
if P_pos == 0
    P_pos = 1000000000000000000000;
else
    P_pos = -log(P_pos);
end
end