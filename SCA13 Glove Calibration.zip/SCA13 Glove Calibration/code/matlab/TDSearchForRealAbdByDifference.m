function [abdRealSearched, bCoord, simplex] = ...
    TDSearchForRealAbdByDifference(leftFlex,rightFlex,abdSensor,abdReal,tupleToSearch)
X=[leftFlex(:)-rightFlex(:),abdSensor(:)];
toSearch=[tupleToSearch(1)-tupleToSearch(2), tupleToSearch(3)];
Tes=delaunayn(X);
[t,bCoord]=tsearchn(X,Tes,toSearch);
simplexIdx=zeros(1,3);
simplex=zeros(3,4);
abdRealSearched=0.5;
if isnan(t)
    bCoord=[0,0,0];
    k=dsearchn(X,Tes,toSearch);
    simplex(1,:)=[leftFlex(k),rightFlex(k),abdSensor(k),abdReal(k)];
    abdRealSearched=abdReal(k);
else
    simplexIdx=Tes(t,:);
    simplex=[leftFlex(simplexIdx),rightFlex(simplexIdx),abdSensor(simplexIdx),abdReal(simplexIdx)];
    simplex=reshape(simplex,3,4);
    abdRealSearched=bCoord(1,1)*simplex(1,4)+bCoord(1,2)*simplex(2,4)+bCoord(1,3)*simplex(3,4);
end
end