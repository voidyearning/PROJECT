%J is the input Jacobian
%J_DLS is %J+ ?  =  JT (J JT + ?2 I )-1   for Damped Least Square
function J_DLS = J_DampedLeastSquare(J, Joint_num, dist_S)
%allocate pseudo inverse
J_DLS = zeros(Joint_num, 3);%Joint_num * 3
J_trans = J';%JT Joint_num * 3
JJ = J * J_trans;%J JT  3*3
dls = zeros(3, 3);
dls(1,1) = 100;%10 * dist_S * dist_S;
dls(2,2) = 100;%10 * dist_S * dist_S;
dls(3,3) = 100;%10 * dist_S * dist_S; % ?2 I % 3*3
J_DLS = J_trans * inv(JJ + dls);
end
%note that 100 const works fine
%dist_S works fine
%10 * dist_S * dist_S works fine
%dist_S * dist_S does NOT work