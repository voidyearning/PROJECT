// GloveSamplingDlg.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "GloveSamplingDlg.h"
#include "GloveUtil.h"
#include "CKinematic\CKinematicChain.h"
#include <fstream>
#include "math.h"

using namespace std;


// CGloveSamplingDlg dialog

IMPLEMENT_DYNAMIC(CGloveSamplingDlg, CDialog)

CGloveSamplingDlg::CGloveSamplingDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGloveSamplingDlg::IDD, pParent)
{
	m_cMarkerType = '+';
	m_cMarkerColor = 'b';
	m_bByDifference = false;
	m_bNewFigure = false;
	m_eShowWhat = eScatter;

	m_bEliminateRepetitiveSamplings = true;
	m_fCCSp2TrValue_r = -100;
	m_bUseFKValue_r = false;
}

CGloveSamplingDlg::~CGloveSamplingDlg()
{
}

void CGloveSamplingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CGloveSamplingDlg, CDialog)
	//cross-coupled	
	ON_BN_CLICKED(IDC_BUTTON_BSW_CC_TR_FILE, &CGloveSamplingDlg::OnBnClickedButtonBswCCTRFile)
	ON_BN_CLICKED(IDC_BUTTON_CC_TR, &CGloveSamplingDlg::OnBnClickedButtonCC2TR)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_CC_SP_FILE, &CGloveSamplingDlg::OnBnClickedButtonBrowseCCSPFile)
	ON_BN_CLICKED(IDC_BUTTON_PLOT_SENSOR_READING_FILE, &CGloveSamplingDlg::OnBnClickedButtonPlotSensorReadingFile)
	ON_BN_CLICKED(IDC_RADIO_MARKER_O, &CGloveSamplingDlg::OnBnClickedRadioMarkerO)
	ON_BN_CLICKED(IDC_RADIO_MARKER_d, &CGloveSamplingDlg::OnBnClickedRadioMarkerd)
	ON_BN_CLICKED(IDC_RADIO_MARKER_dot, &CGloveSamplingDlg::OnBnClickedRadioMarkerdot)
	ON_BN_CLICKED(IDC_RADIO_MARKER_X, &CGloveSamplingDlg::OnBnClickedRadioMarkerX)
	ON_BN_CLICKED(IDC_RADIO_MARKER_PLUS, &CGloveSamplingDlg::OnBnClickedRadioMarkerPlus)
	ON_BN_CLICKED(IDC_RADIO_MARKER_M, &CGloveSamplingDlg::OnBnClickedRadioMarkerM)
	ON_BN_CLICKED(IDC_RADIO_MARKER_R, &CGloveSamplingDlg::OnBnClickedRadioMarkerR)
	ON_BN_CLICKED(IDC_RADIO_MARKER_Y, &CGloveSamplingDlg::OnBnClickedRadioMarkerY)
	ON_BN_CLICKED(IDC_RADIO_MARKER_G, &CGloveSamplingDlg::OnBnClickedRadioMarkerG)
	ON_BN_CLICKED(IDC_RADIO_MARKER_C, &CGloveSamplingDlg::OnBnClickedRadioMarkerC)
	ON_BN_CLICKED(IDC_RADIO_MARKER_B, &CGloveSamplingDlg::OnBnClickedRadioMarkerB)
	ON_BN_CLICKED(IDC_RADIO_MARKER_K, &CGloveSamplingDlg::OnBnClickedRadioMarkerK)
	ON_BN_CLICKED(IDC_RADIO_ANALYSIS_SENSOR, &CGloveSamplingDlg::OnBnClickedRadioAnalysisSensor)
	ON_BN_CLICKED(IDC_RADIO_ANALYSIS_DIFFERENCE, &CGloveSamplingDlg::OnBnClickedRadioAnalysisDifference)
	ON_BN_CLICKED(IDC_RADIO_NEW_FIGURE, &CGloveSamplingDlg::OnBnClickedRadioNewFigure)
	ON_BN_CLICKED(IDC_RADIO_HOLD_ON, &CGloveSamplingDlg::OnBnClickedRadioHoldOn)
	ON_BN_CLICKED(IDC_RADIO_PLOT3, &CGloveSamplingDlg::OnBnClickedRadioPlot3)
	ON_BN_CLICKED(IDC_RADIO_SCATTER3, &CGloveSamplingDlg::OnBnClickedRadioScatter3)
	ON_BN_CLICKED(IDC_RADIO_GRIDDATA, &CGloveSamplingDlg::OnBnClickedRadioGriddata)
	ON_BN_CLICKED(IDC_RADIO_DELAUNAY, &CGloveSamplingDlg::OnBnClickedRadioDelaunay)
	//IK	
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_IK_SP_FILE, &CGloveSamplingDlg::OnBnClickedButtonBrowseIKSPFile)
	ON_BN_CLICKED(IDC_BUTTON_IK_SP_CLOSED_FILE, &CGloveSamplingDlg::OnBnClickedButtonIKSPClosedFile)	
	ON_EN_CHANGE(IDC_EDIT_TR_IK_IDX_S, &CGloveSamplingDlg::OnEnChangeEditTrIkIdxS)
	ON_EN_CHANGE(IDC_EDIT_TR_IK_IDX_R, &CGloveSamplingDlg::OnEnChangeEditTrIkIdxR)

	ON_BN_CLICKED(IDC_BUTTON_IK_TR, &CGloveSamplingDlg::OnBnClickedButtonIK2TR)
	ON_BN_CLICKED(IDC_BUTTON_BSW_IK_TR_FILE, &CGloveSamplingDlg::OnBnClickedButtonBswIKTRFile)
	//FK	
	ON_EN_CHANGE(IDC_EDIT_TR_FK_IDX, &CGloveSamplingDlg::OnEnChangeEditFKTRIdx)	
	ON_EN_CHANGE(IDC_EDIT_TR_FK_VALUE_R, &CGloveSamplingDlg::OnEnChangeEditTrFkValueR)	
	ON_BN_CLICKED(IDC_CHECK_FK_USE_VALUE_R, &CGloveSamplingDlg::OnBnClickedCheckFkUseValueR)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_FK_SP_FILE, &CGloveSamplingDlg::OnBnClickedButtonBrowseFKSPFile)
	ON_BN_CLICKED(IDC_BUTTON_FK_POSE_FILE, &CGloveSamplingDlg::OnBnClickedButtonFKPoseFile)
	ON_BN_CLICKED(IDC_BUTTON_BSW_FK_TR_FILE, &CGloveSamplingDlg::OnBnClickedButtonBswFKTRFile)
	ON_BN_CLICKED(IDC_BUTTON_FK_TR, &CGloveSamplingDlg::OnBnClickedButtonFK2TR)
	//General

	ON_BN_CLICKED(IDC_BUTTON_GR_SP_DEST_FILE, &CGloveSamplingDlg::OnBnClickedButtonBrowseGRSPDestFile)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_GR_SP_SRC_FILE, &CGloveSamplingDlg::OnBnClickedButtonBrowseGRSPSrcFile)
	//Other	
	ON_BN_CLICKED(IDC_BUTTON_CALCULATE_REAL_ABD, &CGloveSamplingDlg::OnBnClickedButtonCalculateRealAbd)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_CALIBRATION, &CGloveSamplingDlg::OnBnClickedButtonLoadCalibration)
	ON_BN_CLICKED(IDC_BUTTON_RE_CALIBRATE, &CGloveSamplingDlg::OnBnClickedButtonReCalibrate)
	ON_BN_CLICKED(IDC_BUTTON_VARIANCE, &CGloveSamplingDlg::OnBnClickedButtonVariance)	
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_SRC_TO_PREDICT_FILE, &CGloveSamplingDlg::OnBnClickedButtonBrowseSrcToPredictFile)
	ON_BN_CLICKED(IDC_BUTTON_DEST_PREDICTED_FILE, &CGloveSamplingDlg::OnBnClickedButtonDestPredictedFile)
	ON_BN_CLICKED(IDC_BUTTON_CONVERT_ABD, &CGloveSamplingDlg::OnBnClickedButtonPredictAbdByDelaunay)
	ON_BN_CLICKED(IDC_BUTTON_PREDICTED_MAT_FILE, &CGloveSamplingDlg::OnBnClickedButtonPredictedMatFile)
	ON_BN_CLICKED(IDC_FILL_TARGET_BY_MAT, &CGloveSamplingDlg::OnBnClickedFillTargetByMat)
	ON_BN_CLICKED(IDC_BUTTON_GLV_RAW, &CGloveSamplingDlg::OnBnClickedButtonGlvRaw)
	ON_BN_CLICKED(IDC_BUTTON_MERGE_CC_SP, &CGloveSamplingDlg::OnBnClickedButtonMergeCcSp)
	ON_EN_CHANGE(IDC_EDIT_TR_CC_IDX, &CGloveSamplingDlg::OnEnChangeEditTrCcIdx)
	ON_EN_CHANGE(IDC_EDIT_TR_CC_VALUE_R, &CGloveSamplingDlg::OnEnChangeEditTrCcValueR)
	ON_EN_CHANGE(IDC_EDIT_PREDICT_IDX_S, &CGloveSamplingDlg::OnEnChangeEditPredictIdxS)
	ON_EN_CHANGE(IDC_EDIT_PREDICT_IDX_R, &CGloveSamplingDlg::OnEnChangeEditPredictIdxR)
	ON_BN_CLICKED(IDC_BUTTON_PREDICT_TRAINING_FILE, &CGloveSamplingDlg::OnBnClickedButtonPredictTrainingFile)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_MERGE_SRC_FILE, &CGloveSamplingDlg::OnBnClickedButtonBrowseMergeSrcFile)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_MERGE_DEST_FILE, &CGloveSamplingDlg::OnBnClickedButtonBrowseMergeDestFile)
	ON_BN_CLICKED(IDC_BUTTON_MERGE, &CGloveSamplingDlg::OnBnClickedButtonMerge)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_REDUNDANCY_ELIMINATION_SRC_FILE, &CGloveSamplingDlg::OnBnClickedButtonBrowseRedundancyEliminationSrcFile)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_REDUNDANCY_ELIMINATION_DEST_FILE, &CGloveSamplingDlg::OnBnClickedButtonBrowseRedundancyEliminationDestFile)
	ON_BN_CLICKED(IDC_BUTTON_ELIMINATE_REDUNDANCY, &CGloveSamplingDlg::OnBnClickedButtonEliminateRedundancy)
	ON_BN_CLICKED(IDC_BUTTON_PLOT_GLV, &CGloveSamplingDlg::OnBnClickedButtonPlotGlv)
	ON_BN_CLICKED(IDC_BUTTON_TRAIN, &CGloveSamplingDlg::OnBnClickedButtonTrain)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_TRAINED, &CGloveSamplingDlg::OnBnClickedButtonLoadTrained)
	ON_BN_CLICKED(IDC_BUTTON_AVERAGE, &CGloveSamplingDlg::OnBnClickedButtonAverage)
	ON_BN_CLICKED(IDC_BUTTON_PLOT_IDX, &CGloveSamplingDlg::OnBnClickedButtonPlotIdx)
	ON_BN_CLICKED(IDC_BUTTON_ELIMINATE_INPUT_REDUNDANCY, &CGloveSamplingDlg::OnBnClickedButtonEliminateInputRedundancy)
	ON_BN_CLICKED(IDC_BUTTON_BATCH_WSPATH, &CGloveSamplingDlg::OnBnClickedButtonBatchWspath)
	ON_BN_CLICKED(IDC_BUTTON_CREATE_TR_FOLDER, &CGloveSamplingDlg::OnBnClickedButtonCreateTrFolder)
	ON_BN_CLICKED(IDC_BUTTON_BATCH_RE_CALIBRATE, &CGloveSamplingDlg::OnBnClickedButtonBatchReCalibrate)
	ON_BN_CLICKED(IDC_BUTTON_BATCH_GPR_FULL, &CGloveSamplingDlg::OnBnClickedButtonBatchGprFull)
	ON_BN_CLICKED(IDC_BUTTON_BATCH_GPR_FITC, &CGloveSamplingDlg::OnBnClickedButtonBatchGprFitc)
	ON_BN_CLICKED(IDC_BUTTON_BATCH_ADJUST_WRIST, &CGloveSamplingDlg::OnBnClickedButtonBatchAdjustWrist)
	ON_BN_CLICKED(IDC_BUTTON_BATCH_TO_BVH, &CGloveSamplingDlg::OnBnClickedButtonBatchToBvh)
	ON_BN_CLICKED(IDC_BUTTON_GLV_RAWTIME, &CGloveSamplingDlg::OnBnClickedButtonGlvRawtime)
	ON_BN_CLICKED(IDC_BUTTON_UN_CALIBRATE, &CGloveSamplingDlg::OnBnClickedButtonUnCalibrate)
	ON_BN_CLICKED(IDC_BUTTON_BATCH_UN_CALIBRATE, &CGloveSamplingDlg::OnBnClickedButtonBatchUnCalibrate)
END_MESSAGE_MAP()


// CGloveSamplingDlg message handlers
BOOL CGloveSamplingDlg::OnInitDialog()
{
	CButton* pButton = (CButton*)GetDlgItem(IDC_RADIO_MARKER_PLUS);
	pButton->SetCheck(1);

	pButton = (CButton*)GetDlgItem(IDC_RADIO_MARKER_B);
	pButton->SetCheck(1);

	pButton = (CButton*)GetDlgItem(IDC_RADIO_ANALYSIS_SENSOR);
	pButton->SetCheck(1);

	pButton = (CButton*)GetDlgItem(IDC_RADIO_HOLD_ON);
	pButton->SetCheck(1);

	pButton = (CButton*)GetDlgItem(IDC_RADIO_SCATTER3);
	pButton->SetCheck(1);

	pButton = (CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT);
	pButton->SetCheck(1);

	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SENSOR_TUPLE);
	pEdit->SetWindowText(L"(-35,-35,10)");

	return TRUE;
}


//beg of GLV -> RAW *******************************************************************************************************
void CGloveSamplingDlg::OnBnClickedButtonLoadCalibration()
{
	CFileDialog dlgFile(TRUE, L"Glove Calibration File(*.gcb)|*.gcb", NULL, 4|2, L"Glove Calibration File(*.gcb)|*.gcb||");
	if(IDOK == dlgFile.DoModal())
	{
		char* pPath = GloveUtil::ToChar(dlgFile.GetPathName());
		m_calib.LoadFromFile(pPath);
		delete pPath;
	}
}

void CGloveSamplingDlg::OnBnClickedButtonBrowseGRSPSrcFile()
{	
	CFileDialog dlgFile(TRUE, L"Glove Capture File(*.glv)|*.glv|Raw Kinematic File(*.raw)|*.raw", NULL, 4|2, L"Glove Capture File(*.glv)|*.glv|Raw Kinematic File(*.raw)|*.raw||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\glv\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK == dlgFile.DoModal())
	{
		m_strGRSrcPath_sp = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_GR_SP_SRC_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}
}

void CGloveSamplingDlg::OnBnClickedButtonBrowseGRSPDestFile()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv||");
	//CString strPath =CString(_T(WS_PATH)) + CString(_T("\\raw\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK == dlgFile.DoModal())
	{
		m_strGRDestPath_sp = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_GR_SP_DEST_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}
}
void CGloveSamplingDlg::OnBnClickedButtonGlvRaw()
{
	CGlvClip clipGlv;
	clipGlv.LoadFromFile(m_strGRSrcPath_sp);
	CRawClip clipRaw;
	CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT);
	bool bLeft = pBut->GetCheck();
	clipRaw = GloveUtil::GlvToRaw(clipGlv, bLeft);
	clipRaw.SaveToFile(m_strGRDestPath_sp);
}

void CGloveSamplingDlg::OnBnClickedButtonReCalibrate()
{
	//glv -> glv, glv->raw, raw->raw
	bool bLeft = ((CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT))->GetCheck() == true;
	int iFileType = -1;
	if(m_strGRSrcPath_sp.find(".glv")!=std::string::npos && m_strGRDestPath_sp.find(".glv")!=std::string::npos)
		iFileType = 0;
	if(m_strGRSrcPath_sp.find(".glv")!=std::string::npos && m_strGRDestPath_sp.find(".raw")!=std::string::npos)
		iFileType = 1;
	if(m_strGRSrcPath_sp.find(".raw")!=std::string::npos && m_strGRDestPath_sp.find(".raw")!=std::string::npos)
		iFileType = 2;
	assert(iFileType >= 0);
	if(iFileType < 0)
		return;
	
	if(iFileType ==0)
	{
		CGlvClip clipUncalib, clipCalib;
		clipUncalib.LoadFromFile(m_strGRSrcPath_sp);
		clipCalib = GloveUtil::LinearCalibrateGlvToGlv(clipUncalib, m_calib);
		clipCalib.SaveToFile(m_strGRDestPath_sp);
		return;
	}
	if(iFileType == 1)
	{
		CGlvClip clipUncalib;
		clipUncalib.LoadFromFile(m_strGRSrcPath_sp);
		CRawClip clipCalib = GloveUtil::LinearCalibrateGlvToRaw(clipUncalib, m_calib, bLeft);
		clipCalib.SaveToFile(m_strGRDestPath_sp);
		return;
	}
	if(iFileType == 2)
	{
		CRawClip clipUncalib, clipCalib;
		clipUncalib.LoadFromFile(m_strGRSrcPath_sp);
		clipCalib = GloveUtil::LinearCalibrateRawToRaw(clipUncalib, m_calib, bLeft);
		clipCalib.SaveToFile(m_strGRDestPath_sp);
		return;
	}

	/*CGlvClip clipUncalib, clipCalib;
	clipUncalib.LoadFromFile(m_strGRSrcPath_sp);
	clipCalib.m_fBaseTime = clipUncalib.m_fBaseTime;
	clipCalib.m_fIntervalTime = clipUncalib.m_fIntervalTime;

	for(int i = 0; i < clipUncalib.GetFrameCount(); ++i)
	{
		CGlvFrame frmUncalib = clipUncalib.m_arFrame[i];
		CGlvFrame frmCalib = frmUncalib;

		assert(m_calib.m_arAdjustItem.size() == frmUncalib.m_arData.size());
		for(int j = 0; j < frmUncalib.m_arData.size(); ++j)
		{
			CGloveCalibrationItem item = m_calib.m_arAdjustItem[j];
			frmCalib.m_arData[j] = item.m_fGain *(frmUncalib.m_arData[j] + item.m_fOffset);
		}
		clipCalib.m_arFrame.push_back(frmCalib);
	}
	clipCalib.SaveToFile(m_strGRDestPath_sp);*/
}

void CGloveSamplingDlg::OnBnClickedButtonUnCalibrate()
{
	//glv -> glv, glv->raw, raw->raw
	bool bLeft = ((CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT))->GetCheck() == true;
	int iFileType = -1;
	if(m_strGRSrcPath_sp.find(".glv")!=std::string::npos && m_strGRDestPath_sp.find(".glv")!=std::string::npos)
		iFileType = 0;
	if(m_strGRSrcPath_sp.find(".glv")!=std::string::npos && m_strGRDestPath_sp.find(".raw")!=std::string::npos)
		iFileType = 1;
	if(m_strGRSrcPath_sp.find(".raw")!=std::string::npos && m_strGRDestPath_sp.find(".raw")!=std::string::npos)
		iFileType = 2;
	assert(iFileType >= 0);
	if(iFileType < 0)
		return;
	
	if(iFileType == 2)
	{
		CRawClip clipUncalib, clipCalib;
		clipUncalib.LoadFromFile(m_strGRSrcPath_sp);
		clipCalib = GloveUtil::LinearUnCalibrateRawToRaw(clipUncalib, m_calib, bLeft);
		clipCalib.SaveToFile(m_strGRDestPath_sp);
		return;
	}
	return;

	if(iFileType ==0)//do not support
	{
		return;
		CGlvClip clipUncalib, clipCalib;
		clipUncalib.LoadFromFile(m_strGRSrcPath_sp);
		clipCalib = GloveUtil::LinearCalibrateGlvToGlv(clipUncalib, m_calib);
		clipCalib.SaveToFile(m_strGRDestPath_sp);
		return;
	}
	if(iFileType == 1)//do not support
	{
		return;
		CGlvClip clipUncalib;
		clipUncalib.LoadFromFile(m_strGRSrcPath_sp);
		CRawClip clipCalib = GloveUtil::LinearCalibrateGlvToRaw(clipUncalib, m_calib, bLeft);
		clipCalib.SaveToFile(m_strGRDestPath_sp);
		return;
	}

}

void CGloveSamplingDlg::OnBnClickedButtonVariance()
{
	CString strIdx;
	GetDlgItem(IDC_EDIT_VARIANCE_IDX)->GetWindowTextW(strIdx);
	int iIdx = _wtoi(strIdx.GetBuffer());

	double fMaxVariance = 0;
	double fStdDeviation = 0;
	double fMaxDeviation = 0;
	if(m_strGRSrcPath_sp.find(".glv")!=std::string::npos)
	{
		CGlvClip clipSrc; 
		clipSrc.LoadFromFile(m_strGRSrcPath_sp);
		
		fMaxVariance = clipSrc.GetMaxVariance(iIdx);
		fMaxVariance = GloveUtil::RadianToDegree(fMaxVariance);
		
		fStdDeviation = clipSrc.GetStandardDeviation(iIdx);
		fStdDeviation = GloveUtil::RadianToDegree(fStdDeviation);
		
		fMaxDeviation = clipSrc.GetMaxDeviation(iIdx);
		fMaxDeviation = GloveUtil::RadianToDegree(fMaxDeviation);
	}
	else if(m_strGRSrcPath_sp.find(".raw")!=std::string::npos)
	{
		CRawClip clipSrc; 
		clipSrc.LoadFromFile(m_strGRSrcPath_sp);
		
		fMaxVariance = clipSrc.GetMaxVariance(iIdx);		
		fStdDeviation = clipSrc.GetStandardDeviation(iIdx);		
		fMaxDeviation = clipSrc.GetMaxDeviation(iIdx);
	}

	char arResult[500];
	sprintf(arResult, "Data %d STDDeviation = %f; MAXDeviation = %f; MAXVariance = %f", iIdx, fStdDeviation, fMaxDeviation, fMaxVariance);
	CString strMaxVariance(arResult);
	::MessageBox(NULL, strMaxVariance, L"Variance", MB_OK);
}
void CGloveSamplingDlg::OnBnClickedButtonAverage()
{
	CString strIdx;
	GetDlgItem(IDC_EDIT_VARIANCE_IDX)->GetWindowTextW(strIdx);
	int iIdx = _wtoi(strIdx.GetBuffer());

	double fAverage = 0;
	if(m_strGRSrcPath_sp.find(".glv")!=std::string::npos)
	{
		CGlvClip clipSrc; 
		clipSrc.LoadFromFile(m_strGRSrcPath_sp);
		
		fAverage = clipSrc.GetMean(iIdx);
		fAverage = GloveUtil::RadianToDegree(fAverage);
	}
	else if(m_strGRSrcPath_sp.find(".raw")!=std::string::npos)
	{
		CRawClip clipSrc; 
		clipSrc.LoadFromFile(m_strGRSrcPath_sp);
		
		fAverage = clipSrc.GetMean(iIdx);
	}

	char arResult[500];
	sprintf(arResult, "Data %d average = %f degree;", iIdx, fAverage);
	CString strAverage(arResult);
	::MessageBox(NULL, strAverage, L"Average", MB_OK);
}

void CGloveSamplingDlg::OnBnClickedButtonPlotGlv()
{
	if(m_strGRSrcPath_sp.find(".glv")!=std::string::npos)
	{
		CGlvClip clipSrc; 
		clipSrc.LoadFromFile(m_strGRSrcPath_sp);
		MatlabUtil::PlotGlvClip(clipSrc);
	}
	else if(m_strGRSrcPath_sp.find(".raw")!=std::string::npos)
	{
		CRawClip clipSrc; 
		clipSrc.LoadFromFile(m_strGRSrcPath_sp);
		MatlabUtil::PlotRawClip(clipSrc);
	}
}
//end of GLV -> RAW ********************************************************************************************************
//beg of FK RAW -> TR *******************************************************************************************************
void CGloveSamplingDlg::OnEnChangeEditFKTRIdx()
{
	CString strSampleToTrIndex;
	GetDlgItem(IDC_EDIT_TR_FK_IDX)->GetWindowText(strSampleToTrIndex);
	m_iFKSp2TrIndex = _wtoi(strSampleToTrIndex.GetBuffer());
}
void CGloveSamplingDlg::OnEnChangeEditTrFkValueR()
{
	CString strFKValue_r;
	GetDlgItem(IDC_EDIT_TR_FK_VALUE_R)->GetWindowText(strFKValue_r);
	m_fFKSp2TrValue_r = _wtof(strFKValue_r.GetBuffer());
}

void CGloveSamplingDlg::OnBnClickedCheckFkUseValueR()
{
	m_bUseFKValue_r = ((CButton*)GetDlgItem(IDC_CHECK_FK_USE_VALUE_R))->GetCheck();
}

void CGloveSamplingDlg::OnBnClickedButtonBrowseFKSPFile()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\fk\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK == dlgFile.DoModal())
	{
		m_strFKPath_sp = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FK_SP_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}	
}

void CGloveSamplingDlg::OnBnClickedButtonFKPoseFile()
{
	CFileDialog dlgFile(TRUE, L"Glove Pose File(*.gfm)|*.gfm", NULL, 4|2, L"Glove Pose File(*.gfm)|*.gfm||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\fk\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK == dlgFile.DoModal())
	{
		m_strFKPosePath_sp = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FK_POSE_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}			
}

void CGloveSamplingDlg::OnBnClickedButtonBswFKTRFile()
{
	//CString strPreprocessedPath = CString(_T(WS_PATH)) + CString(_T("\\trainingset\\"));
	CFileDialog dlgFile(TRUE, L"Trainingset degree file(*.tr)|*.tr", NULL, 4|2, L"Trainingset degree file(*.tr)|*.tr||");
	//dlgFile.m_ofn.lpstrInitialDir = strPreprocessedPath;

	if(IDOK == dlgFile.DoModal())
	{
		m_strFKPath_tr = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FK_TR_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}
}

void CGloveSamplingDlg::OnBnClickedButtonFK2TR()
{
	CRawClip clipSampledFK;
	clipSampledFK.LoadFromFile(m_strFKPath_sp);
	CGlvFrame frmGlvPose;
	CRawFrame frmRawPose;
	if(!m_bUseFKValue_r)
	{
		frmGlvPose.LoadFromFile(m_strFKPosePath_sp);
		CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT);
		bool bLeft = pBut->GetCheck();
		frmRawPose = GloveUtil::GlvToRaw(frmGlvPose, bLeft);
	}
	std::ofstream fout(m_strFKPath_tr.c_str());
	string strToken = " ";

	for(int i = 0; i < clipSampledFK.GetFrameCount(); ++i)
	{
		CRawFrame frmSampledFK = clipSampledFK.m_arFrame[i];

		fout <<frmSampledFK.m_arData[m_iFKSp2TrIndex] << strToken;
		if(m_bUseFKValue_r)
			fout << m_fFKSp2TrValue_r << endl;
		else
			fout << frmRawPose.m_arData[m_iFKSp2TrIndex] << endl;
	}
	fout.flush();
	fout.close();
}
//end of FK RAW -> TR ******************************************************************************************************
//beg of CC RAW -> TR ******************************************************************************************************
void CGloveSamplingDlg::OnBnClickedButtonBrowseCCSPFile()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\fk\\cc\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK == dlgFile.DoModal())
	{
		m_strCCPath_sp = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_CC_SP_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}
}
void CGloveSamplingDlg::OnBnClickedButtonBswCCTRFile()
{
	//CString strPreprocessedPath = CString(_T(WS_PATH)) + CString(_T("\\trainingset\\"));
	CFileDialog dlgFile(TRUE, L"Trainingset degree file(*.tr)|*.tr", NULL, 4|2, L"Trainingset degree file(*.tr)|*.tr||");
	//dlgFile.m_ofn.lpstrInitialDir = strPreprocessedPath;

	if(IDOK == dlgFile.DoModal())
	{
		m_strCCPath_tr = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_CC_TR_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}
}
void CGloveSamplingDlg::OnEnChangeEditTrCcIdx()
{
	m_arCCSp2TrIndex_s.clear();

	CString strSampleToTrIndex_s;
	GetDlgItem(IDC_EDIT_TR_CC_IDX)->GetWindowText(strSampleToTrIndex_s);
	int iBeg = 0;
	int iComa = strSampleToTrIndex_s.Find(L",");
	while(iComa != -1)
	{
		CString strIndex_s = strSampleToTrIndex_s.Mid(iBeg, iComa - iBeg);
		strIndex_s.Trim();
		int iIndex_s = _wtoi(strIndex_s.GetBuffer());
		m_arCCSp2TrIndex_s.push_back(iIndex_s);

		iBeg = iComa + 1;
		iComa = strSampleToTrIndex_s.Find(L",", iBeg);
	}
	CString strIndex_s = strSampleToTrIndex_s.Mid(iBeg);
	strIndex_s.Trim();
	int iIndex_s = _wtoi(strIndex_s.GetBuffer());
	m_arCCSp2TrIndex_s.push_back(iIndex_s);
}
void CGloveSamplingDlg::OnEnChangeEditTrCcValueR()
{
	CString strCCValue_r;
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_REAL_ABD);
	pEdit->GetWindowText(strCCValue_r);

	m_fCCSp2TrValue_r = _wtof(strCCValue_r.GetBuffer());
}
void CGloveSamplingDlg::OnBnClickedButtonCC2TR()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT))->GetCheck() == true;
	std::ofstream fout(m_strCCPath_tr.c_str());
	string strToken = " ";
	
	CRawClip clipRaw;
	clipRaw.LoadFromFile(m_strCCPath_sp);

	int iFrameNum = clipRaw.m_arFrame.size();
	for(int j = 0; j < iFrameNum; ++j)
	{
		CRawFrame frameRaw = clipRaw.m_arFrame[j];
		for(int i = 0; i < m_arCCSp2TrIndex_s.size(); ++i)
		{
			int iIndex = m_arCCSp2TrIndex_s[i];
			float fRotationAngle = frameRaw.m_arData[iIndex]; //frameRaw.GetRotationAngle(iIndex, bLeft);
			fout << fRotationAngle << strToken;
		}
		fout << m_fCCSp2TrValue_r << endl;
	}
	fout.flush();
	fout.close();
}
//end of CC RAW -> TR ******************************************************************************************************
//beg of IK RAW -> TR *******************************************************************************************************
void CGloveSamplingDlg::OnEnChangeEditTrIkIdxS()
{
	m_arIKSp2TrIndex_s.clear();

	CString strSampleToTrIndex_s;
	GetDlgItem(IDC_EDIT_TR_IK_IDX_S)->GetWindowText(strSampleToTrIndex_s);
	int iBeg = 0;
	int iComa = strSampleToTrIndex_s.Find(L",");
	while(iComa != -1)
	{
		CString strIndex_s = strSampleToTrIndex_s.Mid(iBeg, iComa - iBeg);
		strIndex_s.Trim();
		int iIndex_s = _wtoi(strIndex_s.GetBuffer());
		m_arIKSp2TrIndex_s.push_back(iIndex_s);

		iBeg = iComa + 1;
		iComa = strSampleToTrIndex_s.Find(L",", iBeg);
	}
	CString strIndex_s = strSampleToTrIndex_s.Mid(iBeg);
	strIndex_s.Trim();
	int iIndex_s = _wtoi(strIndex_s.GetBuffer());
	m_arIKSp2TrIndex_s.push_back(iIndex_s);
}
void CGloveSamplingDlg::OnEnChangeEditTrIkIdxR()
{
	CString strSampleToTrIndex_r;
	GetDlgItem(IDC_EDIT_TR_IK_IDX_R)->GetWindowText(strSampleToTrIndex_r);
	m_iIKSp2TrIndex_r = _wtoi(strSampleToTrIndex_r.GetBuffer());
}

void CGloveSamplingDlg::OnBnClickedButtonBrowseIKSPFile()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\ik\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK == dlgFile.DoModal())
	{
		m_strIKPath_sp = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_IK_SP_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}	
}

void CGloveSamplingDlg::OnBnClickedButtonIKSPClosedFile()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\ik\\closed"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();
	if(IDOK == dlgFile.DoModal())
	{
		m_strClosedIKPath_sp = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_IK_SP_CLOSED_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}				
}
void CGloveSamplingDlg::OnBnClickedButtonBswIKTRFile()
{
	//CString strPreprocessedPath = CString(_T(WS_PATH)) + CString(_T("\\trainingset\\"));
	CFileDialog dlgFile(TRUE, L"Trainingset degree file(*.tr)|*.tr", NULL, 4|2, L"Trainingset degree file(*.tr)|*.tr||");
	//dlgFile.m_ofn.lpstrInitialDir = strPreprocessedPath;

	if(IDOK == dlgFile.DoModal())
	{
		m_strIKPath_tr = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_IK_TR_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}
}
void CGloveSamplingDlg::OnBnClickedButtonPlotIdx()
{
	CRawClip clipClosed;
	clipClosed.LoadFromFile(m_strClosedIKPath_sp);	
	CRawClip clipUnclosed;
	clipUnclosed.LoadFromFile(m_strIKPath_sp);

	MatlabUtil::PlotPair(clipUnclosed, m_arIKSp2TrIndex_s[0], clipClosed, m_iIKSp2TrIndex_r);
}
void CGloveSamplingDlg::OnBnClickedButtonIK2TR()
{
	bool bLeft = ((CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT))->GetCheck() == true;

	CRawClip clipSampledIK;
	clipSampledIK.LoadFromFile(m_strIKPath_sp);
	CRawClip clipClosedIK;	
	clipClosedIK.LoadFromFile(m_strClosedIKPath_sp);
	assert(clipSampledIK.GetFrameCount() == clipClosedIK.GetFrameCount());

	std::ofstream fout(m_strIKPath_tr.c_str());
	string strToken = " ";

	for(int i = 0; i < clipSampledIK.GetFrameCount(); ++i)
	{
		CRawFrame frmSampledIK = clipSampledIK.m_arFrame[i];
		CRawFrame frmClosedIK = clipClosedIK.m_arFrame[i];
		
		for(int j = 0; j < m_arIKSp2TrIndex_s.size(); ++j)
		{
			int iIdx_s = m_arIKSp2TrIndex_s[j];
			float fRotationAngle = frmSampledIK.m_arData[iIdx_s];//frmSampledIK.GetRotationAngle(iIdx_s, bLeft);
			fout <<fRotationAngle << strToken;
		}
		float fRotationAngle = frmClosedIK.m_arData[m_iIKSp2TrIndex_r];//frmClosedIK.GetRotationAngle(m_iIKSp2TrIndex_r, bLeft);
		fout << fRotationAngle << endl;
	}
	fout.flush();
	fout.close();
}

//end of IK RAW -> TR *******************************************************************************************************
//begin of PREDICT RAW + TR/MAT -> RAW****************************************************************************************
void CGloveSamplingDlg::OnBnClickedButtonBrowseSrcToPredictFile()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw||");
	//CString strPath = CString(_T(WS_PATH));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();

	if(IDOK == dlgFile.DoModal())
	{
		m_strSrcToPredictPath = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SRC_TO_PREDICT_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}
}
void CGloveSamplingDlg::OnBnClickedButtonDestPredictedFile()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw||");
	//CString strPath = CString(_T(WS_PATH));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();

	if(IDOK == dlgFile.DoModal())
	{
		m_strDestPredictedPath = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_DEST_PREDICTED_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}
}
void CGloveSamplingDlg::OnBnClickedButtonPredictedMatFile()
{
	CFileDialog dlgFile(TRUE, L"Predicted Mat File(*.mat)|*.mat", NULL, 4|2, L"Predicted Mat File(*.mat)|*.mat||");
	//CString strPath = CString(_T(WS_PATH));
	//dlgFile.m_ofn.lpstrInitialDir =strPath.GetBuffer();

	if(IDOK == dlgFile.DoModal())
	{
		m_strPredictedMatPath = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_PREDICTED_MAT_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}
}

void CGloveSamplingDlg::OnBnClickedButtonPredictTrainingFile()
{	
	CFileDialog dlgFile(TRUE, L"Trainingset degree file(*.tr)|*.tr", NULL,  OFN_ALLOWMULTISELECT|4|2, L"Trainingset degree file(*.tr)|*.tr||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\trainingset\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();

	if(IDOK == dlgFile.DoModal())
	{
		m_arPredictTrainingPath.clear();
		CString strAllNames = L"";

		 POSITION pos = dlgFile.GetStartPosition();
		 while(pos != NULL)
		 {
			 CString strName = dlgFile.GetNextPathName(pos);
			 strAllNames += strName;
			 std::string strFileName = GloveUtil::ToChar(strName);
			 m_arPredictTrainingPath.push_back(strFileName);
		 }

		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_PREDICT_TRAINING_FILE); 
		pEdit->SetWindowText(strAllNames);
	}
}
void CGloveSamplingDlg::OnEnChangeEditPredictIdxS()
{
	m_arPredictIndex_s.clear();

	CString strPredictIndex_s;
	GetDlgItem(IDC_EDIT_PREDICT_IDX_S)->GetWindowText(strPredictIndex_s);
	int iBeg = 0;
	int iComa = strPredictIndex_s.Find(L",");
	while(iComa != -1)
	{
		CString strIndex_s = strPredictIndex_s.Mid(iBeg, iComa - iBeg);
		strIndex_s.Trim();
		int iIndex_s = _wtoi(strIndex_s.GetBuffer());
		m_arPredictIndex_s.push_back(iIndex_s);

		iBeg = iComa + 1;
		iComa = strPredictIndex_s.Find(L",", iBeg);
	}
	CString strIndex_s = strPredictIndex_s.Mid(iBeg);
	strIndex_s.Trim();
	int iIndex_s = _wtoi(strIndex_s.GetBuffer());
	m_arPredictIndex_s.push_back(iIndex_s);
}
void CGloveSamplingDlg::OnEnChangeEditPredictIdxR()
{
	CString strPredictIndex_r;
	GetDlgItem(IDC_EDIT_PREDICT_IDX_R)->GetWindowText(strPredictIndex_r);
	m_iPredictIndex_r = _wtoi(strPredictIndex_r.GetBuffer());
}
void CGloveSamplingDlg::OnBnClickedButtonPredictAbdByDelaunay()
{
	CRawClip clipTrainingset;
	for(int i = 0; i < m_arPredictTrainingPath.size(); ++i)
	{
		CRawClip clipOne;
		clipOne.LoadFromFile(m_arPredictTrainingPath[i]);
		for(int j = 0; j < clipOne.m_arFrame.size(); ++j)
		{
			CRawFrame frmOne = clipOne.m_arFrame[j];
			clipTrainingset.m_arFrame.push_back(frmOne);
		}
	}
	
	CRawClip clipRawToPredict;
	clipRawToPredict.LoadFromFile(m_strSrcToPredictPath);
	for(int i = 0; i < clipRawToPredict.m_arFrame.size(); ++i)
	{
		CRawFrame frameToPredict = clipRawToPredict.m_arFrame[i];
		CRawFrame rawTuple;
		for(int j = 0; j < m_arPredictIndex_s.size(); ++j)
		{
			int iIndex_s = m_arPredictIndex_s[j];
			float fRotationAngle = frameToPredict.GetRotationAngle(iIndex_s, true);
			rawTuple.m_arData.push_back(fRotationAngle);
		}
	
		std::vector<CRawFrame> arSimplex;
		CRawFrame barencentricCoord;
		float fPredicted = 0;
		if(m_bByDifference)
			fPredicted = MatlabUtil::TDSearchCrossAbdByDifference(clipTrainingset, rawTuple, arSimplex, barencentricCoord);
		else
			fPredicted = MatlabUtil::TDSearchCrossAbd(clipTrainingset, rawTuple, arSimplex, barencentricCoord);
		
		clipRawToPredict.m_arFrame[i].SetRotationAngle(m_iPredictIndex_r, fPredicted, true);
	}
	clipRawToPredict.SaveToFile(m_strDestPredictedPath);
}

void CGloveSamplingDlg::OnBnClickedFillTargetByMat()
{
	std::vector<double> arPredicted;
	MatlabUtil::LoadPredictedMatFile(m_strPredictedMatPath, arPredicted);	
	CRawClip clipRawToPredict;
	clipRawToPredict.LoadFromFile(m_strSrcToPredictPath);
	assert(arPredicted.size() == clipRawToPredict.m_arFrame.size());
	for(int i = 0; i < clipRawToPredict.m_arFrame.size(); ++i)
	{
		double fPredicted = arPredicted[i];
		if(i<arPredicted.size())
			clipRawToPredict.m_arFrame[i].SetRotationAngle(m_iPredictIndex_r,  fPredicted, true);
	}
	clipRawToPredict.SaveToFile(m_strDestPredictedPath);
}

//end of PREDICT RAW + TR/MAT -> RAW ****************************************************************************************
//begin of MERGE ***********************************************************************************************************
void CGloveSamplingDlg::OnBnClickedButtonBrowseMergeSrcFile()
{
	CFileDialog dlgFile(TRUE, L"file to merge(*.*)|*.*", NULL,  OFN_ALLOWMULTISELECT|4|2, L"file to merge(*.*)|*.*||");
	//CString strPath = CString(_T(WS_PATH));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();

	if(IDOK == dlgFile.DoModal())
	{
		m_arMergePath_src.clear();
		CString strAllNames = L"";

		 POSITION pos = dlgFile.GetStartPosition();
		 while(pos != NULL)
		 {
			 CString strName = dlgFile.GetNextPathName(pos);
			 strAllNames += strName;
			 std::string strFileName = GloveUtil::ToChar(strName);
			 m_arMergePath_src.push_back(strFileName);
		 }

		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MERGE_SRC_FILE); 
		pEdit->SetWindowText(strAllNames);
	}
}

void CGloveSamplingDlg::OnBnClickedButtonBrowseMergeDestFile()
{
	CFileDialog dlgFile(TRUE, L"merged location(*.*)|*.*", NULL, 4|2, L"merged location(*.*)|*.*||");
	//CString strPath = CString(_T(WS_PATH));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();

	if(IDOK == dlgFile.DoModal())
	{
		m_strMergePath_dest = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_MERGE_DEST_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}	
}
void CGloveSamplingDlg::OnBnClickedButtonMerge()
{
	CRawClip clipMerged;
	for(int i = 0; i < m_arMergePath_src.size(); ++i)
	{
		CRawClip clipFile;
		clipFile.LoadFromFile(m_arMergePath_src[i]);
		clipMerged.MergeWith(clipFile);
	}

	bool bNoRedu = ((CButton*)GetDlgItem(IDC_CHECK_MERGE_NR))->GetCheck() == true;
	if(bNoRedu)
		clipMerged.EliminateRedundancy();

	clipMerged.SaveToFile(m_strMergePath_dest);
}
//this is not used
void CGloveSamplingDlg::OnBnClickedButtonMergeCcSp()
{
	/*string strDir;
	int iLeftFlex = 0, iRightFlex = 0, iAbd = 0;
	switch(m_eAbdType)
	{
	case MatlabUtil::E_THUMB_INDEX: 
		iLeftFlex = HAND_SKEL_DOF_THUMB_ROLL; iRightFlex = HAND_SKEL_DOF_THUMB_FLEX_PROX; iAbd = HAND_SKEL_DOF_THUMB_ABD; 
		break;
	case MatlabUtil::E_INDEX_MID:
		iLeftFlex = HAND_SKEL_DOF_INDEX_FLEX_PROX; iRightFlex = HAND_SKEL_DOF_MID_FLEX_PROX; iAbd = HAND_SKEL_DOF_INDEX_ABD; 
		break;
	case MatlabUtil::E_MID_RING:
		iLeftFlex =HAND_SKEL_DOF_MID_FLEX_PROX; iRightFlex = HAND_SKEL_DOF_RING_FLEX_PROX; iAbd = HAND_SKEL_DOF_RING_ABD; 
		break;
	case MatlabUtil::E_RING_PINKY:
		iLeftFlex =HAND_SKEL_DOF_RING_FLEX_PROX; iRightFlex =HAND_SKEL_DOF_PINKY_FLEX_PROX; iAbd = HAND_SKEL_DOF_PINKY_ABD; 
		break;
	}
	
	CString strDirDir(strDir.c_str());
	if(PathFileExists(strDirDir) == FALSE)
		CreateDirectory(strDirDir, NULL);	
	
	string strPath; 
	strPath.append(strDir); strPath.append("\\");
	strPath.append(strDir); strPath.append(".tr");

	std::ofstream fout(strPath.c_str());
	string strToken = "	";

	for(int i = 0; i < m_arCrossCoupledPath_sp.size(); ++i)
	{
		string strPath_i = m_arCrossCoupledPath_sp[i];
		CRawClip clipRaw;
		clipRaw.LoadFromFile(strPath_i);

		string strSubPath;
		strSubPath.assign(strDir);
		strSubPath.append("\\");

		double fRealAbd = 0;
		if(strPath_i.find("-0-")!=-1)
		{
			fRealAbd = 0;
			strSubPath.append("-0.tr");
		}
		else if(strPath_i.find("-10-")!=-1)
		{
			fRealAbd = 10;
			strSubPath.append("-10.tr");
		}
		else if(strPath_i.find("-20-")!=-1)
		{
			fRealAbd = 20;
			strSubPath.append("-20.tr");
		}
		else if(strPath_i.find("-25-")!=-1)
		{
			fRealAbd = 25;
			strSubPath.append("-25.tr");
		}
		else if(strPath_i.find("-30-")!=-1)
		{
			fRealAbd = 30;
			strSubPath.append("-30.tr");
		}
		else if(strPath_i.find("-40-")!=-1)
		{
			fRealAbd = 40;
			strSubPath.append("-40.tr");
		}
		else if(strPath_i.find("test")!=-1)
		{
			fRealAbd = -100;
			strSubPath.append("index_abd_testdata.tr");
		}
		std::ofstream foutSub(strSubPath.c_str());

		int iFrameNum = clipRaw.m_arFrame.size();
		for(int j = 0; j < iFrameNum; ++j)
		{
			CRawFrame frameRaw = clipRaw.m_arFrame[j];
			float fAbd = 0;//frameRaw.GetAbductionAngle((E_ABDUCTION_TYPE)m_eAbdType, true);
			
			fout << frameRaw.m_arData[iLeftFlex] << strToken
				<< frameRaw.m_arData[iRightFlex] << strToken
				<< fAbd << strToken
				<< fRealAbd << endl;

			foutSub << frameRaw.m_arData[iLeftFlex] << strToken
				<< frameRaw.m_arData[iRightFlex] << strToken
				<< fAbd<< strToken
				<< fRealAbd << endl;
		}
		foutSub.flush();
		foutSub.close();
	}
	fout.flush();
	fout.close();*/
}
//end of MERGE ************************************************************************************************************
//begin of REDUNDANCY-ELIMINATION *********************************************************************************************************
void CGloveSamplingDlg::OnBnClickedButtonBrowseRedundancyEliminationSrcFile()
{
	CFileDialog dlgFile(TRUE, L"merged location(*.*)|*.*", NULL, 4|2, L"merged location(*.*)|*.*||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();

	if(IDOK == dlgFile.DoModal())
	{
		m_strRedundantPath_src = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_REDUNDANCY_ELIMINATION_SRC_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}
}

void CGloveSamplingDlg::OnBnClickedButtonBrowseRedundancyEliminationDestFile()
{
	CFileDialog dlgFile(FALSE, L"merged location(*.*)|*.*", NULL, 4|2, L"merged location(*.*)|*.*||");
	//CString strPath = CString(_T(WS_PATH)) + CString(_T("\\raw\\"));
	//dlgFile.m_ofn.lpstrInitialDir = strPath.GetBuffer();

	if(IDOK == dlgFile.DoModal())
	{
		m_strNoRedundantPath_dest = GloveUtil::ToChar(dlgFile.GetPathName());
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_REDUNDANCY_ELIMINATION_DEST_FILE); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}
}

void CGloveSamplingDlg::OnBnClickedButtonEliminateRedundancy()
{
	CRawClip clipRedundant;
	clipRedundant.LoadFromFile(m_strRedundantPath_src);
	clipRedundant.EliminateRedundancy();
	clipRedundant.SaveToFile(m_strNoRedundantPath_dest);
}
void CGloveSamplingDlg::OnBnClickedButtonEliminateInputRedundancy()
{
	CRawClip clipRedundant;
	clipRedundant.LoadFromFile(m_strRedundantPath_src);
	clipRedundant.EliminateInputRedundancy();
	clipRedundant.SaveToFile(m_strNoRedundantPath_dest);
}
//end of REDUNDANCY-ELIMINATION **********************************************************************************************************
//Others ***********************************************************************************************************
/*c*/void CGloveSamplingDlg::OnBnClickedButtonPlotSensorReadingFile()
{
	CRawClip clipRaw;

	//plot
	if(m_eShowWhat == ePlot)
	{
		if(m_bByDifference)
			MatlabUtil::PlotCrossAbdByDifference(clipRaw, m_fCCSp2TrValue_r, m_cMarkerType, m_cMarkerColor, m_bNewFigure, true);
		else
			MatlabUtil::PlotCrossAbd(clipRaw, m_cMarkerType, m_cMarkerColor, m_bNewFigure, true);
	}
	//scatter
	if(m_eShowWhat == eScatter)
	{
		if(m_bByDifference)
			MatlabUtil::PlotCrossAbdByDifference(clipRaw, m_fCCSp2TrValue_r, m_cMarkerType, m_cMarkerColor, m_bNewFigure, false);
		else
			MatlabUtil::PlotCrossAbd(clipRaw, m_cMarkerType, m_cMarkerColor, m_bNewFigure, false);
	}
	//griddata
	if(m_eShowWhat == eGriddata)
	{
			if(m_bByDifference)
			MatlabUtil::GriddataCrossAbdByDifference(clipRaw);
		else
			MatlabUtil::GriddataCrossAbd(clipRaw);
	}
	//delaunay
	if(m_eShowWhat == eDelaunay)
	{
		if(m_bByDifference)
			MatlabUtil::DelaunayCrossAbdByDifference(clipRaw);
		else
			MatlabUtil::DelaunayCrossAbd(clipRaw);
	}
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioMarkerO()
{
	m_cMarkerType = 'o';
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioMarkerd()
{
	m_cMarkerType = 'd';
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioMarkerdot()
{
	m_cMarkerType = '.';
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioMarkerX()
{
	m_cMarkerType = 'x';
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioMarkerPlus()
{
	m_cMarkerType = '+';
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioMarkerM()
{
	m_cMarkerColor = 'm';
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioMarkerR()
{
	m_cMarkerColor = 'r';
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioMarkerY()
{
	m_cMarkerColor = 'y';
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioMarkerG()
{
	m_cMarkerColor = 'g';
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioMarkerC()
{
	m_cMarkerColor = 'c';
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioMarkerB()
{
	m_cMarkerColor = 'b';
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioMarkerK()
{
	m_cMarkerColor = 'k';
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioAnalysisSensor()
{
	m_bByDifference = false;
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioAnalysisDifference()
{
	m_bByDifference = true;
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioNewFigure()
{
	m_bNewFigure = true;
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioHoldOn()
{
	m_bNewFigure = false;
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioPlot3()
{
	m_eShowWhat = ePlot;
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioScatter3()
{
	m_eShowWhat = eScatter;
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioGriddata()
{
	m_eShowWhat = eGriddata;
}

/*c*/void CGloveSamplingDlg::OnBnClickedRadioDelaunay()
{
	m_eShowWhat = eDelaunay;
}

/*c*/void CGloveSamplingDlg::OnBnClickedButtonCalculateRealAbd()
{	
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SENSOR_TUPLE);
	CString strTuple;
	pEdit->GetWindowText(strTuple);
	CKinematicPoint ptTuple(strTuple.GetBuffer());

	//MatlabUtil::Test1();	
	//MatlabUtil::Test2();

	//========================================
	//call matlab
	CRawFrame rawTuple;
	rawTuple.m_arData.push_back(ptTuple.m_fX);
	rawTuple.m_arData.push_back(ptTuple.m_fY);
	rawTuple.m_arData.push_back(ptTuple.m_fZ);
	CRawClip clipRaw;
//	CombineClip(m_arCrossCoupledPath_sp, m_eAbdType, clipRaw);
	std::vector<CRawFrame> arSimplex;
	CRawFrame barencentricCoord;
	double fAbdRealSearched = 0;
	if(m_bByDifference)
		fAbdRealSearched = MatlabUtil::TDSearchCrossAbdByDifference(clipRaw, rawTuple, arSimplex, barencentricCoord);
	else
		fAbdRealSearched = MatlabUtil::TDSearchCrossAbd(clipRaw, rawTuple, arSimplex, barencentricCoord);
	
	//update results from matlab
	CString strResult = L"Simplex vertice:\r\n";
	for(int i = 0; i < arSimplex.size(); ++i)
	{
		CRawFrame frameSimplex = arSimplex[i];
		char strSimplex[100];
		for(int j =0; j < frameSimplex.m_arData.size(); ++j)
		{
			if(j==0)
				sprintf(strSimplex, "(%.2f", frameSimplex.m_arData[j]);
			else if(j==frameSimplex.m_arData.size()-1)
				sprintf(strSimplex, ",%.2f)\r\n", frameSimplex.m_arData[j]);
			else
				sprintf(strSimplex, ",%.2f", frameSimplex.m_arData[j]);
			CString strSimp(strSimplex);
			strResult += strSimp;
		}
	}	
	for(int i = 0; i < barencentricCoord.m_arData.size(); ++i)
	{
		char strBCoord[100];
		if(i==0)
			sprintf(strBCoord, "(%.2f", barencentricCoord.m_arData[i]);
		else if(i==barencentricCoord.m_arData.size()-1)
			sprintf(strBCoord, ",%.2f)\r\n", barencentricCoord.m_arData[i]);
		else
			sprintf(strBCoord, ",%.2f", barencentricCoord.m_arData[i]);
		CString strB(strBCoord);
		strResult += strB;
	}
	strResult +="calculated abd: ";
	char strRealAbd[20];
	sprintf(strRealAbd, "%f", fAbdRealSearched);
	CString cstrRealAbd(strRealAbd);
	strResult += cstrRealAbd; 

	//calculate real abd
	GetDlgItem(IDC_STATIC_REAL_ABD)->SetWindowText(strResult);
}


#include "shlwapi.h"


















void CGloveSamplingDlg::OnBnClickedButtonTrain()
{
	MatlabUtil::ReTrainAll();
}

void CGloveSamplingDlg::OnBnClickedButtonLoadTrained()
{
	MatlabUtil::LoadTrained();
}
void CGloveSamplingDlg::OnBnClickedButtonBatchWspath()
{
	/*CString strGlvBase(_T(WS_PATH));
	strGlvBase = strGlvBase + L"\\glv";
	CString strRawBase(_T(WS_PATH));
	strRawBase = strRawBase + L"\\raw";

	BatchUnder(strGlvBase + L"\\left", strRawBase + L"\\left", true);
	//BatchUnder(strGlvBase + L"\\right", strRawBase + L"\\right", false);*/
	CString strSrc(m_strGRSrcPath_sp.c_str());
	CString strDest(m_strGRDestPath_sp.c_str());
	int iSepSrc = strSrc.ReverseFind('\\');
	int iSepDest = strDest.ReverseFind('\\');
	strSrc = strSrc.Left(iSepSrc);
	strDest = strDest.Left(iSepDest);
	bool bLeft = ((CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT))->GetCheck() == true;
	GloveUtil::BatchGlvToRawUnder(strSrc, strDest, bLeft);	
}


void CGloveSamplingDlg::OnBnClickedButtonCreateTrFolder()
{
	CString strTrBase(m_strGRSrcPath_sp.c_str());
	int iSepSrc = strTrBase.ReverseFind('\\');
	strTrBase = strTrBase.Left(iSepSrc);
	strTrBase = strTrBase + L"\\trainingset";
	bool bLeft = ((CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT))->GetCheck() == true;
	if(bLeft)
		GloveUtil::CreateTrUnder(strTrBase + L"\\left");
	else
		GloveUtil::CreateTrUnder(strTrBase + L"\\right");
}

void CGloveSamplingDlg::OnBnClickedButtonBatchReCalibrate()
{
	CString strSrc(m_strGRSrcPath_sp.c_str());
	CString strDest(m_strGRDestPath_sp.c_str());
	int iSepSrc = strSrc.ReverseFind('\\');
	int iSepDest = strDest.ReverseFind('\\');
	strSrc = strSrc.Left(iSepSrc);
	strDest = strDest.Left(iSepDest);
	bool bLeft = ((CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT))->GetCheck() == true;
	GloveUtil::BatchRecalibUnder(strSrc, strDest, m_calib, bLeft);	
}
void CGloveSamplingDlg::OnBnClickedButtonBatchUnCalibrate()
{
	CString strSrc(m_strGRSrcPath_sp.c_str());
	CString strDest(m_strGRDestPath_sp.c_str());
	int iSepSrc = strSrc.ReverseFind('\\');
	int iSepDest = strDest.ReverseFind('\\');
	strSrc = strSrc.Left(iSepSrc);
	strDest = strDest.Left(iSepDest);
	bool bLeft = ((CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT))->GetCheck() == true;
	GloveUtil::BatchUncalibUnder(strSrc, strDest, m_calib, bLeft);
}
void CGloveSamplingDlg::OnBnClickedButtonBatchGprFull()
{
	CString strSrc(m_strGRSrcPath_sp.c_str());
	CString strDest(m_strGRDestPath_sp.c_str());
	int iSepSrc = strSrc.ReverseFind('\\');
	int iSepDest = strDest.ReverseFind('\\');
	strSrc = strSrc.Left(iSepSrc);
	strDest = strDest.Left(iSepDest);
	bool bLeft = ((CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT))->GetCheck() == true;
	GloveUtil::BatchGPRfullUnder(strSrc, strDest, bLeft);	
}

void CGloveSamplingDlg::OnBnClickedButtonBatchGprFitc()
{
	CString strSrc(m_strGRSrcPath_sp.c_str());
	CString strDest(m_strGRDestPath_sp.c_str());
	int iSepSrc = strSrc.ReverseFind('\\');
	int iSepDest = strDest.ReverseFind('\\');
	strSrc = strSrc.Left(iSepSrc);
	strDest = strDest.Left(iSepDest);
	bool bLeft = ((CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT))->GetCheck() == true;
	GloveUtil::BatchGPRfitcUnder(strSrc, strDest, bLeft);	
}
void CGloveSamplingDlg::OnBnClickedButtonBatchAdjustWrist()
{
	CString strSrc(m_strGRSrcPath_sp.c_str());
	CString strDest(m_strGRDestPath_sp.c_str());
	int iSepSrc = strSrc.ReverseFind('\\');
	int iSepDest = strDest.ReverseFind('\\');
	strSrc = strSrc.Left(iSepSrc);
	strDest = strDest.Left(iSepDest);
	bool bLeft = ((CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT))->GetCheck() == true;
	GloveUtil::BatchWristUnder(strSrc, strDest, bLeft);	
}
void CGloveSamplingDlg::OnBnClickedButtonBatchToBvh()
{
	CString strSrc(m_strGRSrcPath_sp.c_str());
	CString strDest(m_strGRDestPath_sp.c_str());
	int iSepSrc = strSrc.ReverseFind('\\');
	int iSepDest = strDest.ReverseFind('\\');
	strSrc = strSrc.Left(iSepSrc);
	strDest = strDest.Left(iSepDest);
	bool bLeft = ((CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT))->GetCheck() == true;
	GloveUtil::BatchToBvh(strSrc, strDest, bLeft);	
}

void CGloveSamplingDlg::OnBnClickedButtonGlvRawtime()
{
	CGlvClip clipGlv;
	clipGlv.LoadFromFile(m_strGRSrcPath_sp);
	CRawTimeClip clipRawTime;
	CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_HANDNESS_LEFT);
	bool bLeft = pBut->GetCheck();
	clipRawTime = GloveUtil::GlvToRawTime(clipGlv, bLeft);
	std::string strRawTimePath = m_strGRDestPath_sp;
	strRawTimePath.append("t");
	clipRawTime.SaveToFile(strRawTimePath);
}


