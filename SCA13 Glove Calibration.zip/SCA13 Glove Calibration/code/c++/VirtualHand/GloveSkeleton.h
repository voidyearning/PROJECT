#pragma once
#include <vector>

#include "CKinematic\CKinematicHand.h"
#include "RawAnimation.h"
#include "GloveAnimation.h"
#include "IKAnimation.h"

class CHandSkeletonKin
{	
public:
	CHandSkeletonKin();
	CHandSkeletonKin(bool bRightHand);
	~CHandSkeletonKin();

	CKinematicHand* m_pHand;
	bool m_bRightHand;
	float m_fWristAbd;
	float m_fWristFlex;

	void SetActiveFlag(short sActiveFinger);
	void UnsetActiveFlag(short sActiveFinger);
	bool IsFingerActive(short sActiveFinger);	
	double GetActiveProbability(CKinematicPos posEnd);

	void Init();
	void InitMotion();
	void InitMotionLeft();
	void InitMotionRight();

	void UpdateFromSensorData(const std::vector<float>& arSensorData);
	void UpdateToSensorData(std::vector<float>& arSensorData);

	void UpdateFromKinematicData(const std::vector<float>& arKinData);
	void UpdateToKinematicData(std::vector<float>& arKinData);

	void UpdateFromFrame(CBaseFrame* pFrame);
	void UpdateToFrame(CBaseFrame* pFrame);

	//ik help close glv clip, and save to raw clip
	void FingerTouchingSampling(IK_FINGER_TOUCHING_TYPE eTouchingType, CBaseClip* pClipSrc, CBaseClip* pClipDest);
	void FingerTouchingSampling(IK_FINGER_TOUCHING_TYPE eTouchingType, CGlvClip& inputClip, CGlvClip& outputClip);
	void FingerTouchingSampling(IK_FINGER_TOUCHING_TYPE eTouchingType, CRawClip& inputClip, CRawClip& outputClip);
	void FingerTouchingSampling(IK_FINGER_TOUCHING_TYPE eTouchingType, CGlvClip& inputClip, CRawClip& outputClip);
	void FingerTouchingSampling(CIKClip& inputClip, CRawClip& outputClip);

	void FingerTouchingSamplingConcatenated(IK_FINGER_TOUCHING_TYPE eTouchingType, CGlvClip& inputClip, CRawClip& outputClip, std::vector<float>& arGain, std::vector<float>& arOffset);
	void SmoothenFingerTouchingSampling(IK_FINGER_TOUCHING_TYPE eTouchingType, CRawClip& inputClip, CRawClip& outputClip);

	void LoadSizeFromFile(CString strPath);
	void SaveSizeToFile(CString strPath);
	virtual string GetBvhHeader();
	virtual string GetBvhHeaderConsistentWithBody();
	virtual string GetBvhOneFrame();
	virtual string GetASF();

	virtual void ExportTrajectory(CRawClip clipRaw, int iTrjIndex, std::string strPath);
	virtual void ExportTipDistance(CRawClip clipRaw, IK_FINGER_TOUCHING_TYPE eTouchingType, std::string strPath);
	virtual void ExportBvh(CRawClip clipRaw, std::string strPath);
};