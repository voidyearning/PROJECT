#include "stdafx.h"
#include "MarkerAnimation.h"
#include <fstream>
#include "math.h"


CMarkerPosition::CMarkerPosition()
{
	m_fX = 0;
	m_fY = 0;
	m_fZ = 0;
}
CMarkerPosition::CMarkerPosition(float fX, float fY, float fZ)
{
	m_fX = fX;
	m_fY = fY;
	m_fZ = fZ;
}
CMarkerPosition CMarkerPosition::Negate() const
{
	CMarkerPosition posNew(-m_fX, -m_fY, -m_fZ);
	return posNew;
}
CMarkerPosition CMarkerPosition::Multiply(float fCoef) const
{
	CMarkerPosition posNew(m_fX * fCoef, m_fY * fCoef, m_fZ * fCoef);
	return posNew;
}
CMarkerPosition CMarkerPosition::DivideBy(float fCoef) const
{
	if(fCoef == 0)
		return *this;

	CMarkerPosition posNew(m_fX/fCoef, m_fY/fCoef, m_fZ/fCoef);
	return posNew;
}

CMarkerPosition CMarkerPosition::Add(CMarkerPosition posToAdd) const
{
	CMarkerPosition posNew(m_fX + posToAdd.m_fX, m_fY + posToAdd.m_fY, m_fZ + posToAdd.m_fZ);
	return posNew;
}
CMarkerPosition CMarkerPosition::Substract(CMarkerPosition posToSub) const
{
	CMarkerPosition posNew(m_fX - posToSub.m_fX, m_fY - posToSub.m_fY, m_fZ - posToSub.m_fZ);
	return posNew;
}

float CMarkerPosition::DotMul(CMarkerPosition posToMul) const
{
	float fResult = m_fX * posToMul.m_fX + 
		m_fY * posToMul.m_fY + 
		m_fZ * posToMul.m_fZ;
	return fResult;
}
float CMarkerPosition::Cosine(CMarkerPosition vecAnother) const
{
	if(this->vecLength() == 0 ||
		vecAnother.vecLength() == 0)
		return 0;

	float fDotMul = this->DotMul(vecAnother);
	float fCosine = fDotMul / (vecAnother.vecLength() * this->vecLength());
	return fCosine;
}
CMarkerPosition CMarkerPosition::XMul(CMarkerPosition posToMul) const
{
	CMarkerPosition posNew;
	posNew.m_fX = m_fY * posToMul.m_fZ - m_fZ * posToMul.m_fY;
	posNew.m_fY = m_fZ * posToMul.m_fX - m_fX * posToMul.m_fZ;
	posNew.m_fZ = m_fX * posToMul.m_fY - m_fY * posToMul.m_fX;

	return posNew;
}
CMarkerPosition CMarkerPosition::vecNormalize() const
{
	float fLength = vecLength();
	if(fLength == 0)
		return *this;

	CMarkerPosition vecNormalized(m_fX/fLength, m_fY/fLength, m_fZ/fLength);
	return vecNormalized;
}
float CMarkerPosition::vecLength() const
{
	float fLength = m_fX * m_fX + m_fY * m_fY + m_fZ * m_fZ;
	fLength = sqrt(fLength);
	return fLength;
}

CMarkersFrame::CMarkersFrame()
{
	m_fTime = 0;	
}

void CMarkersFrame::MM2CM()
{
	for(int i = 0; i < m_arMarkers.size(); ++i)
	{
		CMarkerPosition pos = m_arMarkers[i];
		CMarkerPosition posNew = pos.Multiply(0.1);
		m_arMarkers[i] = posNew;
	}
}
CMarkersFrame::CMarkersFrame(CString strLine)
{
	strLine.Trim();
	int iComma = strLine.Find(L",");
	CString strTime = strLine.Left(iComma);
	m_fTime = _wtof(strTime.GetBuffer());

	CString strMarkers = strLine.Right(strLine.GetLength() - iComma -1);
	strMarkers.Trim();
	while(strMarkers.GetLength() > 0)
	{
		CMarkerPosition pos;
		iComma = strMarkers.Find(L",");
		CString strX = strMarkers.Left(iComma);
		pos.m_fX = _wtof(strX.GetBuffer());
		strMarkers = strMarkers.Right(strMarkers.GetLength() - iComma -1);
		strMarkers.Trim();

		iComma = strMarkers.Find(L",");
		CString strY = strMarkers.Left(iComma);
		pos.m_fY = _wtof(strY.GetBuffer());
		strMarkers = strMarkers.Right(strMarkers.GetLength() - iComma -1);
		strMarkers.Trim();

		iComma = strMarkers.Find(L",");		
		CString strZ = strMarkers.Left(iComma);
		if(iComma == -1)
			strZ = strMarkers;
		pos.m_fZ = _wtof(strZ.GetBuffer());

		m_arMarkers.push_back(pos);		
		if(iComma == -1)
			break;
		strMarkers = strMarkers.Right(strMarkers.GetLength() - iComma - 1);
		strMarkers.Trim();
	};
}

CMarkersFrame CMarkersFrame::ViconEVTransformCoord()
{
	int iRootIndex = 0;
	int iIndexBaseIndex = 2;
	int iPinkyBaseIndex = 6;

	CMarkerPosition posRoot = m_arMarkers[iRootIndex];
	CMarkerPosition posIndexBase = m_arMarkers[iIndexBaseIndex];
	CMarkerPosition posPinkyBase = m_arMarkers[iPinkyBaseIndex];

	//calculating X-axis
	CMarkerPosition vecI2P(posPinkyBase.m_fX-posIndexBase.m_fX, 
		posPinkyBase.m_fY-posIndexBase.m_fY,
		posPinkyBase.m_fZ-posIndexBase.m_fZ);
	CMarkerPosition vecI2R(posRoot.m_fX-posIndexBase.m_fX,
		posRoot.m_fY-posIndexBase.m_fY,
		posRoot.m_fZ-posIndexBase.m_fZ);
	float fCosineBeta = vecI2P.Cosine(vecI2R);
	float fRadianBeta = acos(fCosineBeta);
	CMarkerPosition vecR2I(posIndexBase.m_fX - posRoot.m_fX, 
		posIndexBase.m_fY - posRoot.m_fY,
		posIndexBase.m_fZ - posRoot.m_fZ);
	CMarkerPosition vecR2P(posPinkyBase.m_fX-posRoot.m_fX,
		posPinkyBase.m_fY - posRoot.m_fY,
		posPinkyBase.m_fZ - posRoot.m_fZ);
	float fCosineAlpha3 = vecR2I.Cosine(vecR2P);
	float fRadianAlpha = acos(fCosineAlpha3) / 3;
	float fRadianExtra = (3.14159265 / 2) - fRadianAlpha - fRadianBeta;
	float fLengthX = vecR2I.vecLength() * sin(fRadianAlpha) / cos(fRadianExtra);
	CMarkerPosition vecI2PNormalized = vecI2P.vecNormalize();
	CMarkerPosition vecI2X = vecI2PNormalized.Multiply(fLengthX);
	CMarkerPosition posX(vecI2X.m_fX + posIndexBase.m_fX, vecI2X.m_fY + posIndexBase.m_fY, vecI2X.m_fZ + posIndexBase.m_fZ);
	CMarkerPosition vecX(posRoot.m_fX - posX.m_fX, posRoot.m_fY - posX.m_fY, posRoot.m_fZ - posX.m_fZ);

	//calculating Z-axis
	CMarkerPosition vecR2X = vecX.Negate();
	float fCosineAlpha = vecR2X.Cosine(vecR2I);
	float fLengthOB = vecR2X.vecLength() / fCosineAlpha;
	CMarkerPosition vecR2INormalized = vecR2I.vecNormalize();
	CMarkerPosition vecR2B = vecR2INormalized.Multiply(fLengthOB);
	CMarkerPosition posB(posRoot.m_fX + vecR2B.m_fX, 
		posRoot.m_fY + vecR2B.m_fY,
		posRoot.m_fZ + vecR2B.m_fZ);
	CMarkerPosition vecZ(posB.m_fX - posX.m_fX, 
		posB.m_fY - posX.m_fY,
		posB.m_fZ - posX.m_fZ);

	//calculating Y-axis
	CMarkerPosition vecY = vecZ.XMul(vecX);

	//normalize
	vecX = vecX.vecNormalize();
	vecY = vecY.vecNormalize();
	vecZ = vecZ.vecNormalize();

	//do the coordinate transformation
	CMarkersFrame frmMarkersNew;
	frmMarkersNew.m_fTime = m_fTime;
	for(int i = 0; i < m_arMarkers.size(); ++i)
	{
		CMarkerPosition posMarker = m_arMarkers[i];
		CMarkerPosition vecR2M(posMarker.m_fX - posRoot.m_fX, posMarker.m_fY - posRoot.m_fY, posMarker.m_fZ - posRoot.m_fZ);
		float fLengthR2M = vecR2M.vecLength();
		float fCosineX = vecX.Cosine(vecR2M);
		float fCosineY = vecY.Cosine(vecR2M);
		float fCosineZ = vecZ.Cosine(vecR2M);
		CMarkerPosition posMarkerNew(fLengthR2M * fCosineX, fLengthR2M * fCosineY, fLengthR2M * fCosineZ);
		frmMarkersNew.m_arMarkers.push_back(posMarkerNew);
	}
	return frmMarkersNew;
}


CMarkersClip::CMarkersClip()
{}
CMarkersClip CMarkersClip::ViconEVTransformCoord()
{
	CMarkersClip clipMarkersNew;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CMarkersFrame frmMarkersNew = m_arFrame[i].ViconEVTransformCoord();
		clipMarkersNew.m_arFrame.push_back(frmMarkersNew);
	}
	return clipMarkersNew;
}

void CMarkersClip::LoadFromFile(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	m_arFrame.clear();
	while(fin.good())
	{
		char buf[1024] = {0};
		fin.getline(buf, sizeof(buf));
		CString strLine(buf);
		strLine.Trim();
		if(strLine.GetLength() == 0)
			break;

		CMarkersFrame frm(strLine);
		m_arFrame.push_back(frm);
	};
	fin.close();
}

void CMarkersClip::SaveToFile(std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CMarkersFrame frm = m_arFrame[i];
		fout << frm.m_fTime;
		for(int j = 0; j < frm.m_arMarkers.size(); ++j)
		{
			CMarkerPosition pos = frm.m_arMarkers[j];
			fout << "," << pos.m_fX << 
				"," << pos.m_fY << 
				"," << pos.m_fZ;
		}
		fout<<std::endl;
	}
	fout.flush();
	fout.close();
}
void CMarkersClip::MM2CM()
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CMarkersFrame frm = m_arFrame[i];
		frm.MM2CM();
		m_arFrame[i] = frm;
	}
}


