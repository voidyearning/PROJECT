#pragma once
#include <vector>
#include <string>
#include "RawAnimation.h"

class CIKFrame : public CBaseFrame
{
public:
	CIKFrame();
	CIKFrame(CRawFrame frmRaw, float x, float y, float z);
	CRawFrame ToRawFrame();
	float DataDistanceToThumb(CIKFrame& frmIK);
	float DataDistanceToThumbHD(CIKFrame& frmIK);
	float GoalDistanceTo(CIKFrame& frmIK);
	bool IsEqualData(CIKFrame& frmIK);
	bool IsEqualGoal(CIKFrame& frmIK);
	float m_fGoalX;
	float m_fGoalY;
	float m_fGoalZ;
};
class CIKClip : public CBaseClip
{
public:
	
	static CIKClip NewFromRawClip(CRawClip& clipRaw, IK_FINGER_TOUCHING_TYPE, bool bLeft = true);
	std::vector<CIKFrame> m_arFrame;
	void SaveToFile(std::string strPath);
	void LoadFromFile(std::string strPath);
	int GetFrameCount();
	CBaseFrame* GetFrameAt(int iFrmIdx);	
	virtual void SetFrameAt(int iFrmIdx, CBaseFrame*);
	CIKClip GetAllDataRedundantClip();
	CIKClip GetAllGoalRedundantClip();
	CIKClip GetDataRedundantClip(CIKFrame& frmIK);
	CIKClip GetGoalRedundantClip(CIKFrame& frmIK);
	CIKClip GetNoDataRedundantClip();
	CIKClip GetNoGoalRedundantClip();
	void CheckIKSampleQuality(float fJointGranularity = 1, float fGoalGranularity = 0.5);
	CRawClip GetRawClip();

	bool HasFrameEqualData(CIKFrame& frmIK);
	bool HasFrameEqualGoal(CIKFrame& frmIK);

	void MergeWith(const CIKClip& clipToMerge);	
	CIKClip GetReorderedClipByThumb(CIKFrame& frmStart);
	CIKClip GetReorderedClipByGoal(CIKFrame& frmStart);

	
	int FindNearestFrameByThumb(CIKFrame& frmIK);
	int FindNearestFrameByGoal(CIKFrame& frmIK);
};