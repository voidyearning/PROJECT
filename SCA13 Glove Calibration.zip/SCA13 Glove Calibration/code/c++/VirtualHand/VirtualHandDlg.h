// VirtualHandDlg.h : header file
//
#pragma once
#include "GloveMocapDlg.h"
#include "GloveEditDlg.h"
#include "GloveMergeDlg.h"
#include "GlovePlayDlg.h"
#include "GloveCalibDlg.h"
#include "GloveSamplingDlg.h"
#include "FastDlg.h"

// CVirtualHandDlg dialog
class CVirtualHandDlg : public CDialog
{
// Construction
public:
	CVirtualHandDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_VIRTUALHAND_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTcnSelchangeTabGlv(NMHDR *pNMHDR, LRESULT *pResult);
	CFastDlg m_dlgFast;
	CGloveSamplingDlg m_dlgSampling;
	CGloveMocapDlg m_dlgMocap;
	CGloveMergeDlg m_dlgMerge;
	CGloveEditDlg m_dlgEdit;
	CGlovePlayDlg m_dlgPlay;
	CGloveCalibDlg 
	//CGlovePlayDlg 
	m_dlgCalib;

	std::string m_strLoadPath;
	afx_msg void OnBnClickedButtonTestKin();
	afx_msg void OnBnClickedButtonLoadFull();
	afx_msg void OnBnClickedButtonLoadFitc();
	afx_msg void OnBnClickedButtonLoadFingerabdFull();
	afx_msg void OnBnClickedButtonSelectBasePath();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButtonLoadLinearGo();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
};
