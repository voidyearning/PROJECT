#pragma once
#include "CRenderer.h"
#include "PtTrajAnimation.h"

class CPtTrajRenderer : public COpenGLRenderer
{
public:
	CPtTrajRenderer();
	CKinematicPoint m_color;
	bool m_bShow;
	bool m_bDiscrete;
	float m_fRenderSize;
	int m_iRenderBegIdx;
	int m_iRenderEndIdx;
	CPtTrajClip m_traj;
	void Render();
};