#include "stdafx.h"
#include "IKAnimation.h"
#include <fstream>
#include "math.h"
#include "CKinematic\CKinematicHand.h"
CIKFrame::CIKFrame()
{
	m_fGoalX = m_fGoalY = m_fGoalZ = 0;
}
CIKFrame::CIKFrame(CRawFrame frmRaw, float x, float y, float z)
{
	for(int i = 0; i < frmRaw.m_arData.size(); ++i)
	{
		m_arData.push_back(frmRaw.m_arData[i]);
	}
	m_fGoalX = x;
	m_fGoalY = y;
	m_fGoalZ = z;
}
CRawFrame CIKFrame::ToRawFrame()
{
	CRawFrame frmRaw(m_arData);
	return frmRaw;
}
float CIKFrame::DataDistanceToThumb(CIKFrame& frmIK)
{
	CRawFrame frmRawThis = ToRawFrame();
	CRawFrame frmRawIK = frmIK.ToRawFrame();
	return frmRawThis.DistanceToThumb(frmRawIK);
}
float CIKFrame::DataDistanceToThumbHD(CIKFrame& frmIK)
{
	CRawFrame frmRawThis = ToRawFrame();
	CRawFrame frmRawIK = frmIK.ToRawFrame();
	return frmRawThis.DistanceToThumbHD(frmRawIK);
}
float CIKFrame::GoalDistanceTo(CIKFrame& frmIK)
{
	float fDist = (frmIK.m_fGoalX - m_fGoalX) * (frmIK.m_fGoalX - m_fGoalX) + 
		(frmIK.m_fGoalY - m_fGoalY) * (frmIK.m_fGoalY - m_fGoalY) + 
		(frmIK.m_fGoalZ - m_fGoalZ) * (frmIK.m_fGoalZ - m_fGoalZ);
	fDist = sqrt(fDist);
	return fDist;
}
bool CIKFrame::IsEqualData(CIKFrame& frmIK)
{
	if(frmIK.m_arData.size() != m_arData.size())
		return false;
	for(int i = 0; i < m_arData.size(); ++i)
	{
		if(m_arData[i] != frmIK.m_arData[i])
			return false;
	}
	return true;
}
bool CIKFrame::IsEqualGoal(CIKFrame& frmIK)
{
	return m_fGoalX == frmIK.m_fGoalX && m_fGoalY == frmIK.m_fGoalY && m_fGoalZ == frmIK.m_fGoalZ;
}


CIKClip CIKClip::NewFromRawClip(CRawClip& clipRaw, IK_FINGER_TOUCHING_TYPE eTouchingType, bool bLeft)
{
	CIKClip clipIK;
	CKinematicHand* pHand;
	if(bLeft)
		pHand = new CKinematicHandLeft();
	else
		pHand = new CKinematicHandRight();
	pHand->ConstructHand();

	CKinematicChain* pFingerChain = NULL;
	switch(eTouchingType)
	{
	case IK_FINGER_TOUCHING_TYPE::eThumbIndex: pFingerChain = pHand->m_arChain[1];
		break;
	case IK_FINGER_TOUCHING_TYPE::eThumbMid: pFingerChain = pHand->m_arChain[2];
		break;
	case IK_FINGER_TOUCHING_TYPE::eThumbRing: pFingerChain = pHand->m_arChain[3];
		break;
	case IK_FINGER_TOUCHING_TYPE::eThumbPinky: pFingerChain = pHand->m_arChain[4];
		break;
	}

	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = clipRaw.m_arFrame[i];
		pHand->UpdateFromKinematicData(frmRaw.m_arData);
		pHand->PopulateGlobalPosAndAxis();
		CKinematicPoint ptGoal = pFingerChain->GetGlobalEndEffectorPos();
		CIKFrame frmIK(frmRaw, ptGoal.m_fX, ptGoal.m_fY, ptGoal.m_fZ);
		clipIK.m_arFrame.push_back(frmIK);
	}
	delete pHand;
	return clipIK;
}
void CIKClip::SaveToFile(std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frm = m_arFrame[i];
		for(int j = 0; j < frm.m_arData.size(); ++j)
		{
			fout << frm.m_arData[j];
			if(j < frm.m_arData.size()-1)
				fout << " ";
		}
		fout << frm.m_fGoalX << " " 
			<< frm.m_fGoalY << " " 
			<< frm.m_fGoalZ;
		fout<<std::endl;
	}
	fout.flush();
	fout.close();
}
void CIKClip::LoadFromFile(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	m_arFrame.clear();
	while(fin.good())
	{
		char buf[1024] = {0};
		fin.getline(buf, sizeof(buf));
		CIKFrame frm;
		CString strData(buf);
		int iStart = 0, iEnd = strData.Find(L" ");
		int iCount = 0;
		while(iEnd > iStart)
		{
			CString strOneData = strData.Mid(iStart, iEnd - iStart);
			strOneData.Trim();
			float fData = _wtof(strOneData);
			frm.m_arData.push_back(fData);
			iStart = iEnd + 1;
			iEnd = strData.Find(L" ", iStart);
		}
		//last one
		CString strOneData = strData.Mid(iStart);
		strOneData.Trim();
		if(!strOneData.IsEmpty())
		{
			float fData = _wtof(strOneData);
			frm.m_arData.push_back(fData);
		}
		
		frm.m_fGoalZ = frm.m_arData[frm.m_arData.size()-1];
		frm.m_arData.pop_back();
		frm.m_fGoalY = frm.m_arData[frm.m_arData.size()-1];
		frm.m_arData.pop_back();
		frm.m_fGoalZ = frm.m_arData[frm.m_arData.size()-1];
		frm.m_arData.pop_back();

		if(frm.m_arData.size() != 0)
			m_arFrame.push_back(frm);
	}
}
int CIKClip::GetFrameCount()
{
	return (int)m_arFrame.size();
}
CBaseFrame* CIKClip::GetFrameAt(int iFrmIdx)
{
	return (CBaseFrame*)(&m_arFrame[iFrmIdx]);
}
void CIKClip::SetFrameAt(int iFrmIdx, CBaseFrame* pFrame)
{
	m_arFrame[iFrmIdx] = *(CIKFrame*)pFrame;
}
void CIKClip::MergeWith(const CIKClip& clipToMerge)
{
	for(int i = 0; i < clipToMerge.m_arFrame.size(); ++i)
	{
		CIKFrame frmToMerge = clipToMerge.m_arFrame[i];
		m_arFrame.push_back(frmToMerge);
	}
}
bool CIKClip::HasFrameEqualData(CIKFrame& frmIK)
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frm = m_arFrame[i];
		if(frm.IsEqualData(frmIK))
			return true;
	}
	return false;
}
bool CIKClip::HasFrameEqualGoal(CIKFrame& frmIK)
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frm = m_arFrame[i];
		if(frm.IsEqualGoal(frmIK))
			return true;
	}
	return false;
}

CIKClip CIKClip::GetNoDataRedundantClip()
{
	CIKClip clipResult;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frmIK = m_arFrame[i];	
		if(!clipResult.HasFrameEqualData(frmIK))
			clipResult.m_arFrame.push_back(frmIK);
	}
	return clipResult;
}
CIKClip CIKClip::GetNoGoalRedundantClip()
{
	CIKClip clipResult;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frmIK = m_arFrame[i];	
		if(!clipResult.HasFrameEqualGoal(frmIK))
			clipResult.m_arFrame.push_back(frmIK);
	}
	return clipResult;
}

//we only check the thumb sensor reading differences and the goal differences
void CIKClip::CheckIKSampleQuality(float fJointGranularity, float fGoalGranularity)
{
	std::string strResult = "";
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frmIK = m_arFrame[i];

		//go through self to check redundancy
		std::string strRedundancy = "";
		for(int j = 0; j < m_arFrame.size(); ++j)
		{
			CIKFrame frmSample = m_arFrame[j];
			if(abs(frmIK.m_arData[0]-frmSample.m_arData[0]) < fJointGranularity &&
				abs(frmIK.m_arData[1]-frmSample.m_arData[1]) < fJointGranularity &&
				abs(frmIK.m_arData[2]-frmSample.m_arData[2]) < fJointGranularity &&
				abs(frmIK.m_arData[3]-frmSample.m_arData[3]) < fJointGranularity &&
				abs(frmIK.m_arData[4]-frmSample.m_arData[4]) < fJointGranularity &&
				frmIK.GoalDistanceTo(frmSample) > fGoalGranularity)
			{
				char buffer[100];
				sprintf(buffer, "\t%d, goal dist: %f\r\n", j, frmIK.GoalDistanceTo(frmSample));
				strRedundancy.append(buffer);
			}
		}
		if(strRedundancy != "")
		{
			char buffer[100];
			sprintf(buffer, "%d, thumb(%.2f, %.2f, %.2f, %.2f, %.2f), goal(%.2f, %.2f, %.2f)\r\n", i, 
				frmIK.m_arData[0], frmIK.m_arData[1], frmIK.m_arData[2], frmIK.m_arData[3], frmIK.m_arData[4],
				frmIK.m_fGoalX, frmIK.m_fGoalY, frmIK.m_fGoalZ);
			std::string strCurrent(buffer);
			strResult.append(strCurrent);
			strResult.append(strRedundancy);
		}
	}

	if(strResult != "")
		::MessageBox(NULL, CString(strResult.c_str()), L"Input Quality", MB_OK);

}
CIKClip CIKClip::GetDataRedundantClip(CIKFrame& frmIK)
{
	CIKClip clipIKEqualData;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frm = m_arFrame[i];
		if(frm.IsEqualData(frmIK))
		{
			clipIKEqualData.m_arFrame.push_back(frm);
			//verify goal distance for equal sensor input
			float fDist = (frmIK.m_fGoalX - frm.m_fGoalX) * (frmIK.m_fGoalX - frm.m_fGoalX) + 
				(frmIK.m_fGoalY - frm.m_fGoalY) * (frmIK.m_fGoalY - frm.m_fGoalY) +
				(frmIK.m_fGoalZ - frm.m_fGoalZ) * (frmIK.m_fGoalZ - frm.m_fGoalZ);
			fDist = sqrt(fDist);
			assert(fDist < 0.1);
		}
	}
	return clipIKEqualData;
}
CIKClip CIKClip::GetGoalRedundantClip(CIKFrame& frmIK)
{
	CIKClip clipIKEqualGoal;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frm = m_arFrame[i];
		if(frm.IsEqualGoal(frmIK))
			clipIKEqualGoal.m_arFrame.push_back(frm);
	}
	return clipIKEqualGoal;
}
CIKClip CIKClip::GetAllDataRedundantClip()
{
	CIKClip clipIKAll;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frmIK = m_arFrame[i];
		if(clipIKAll.HasFrameEqualData(frmIK))
			continue;

		CIKClip clipIK = GetDataRedundantClip(frmIK);
		if(clipIK.m_arFrame.size() > 1)
			clipIKAll.MergeWith(clipIK);
	}
	return clipIKAll;
}
CIKClip CIKClip::GetAllGoalRedundantClip()
{
	CIKClip clipIKAll;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frmIK = m_arFrame[i];
		CIKClip clipIK = GetGoalRedundantClip(frmIK);
		if(clipIK.m_arFrame.size() > 1)
			clipIKAll.MergeWith(clipIK);
	}
	return clipIKAll;
}
CRawClip CIKClip::GetRawClip()
{
	CRawClip clipRaw;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frmIK = m_arFrame[i];
		CRawFrame frmRaw(frmIK.m_arData);
		clipRaw.m_arFrame.push_back(frmRaw);
	}
	return clipRaw;
}

CIKClip CIKClip::GetReorderedClipByThumb(CIKFrame& frmStart)
{
	CIKClip clipResult;
	if(m_arFrame.size() == 0)
		return clipResult;
	CIKClip clipOriginal = *this;
	CIKFrame frmToTest = frmStart;
	while(clipResult.m_arFrame.size() < m_arFrame.size())
	{
		int iIdx = clipOriginal.FindNearestFrameByThumb(frmToTest);
		int i = 0;
		std::vector<CIKFrame>::iterator iter = clipOriginal.m_arFrame.begin();
		while(i!=iIdx)
		{
			i ++;
			iter ++;
		}
		frmToTest = clipOriginal.m_arFrame[iIdx];
		clipResult.m_arFrame.push_back(frmToTest);
		clipOriginal.m_arFrame.erase(iter);
	}
	assert(clipResult.m_arFrame.size() == m_arFrame.size());
	assert(clipOriginal.m_arFrame.size() == 0);
	return clipResult;
}
CIKClip CIKClip::GetReorderedClipByGoal(CIKFrame& frmStart)
{
	CIKClip clipResult;
	if(m_arFrame.size() == 0)
		return clipResult;
	CIKClip clipOriginal = *this;
	CIKFrame frmToTest = frmStart;
	while(clipResult.m_arFrame.size() < m_arFrame.size())
	{
		int iIdx = clipOriginal.FindNearestFrameByGoal(frmToTest);
		int i = 0;
		std::vector<CIKFrame>::iterator iter = clipOriginal.m_arFrame.begin();
		while(i!=iIdx)
		{
			i ++;
			iter ++;
		}
		frmToTest = clipOriginal.m_arFrame[iIdx];
		clipResult.m_arFrame.push_back(frmToTest);
		clipOriginal.m_arFrame.erase(iter);
	}
	assert(clipResult.m_arFrame.size() == m_arFrame.size());
	assert(clipOriginal.m_arFrame.size() == 0);
	return clipResult;
}
int CIKClip::FindNearestFrameByThumb(CIKFrame& frmIK)
{
	CRawFrame frmRaw(frmIK.m_arData);
	int iNearestIdx = -1;
	float fNearestDist = 10000000;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frmIKThis = m_arFrame[i];
		CRawFrame frmRawThis(frmIKThis.m_arData);
		float fDistThis = frmRawThis.DistanceToThumb(frmRaw);
		if(fDistThis < fNearestDist)
		{
			fNearestDist = fDistThis;
			iNearestIdx = i;
		}
	}
	return iNearestIdx;
}
int CIKClip::FindNearestFrameByGoal(CIKFrame& frmIK)
{
	CKinematicPoint ptIKGoal(frmIK.m_fGoalX, frmIK.m_fGoalY, frmIK.m_fGoalZ);
	int iNearestIdx = -1;
	float fNearestDist = 100000000;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CIKFrame frmIKThis = m_arFrame[i];
		CKinematicPoint ptIKGoalThis(frmIKThis.m_fGoalX, frmIKThis.m_fGoalY, frmIKThis.m_fGoalZ);
		float fDistThis = ptIKGoalThis.DistanceTo(ptIKGoal);
		if(fDistThis < fNearestDist)
		{
			fNearestDist = fDistThis;
			iNearestIdx = i;
		}
	}
	return iNearestIdx;
}