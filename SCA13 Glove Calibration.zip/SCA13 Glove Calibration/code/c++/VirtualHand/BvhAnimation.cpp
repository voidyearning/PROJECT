#include "stdafx.h"
#include "BvhAnimation.h"
#include <fstream>
#include "GloveUtil.h"
using namespace GloveUtil;

CBvhFrame CBvhClip::GetAveragePose()
{
	CBvhFrame frmAvePose;
	if(m_arFrame.size() <= 0)
		return frmAvePose;

	for(int d = 0; d < m_arFrame[0].m_arData.size(); ++d)
		frmAvePose.m_arData.push_back(0);

	for(int f = 0; f < m_arFrame.size(); ++f)
	{
		CBvhFrame frmCur = m_arFrame[f];
		for(int d = 0; d < frmCur.m_arData.size(); ++d)
			frmAvePose.m_arData[d] += frmCur.m_arData[d];
	}
	for(int d = 0; d < frmAvePose.m_arData.size(); ++d)
		frmAvePose.m_arData[d] = frmAvePose.m_arData[d] / m_arFrame.size();

	return frmAvePose;
}
void CBvhClip::LoadFromFile(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	if(!fin.good())
		return;

	CString strHierarchy = L"";
	while(fin.good())
	{
		char buf[1024] = {0};
		fin.getline(buf, sizeof(buf));
		CString strLine(buf);
		strHierarchy += strLine;

		if(strLine.Find(L"MOTION") != -1)
			break;		
	}
	strHierarchy = strHierarchy.Mid(0, strHierarchy.Find(L"MOTION"));
	m_bvhStructure.m_strHeader = strHierarchy;
	m_bvhStructure.Parse(strHierarchy);

	char buf[500] = {0};
	fin.getline(buf, sizeof(buf));
	CString strLine(buf);
	int iIdx = strLine.Find(L"Frames:");
	CString strFrames = strLine.Mid(iIdx + 7);
	strFrames.Trim();
	m_iTotalFrames = _wtoi(strFrames.GetBuffer());

	buf[499] = 0;
	fin.getline(buf, sizeof(buf));
	strLine = CString(buf);
	iIdx = strLine.Find(L"Frame Time:");
	CString strInterval = strLine.Mid(iIdx + 11);
	strInterval.Trim();
	m_fIntervalTime = _wtof(strInterval.GetBuffer());

	while(fin.good())
	{
		char buf[3024] = {0};
		fin.getline(buf, sizeof(buf));
		CString strLine(buf);
		CBvhFrame bvhFrame;
		do
		{
			int iSpace = strLine.Find(L" ");
			if(iSpace == -1)
				iSpace = strLine.GetLength();

			CString strDOF=strLine.Mid(0, iSpace);
			strDOF=strDOF.Trim();
			float fDOF = _wtof(strDOF);
			if(!strDOF.IsEmpty())
				bvhFrame.m_arData.push_back(fDOF);

			strLine = strLine.Mid(iSpace+1);
			strLine.Trim();
			if(strLine.IsEmpty())
				break;
		}while(true);

		if(bvhFrame.m_arData.size() > 1)
			m_arFrame.push_back(bvhFrame);
	}
}
void CBvhClip::SaveToFile(std::string strPath)
{}
int CBvhClip::GetFrameCount()
{
	return m_arFrame.size();
}
CBaseFrame* CBvhClip::GetFrameAt(int iFrmIdx)
{
	if(iFrmIdx < 0 || iFrmIdx >= m_arFrame.size())
		return NULL;
	return (CBaseFrame*)(&m_arFrame[iFrmIdx]);
}
CBvhFrame CBvhClip::GetFrameAt(float fPropToBeg)
{
	int iTotalCount = m_arFrame.size();
	float fPos=fPropToBeg * (iTotalCount-1);
	int iPosPrev=int(fPos);
	int iPosNext=iPosPrev+1;
	CBvhFrame frmPrev=m_arFrame[iPosPrev];
	CBvhFrame frmNext=frmPrev;
	if(iPosNext < iTotalCount)
		frmNext=m_arFrame[iPosNext];

	CBvhFrame frmResult;
	float fProp=fPos-iPosPrev;
	for(int i=0; i < frmPrev.m_arData.size(); ++i)
	{
		float fData=(1-fProp)*frmPrev.m_arData[i]+fProp*frmNext.m_arData[i];
		frmResult.m_arData.push_back(fData);
	}
	return frmResult;
}
void CBvhClip::SetFrameAt(int iFrmIdx, CBaseFrame* pFrame)
{
	m_arFrame[iFrmIdx] = *(CBvhFrame*)pFrame;
}
void CBvhClip::FillingBodyConsistent(CString strOutputPath, CRawClip clipHandL, CRawClip clipHandR)
{
	std::ofstream fout(strOutputPath);
	int iBodyClipLength = 1700;//m_arFrame.size();
	int iHandClipLengthL = clipHandL.m_arFrame.size();
	int iHandClipLengthR = clipHandR.m_arFrame.size();

	for(int i = 0; i < iBodyClipLength; ++i)
	{
		CBvhFrame bvhFrame = m_arFrame[0];
		int iLEFT_HAND_START = 27;
		for(int j = 0; j < iLEFT_HAND_START; j++)
			fout << bvhFrame.m_arData[j] << " ";

		//give fout to clipHandL to insert data
		CRawFrame rawFrameL = clipHandL.m_arFrame[i%iHandClipLengthL];
		rawFrameL.SaveToBvhConsistentWithBody(true, fout);

		//continue body
		int iLEFT_HAND_END = 47, iRIGHT_HAND_START = 57;
		for(int j = iLEFT_HAND_END + 1; j < iRIGHT_HAND_START; j++)
			fout << bvhFrame.m_arData[j] << " ";

		//give fout to clipHandR to insert data
		CRawFrame rawFrameR = clipHandR.m_arFrame[i%iHandClipLengthR];
		rawFrameR.SaveToBvhConsistentWithBody(false, fout);

		//finish body
		int iRIGHT_HAND_END = 77;
		for(int j = iRIGHT_HAND_END+1; j < bvhFrame.m_arData.size(); j++)
		{
			if(j==m_arFrame.size()-1)
				fout << bvhFrame.m_arData[j];
			else
				fout << bvhFrame.m_arData[j] << " ";
		}

		//finish the frame
		fout << std::endl;
	}
	fout.flush();
	fout.close();
}
void CBvhClip::FillInVirtualHand(CString strInputPath, CString strOutputPath, CGlvClip glvFilerLeft, int iOffsetLeft, CGlvClip glvFilerRight, int iOffsetRight, CGloveBvhRetarget glvRetarget, CGloveBvhInsert glvInsert, bool bInsert)
{
	std::ifstream fin(strInputPath);
	std::ofstream fout(strOutputPath);

	while(fin.good())
	{
		char buf[1024] = {0};
		fin.getline(buf, sizeof(buf));
		CString strLine(buf);

		fout << buf << std::endl;

		if(strLine.Find(L"MOTION") != -1)
			break;		
	}

	char buf[500] = {0};
	fin.getline(buf, sizeof(buf));
	fout << buf << std::endl;

	CString strLine(buf);
	int iIdx = strLine.Find(L"Frames:");
	CString strFrames = strLine.Mid(iIdx + 7);
	strFrames.Trim();
	int iFrames = _wtoi(strFrames.GetBuffer());

	buf[499] = 0;
	fin.getline(buf, sizeof(buf));
	fout << buf << std::endl;

	strLine = CString(buf);
	iIdx = strLine.Find(L"Frame Time:");
	CString strInterval = strLine.Mid(iIdx + 11);
	strInterval.Trim();
	float fInterval = _wtof(strInterval.GetBuffer());

	int iFrameCount = 1;
	while(fin.good())
	{
		char buf[2048] = {0};
		fin.getline(buf, sizeof(buf));
		CString strLine(buf);
		if(strLine.IsEmpty())
			continue;

		strLine.TrimLeft();
		CBvhFrame bvhFrame;
		int iBeg = 0, iEnd = strLine.Find(L" ");
		float fCurTime = iFrameCount * fInterval;
		while(iBeg < iEnd)
		{
			CString strData = strLine.Mid(iBeg, iEnd-iBeg);
			strData.Trim();
			float fData = _wtof(strData.GetBuffer());
			bvhFrame.m_arData.push_back(fData);

			iBeg = iEnd + 1;
			iEnd = strLine.Find(L" ", iBeg);
			if(iEnd == -1)
				iEnd = strLine.GetLength();
		}
		if(bvhFrame.m_arData.size() == 0)
			break;

		CGlvFrame glvFrameLeft = glvFilerLeft.GetFrameAt(float(fCurTime + iOffsetLeft/1000.0));
		CGlvFrame glvFrameRight = glvFilerRight.GetFrameAt(float(fCurTime + iOffsetRight/1000.0));
		CBvhFrame bvhFrameFilled = FillInVirtualHand(bvhFrame, glvFrameLeft, glvFrameRight, glvRetarget, glvInsert, bInsert);

		for(int i = 0; i < bvhFrameFilled.m_arData.size(); ++i)
			fout << bvhFrameFilled.m_arData[i] << " ";
		fout << std::endl;

		m_arFrame.push_back(bvhFrame);
		iFrameCount ++;
	}
}

void CBvhClip::FillInBvhHand(CString strOutputPath, CBvhClip& clipHandLeft, CBvhClip& clipHandRight, int iOffset, bool bSkel2, bool bTest10000)
{
	std::ofstream fout(strOutputPath);
	
	int iBodyClipLength = m_arFrame.size();
	if(bTest10000)
		iBodyClipLength=5000;
	int iHandClipLengthL = clipHandLeft.m_arFrame.size();
	int iHandClipLengthR = clipHandRight.m_arFrame.size();

	for(int i = 0; i < iBodyClipLength; ++i)
	{
		CBvhFrame bvhBodyFrame = m_arFrame[i];
		float fPropToBeg=float(float(i)/(m_arFrame.size()-1));
		CBvhFrame bvhHandFrameLeft=clipHandLeft.GetFrameAt(fPropToBeg);
		CBvhFrame bvhHandFrameRight=clipHandRight.GetFrameAt(fPropToBeg);

		int iLEFT_HAND_START = 54;
		for(int j = 0; j < iLEFT_HAND_START; j++)
			fout << bvhBodyFrame.m_arData[j] << " ";

		//give fout to clipHandL to insert data
		for(int j = 2; j < bvhHandFrameLeft.m_arData.size(); ++j)
			fout << bvhHandFrameLeft.m_arData[j] <<" ";
		//CRawFrame rawFrameL = clipHandL.m_arFrame[i%iHandClipLengthL];
		//rawFrameL.SaveToBvhConsistentWithBody(true, fout);

		//continue body
		int iLEFT_HAND_END = 59, iRIGHT_HAND_START = 72;
		if(bSkel2)
		{
			iLEFT_HAND_END=56;
			iRIGHT_HAND_START=69;
		}

		for(int j = iLEFT_HAND_END + 1; j < iRIGHT_HAND_START; j++)
			fout << bvhBodyFrame.m_arData[j] << " ";

		//give fout to clipHandR to insert data
		for(int j =2; j < bvhHandFrameRight.m_arData.size(); ++j)
		{
			if(j==bvhHandFrameRight.m_arData.size()-1)
				fout << bvhHandFrameRight.m_arData[j];
			else
				fout << bvhHandFrameRight.m_arData[j] << " ";
		}
		//CRawFrame rawFrameR = clipHandR.m_arFrame[i%iHandClipLengthR];
		//rawFrameR.SaveToBvhConsistentWithBody(false, fout);

		/*/finish body
		int iRIGHT_HAND_END = 77;
		for(int j = iRIGHT_HAND_END+1; j < bvhBodyFrame.m_arData.size(); j++)
		{
			if(j==m_arFrame.size()-1)
				fout << bvhBodyFrame.m_arData[j];
			else
				fout << bvhBodyFrame.m_arData[j] << " ";
		}*/

		//finish the frame
		fout << std::endl;
	}
	fout.flush();
	fout.close();
}

CBvhFrame CBvhClip::FillInVirtualHand(CBvhFrame bvhFrame, CGlvFrame glvFrameLeft, CGlvFrame glvFrameRight, CGloveBvhRetarget glvRetarget, CGloveBvhInsert glvInsert, bool bInsert)
{
	if(bvhFrame.m_arData.size() != glvRetarget.GetBvhDataSize())
		ASSERT(FALSE);

	CBvhFrame resultFrame;

	if(bInsert)
	{
		int iLeft = glvInsert.m_iEndIdxLeft - glvInsert.m_iStartIdxLeft;
		int iRight = glvInsert.m_iEndIdxRight - glvInsert.m_iStartIdxRight;
		if( iLeft < 0  || iRight < 0)
			return resultFrame;

		//before left start
		for(int i = 0; i < glvInsert.m_iStartIdxLeft; ++i)
			resultFrame.m_arData.push_back(bvhFrame.m_arData[i]);

		//left
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[3]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[0]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[0]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[1]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[2]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[7]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[4]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[5]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[6]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[11]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[8]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[9]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[10]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[15]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[12]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[13]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[14]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[19]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[16]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[17]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameLeft.m_arData[18]));

		//after left - before right
		for(int i = glvInsert.m_iEndIdxLeft + 1; i < glvInsert.m_iStartIdxRight; ++i)
			resultFrame.m_arData.push_back(bvhFrame.m_arData[i]);

		//right
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[3]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[0]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[0]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[1]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[2]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[7]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[4]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[5]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[6]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[11]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[8]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[9]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[10]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[15]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[12]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[13]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[14]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[19]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[16]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[17]));
		resultFrame.m_arData.push_back(RadianToDegree(glvFrameRight.m_arData[18]));
		//after right
		for(int i = glvInsert.m_iEndIdxRight + 1; i < bvhFrame.m_arData.size(); ++i)
			resultFrame.m_arData.push_back(bvhFrame.m_arData[i]);
		
		return resultFrame;
	}

	for(int i = 0; i < bvhFrame.m_arData.size(); ++i)
	{
		float fData = bvhFrame.m_arData[i];
		CGloveMapping glvMapping = glvRetarget.GetMappingOf(i);
		//preserve original
		if(!glvMapping.IsNone())
		{
			fData = 0;
			for(int j = 0; j < glvMapping.m_arMappingLeft.size(); ++j)
			{
				CGloveMappingItem item = glvMapping.m_arMappingLeft[j];
				fData += RadianToDegree(glvFrameLeft.m_arData[item.m_iGlvIdx]) * item.m_fWeight;
			}

			for(int j = 0; j < glvMapping.m_arMappingRight.size(); ++j)
			{
				CGloveMappingItem item = glvMapping.m_arMappingRight[j];
				fData += RadianToDegree(glvFrameRight.m_arData[item.m_iGlvIdx]) * item.m_fWeight;
			}
		}
		resultFrame.m_arData.push_back(fData);
	}
	return resultFrame;
}
BVH_CHANNEL_TYPE CBvhStructure::GetChannelTypeFromString(CString strChannel)
{
	if(strChannel == L"Xposition")
		return BVH_CHANNEL_TYPE::BVH_X_POS;
	if(strChannel == L"Xrotation")
		return BVH_CHANNEL_TYPE::BVH_X_ROT;

	if(strChannel == L"Yposition")
		return BVH_CHANNEL_TYPE::BVH_Y_POS;
	if(strChannel == L"Yrotation")
		return BVH_CHANNEL_TYPE::BVH_Y_ROT;
	
	if(strChannel == L"Zposition")
		return BVH_CHANNEL_TYPE::BVH_Z_POS;
	if(strChannel == L"Zrotation")
		return BVH_CHANNEL_TYPE::BVH_Z_ROT;

	return BVH_CHANNEL_TYPE::unknown;

}
CString CBvhStructure::GetChannelStringFromType(BVH_CHANNEL_TYPE typeChannel)
{
	switch(typeChannel)
	{
	case BVH_CHANNEL_TYPE::BVH_X_POS:
		return L"Xposition";
	case BVH_CHANNEL_TYPE::BVH_X_ROT:
		return L"Xrotation";
	case BVH_CHANNEL_TYPE::BVH_Y_POS:
		return L"Yposition";
	case BVH_CHANNEL_TYPE::BVH_Y_ROT:
		return L"Yrotation";
	case BVH_CHANNEL_TYPE::BVH_Z_POS:
		return L"Zposition";
	case BVH_CHANNEL_TYPE::BVH_Z_ROT:
		return L"Zrotation";
	}
	return L"";
}
void CBvhStructure::Parse(CString strHierarchy)
{
	m_arJoint.clear();
	ParseNodes(strHierarchy, m_arJoint);
}
CString CBvhStructure::ParseNodes(CString strNodes, std::vector<CBvhJoint>& arJoint)
{
	//joint type
	strNodes.Trim();
	BVH_JOINT_TYPE jointType;
	int idxJoint = strNodes.Find(L"ROOT");
	if(idxJoint != -1)
		jointType = BVH_JOINT_TYPE::BVH_ROOT;
	else
	{
		int idxJ = strNodes.Find(L"JOINT");
		int idxE = strNodes.Find(L"End Site");
		if(idxJ == -1 && idxE == -1)
			return strNodes;
		idxJoint = idxE;
		jointType = BVH_JOINT_TYPE::BVH_ENDSITE;

		if(idxE <= idxJ && idxE != -1)
		{
			idxJoint = idxE;
			jointType = BVH_JOINT_TYPE::BVH_ENDSITE;
		}
		if(idxJ < idxE && idxJ != -1)
		{
			idxJoint = idxJ;
			jointType = BVH_JOINT_TYPE::BVH_JOINT;
		}
		if(idxJoint != 0)
			return strNodes;
	}

	//current joint info
	CBvhJoint curJoint;
	curJoint.m_type = jointType;
	int idxBlank = strNodes.Find(L" ", idxJoint);
	int idxStartB = strNodes.Find(L"{", idxBlank);
	curJoint.m_strJointName = strNodes.Mid(idxBlank+1, idxStartB-idxBlank-1);
	if(jointType == BVH_JOINT_TYPE::BVH_ENDSITE)
		curJoint.m_strJointName = L"End Site";
	curJoint.m_strJointName.Trim();
	int idxOffset = strNodes.Find(L"OFFSET", idxStartB);
	int idxChannels = strNodes.Find(L"CHANNELS", idxStartB);

	//end position and sub joint start position
	int idxSubJoint = -1, idxCurEnd = -1, idxJ = -1;
	switch(jointType)
	{
	case BVH_JOINT_TYPE::BVH_ROOT:
	case BVH_JOINT_TYPE::BVH_JOINT:
		idxSubJoint = strNodes.Find(L"End Site", idxStartB);
		idxJ = strNodes.Find(L"JOINT", idxStartB);
		if(idxJ < idxSubJoint && idxJ != -1)
			idxSubJoint = idxJ;
		idxCurEnd = idxSubJoint;
		break;
	case BVH_JOINT_TYPE::BVH_ENDSITE:
		idxCurEnd = strNodes.Find(L"}", idxStartB);
	}

	CString strOffsets = L"", strChannels = L"";
	if(idxChannels != -1)
	{
		strOffsets = strNodes.Mid(idxOffset+6, idxChannels-idxOffset-6);
		strChannels = strNodes.Mid(idxChannels +8, idxCurEnd - idxChannels - 8);
	}
	else
	{
		strOffsets = strNodes.Mid(idxOffset+6, idxCurEnd-idxOffset-6);
	}
	strOffsets.Trim();
	strChannels.Trim();

	while(strOffsets != L"")
	{
		int idxB = strOffsets.Find(L" ");
		if(idxB == -1)
			idxB = strOffsets.GetLength();
		CString strOneOffset = strOffsets.Mid(0, idxB);
		strOffsets = strOffsets.Mid(idxB+1);
		strOneOffset.Trim();
		strOffsets.Trim();
		curJoint.m_arOffset.push_back(_wtof(strOneOffset.GetBuffer()));
	}

	while(strChannels != L"")
	{
		int idxB = strChannels.Find(L" ");
		if(idxB == -1)
			idxB = strChannels.GetLength();
		CString strOneChannel = strChannels.Mid(0, idxB);
		strChannels = strChannels.Mid(idxB+1);
		strOneChannel.Trim();
		strChannels.Trim();
		BVH_CHANNEL_TYPE typeChannel = GetChannelTypeFromString(strOneChannel);
		if(typeChannel != BVH_CHANNEL_TYPE::unknown)
			curJoint.m_arChannel.push_back(typeChannel);		
	}

	arJoint.push_back(curJoint);
	CString strRemaining = strNodes;

	//extract child
	if(idxSubJoint != -1)
	{
		int idxCur = arJoint.size() -1;

		CString strHalf1 = strNodes.Mid(0, idxSubJoint);
		CString strHalf2 = strNodes.Mid(idxSubJoint);
		strRemaining = strHalf1 + ParseNodes(strHalf2, arJoint);
		
		for(int i = idxCur + 1; i < arJoint.size(); ++i)
		{
			CBvhJoint childJoint = arJoint[i];
			if(childJoint.m_iParentIdx == -1)
			{
				childJoint.m_iParentIdx = idxCur;
				arJoint[idxCur].m_arChildIdx.push_back(idxCur+i);
			}
		}
	}

	//matching the idxStartB
	int idxEndB = strRemaining.Find(L"}");
	if(idxEndB + 1 < strRemaining.GetLength())
		strRemaining = strRemaining.Mid(idxEndB+1);
	else 
		strRemaining = L"";

	//siblings
	if(strRemaining != L"")
	{
		if(strRemaining != L"")
			strRemaining = ParseNodes(strRemaining, arJoint);
	}

	return strRemaining;
}
CString CBvhStructure::ToString()
{
	CString strResult = L"";
	for(int i = 0; i < GetDataSize(); ++i)
	{
		CString strName = GetDataNameAt(i);
		CString strIdx = L"";
		strIdx.Format(L"%d: ", i);
		strResult += strIdx + strName + L"\r\n";
	}
	return strResult;
}
int CBvhStructure::GetDataSize()
{
	int iSize = 0;
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CBvhJoint joint = m_arJoint[i];
		iSize += joint.m_arChannel.size();
	}
	return iSize;
}
CString CBvhStructure::GetDataNameAt(int idxData)
{
	int iDataSize = GetDataSize();
	int iCurData = 0;
	for(int i = 0; i < iDataSize; ++i)
	{
		CBvhJoint joint = m_arJoint[i];
		for(int j = 0; j < joint.m_arChannel.size(); ++j)
		{
			if(idxData == iCurData)
			{
				return joint.m_strJointName + L":" + 
					GetChannelStringFromType(joint.m_arChannel[j]);
			}
			iCurData ++;
		}
	}
	return L"no existed";
}


int CGloveBvhRetarget::GetBvhDataSize()
{
	return m_bvhStructure.GetDataSize();
}
CString CGloveBvhRetarget::GetBvhDataNameAt(int idxData)
{
	return m_bvhStructure.GetDataNameAt(idxData);
}
int CGloveBvhRetarget::GetGlvDataSize()
{
	return m_glvStructure.GetDataSize();
}
CString CGloveBvhRetarget::GetGlvDataNameAt(int idxData)
{
	return CString(m_glvStructure.GetDataNameAt(idxData));
}

void CGloveBvhRetarget::Reset()
{
	m_arMapping.clear();
}
void CGloveBvhRetarget::Init(CBvhStructure bvhStructure, CGlvStructre glvStructure)
{
	m_bvhStructure = bvhStructure;
	m_glvStructure = glvStructure;

	//default ones
	//left hand
	for(int i = 27; i <= 47; ++i)
	{
		CGloveMapping mapping;
		mapping.m_iBvhIdx = i;
		CGloveMappingItem item;
		item.m_fWeight = 1;
		switch(i)
		{
		case 27: item.m_iGlvIdx = 3; break;
		case 28: item.m_iGlvIdx = 0; item.m_fWeight = 0.5; break;
		case 29: item.m_iGlvIdx = 0; item.m_fWeight = 0.5; break;
		case 30: item.m_iGlvIdx = 1; break;
		case 31: item.m_iGlvIdx = 2; break;
		case 32: item.m_iGlvIdx = 7; break;
		case 33: item.m_iGlvIdx = 4; break;
		case 34: item.m_iGlvIdx = 5; break;
		case 35: item.m_iGlvIdx = 6; break;
		case 36: item.m_iGlvIdx = 11; break;
		case 37: item.m_iGlvIdx = 8; break;
		case 38: item.m_iGlvIdx = 9; break;
		case 39: item.m_iGlvIdx = 10; break;
		case 40: item.m_iGlvIdx = 15; break;
		case 41: item.m_iGlvIdx = 12; break;
		case 42: item.m_iGlvIdx = 13; break;
		case 43: item.m_iGlvIdx = 14; break;
		case 44: item.m_iGlvIdx = 19; break;
		case 45: item.m_iGlvIdx = 16; break;
		case 46: item.m_iGlvIdx = 17; break;
		case 47: item.m_iGlvIdx = 18; break;
		}
		mapping.m_arMappingLeft.push_back(item);
		m_arMapping.push_back(mapping);
	}

	//right hand
	for(int i = 57; i <= 77; ++i)
	{
		CGloveMapping mapping;
		mapping.m_iBvhIdx = i;
		CGloveMappingItem item;
		//right hand needs flip
		item.m_fWeight = -1;
		switch(i)
		{
		case 57: item.m_iGlvIdx = 3; break;
		case 58: item.m_iGlvIdx = 0; break;
		case 59: item.m_iGlvIdx = 0; break;
		case 60: item.m_iGlvIdx = 1; break;
		case 61: item.m_iGlvIdx = 2; break;
		case 62: item.m_iGlvIdx = 7; break;
		case 63: item.m_iGlvIdx = 4; break;
		case 64: item.m_iGlvIdx = 5; break;
		case 65: item.m_iGlvIdx = 6; break;
		case 66: item.m_iGlvIdx = 11; break;
		case 67: item.m_iGlvIdx = 8; break;
		case 68: item.m_iGlvIdx = 9; break;
		case 69: item.m_iGlvIdx = 10; break;
		case 70: item.m_iGlvIdx = 15; break;
		case 71: item.m_iGlvIdx = 12; break;
		case 72: item.m_iGlvIdx = 13; break;
		case 73: item.m_iGlvIdx = 14; break;
		case 74: item.m_iGlvIdx = 19; break;
		case 75: item.m_iGlvIdx = 16; break;
		case 76: item.m_iGlvIdx = 17; break;
		case 77: item.m_iGlvIdx = 18; break;
		}
		mapping.m_arMappingRight.push_back(item);
		m_arMapping.push_back(mapping);
	}

	//m_arMapping.clear();
}
void CGloveBvhRetarget::SetMappingOf(int idxBvhData, CGloveMapping mapping)
{
	if(idxBvhData == -1 || mapping.IsNone())
		return;

	for(int i = 0; i < m_arMapping.size(); ++i)
	{
		CGloveMapping mapping2 = m_arMapping[i];
		if(mapping.m_iBvhIdx == idxBvhData)
		{
			m_arMapping[i] = mapping;
			return;
		}
	}
	m_arMapping.push_back(mapping);
}
CGloveMapping CGloveBvhRetarget::GetMappingOf(int idxBvhData)
{	
	for(int i = 0; i < m_arMapping.size(); ++i)
	{
		CGloveMapping mapping = m_arMapping[i];
		if(mapping.m_iBvhIdx == idxBvhData)
			return mapping;
	}
	return CGloveMapping();
}
CString CGloveBvhRetarget::GetExpressionOf(CGloveMapping mapping)
{
	if(mapping.IsNone())
		return L"preserve original";

	CString strExpr = GetBvhDataNameAt(mapping.m_iBvhIdx);
	strExpr += L" = ";

	for(int i = 0; i < mapping.m_arMappingLeft.size(); ++i)
	{
		CGloveMappingItem item = mapping.m_arMappingLeft[i];
		if(item.m_fWeight == 0)
			continue;
		CString strWeight = L"";
		strWeight.Format(L"%4f", item.m_fWeight);
		strExpr += strWeight;		
		strExpr += L"*";
		strExpr += L"l_" + GetGlvDataNameAt(item.m_iGlvIdx);
		if(i != mapping.m_arMappingLeft.size() -1 || !mapping.IsNoneRight())
			strExpr += L" + ";
	}

	for(int i = 0; i < mapping.m_arMappingRight.size(); ++i)
	{
		CGloveMappingItem item = mapping.m_arMappingRight[i];
		if(item.m_fWeight == 0)
			continue;
		CString strWeight = L"";
		strWeight.Format(L"%4f", item.m_fWeight);
		strExpr += strWeight;		
		strExpr += L"*";
		strExpr += L"r_" + GetGlvDataNameAt(item.m_iGlvIdx);
		if(i != mapping.m_arMappingRight.size() -1)
			strExpr += L" + ";
	}
	return strExpr;
}

void CGloveBvhRetarget::SaveTo(CString strPath)
{
	std::ofstream fout(strPath);
	for(int i = 0; i < m_arMapping.size(); ++i)
	{
		CGloveMapping mapping = m_arMapping[i];
		if(mapping.IsNone())
			continue;

		for(int l = 0; l < mapping.m_arMappingLeft.size(); ++l)
		{
			CGloveMappingItem item = mapping.m_arMappingLeft[l];
			fout << "l_mapping_item " << item.m_iGlvIdx << " " << item.m_fWeight << std::endl;
		}

		for(int r = 0; r < mapping.m_arMappingRight.size(); ++r)
		{
			CGloveMappingItem item = mapping.m_arMappingRight[r];
			fout << "r_mapping_item " << item.m_iGlvIdx << " " << item.m_fWeight << std::endl;
		}
		
		fout << "mapping " << mapping.m_iBvhIdx << std::endl;
	}
	fout.flush();
	fout.close();
}
void CGloveBvhRetarget::LoadFrom(CString strPath)
{
	std::ifstream fin(strPath);
	m_arMapping.clear();

	CGloveMapping mapping;
	while(fin.good())
	{
		char buf[1024] = {0};
		fin.getline(buf, sizeof(buf));
		CString strLine(buf);
		int idxItemL = strLine.Find(L"l_mapping_item");
		int idxItemR = strLine.Find(L"r_mapping_item");
		int idxMapping = strLine.Find(L"mapping");

		if(idxItemL != -1 || idxItemR != -1)
		{
			CGloveMappingItem item;
			int iBegWeight = strLine.Find(L" ",15); 
			CString strGlvIdx = strLine.Mid(15, iBegWeight-15);
			CString strWeight = strLine.Mid(iBegWeight);			
			item.m_iGlvIdx = _wtoi(strGlvIdx);
			item.m_fWeight = _wtof(strWeight);
			if(idxItemL!= -1)
				mapping.m_arMappingLeft.push_back(item);
			else
				mapping.m_arMappingRight.push_back(item);
		}
		if( idxMapping != -1)
		{
			CString strBvhIdx = strLine.Mid(8);
			mapping.m_iBvhIdx = _wtoi(strBvhIdx.GetBuffer());
			m_arMapping.push_back(mapping);			
			mapping = CGloveMapping();
		}
	}
}
bool CGloveMapping::IsNone()
{
	if((m_arMappingLeft.size() == 0 && m_arMappingRight.size() == 0)|| m_iBvhIdx == -1)
		return true;

	for(int i = 0; i < m_arMappingLeft.size(); ++i)
	{
		CGloveMappingItem item = m_arMappingLeft[i];
		if(item.m_fWeight != 0 && item.m_iGlvIdx >= 0)
			return false;
	}

	for(int i = 0; i < m_arMappingRight.size(); ++i)
	{
		CGloveMappingItem item = m_arMappingRight[i];
		if(item.m_fWeight != 0 && item.m_iGlvIdx >= 0)
			return false;
	}
	return true;
}

bool CGloveMapping::IsNoneLeft()
{
	if(m_arMappingLeft.size() == 0 || m_iBvhIdx == -1)
		return true;

	for(int i = 0; i < m_arMappingLeft.size(); ++i)
	{
		CGloveMappingItem item = m_arMappingLeft[i];
		if(item.m_fWeight != 0 && item.m_iGlvIdx >= 0)
			return false;
	}
	return true;
}
bool CGloveMapping::IsNoneRight()
{
	if(m_arMappingRight.size() == 0 || m_iBvhIdx == -1)
		return true;

	for(int i = 0; i < m_arMappingRight.size(); ++i)
	{
		CGloveMappingItem item = m_arMappingRight[i];
		if(item.m_fWeight != 0 && item.m_iGlvIdx >= 0)
			return false;
	}
	return true;
}

CGloveMappingItem CGloveMapping::GetMappingItemOf(int idxGlv, bool bLeft)
{
	if(bLeft)
	{
		for(int i = 0; i < m_arMappingLeft.size(); ++i)
		{
			CGloveMappingItem item = m_arMappingLeft[i];
			if(item.m_iGlvIdx == idxGlv)
				return item;
		}
		return CGloveMappingItem();
	}
	else
	{
		for(int i = 0; i < m_arMappingRight.size(); ++i)
		{
			CGloveMappingItem item = m_arMappingRight[i];
			if(item.m_iGlvIdx == idxGlv)
				return item;
		}
		return CGloveMappingItem();
	}
}

void CGloveMapping::SetMappingItemOf(int idxGlv, bool bLeft, CGloveMappingItem item)
{
	if(idxGlv == -1 || item.m_fWeight == 0)
		return;

	if(bLeft)
	{
		for(int i = 0; i < m_arMappingLeft.size(); ++i)
		{
			CGloveMappingItem item2 = m_arMappingLeft[i];
			if(item2.m_iGlvIdx == idxGlv)
			{
				m_arMappingLeft[i] = item;
				return;
			}
		}
		m_arMappingLeft.push_back(item);
	}
	else
	{
		for(int i = 0; i < m_arMappingRight.size(); ++i)
		{
			CGloveMappingItem item2 = m_arMappingRight[i];
			if(item2.m_iGlvIdx == idxGlv)
			{
				m_arMappingRight[i] = item;
				return;
			}
		}
		m_arMappingRight.push_back(item);
	}
}
int CGloveBvhInsert::GetBvhDataSize()
{
	return m_bvhStructure.GetDataSize();

}
CString CGloveBvhInsert::GetBvhDataNameAt(int idxData)
{
	return m_bvhStructure.GetDataNameAt(idxData);
}
