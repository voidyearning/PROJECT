#include "stdafx.h"
#include "GloveCalibration.h"
#include <fstream>


CGloveCalibrationItem::CGloveCalibrationItem()
{
	m_fGain = 1;
	m_fOffset = 0;
}
CGloveCalibrationItem::CGloveCalibrationItem(float fGain, float fOffset)
{
	m_fGain = fGain;
	m_fOffset = fOffset;
}
CGloveCalibration::CGloveCalibration()
{
	Init();
}
void CGloveCalibration::Init()
{
	InitBaseCalibration();	
	InitAdjustCalibration();
}
void CGloveCalibration::ResetStandardBaseCalibration()
{
	//Let's keep everything standard - rawdata is degree, so this is basically change it to radian scale with some fine adjustment
	m_arBaseItem[0] = CGloveCalibrationItem(0.034, 142);//0.024->0.034
	m_arBaseItem[1] = CGloveCalibrationItem(0.016, 61);
	m_arBaseItem[2] = CGloveCalibrationItem(0.039, 130);//0.024->0.039
	m_arBaseItem[3] = CGloveCalibrationItem(-0.006, 200);//0.006->-0.006, 94->200

	m_arBaseItem[4] = CGloveCalibrationItem(0.019, 70);//99->70
	m_arBaseItem[5] = CGloveCalibrationItem(0.017, 61);
	m_arBaseItem[6] = CGloveCalibrationItem(0.024, 0);
	m_arBaseItem[7] = CGloveCalibrationItem(0.016, 127);

	m_arBaseItem[8] = CGloveCalibrationItem(0.013, 94);
	m_arBaseItem[9] = CGloveCalibrationItem(0.021, 60);//71->60
	m_arBaseItem[10] = CGloveCalibrationItem(0.001, 0);
	m_arBaseItem[11] = CGloveCalibrationItem(0.172, 165);

	m_arBaseItem[12] = CGloveCalibrationItem(0.027, 112);//0.017->0.027
	m_arBaseItem[13] = CGloveCalibrationItem(0.022, 112);//68->112
	m_arBaseItem[14] = CGloveCalibrationItem(0.024, 0);
	m_arBaseItem[15] = CGloveCalibrationItem(0.003, 130);

	m_arBaseItem[16] = CGloveCalibrationItem(0.015, 94);
	m_arBaseItem[17] = CGloveCalibrationItem(0.018, 100);//66->100
	m_arBaseItem[18] = CGloveCalibrationItem(0.024, 0);
	m_arBaseItem[19] = CGloveCalibrationItem(0.004, 112);

	m_arBaseItem[20] = CGloveCalibrationItem(0.024, 173);
	m_arBaseItem[21] = CGloveCalibrationItem(0.024, 0);
	m_arBaseItem[22] = CGloveCalibrationItem(0.016, 255);
}
void CGloveCalibration::InitBaseCalibration()
{
	m_arBaseItem.clear();
	for(int i = 0; i < 23; ++i)
		m_arBaseItem.push_back(CGloveCalibrationItem());

	ResetStandardBaseCalibration();	
}
void CGloveCalibration::InitAdjustCalibration()
{
	m_arAdjustItem.clear();
	for(int i = 0; i < 23; ++i)
		m_arAdjustItem.push_back(CGloveCalibrationItem());

	/*Let's keep everything standard
	m_arAdjustItem[3] = CGloveCalibrationItem(-1, 0);
	m_arAdjustItem[21] = CGloveCalibrationItem(1.4, 1);
	m_arAdjustItem[22] = CGloveCalibrationItem(-0.6, 3);*/
}
void CGloveCalibration::LoadFromFile(std::string strPath)
{
	m_arBaseItem.clear();
	m_arAdjustItem.clear();

	std::ifstream fin(strPath.c_str());

	//base item
	char bufBase[1024] = {0};
	fin.getline(bufBase, sizeof(bufBase));
	CString strLine(bufBase);
	int iItemBeg = strLine.Find(L"(");
	while(iItemBeg != -1)
	{
		CGloveCalibrationItem item;
		int iComma = strLine.Find(L",", iItemBeg);
		CString strGain = strLine.Mid(iItemBeg+1, iComma-iItemBeg-1);
		item.m_fGain = _wtof(strGain.GetBuffer());

		int iItemEnd = strLine.Find(L")", iItemBeg);
		CString strOffset = strLine.Mid(iComma+1, iItemEnd-iComma-1);
		item.m_fOffset = _wtof(strOffset.GetBuffer());
		m_arBaseItem.push_back(item);
		iItemBeg = strLine.Find(L"(", iItemEnd);
	};

	//adjust item
	char bufAdj[1024] = {0};
	fin.getline(bufAdj, sizeof(bufAdj));
	strLine = CString(bufAdj);
	iItemBeg = strLine.Find(L"(");
	while(iItemBeg != -1)
	{
		CGloveCalibrationItem item;
		int iComma = strLine.Find(L",", iItemBeg);
		CString strGain = strLine.Mid(iItemBeg+1, iComma-iItemBeg-1);
		item.m_fGain = _wtof(strGain.GetBuffer());

		int iItemEnd = strLine.Find(L")", iItemBeg);
		CString strOffset = strLine.Mid(iComma+1, iItemEnd-iComma-1);
		item.m_fOffset = _wtof(strOffset.GetBuffer());
		m_arAdjustItem.push_back(item);		
		iItemBeg = strLine.Find(L"(", iItemEnd);
	};
}
void CGloveCalibration::SaveToFile(std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	for(int i = 0; i < m_arBaseItem.size(); ++i)
	{
		fout << "(" << m_arBaseItem[i].m_fGain << "," << 
			m_arBaseItem[i].m_fOffset << ")";
	}
	fout << "\n";
	for(int i = 0; i < m_arAdjustItem.size(); ++i)
	{
		fout << "(" << m_arAdjustItem[i].m_fGain << "," << 
			m_arAdjustItem[i].m_fOffset << ")";
	}
	fout.flush();
	fout.close();
}

void CGloveCalibration::WriteToFast(std::string strPath)
{
	std::ofstream foutFastTr(strPath.c_str());
	for(int i = 0; i < m_arAdjustItem.size(); ++i)
	{
		CGloveCalibrationItem item = m_arAdjustItem[i];
		foutFastTr << item.m_fGain << " " << item.m_fOffset * (180/3.1415926) << " ";
	}
	foutFastTr.flush();
	foutFastTr.close();
}
void CGloveCalibration::WriteToTrHp(std::string strPath, bool bLeft)
{
	CString strPathBase(strPath.c_str());
	if(strPathBase.IsEmpty())
		strPathBase = CString(WS_PATH);
	if(bLeft)
		strPathBase = strPathBase + L"trainingset\\left";
	else
		strPathBase = strPathBase + L"trainingset\\right";

	//thumb =========================================================================
	//thumb roll
	std::ofstream fout_thumb_roll(strPathBase + L"\\0_HAND_SKEL_DOF_THUMB_ROLL\\go_0.go");
	if(bLeft)
		fout_thumb_roll << m_arAdjustItem[0].m_fGain << " " << m_arAdjustItem[0].m_fOffset * (180/3.1415926);
	else		
		fout_thumb_roll << m_arAdjustItem[0].m_fGain << " " << -m_arAdjustItem[0].m_fOffset * (180/3.1415926);
	fout_thumb_roll.flush();
	fout_thumb_roll.close();

	//thumb inner flex
	std::ofstream fout_thumb_inner_flex(strPathBase + L"\\3_HAND_SKEL_DOF_THUMB_FLEX_PROX\\go_3.go");
	fout_thumb_inner_flex << m_arAdjustItem[1].m_fGain << " " << m_arAdjustItem[1].m_fOffset * (180/3.1415926);
	fout_thumb_inner_flex.flush();
	fout_thumb_inner_flex.close();

	//thumb outter flex
	std::ofstream fout_thumb_outter_flex(strPathBase + L"\\4_HAND_SKEL_DOF_THUMB_FLEX_DIST\\go_4.go");
	fout_thumb_outter_flex << m_arAdjustItem[2].m_fGain << " " << m_arAdjustItem[2].m_fOffset * (180/3.1415926);
	fout_thumb_outter_flex.flush();
	fout_thumb_outter_flex.close();

	//thumb abd
	std::ofstream fout_thumb_abd(strPathBase + L"\\1_HAND_SKEL_DOF_THUMB_ABD\\go_1.go");
	fout_thumb_abd << m_arAdjustItem[3].m_fGain << " " << m_arAdjustItem[3].m_fOffset * (180/3.1415926);
	fout_thumb_abd.flush();
	fout_thumb_abd.close();

	//index =========================================================================
	//index MCP flex
	std::ofstream fout_index_MCP_flex(strPathBase + L"\\8_HAND_SKEL_DOF_INDEX_FLEX_PROX\\go_8.go");
	fout_index_MCP_flex << m_arAdjustItem[4].m_fGain << " " << m_arAdjustItem[4].m_fOffset * (180/3.1415926);
	fout_index_MCP_flex.flush();
	fout_index_MCP_flex.close();
	
	//index PIP flex
	std::ofstream fout_index_PIP_flex(strPathBase + L"\\9_HAND_SKEL_DOF_INDEX_FLEX_MID\\go_9.go");
	fout_index_PIP_flex << m_arAdjustItem[5].m_fGain << " " << m_arAdjustItem[5].m_fOffset * (180/3.1415926);
	fout_index_PIP_flex.flush();
	fout_index_PIP_flex.close();

	//index DIP flex
	std::ofstream fout_index_DIP_flex(strPathBase + L"\\10_HAND_SKEL_DOF_INDEX_FLEX_DIST\\go_10.go");
	fout_index_DIP_flex << m_arAdjustItem[6].m_fGain << " " << m_arAdjustItem[6].m_fOffset * (180/3.1415926);
	fout_index_DIP_flex.flush();
	fout_index_DIP_flex.close();

	//index abd
	std::ofstream fout_index_abd(strPathBase + L"\\7_HAND_SKEL_DOF_INDEX_ABD\\go_7.go");
	fout_index_abd << m_arAdjustItem[7].m_fGain << " " << m_arAdjustItem[7].m_fOffset * (180/3.1415926);
	fout_index_abd.flush();
	fout_index_abd.close();

	//middle =========================================================================
	//middle MCP flex
	std::ofstream fout_middle_MCP_flex(strPathBase + L"\\14_HAND_SKEL_DOF_MID_FLEX_PROX\\go_14.go");
	fout_middle_MCP_flex << m_arAdjustItem[8].m_fGain << " " << m_arAdjustItem[8].m_fOffset * (180/3.1415926);
	fout_middle_MCP_flex.flush();
	fout_middle_MCP_flex.close();

	//middle PIP flex
	std::ofstream fout_middle_PIP_flex(strPathBase + L"\\15_HAND_SKEL_DOF_MID_FLEX_MID\\go_15.go");
	fout_middle_PIP_flex << m_arAdjustItem[9].m_fGain << " " << m_arAdjustItem[9].m_fOffset * (180/3.1415926);
	fout_middle_PIP_flex.flush();
	fout_middle_PIP_flex.close();

	//middle DIP flex
	std::ofstream fout_middle_DIP_flex(strPathBase + L"\\16_HAND_SKEL_DOF_MID_FLEX_DIST\\go_16.go");
	fout_middle_DIP_flex << m_arAdjustItem[10].m_fGain << " " << m_arAdjustItem[10].m_fOffset * (180/3.1415926);
	fout_middle_DIP_flex.flush();
	fout_middle_DIP_flex.close();

	//middle abd
	std::ofstream fout_middle_abd(strPathBase + L"\\13_HAND_SKEL_DOF_MID_ABD\\go_13.go");
	fout_middle_abd << 0 << " " << 0;
	fout_middle_abd.flush();
	fout_middle_abd.close();

	//ring ==========================================================================
	//ring MCP flex
	std::ofstream fout_ring_MCP_flex(strPathBase + L"\\20_HAND_SKEL_DOF_RING_FLEX_PROX\\go_20.go");
	fout_ring_MCP_flex << m_arAdjustItem[12].m_fGain << " " << m_arAdjustItem[12].m_fOffset * (180/3.1415926);
	fout_ring_MCP_flex.flush();
	fout_ring_MCP_flex.close();

	//ring PIP flex
	std::ofstream fout_ring_PIP_flex(strPathBase + L"\\21_HAND_SKEL_DOF_RING_FLEX_MID\\go_21.go");
	fout_ring_PIP_flex << m_arAdjustItem[13].m_fGain << " " << m_arAdjustItem[13].m_fOffset * (180/3.1415926);
	fout_ring_PIP_flex.flush();
	fout_ring_PIP_flex.close();
	
	//ring DIP flex
	std::ofstream fout_ring_DIP_flex(strPathBase + L"\\22_HAND_SKEL_DOF_RING_FLEX_DIST\\go_22.go");
	fout_ring_DIP_flex << m_arAdjustItem[14].m_fGain << " " << m_arAdjustItem[14].m_fOffset * (180/3.1415926);
	fout_ring_DIP_flex.flush();
	fout_ring_DIP_flex.close();

	//ring abd
	std::ofstream fout_ring_abd(strPathBase + L"\\19_HAND_SKEL_DOF_RING_ABD\\go_19.go");
	fout_ring_abd << m_arAdjustItem[15].m_fGain << " " << m_arAdjustItem[15].m_fOffset * (180/3.1415926);
	fout_ring_abd.flush();
	fout_ring_abd.close();

	//pinky ==========================================================================
	//pinky MCP flex
	std::ofstream fout_pinky_MCP_flex(strPathBase + L"\\26_HAND_SKEL_DOF_PINKY_FLEX_PROX\\go_26.go");
	fout_pinky_MCP_flex << m_arAdjustItem[16].m_fGain << " " << m_arAdjustItem[16].m_fOffset * (180/3.1415926);
	fout_pinky_MCP_flex.flush();
	fout_pinky_MCP_flex.close();

	//pinky PIP flex
	std::ofstream fout_pinky_PIP_flex(strPathBase + L"\\27_HAND_SKEL_DOF_PINKY_FLEX_MID\\go_27.go");
	fout_pinky_PIP_flex << m_arAdjustItem[17].m_fGain << " " << m_arAdjustItem[17].m_fOffset * (180/3.1415926);
	fout_pinky_PIP_flex.flush();
	fout_pinky_PIP_flex.close();

	//pinky DIP flex
	std::ofstream fout_pinky_DIP_flex(strPathBase + L"\\28_HAND_SKEL_DOF_PINKY_FLEX_DIST\\go_28.go");
	fout_pinky_DIP_flex << m_arAdjustItem[18].m_fGain << " " << m_arAdjustItem[18].m_fOffset * (180/3.1415926);
	fout_pinky_DIP_flex.flush();
	fout_pinky_DIP_flex.close();

	//pinky abd
	std::ofstream fout_pinky_abd(strPathBase + L"\\25_HAND_SKEL_DOF_PINKY_ABD\\go_25.go");
	fout_pinky_abd << m_arAdjustItem[19].m_fGain << " " << m_arAdjustItem[19].m_fOffset * (180/3.1415926);
	fout_pinky_abd.flush();
	fout_pinky_abd.close();

	//wrist ==========================================================================
	std::ofstream fout_wrist_flex(strPathBase + L"\\29_HAND_SKEL_DOF_WRIST_FLEX\\go_29.go");
	fout_wrist_flex << m_arAdjustItem[21].m_fGain << " " << m_arAdjustItem[21].m_fOffset * (180/3.1415926);
	fout_wrist_flex.flush();
	fout_wrist_flex.close();

	std::ofstream fout_wrist_abd(strPathBase + L"\\30_HAND_SKEL_DOF_WRIST_ABD\\go_30.go");
	fout_wrist_abd << m_arAdjustItem[22].m_fGain << " " << m_arAdjustItem[22].m_fOffset * (180/3.1415926);
	fout_wrist_abd.flush();
	fout_wrist_abd.close();
}

void CGloveCalibration::UpdateCalibration(const CGloveCalibration& calibration)
{
	m_arBaseItem = calibration.m_arBaseItem;
	m_arAdjustItem = calibration.m_arAdjustItem;
}