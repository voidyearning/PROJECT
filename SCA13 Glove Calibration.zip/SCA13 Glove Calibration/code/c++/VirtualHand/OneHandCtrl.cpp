// LeftHandCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "OneHandCtrl.h"


// CLeftHandCtrl dialog

IMPLEMENT_DYNAMIC(COneHandCtrl, CDialog)

COneHandCtrl::COneHandCtrl(bool bLeft, CWnd* pParent /*=NULL*/)
	: CDialog(), m_ctrlPlayback(bLeft, this), m_ctrlKinematicRotation(bLeft, this), m_ctrlLinearCalibration(bLeft, this), m_ctrlKinematicDimension(bLeft, this)
{
	m_ctrlKinematicDimension.m_pHandSkeleton = ((COpenGLHandRendererKin*)m_ctrlPlayback.m_wndOpenGL.m_pRenderer)->m_pHand;
	m_bLeft = bLeft;
	m_pParentWnd = pParent;
}

COneHandCtrl::~COneHandCtrl()
{
}

void COneHandCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

//kinematic dimension: update size to handkin in playback and linCalib
	//gpr calib: independent
	//lin calib: independent
	//kin rotate:independent, but remember to synchronize frm pointer with playback
	//playback: update frm to kin rotate

BOOL COneHandCtrl::OnInitDialog()
{
	//create sub window and show in accurate location
	CRect rcPlayback, rcKinRot, rcLinCalib, rcGPRCalib, rcKinDim, rcParent;
	if(m_bLeft)
	{
		GetDlgItem(IDC_STATIC_PLAYBACK_L)->GetWindowRect(rcPlayback);
		GetDlgItem(IDC_STATIC_KINEMATIC_ROTATION_L)->GetWindowRect(rcKinRot);
		GetDlgItem(IDC_STATIC_LINEAR_CALIBRATION_L)->GetWindowRect(rcLinCalib);
		GetDlgItem(IDC_STATIC_GPR_CALIBRATION_L)->GetWindowRect(rcGPRCalib);
		GetDlgItem(IDC_STATIC_KINEMATIC_DIMENSION_L)->GetWindowRect(rcKinDim);
	}
	else
	{
		GetDlgItem(IDC_STATIC_PLAYBACK_R)->GetWindowRect(rcPlayback);
		GetDlgItem(IDC_STATIC_KINEMATIC_ROTATION_R)->GetWindowRect(rcKinRot);
		GetDlgItem(IDC_STATIC_LINEAR_CALIBRATION_R)->GetWindowRect(rcLinCalib);
		GetDlgItem(IDC_STATIC_GPR_CALIBRATION_R)->GetWindowRect(rcGPRCalib);
		GetDlgItem(IDC_STATIC_KINEMATIC_DIMENSION_R)->GetWindowRect(rcKinDim);
	}
	GetWindowRect(rcParent);
	rcPlayback.MoveToXY(rcPlayback.left-rcParent.left, rcPlayback.top-rcParent.top);
	rcKinRot.MoveToXY(rcKinRot.left-rcParent.left, rcKinRot.top-rcParent.top);
	rcLinCalib.MoveToXY(rcLinCalib.left-rcParent.left, rcLinCalib.top-rcParent.top);
	rcGPRCalib.MoveToXY(rcGPRCalib.left-rcParent.left, rcGPRCalib.top-rcParent.top);
	rcKinDim.MoveToXY(rcKinDim.left-rcParent.left, rcKinDim.top-rcParent.top);

	m_ctrlPlayback.Create(IDD_CTRL_PLAYBACK, this);
	m_ctrlKinematicRotation.Create(IDD_CTRL_KINEMATIC_ROTATION, this);
	m_ctrlLinearCalibration.Create(IDD_CTRL_LINEAR_CALIBRATION, this);
	m_ctrlGPRCalibration.Create(IDD_CTRL_GPR_CALIBRATION, this);
	m_ctrlKinematicDimension.Create(IDD_CTRL_KINEMATIC_DIMENSION, this);

	m_ctrlPlayback.MoveWindow(rcPlayback);
	m_ctrlKinematicRotation.MoveWindow(rcKinRot);
	m_ctrlLinearCalibration.MoveWindow(rcLinCalib);
	m_ctrlGPRCalibration.MoveWindow(rcGPRCalib);
	m_ctrlKinematicDimension.MoveWindow(rcKinDim);

	return CDialog::OnInitDialog();
}
BEGIN_MESSAGE_MAP(COneHandCtrl, CDialog)
END_MESSAGE_MAP()
