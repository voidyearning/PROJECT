#pragma once
#include <vector>
#include <string>
#include "RawAnimation.h"
#include "GloveAnimation.h"


class CRawTimeClip : public CRawClip
{
public:
	CRawTimeClip();
	CRawTimeClip(CRawClip clipMotion, CGlvClip clipTime);
	std::vector<float> m_arTime;
	void SaveToFile(std::string strPath);
	void LoadFromFile(std::string strPath);
	CRawClip ReSample(float fRateMS = 30, bool bAbsoluteTime=false);	
};
