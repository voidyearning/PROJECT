#pragma once
#include <vector>
#include <string>

//in radian, offset is radian
class CGloveCalibrationItem
{
public:
	CGloveCalibrationItem();
	CGloveCalibrationItem(float fGain, float fOffset);
	float m_fGain;
	float m_fOffset;
};
class CGloveCalibration
{
public:
	CGloveCalibration();
	void Init();
	void InitBaseCalibration();
	void ResetStandardBaseCalibration();
	void InitAdjustCalibration();
	std::vector<CGloveCalibrationItem> m_arBaseItem;
	std::vector<CGloveCalibrationItem> m_arAdjustItem;
	void LoadFromFile(std::string strPath);
	void SaveToFile(std::string strPath);
	void WriteToTrHp(std::string strPath="", bool bLeft = true);
	void WriteToFast(std::string strPath);
	void UpdateCalibration(const CGloveCalibration& calibration);
};
