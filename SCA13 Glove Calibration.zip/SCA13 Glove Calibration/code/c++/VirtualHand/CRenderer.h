#pragma once

class CRenderer
{
public:
	virtual void Render() = 0;
};
class COpenGLRenderer : public CRenderer
{

};