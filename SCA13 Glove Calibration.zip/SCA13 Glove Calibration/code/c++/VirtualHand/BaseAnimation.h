#pragma once
#include <vector>

#define STATIC_GAP    std::pair<int, int>
#define STATIC_GAPS  std::vector<STATIC_GAP >

class CBaseFrame
{
public:
	virtual ~CBaseFrame(){};
	
	std::vector<float> m_arData;
};
enum IK_FINGER_TOUCHING_TYPE 
	{
		eThumbIndex = 1, 
		eThumbMid = 2, 
		eThumbRing = 3, 
		eThumbPinky = 4
	};
class CBaseClip
{
public:
	static CBaseClip* NewFromFile(std::string strPath);
	virtual void SaveToFile(std::string strPath)=0;
	virtual void LoadFromFile(std::string strPath)=0;
	virtual int GetFrameCount()=0;
	virtual CBaseFrame* GetFrameAt(int iFrmIdx) = 0;
	virtual void SetFrameAt(int iFrmIdx, CBaseFrame*) = 0;
	virtual CBaseClip* GetSubClip(int iBegIdx, int iEndIdx) {return NULL;};
	virtual STATIC_GAPS FindUnchaningData(int iConsecutiveThreshold = 3){STATIC_GAPS gaps; return gaps;};

	//statistical related
	virtual double GetMaxVariance(int iIdx);
	virtual double GetStandardDeviation(int iIdx);
	virtual double GetMean(int iIdx);
	virtual double GetMaxDeviation(int iIdx);
};