#pragma once
#include "GloveAnimation.h"
#include "MatlabUtil.h"
#include "RawAnimation.h"
#include "GloveCalibration.h"

// CGloveSamplingDlg dialog

class CGloveSamplingDlg : public CDialog
{
	DECLARE_DYNAMIC(CGloveSamplingDlg)

public:
	CGloveSamplingDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGloveSamplingDlg();

// Dialog Data
	enum { IDD = IDD_DIALOG_SAMPLING };

	//GLV -> RAW
	CGloveCalibration m_calib;
	std::string m_strGRSrcPath_sp;
	std::string m_strGRDestPath_sp;
	
	//FK RAW -> TR
	int m_iFKSp2TrIndex;
	float m_fFKSp2TrValue_r;
	bool m_bUseFKValue_r;
	std::string m_strFKPath_sp;
	std::string m_strFKPosePath_sp;
	std::string m_strFKPath_tr;

	//CC RAW -> TR
	std::string m_strCCPath_sp;
	std::string m_strCCPath_tr;
	std::vector<int> m_arCCSp2TrIndex_s;
	float m_fCCSp2TrValue_r;	
	
	//IK RAW -> TR
	std::vector<int> m_arIKSp2TrIndex_s;
	int m_iIKSp2TrIndex_r;
	std::string m_strIKPath_sp;
	std::string m_strClosedIKPath_sp;
	std::string m_strIKPath_tr;

	//PREDICT RAW + MAT -> RAW
	std::string m_strSrcToPredictPath;
	std::string m_strDestPredictedPath;
	std::string m_strPredictedMatPath;
	std::vector<std::string> m_arPredictTrainingPath; 
	std::vector<int> m_arPredictIndex_s;
	int m_iPredictIndex_r;

	//MERGE
	std::vector<std::string> m_arMergePath_src;
	std::string m_strMergePath_dest;

	//REDUNDANCY ELIMINATION
	std::string m_strRedundantPath_src;
	std::string m_strNoRedundantPath_dest;

	char m_cMarkerType;
	char m_cMarkerColor;
	bool m_bByDifference;
	bool m_bNewFigure;
	enum E_SHOW_WHAT {ePlot, eScatter, eGriddata, eDelaunay} m_eShowWhat;	
	bool m_bEliminateRepetitiveSamplings;


	
	


protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:	
	afx_msg void OnBnClickedButtonBswCCTRFile();
	afx_msg void OnBnClickedButtonCC2TR();
	afx_msg void OnBnClickedButtonBrowseCCSPFile();
	afx_msg void OnBnClickedButtonPlotSensorReadingFile();
	afx_msg void OnBnClickedRadioMarkerO();
	afx_msg void OnBnClickedRadioMarkerd();
	afx_msg void OnBnClickedRadioMarkerdot();
	afx_msg void OnBnClickedRadioMarkerX();
	afx_msg void OnBnClickedRadioMarkerPlus();
	afx_msg void OnBnClickedRadioMarkerM();
	afx_msg void OnBnClickedRadioMarkerR();
	afx_msg void OnBnClickedRadioMarkerY();
	afx_msg void OnBnClickedRadioMarkerG();
	afx_msg void OnBnClickedRadioMarkerC();
	afx_msg void OnBnClickedRadioMarkerB();
	afx_msg void OnBnClickedRadioMarkerK();
	afx_msg void OnBnClickedRadioAnalysisSensor();
	afx_msg void OnBnClickedRadioAnalysisDifference();
	afx_msg void OnEnChangeEditAbdReal();
	afx_msg void OnBnClickedRadioNewFigure();
	afx_msg void OnBnClickedRadioHoldOn();
	afx_msg void OnBnClickedRadioPlot3();
	afx_msg void OnBnClickedRadioScatter3();
	afx_msg void OnBnClickedRadioGriddata();
	afx_msg void OnBnClickedRadioDelaunay();
	afx_msg void OnBnClickedButtonCalculateRealAbd();
	afx_msg void OnBnClickedButtonBrowseSrcToPredictFile();
	afx_msg void OnBnClickedButtonDestPredictedFile();
	afx_msg void OnBnClickedButtonPredictAbdByDelaunay();
	afx_msg void OnBnClickedButtonPredictedMatFile();
	afx_msg void OnBnClickedFillTargetByMat();
	afx_msg void OnBnClickedButtonPreprocessTr();
	afx_msg void OnBnClickedButtonBswPreprocessTrFile();
	CRawClip EliminateRepetitive(CRawClip clipRaw, MatlabUtil::E_ABDUCTION_TYPE eType);
	afx_msg void OnBnClickedButtonBrowseIKSPFile();
	afx_msg void OnBnClickedButtonIKSPClosedFile();
	afx_msg void OnBnClickedButtonIK2TR();
	afx_msg void OnBnClickedButtonLoadCalibration();
	afx_msg void OnBnClickedButtonBrowseGRSPSrcFile();
	afx_msg void OnBnClickedButtonBrowseGRSPDestFile();
	afx_msg void OnBnClickedButtonReCalibrate();
	afx_msg void OnBnClickedButtonVariance();
	afx_msg void OnBnClickedButtonBswIKTRFile();
	afx_msg void OnEnChangeEditFKTRIdx();
	afx_msg void OnBnClickedButtonBrowseFKSPFile();
	afx_msg void OnBnClickedButtonFKPoseFile();
	afx_msg void OnBnClickedButtonBswFKTRFile();
	afx_msg void OnBnClickedButtonFK2TR();
	afx_msg void OnBnClickedButtonGlvRaw();
	afx_msg void OnBnClickedButtonMergeCcSp();
	afx_msg void OnEnChangeEditTrIkIdxS();
	afx_msg void OnEnChangeEditTrIkIdxR();
	afx_msg void OnEnChangeEditTrFkValueR();
	afx_msg void OnBnClickedCheckFkUseValueR();
	afx_msg void OnEnChangeEditTrCcIdx();
	afx_msg void OnEnChangeEditTrCcValueR();
	afx_msg void OnEnChangeEditPredictIdxS();
	afx_msg void OnEnChangeEditPredictIdxR();
	afx_msg void OnBnClickedButtonPredictTrainingFile();
	afx_msg void OnBnClickedButtonBrowseMergeSrcFile();
	afx_msg void OnBnClickedButtonBrowseMergeDestFile();
	afx_msg void OnBnClickedButtonMerge();
	afx_msg void OnBnClickedButtonBrowseRedundancyEliminationSrcFile();
	afx_msg void OnBnClickedButtonBrowseRedundancyEliminationDestFile();
	afx_msg void OnBnClickedButtonEliminateRedundancy();
	afx_msg void OnBnClickedButtonPlotGlv();
	afx_msg void OnBnClickedButtonTrain();
	afx_msg void OnBnClickedButtonLoadTrained();
	afx_msg void OnBnClickedButtonAverage();
	afx_msg void OnBnClickedButtonPlotIdx();
	afx_msg void OnBnClickedButtonEliminateInputRedundancy();
	afx_msg void OnBnClickedButtonBatchWspath();
	afx_msg void OnBnClickedButtonCreateTrFolder();
	afx_msg void OnBnClickedButtonBatchReCalibrate();
	afx_msg void OnBnClickedButtonBatchGprFull();
	afx_msg void OnBnClickedButtonBatchGprFitc();
	afx_msg void OnBnClickedButtonBatchAdjustWrist();
	afx_msg void OnBnClickedButtonBatchToBvh();
	afx_msg void OnBnClickedButtonGlvRawtime();
	afx_msg void OnBnClickedButtonUnCalibrate();
	afx_msg void OnBnClickedButtonBatchUnCalibrate();
};
