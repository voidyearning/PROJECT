#pragma once

#include "BvhAnimation.h"

class CGloveBvhInsertDlg : public CDialog
{
	DECLARE_DYNAMIC(CGloveBvhInsertDlg)

public:
	CGloveBvhInsertDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGloveBvhInsertDlg();

// Dialog Data
	enum { IDD = IDD_INSERT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedRadioLeft();
	afx_msg void OnBnClickedRadioRight();
	afx_msg void OnEnChangeEditStart();
	afx_msg void OnEnChangeEditEnd();

	CGloveBvhInsert m_glvInsert;
};
