#include "stdafx.h"
#include "GPRDB.h"

CGPRDBItem::CGPRDBItem()
{

}
CGPRDBItem::CGPRDBItem(CRawFrame frmSensor, CRawFrame frmSln)
{
	m_frmSensor = frmSensor;
	m_frmSln = frmSln;	
}

CGPRDB* CGPRDB::m_pIKDB = NULL;
CGPRDB* CGPRDB::GetIKDB()
{
	if(m_pIKDB == NULL)
		m_pIKDB = new CGPRDB();

	return m_pIKDB;
}
void CGPRDB::SaveToFile(std::string strPath)
{}
void CGPRDB::LoadFromFile(std::string strPath)
{}

CRawClip CGPRDB::GetClipSensor()
{
	CRawClip clipResult;
	for(int i = 0; i < m_arDBItem.size(); ++i)
	{
		clipResult.m_arFrame.push_back(m_arDBItem[i].m_frmSensor);
	}
	return clipResult;
}
CRawClip CGPRDB::GetClipSln()
{	
	CRawClip clipResult;
	for(int i = 0; i < m_arDBItem.size(); ++i)
	{
		clipResult.m_arFrame.push_back(m_arDBItem[i].m_frmSln);
	}
	return clipResult;
}
std::vector<int> CGPRDB::GetKNearestThumbSensor(CRawFrame frmTarget, int iK, bool bHD)
{
	CRawClip clipSensor = GetClipSensor();
	return clipSensor.GetKNearestThumb(frmTarget, iK, bHD);
}

CRawFrame CGPRDB::GetSlnGuessed(CRawFrame frmSensor, std::vector<int> arIdx)
{
	CRawFrame frmSln = frmSensor;
	std::vector<float> arCoef0, arCoef1, arCoef2, arCoef3, arCoef4;
	float fSum0=0, fSum1=0, fSum2 =0, fSum3 = 0, fSum4 = 0;
	for(int i = 0; i < arIdx.size(); ++i)
	{
		int iIndex = arIdx[i];
		CGPRDBItem item = m_arDBItem[iIndex];
		arCoef0.push_back(abs(frmSensor.m_arData[0] - item.m_frmSensor.m_arData[0]));
		fSum0 += abs(frmSensor.m_arData[0] - item.m_frmSensor.m_arData[0]);

		arCoef1.push_back(abs(frmSensor.m_arData[1] - item.m_frmSensor.m_arData[1]));		
		fSum1 += abs(frmSensor.m_arData[1] - item.m_frmSensor.m_arData[1]);

		arCoef2.push_back(abs(frmSensor.m_arData[2] - item.m_frmSensor.m_arData[2]));		
		fSum2 += abs(frmSensor.m_arData[2] - item.m_frmSensor.m_arData[2]);

		arCoef3.push_back(abs(frmSensor.m_arData[3] - item.m_frmSensor.m_arData[3]));		
		fSum3 += abs(frmSensor.m_arData[3] - item.m_frmSensor.m_arData[3]);

		arCoef4.push_back(abs(frmSensor.m_arData[4] - item.m_frmSensor.m_arData[4]));		
		fSum4 += abs(frmSensor.m_arData[4] - item.m_frmSensor.m_arData[4]);
	}
	
	//normalize and calculate weights
	float fSumSum0=0, fSumSum1=0, fSumSum2 =0, fSumSum3 = 0, fSumSum4 = 0;
	for(int i = 0; i < arIdx.size(); ++i)
	{
		arCoef0[i] = 1 - arCoef0[i] / fSum0;
		fSumSum0 += arCoef0[i];

		arCoef1[i] = 1 - arCoef1[i] / fSum1;
		fSumSum1 += arCoef1[i];

		arCoef2[i] = 1 - arCoef2[i] / fSum2;
		fSumSum2 += arCoef2[i];

		arCoef3[i] = 1 - arCoef3[i] / fSum3;
		fSumSum3 += arCoef3[i];

		arCoef4[i] = 1 - arCoef4[i] / fSum4;
		fSumSum4 += arCoef4[i];
	}
	for(int i = 0; i < arIdx.size(); ++i)
	{
		arCoef0[i] = arCoef0[i] / fSumSum0;
		arCoef1[i] = arCoef1[i] / fSumSum1;
		arCoef2[i] = arCoef2[i] / fSumSum2;
		arCoef3[i] = arCoef3[i] / fSumSum3;
		arCoef4[i] = arCoef4[i] / fSumSum4;
	}
	//calculate guessed solution
	frmSln.m_arData[0] = 0;
	frmSln.m_arData[1] = 0;
	frmSln.m_arData[2] = 0;
	frmSln.m_arData[3] = 0;
	frmSln.m_arData[4] = 0;
	for(int i = 0; i < arIdx.size(); ++i)
	{
		int iIndex = arIdx[i];
		CGPRDBItem item = m_arDBItem[iIndex];
		frmSln.m_arData[0] += arCoef0[i] * item.m_frmSln.m_arData[0];
		frmSln.m_arData[1] += arCoef1[i] * item.m_frmSln.m_arData[1];
		frmSln.m_arData[2] += arCoef2[i] * item.m_frmSln.m_arData[2];
		frmSln.m_arData[3] += arCoef3[i] * item.m_frmSln.m_arData[3];
		frmSln.m_arData[4] += arCoef4[i] * item.m_frmSln.m_arData[4];
	}
	return frmSln;
}
//we can only add smoothed data
bool CGPRDB::CheckQuality(CGPRDBItem item)
{
	if(m_arDBItem.size() ==0)
		return true;

	std::vector<int> arIdx = GetKNearestThumbSensor(item.m_frmSensor);
	CRawClip clipSensor, clipSln;
	for(int i = 0; i < arIdx.size(); ++i)
	{
		int iIndex = arIdx[i];
		clipSensor.m_arFrame.push_back(m_arDBItem[iIndex].m_frmSensor);
		clipSln.m_arFrame.push_back(m_arDBItem[iIndex].m_frmSln);
	}

	CGPRDBItem itemAvg(clipSensor.GetAveragePose(), clipSln.GetAveragePose());
	float fDiffSensor0 = abs(itemAvg.m_frmSensor.m_arData[0] - item.m_frmSensor.m_arData[0]);
	float fDiffSensor1 = abs(itemAvg.m_frmSensor.m_arData[1] - item.m_frmSensor.m_arData[1]);	
	float fDiffSensor2 = abs(itemAvg.m_frmSensor.m_arData[2] - item.m_frmSensor.m_arData[2]);	
	float fDiffSensor3 = abs(itemAvg.m_frmSensor.m_arData[3] - item.m_frmSensor.m_arData[3]);	
	float fDiffSensor4 = abs(itemAvg.m_frmSensor.m_arData[4] - item.m_frmSensor.m_arData[4]);
	float fDiffSensorAll = fDiffSensor0 + fDiffSensor1 + fDiffSensor2 + fDiffSensor3 + fDiffSensor4;

	float fDiffSln0 = abs(itemAvg.m_frmSln.m_arData[0] - item.m_frmSln.m_arData[0]);
	float fDiffSln1 = abs(itemAvg.m_frmSln.m_arData[1] - item.m_frmSln.m_arData[1]);	
	float fDiffSln2 = abs(itemAvg.m_frmSln.m_arData[2] - item.m_frmSln.m_arData[2]);	
	float fDiffSln3 = abs(itemAvg.m_frmSln.m_arData[3] - item.m_frmSln.m_arData[3]);	
	float fDiffSln4 = abs(itemAvg.m_frmSln.m_arData[4] - item.m_frmSln.m_arData[4]);
	float fDiffSlnAll = fDiffSln0 + fDiffSln1 + fDiffSln2 + fDiffSln3 + fDiffSln4;


	float fDiffSlnMax = 5;
	if(fDiffSln0  > fDiffSensorAll && fDiffSln0 > fDiffSlnMax)//dof 0 moves too much
		return false;

	if(fDiffSln1 > fDiffSensorAll && fDiffSln1 > fDiffSlnMax)//dof 1 moves too much
		return false;

	if(fDiffSln2 > fDiffSensorAll && fDiffSln2 > fDiffSlnMax)//dof 2 moves too much
		return false;

	if(fDiffSln3 > fDiffSensorAll && fDiffSln3 > fDiffSlnMax)//dof 3 moves too much
		return false;

	if(fDiffSln4 > fDiffSensorAll && fDiffSln4 > fDiffSlnMax)//dof 4 moves too much
		return false;

	if(fDiffSensorAll == 0 && fDiffSlnAll == 0)//already had it in DB
		return false;

	return true;
}