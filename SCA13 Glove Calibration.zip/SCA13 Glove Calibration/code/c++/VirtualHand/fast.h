#include <string>
#include "RawAnimation.h"
#include "GloveSkeleton.h"

class CFastCal
{
public:
	CFastCal();
	CFastCal(std::string strBasePath);
	virtual ~CFastCal()
	{ 
		delete m_pHandLeft; 
		delete m_pHandRight;
	};
	std::string m_strBasePath;
	CHandSkeletonKin* m_pHandLeft;
	CHandSkeletonKin* m_pHandRight;
	int m_iHD;

	void SetBasePath(std::string strBasePath);
	void ExtractTrainingData();
	void Train();
	void BatchCalibrate();
	void Calibrate(CRawClip& clipInput, CRawClip& clipOutput, bool bLeft = true);

//private:
	//first step, fk finger except thumb
	void generate_fk_groundtruth(bool bLeft = true);
	//0. linear if necessary 
	void extract_linear_go(bool bLeft = true);
	//1. flex
	void extract_finger_flex_tr(bool bLeft = true, bool bFull = true);
	void train_finger_flex(bool bLeft = true, bool bFull = true);
	void generate_finger_2flex(bool bLeft = true, bool bFull = true);
	//2. abd
	void extract_finger_abd_tr(bool bLeft = true, bool bFull = true);
	void train_finger_abd(bool bLeft = true, bool bFull = true);
	void generate_finger_3abd(bool bLeft = true, bool bFull = true);
	//3.thumb
	void generate_ik_groundtruth(bool bLeft = true, bool bFull = true);
	void generate_ik_groundtruth2(bool bLeft = true, bool bFull = true);
	void extract_thumb_tr(bool bLeft = true, bool bFull = true);
	void extract_thumb_tr2(bool bLeft = true, bool bFull = true);
	void train_thumb(bool bLeft = true, bool bFull = true);	
	void generate_thumb_4ik(bool bLeft=true, bool bFull=true);
	void check_ik_quality(bool bLeft = true, bool bFull = true);

	void extract_wrist_tr(bool bLeft = true, bool bFull = true);

	void batch_calibrate(bool bLeft = true);
	void batch_calibrate_under(CString strRawPath, CString strResultPath, bool bLeft);
	void load_hand_size(CString strSizePath, bool bLeft = true);

	//extremely fast
	CRawClip xfast_calibrate(CRawClip clipInput, bool bLeft = true, std::string strFileName = "");
	CRawClip xfast_calibrate_finger_flex(CRawClip clipInput, bool bLeft = true);
	CRawClip xfast_calibrate_finger_abd(CRawClip clipInput, bool bLeft = true);
	CRawClip xfast_calibrate_thumb(CRawClip clipInput, bool bLeft = true);
	CRawClip xfast_calibrate_ik(CRawClip clipInput, std::string strThisName, bool bLeft = true);

	
};