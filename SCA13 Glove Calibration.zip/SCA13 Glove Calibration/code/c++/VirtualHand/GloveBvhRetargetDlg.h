#pragma once


// CGloveBvhRetargetDlg dialog

#include "GloveAnimation.h"
#include "BvhAnimation.h"
class CGloveBvhRetargetDlg : public CDialog
{
	DECLARE_DYNAMIC(CGloveBvhRetargetDlg)

public:
	CGloveBvhRetargetDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGloveBvhRetargetDlg();

// Dialog Data
	enum { IDD = IDD_RETARGET_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLbnSelchangeListBvh();

	CGloveBvhRetarget m_glvRetarget;
	CGloveMapping m_curGlvMapping;
	CGloveMappingItem m_curGlvMappingItem;

	afx_msg void OnLbnSelchangeListGlove();
	afx_msg void OnEnChangeEditWeight();
	void UpdateCtrlFromMapping();
	void UpdateMappingFromCtrl();
	afx_msg void OnBnClickedRadioLeft();
	afx_msg void OnBnClickedRadioRight();
	afx_msg void OnBnClickedButtonReset();
	afx_msg void OnBnClickedButtonLoad();
	afx_msg void OnBnClickedButtonSave();
};
