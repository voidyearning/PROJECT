#include "deprecated.h"
#include <gl/glaux.h>
#include <gl/glut.h>

CKinematicHandRigidPalmLeft::CKinematicHandRigidPalmLeft()
{
}
void CKinematicHandRigidPalmLeft::ConstructHand()
{
	for(int i = 0; i < m_arChain.size(); ++i)
		delete m_arChain[i];
	m_arChain.clear();

	//thumb=================================================================
	CKinematicChain* pChainThumb = new CKinematicChain(CKinematicPos(1.5, -0, 2.0), E_CHAIN_THUMB);
	
	CKinematicJoint* pJointThumbRoot = new CKinematicJoint(CKinematicPos(0, 0, 0), E_JOINT_THUMB_ROOT);
	pJointThumbRoot->AddDOF(new CKinematicDOF(15, CKinematicVec3D(1,0,0), E_DOF_ROLL_X));
	pChainThumb->AddJoint(pJointThumbRoot);

	CKinematicJoint* pJointThumbAbduct = new CKinematicJoint(CKinematicPos(0, 0, 1.0), E_JOINT_THUMB_ABDUCT);
	pJointThumbAbduct->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y));
	pChainThumb->AddJoint(pJointThumbAbduct);

	CKinematicJoint* pJointThumbMid = new CKinematicJoint(CKinematicPos(3.5, 0, 0), E_JOINT_THUMB_FLEX_1);
	pJointThumbMid->AddDOF(new CKinematicDOF(0, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z));
	pChainThumb->AddJoint(pJointThumbMid);

	CKinematicJoint* pJointThumbDistal = new CKinematicJoint(CKinematicPos(3.6, 0, 0), E_JOINT_THUMB_FLEX_2);
	pJointThumbDistal->AddDOF(new CKinematicDOF(0, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z));
	pChainThumb->AddJoint(pJointThumbDistal);

	CKinematicJoint* pJointThumbEnd = new CKinematicJoint(CKinematicPos(3, 0, 0), E_JOINT_THUMB_END);
	pChainThumb->AddJoint(pJointThumbEnd);

	//index==================================================================
	//proximal
	CKinematicChain* pChainIndex = new CKinematicChain(CKinematicPos(7,0,2.3), E_CHAIN_INDEX);
	CKinematicJoint* pJointIndexProximal = new CKinematicJoint(CKinematicPos(0,0,0), E_JOINT_INDEX_PROXIMAL);
	pJointIndexProximal->AddDOF(new CKinematicDOF(0, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y));
	pJointIndexProximal->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z));
	pChainIndex->AddJoint(pJointIndexProximal);
	//mid
	CKinematicJoint* pJointIndexMid = new CKinematicJoint(CKinematicPos(4.5,0,0), E_JOINT_INDEX_MID);
	pJointIndexMid->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1),E_DOF_FLEX_Z));
	pChainIndex->AddJoint(pJointIndexMid);
	//distal
	CKinematicJoint* pJointIndexDistal = new CKinematicJoint(CKinematicPos(2.6,0,0), E_JOINT_INDEX_DISTAL);
	pJointIndexDistal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z));
	pChainIndex->AddJoint(pJointIndexDistal);
	//end
	CKinematicJoint* pJointIndexEnd = new CKinematicJoint(CKinematicPos(2.2,0,0),E_JOINT_INDEX_END);
	pChainIndex->AddJoint(pJointIndexEnd);

	//mid===================================================================
	//proximal
	CKinematicChain* pChainMid = new CKinematicChain(CKinematicPos(7.1,0,0),E_CHAIN_MID);
	CKinematicJoint* pJointMidProximal = new CKinematicJoint(CKinematicPos(0,0,0),E_JOINT_MID_PROXIMAL);
	pJointMidProximal->AddDOF(new CKinematicDOF(0, CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y));
	pJointMidProximal->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z));
	pChainMid->AddJoint(pJointMidProximal);
	//mid
	CKinematicJoint* pJointMidMid = new CKinematicJoint(CKinematicPos(5,0,0),E_JOINT_MID_MID);
	pJointMidMid->AddDOF(new CKinematicDOF(-15, CKinematicVec3D(0,0,1), E_DOF_FLEX_Z));
	pChainMid->AddJoint(pJointMidMid);
	//distal
	CKinematicJoint* pJointMidDistal = new CKinematicJoint(CKinematicPos(2.9,0,0),E_JOINT_MID_DISTAL);
	pJointMidDistal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z));
	pChainMid->AddJoint(pJointMidDistal);
	//end
	CKinematicJoint* pJointMidEnd = new CKinematicJoint(CKinematicPos(2.4,0,0), E_JOINT_MID_END);
	pChainMid->AddJoint(pJointMidEnd);

	//ring====================================================================
	//proximal
	CKinematicChain* pChainRing = new CKinematicChain(CKinematicPos(6.8,0,-2), E_CHAIN_RING);
	CKinematicJoint* pJointRingProximal = new CKinematicJoint(CKinematicPos(0,0,0), E_JOINT_RING_PROXIMAL);
	pJointRingProximal->AddDOF(new CKinematicDOF(0,CKinematicVec3D(0,1,0), E_DOF_ABDUCT_Y));
	pJointRingProximal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1), E_DOF_FLEX_Z));
	pChainRing->AddJoint(pJointRingProximal);
	//mid
	CKinematicJoint* pJointRingMid = new CKinematicJoint(CKinematicPos(5,0,0), E_JOINT_RING_MID);
	pJointRingMid->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z));
	pChainRing->AddJoint(pJointRingMid);
	//distal
	CKinematicJoint* pJointRingDistal = new CKinematicJoint(CKinematicPos(2.7,0,0),E_JOINT_RING_DISTAL);
	pJointRingDistal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z));
	pChainRing->AddJoint(pJointRingDistal);
	//end
	CKinematicJoint* pJointRingEnd = new CKinematicJoint(CKinematicPos(2.3,0,0),E_JOINT_RING_END);
	pChainRing->AddJoint(pJointRingEnd);

	//pinky====================================================================
	//proximal
	CKinematicChain* pChainPinky = new CKinematicChain(CKinematicPos(6.5,0,-3.5), E_CHAIN_PINKY);
	CKinematicJoint* pJointPinkyProximal = new CKinematicJoint(CKinematicPos(0,0,0),E_JOINT_PINKY_PROXIMAL);
	pJointPinkyProximal->AddDOF(new CKinematicDOF(0,CKinematicVec3D(0,1,0),E_DOF_ABDUCT_Y));
	pJointPinkyProximal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z));
	pChainPinky->AddJoint(pJointPinkyProximal);
	//mid
	CKinematicJoint* pJointPinkyMid = new CKinematicJoint(CKinematicPos(3.6,0,0),E_JOINT_PINKY_MID);
	pJointPinkyMid->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z));
	pChainPinky->AddJoint(pJointPinkyMid);
	//distal
	CKinematicJoint* pJointPinkyDistal = new CKinematicJoint(CKinematicPos(2.1,0,0),E_JOINT_PINKY_DISTAL);
	pJointPinkyDistal->AddDOF(new CKinematicDOF(-15,CKinematicVec3D(0,0,1),E_DOF_FLEX_Z));
	pChainPinky->AddJoint(pJointPinkyDistal);
	//end
	CKinematicJoint* pJointPinkyEnd = new CKinematicJoint(CKinematicPos(2.2,0,0),E_JOINT_PINKY_END);
	pChainPinky->AddJoint(pJointPinkyEnd);

	//populate global info ============================================================
	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();

	//initialize goal ================================================================
	pChainThumb->m_posGoal = pChainThumb->m_arJoint[pChainThumb->m_arJoint.size()-1]->m_posGlobalCoord;
	pChainIndex->m_posGoal = pChainIndex->m_arJoint[pChainIndex->m_arJoint.size()-1]->m_posGlobalCoord;
	pChainMid->m_posGoal = pChainMid->m_arJoint[pChainMid->m_arJoint.size()-1]->m_posGlobalCoord;
	pChainRing->m_posGoal = pChainRing->m_arJoint[pChainRing->m_arJoint.size()-1]->m_posGlobalCoord;
	pChainPinky->m_posGoal = pChainPinky->m_arJoint[pChainPinky->m_arJoint.size()-1]->m_posGlobalCoord;

	//add to vector ================================================================
	m_arChain.push_back(pChainThumb);
	m_arChain.push_back(pChainIndex);
	m_arChain.push_back(pChainMid);
	m_arChain.push_back(pChainRing);
	m_arChain.push_back(pChainPinky);
}
void CKinematicHandRigidPalmLeft::DestructHand()
{
	for(int i = 0; i < m_arChain.size(); ++i)
		delete m_arChain[i];
	m_arChain.clear();
}
void CKinematicHandRigidPalmLeft::Reset()
{
	SetDefaultPose();
}

void CKinematicHandRigidPalmLeft::SetDefaultPose()
{	
	//thumb
	CKinematicChain* pChainThumb =m_arChain[0];
	/*roll*/	pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 15;
	/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flex1*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flex2*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//index
	CKinematicChain* pChainIndex =m_arChain[1];
	/*abd*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	/*flexMid*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexDist*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	//mid
	CKinematicChain* pChainMid = m_arChain[2];	
	/*abd*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	/*flexMid*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexDist*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	/*abd*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	/*flexMid*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexDist*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	//pinky
	CKinematicChain* pChainPinky =m_arChain[4];	
	/*abd*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = -15;
	/*flexMid*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -15;
	/*flexDist*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -15;

	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();
}
void CKinematicHandRigidPalmLeft::SetFlatPose()
{
	//thumb
	CKinematicChain* pChainThumb = m_arChain[0];
	/*roll*/	pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flex1*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flex2*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//index
	CKinematicChain* pChainIndex = m_arChain[1];
	/*abd*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//mid
	CKinematicChain* pChainMid = m_arChain[2];	
	/*abd*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	/*abd*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//pinky
	CKinematicChain* pChainPinky = m_arChain[4];	
	/*abd*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();
}
void CKinematicHandRigidPalmLeft::SetFistPose()
{
	//thumb
	CKinematicChain* pChainThumb = m_arChain[0];
	/*roll*/	pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 60;
	/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -30;
	/*flex1*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -45;
	/*flex2*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	//index
	CKinematicChain* pChainIndex = m_arChain[1];
	/*abd*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = -100;
	/*flexMid*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -90;
	/*flexDist*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	//mid
	CKinematicChain* pChainMid = m_arChain[2];	
	/*abd*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = -100;
	/*flexMid*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -90;
	/*flexDist*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	/*abd*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = -100;
	/*flexMid*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -90;
	/*flexDist*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	//pinky
	CKinematicChain* pChainPinky = m_arChain[4];	
	/*abd*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = -100;
	/*flexMid*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -90;
	/*flexDist*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = -90;

	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();
}
void CKinematicHandRigidPalmLeft::SetSpreadPose()
{
	//thumb
	CKinematicChain* pChainThumb = m_arChain[0];
	/*roll*/	pChainThumb->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*abd*/pChainThumb->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = -45;
	/*flex1*/pChainThumb->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flex2*/pChainThumb->m_arJoint[3]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//index
	CKinematicChain* pChainIndex = m_arChain[1];
	/*abd*/pChainIndex->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = -30;
	/*flexProx*/pChainIndex->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainIndex->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainIndex->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//mid
	CKinematicChain* pChainMid = m_arChain[2];	
	/*abd*/pChainMid->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexProx*/pChainMid->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainMid->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainMid->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//ring
	CKinematicChain* pChainRing = m_arChain[3];
	/*abd*/pChainRing->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 20;
	/*flexProx*/pChainRing->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainRing->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainRing->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	//pinky
	CKinematicChain* pChainPinky = m_arChain[4];	
	/*abd*/pChainPinky->m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle = 30;
	/*flexProx*/pChainPinky->m_arJoint[0]->m_arDOF[1]->m_dLocalRotationAngle = 0;
	/*flexMid*/pChainPinky->m_arJoint[1]->m_arDOF[0]->m_dLocalRotationAngle = 0;
	/*flexDist*/pChainPinky->m_arJoint[2]->m_arDOF[0]->m_dLocalRotationAngle = 0;

	pChainThumb->PopulateGlobalPosAndAxis();
	pChainIndex->PopulateGlobalPosAndAxis();
	pChainMid->PopulateGlobalPosAndAxis();
	pChainRing->PopulateGlobalPosAndAxis();
	pChainPinky->PopulateGlobalPosAndAxis();
}
CKinematicChain* CKinematicHandRigidPalmLeft::GetChain(enum HAND_CHAIN_ID eChainId)
{
	switch(eChainId)
	{
	case E_CHAIN_THUMB: return m_arChain[0];
	case E_CHAIN_INDEX: return m_arChain[1];
	case E_CHAIN_MID: return m_arChain[2];
	case E_CHAIN_RING: return m_arChain[3];
	case E_CHAIN_PINKY: return m_arChain[4];
	}
	return NULL;
}
CKinematicJoint* CKinematicHandRigidPalmLeft::GetJoint(enum HAND_JOINT_ID eJointId)
{
	switch(eJointId)
	{
	case E_JOINT_THUMB_ROOT: return m_arChain[0]->m_arJoint[0];
	case E_JOINT_THUMB_ABDUCT: return m_arChain[0]->m_arJoint[1];
	case E_JOINT_THUMB_FLEX_1: return m_arChain[0]->m_arJoint[2];
	case E_JOINT_THUMB_FLEX_2: return m_arChain[0]->m_arJoint[3];
	case E_JOINT_THUMB_END: return m_arChain[0]->m_arJoint[4];

	case E_JOINT_INDEX_PROXIMAL: return m_arChain[1]->m_arJoint[0];
	case E_JOINT_INDEX_MID: return m_arChain[1]->m_arJoint[1];
	case E_JOINT_INDEX_DISTAL: return m_arChain[1]->m_arJoint[2];
	case E_JOINT_INDEX_END: return m_arChain[1]->m_arJoint[3];

	case E_JOINT_MID_PROXIMAL: return m_arChain[2]->m_arJoint[0]; 
	case E_JOINT_MID_MID: return m_arChain[2]->m_arJoint[1];
	case E_JOINT_MID_DISTAL: return m_arChain[2]->m_arJoint[2];
	case E_JOINT_MID_END: return m_arChain[2]->m_arJoint[3];

	case E_JOINT_RING_PROXIMAL: return m_arChain[3]->m_arJoint[0];
	case E_JOINT_RING_MID: return m_arChain[3]->m_arJoint[1];
	case E_JOINT_RING_DISTAL: return m_arChain[3]->m_arJoint[2];
	case E_JOINT_RING_END: return m_arChain[3]->m_arJoint[3];

	case E_JOINT_PINKY_PROXIMAL: return m_arChain[4]->m_arJoint[0];
	case E_JOINT_PINKY_MID: return m_arChain[4]->m_arJoint[1];
	case E_JOINT_PINKY_DISTAL: return m_arChain[4]->m_arJoint[2];
	case E_JOINT_PINKY_END: return m_arChain[4]->m_arJoint[3];
	}
	return NULL;
}
CKinematicDOF* CKinematicHandRigidPalmLeft::GetDOF(enum HAND_JOINT_ID eJointId, enum HAND_DOF_ID eDOFId)
{
	CKinematicJoint* pJoint = GetJoint(eJointId);
	switch(eDOFId)
	{
	case E_DOF_ROLL_X: return pJoint->m_arDOF[0];
	case E_DOF_ABDUCT_Y: return pJoint->m_arDOF[0];
	case E_DOF_FLEX_Z: return pJoint->m_arDOF[pJoint->m_arDOF.size()-1];
	}
	return NULL;
}
void CKinematicHandRigidPalmLeft::Render()
{
	//finger
	glColor3f(1.0f, 0.0f, 0.0f);
	m_arChain[0]->Render();
	glColor3f(1.0f, 1.0f, 0.0f);
	m_arChain[1]->Render();
	glColor3f(0.0f, 0.0f, 1.0f);
	m_arChain[2]->Render();
	glColor3f(0.0f, 1.0f, 0.0f);
	m_arChain[3]->Render();
	glColor3f(1.0f, 0.0f, 1.0f);
	m_arChain[4]->Render();

	//palm polygon
	glColor3f(1.0f, 0.8f, 0.7f);
	glBegin(GL_POLYGON);
	CKinematicPos posFirst, posLast, posMid;
	for(int i = 0; i < m_arChain.size(); ++i)
	{
		CKinematicChain* pChain = m_arChain[i];
		if(pChain == NULL)
			continue;
		if(i ==0)
			posFirst = pChain->m_posRoot;
		if(i==m_arChain.size()-1)
			posLast = pChain->m_posRoot;
		if(i==1)
			posMid = pChain->m_posRoot;

		glVertex3f(pChain->m_posRoot.m_fX, pChain->m_posRoot.m_fY, pChain->m_posRoot.m_fZ);
	}
	glVertex3f(posFirst.m_fX+posLast.m_fX-posMid.m_fX, posFirst.m_fY+posLast.m_fY-posMid.m_fY, posFirst.m_fZ+posLast.m_fZ-posMid.m_fZ);
	glEnd();
}
void CKinematicHandRigidPalmLeft::LoadHandSize(string strPath)
{}
void CKinematicHandRigidPalmLeft::LoadHandPose(string strPath)
{}

//==========================================================================================