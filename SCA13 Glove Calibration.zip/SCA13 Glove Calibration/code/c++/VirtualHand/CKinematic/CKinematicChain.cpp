#include "stdafx.h"
#include "CKinematicChain.h"
#include <math.h>
#include "..\GloveUtil.h"

//CKinematicPoint==============================================================================================
CKinematicPoint::CKinematicPoint(const CKinematicPoint& kPt)
{
	m_fX = kPt.m_fX;
	m_fY = kPt.m_fY;
	m_fZ = kPt.m_fZ;
}
CKinematicPoint::CKinematicPoint()
{
	m_fX = m_fY = m_fZ = 0;
}
CKinematicPoint::CKinematicPoint(float x, float y, float z)
{
	m_fX = x;
	m_fY = y;
	m_fZ = z;
}

CKinematicPoint::CKinematicPoint(char* strPos)
{
	if(strPos == NULL)
	{
		m_fX = m_fY = m_fZ = 0;
		return;
	}
	CString strData(strPos);
	int iBeg = strData.Find(L"(");
	int iEnd = strData.Find(L",", iBeg+1);
	CString strX = strData.Mid(iBeg+1, iEnd-iBeg-1);
	m_fX = _wtof(strX.GetBuffer());

	iBeg = iEnd;
	iEnd = strData.Find(L",", iBeg +1);
	CString strY = strData.Mid(iBeg+1, iEnd-iBeg-1);
	m_fY = _wtof(strY.GetBuffer());

	iBeg = iEnd;
	iEnd = strData.Find(L")", iBeg+1);
	CString strZ = strData.Mid(iBeg+1, iEnd-iBeg-1);
	m_fZ = _wtof(strZ.GetBuffer());
}

CKinematicPoint::CKinematicPoint(wchar_t* strPos)
{
	if(strPos == NULL)
	{
		m_fX = m_fY = m_fZ = 0;
		return;
	}
	CString strData(strPos);
	int iBeg = strData.Find(L"(");
	int iEnd = strData.Find(L",", iBeg+1);
	CString strX = strData.Mid(iBeg+1, iEnd-iBeg-1);
	m_fX = _wtof(strX.GetBuffer());

	iBeg = iEnd;
	iEnd = strData.Find(L",", iBeg +1);
	CString strY = strData.Mid(iBeg+1, iEnd-iBeg-1);
	m_fY = _wtof(strY.GetBuffer());

	iBeg = iEnd;
	iEnd = strData.Find(L")", iBeg+1);
	CString strZ = strData.Mid(iBeg+1, iEnd-iBeg-1);
	m_fZ = _wtof(strZ.GetBuffer());
}
float CKinematicPoint::DistanceTo(CKinematicPoint& kPt)
{
	float fDist = ((m_fX - kPt.m_fX) * (m_fX - kPt.m_fX) )+ 
		((m_fY - kPt.m_fY) * (m_fY - kPt.m_fY) )+ 
		((m_fZ- kPt.m_fZ) * (m_fZ - kPt.m_fZ));
	fDist = sqrt(fDist);
	return fDist;
}
CKinematicPoint& CKinematicPoint::operator=(const CKinematicPoint& kPt)
{
	m_fX = kPt.m_fX;
	m_fY = kPt.m_fY;
	m_fZ = kPt.m_fZ;
	return *this;
}
void CKinematicPoint::operator +=(const CKinematicPoint& kPt)
{
	m_fX = m_fX + kPt.m_fX;
	m_fY = m_fY + kPt.m_fY;
	m_fZ = m_fZ + kPt.m_fZ;
}
void CKinematicPoint::operator-=(const CKinematicPoint& kPt)
{
	m_fX = m_fX - kPt.m_fX;
	m_fY = m_fY - kPt.m_fY;
	m_fZ = m_fZ - kPt.m_fZ;
}
void CKinematicPoint::operator*=(const float k)
{
	m_fX = m_fX * k;
	m_fY = m_fY * k;
	m_fZ = m_fZ * k;
}
void CKinematicPoint::operator /=(const float k)
{
	if(k==0)
		return;
	m_fX = m_fX / k;
	m_fY = m_fY / k;
	m_fZ = m_fZ / k;
}

CKinematicPoint CKinematicPoint::operator*(const float k)
{
	CKinematicPoint kPtResult(m_fX * k, m_fY * k, m_fZ * k);
	return kPtResult;
}
CKinematicPoint CKinematicPoint::operator+(const CKinematicPoint& kPt)
{
	CKinematicPoint kPtResult(m_fX + kPt.m_fX, m_fY + kPt.m_fY, m_fZ + kPt.m_fZ);
	return kPtResult;
}
CKinematicPoint::~CKinematicPoint()
{}
float CKinematicPoint::GetEuclideanLength()
{
	return sqrt(m_fX*m_fX+m_fY*m_fY+m_fZ*m_fZ);
}
void CKinematicPoint::Normalize()
{
	float fLength = GetEuclideanLength();
	if(fLength == 0)
		return;

	m_fX = m_fX / fLength;
	m_fY = m_fY / fLength;
	m_fZ = m_fZ / fLength;
}
std::string CKinematicPoint::ToString()
{
	char buf[500] = {0};
	sprintf(buf, "(%f,%f,%f)", m_fX, m_fY, m_fZ);
	std::string strPoint(buf);
	return strPoint;
}

//CKinematicDOF=================================================================================================
CKinematicDOF* CKinematicDOF::CloneNew(const CKinematicDOF& kDOF, CKinematicJoint* pParentJoint/*=NULL*/)
{
	CKinematicDOF* pDOFNew = new CKinematicDOF(kDOF.m_dLocalRotationAngle, kDOF.m_vecLocalAxis, kDOF.m_vecGlobalAxis, kDOF.m_iID);
	pDOFNew->m_pParentJoint = pParentJoint;
	pDOFNew->m_vecConstraints = kDOF.m_vecConstraints;
	pDOFNew->m_dWeight = kDOF.m_dWeight;
	pDOFNew->m_fVariance = kDOF.m_fVariance;
	pDOFNew->m_bActive = kDOF.m_bActive;
	return pDOFNew;
}
CKinematicDOF::CKinematicDOF()
{
	m_dLocalRotationAngle = 0;
	m_iID = -1;
	m_fVariance = 3;
	
	m_dWeight = 1;
	m_bActive = true;
}
CKinematicDOF::CKinematicDOF(float dLocalRotationAngle, CKinematicVec3D vecLocalAxis)
{
	m_dLocalRotationAngle = dLocalRotationAngle;
	m_vecLocalAxis = vecLocalAxis;
	m_iID = -1;
	m_fVariance = 3;

	m_dWeight = 1;
	m_bActive = true;
}	
CKinematicDOF::CKinematicDOF(float dLocalRotationAngle, CKinematicVec3D vecLocalAxis, CKinematicVec3D vecGlobalAxis)
{
	m_dLocalRotationAngle = dLocalRotationAngle;
	m_vecLocalAxis = vecLocalAxis;
	m_vecGlobalAxis = vecGlobalAxis;
	m_iID = -1;
	m_fVariance = 3;

	m_dWeight = 1;
	m_bActive = true;
}
CKinematicDOF::CKinematicDOF(float dLocalRotationAngle, CKinematicVec3D vecLocalAxis, CKinematicVec3D vecGlobalAxis, int iID)
{
	m_dLocalRotationAngle = dLocalRotationAngle;
	m_vecLocalAxis = vecLocalAxis;
	m_vecGlobalAxis = vecGlobalAxis;
	m_iID = iID;
	m_fVariance = 3;

	m_dWeight = 1;
	m_bActive = true;
}
CKinematicDOF::CKinematicDOF(float dLocalRotationAngle, CKinematicVec3D vecLocalAxis, int iID)
{
	m_dLocalRotationAngle = dLocalRotationAngle;
	m_vecLocalAxis = vecLocalAxis;
	m_iID = iID;
	m_fVariance = 3;

	m_dWeight = 1;
	m_bActive = true;
}
CKinematicDOF::CKinematicDOF(float dLocalRotationAngle, CKinematicVec3D vecLocalAxis, int iID, float dWeight, CKinematicVec3D vecConstraints)
{
	m_dLocalRotationAngle = dLocalRotationAngle;
	m_vecLocalAxis = vecLocalAxis;
    m_iID = iID;
	m_dWeight = dWeight;
	m_vecConstraints = vecConstraints;
	m_fVariance = 3;
	m_bActive = true;
}
CKinematicDOF::CKinematicDOF(float dLocalRotationAngle, CKinematicVec3D vecLocalAxis, int iID, float dWeight, CKinematicVec3D vecConstraints, float fVariance)
{
	m_dLocalRotationAngle = dLocalRotationAngle;
	m_vecLocalAxis = vecLocalAxis;
    m_iID = iID;
	m_dWeight = dWeight;
	m_vecConstraints = vecConstraints;
	m_fVariance = fVariance;
	m_bActive = true;
}
CKinematicDOF::CKinematicDOF(const CKinematicDOF& kDOF)
{
	m_vecLocalAxis = kDOF.m_vecLocalAxis;
	m_vecGlobalAxis = kDOF.m_vecGlobalAxis;
	m_dLocalRotationAngle = kDOF.m_dLocalRotationAngle;
	m_iID = kDOF.m_iID;
	m_vecConstraints = kDOF.m_vecConstraints;
	m_dWeight = kDOF.m_dWeight;
	m_fVariance = kDOF.m_fVariance;
	m_bActive = true;
}
CKinematicDOF::~CKinematicDOF()
{}
string CKinematicDOF::GetBvhChannelInfo()
{
	if(m_vecLocalAxis.m_fX == 1 && m_vecLocalAxis.m_fY == 0 && m_vecLocalAxis.m_fZ ==0)
		return "Xrotation";
	if(m_vecLocalAxis.m_fX == 0 && m_vecLocalAxis.m_fY == 1 && m_vecLocalAxis.m_fZ ==0)
		return "Yrotation";
	if(m_vecLocalAxis.m_fX == 0 && m_vecLocalAxis.m_fY == 0 && m_vecLocalAxis.m_fZ ==1)
		return "Zrotation";
	return "";
}
bool CKinematicDOF::IsViolateConstraints()
{
	double fRange = abs(m_vecConstraints.m_fZ - m_vecConstraints.m_fY);
	if(m_dLocalRotationAngle > m_vecConstraints.m_fZ + 0.1 * fRange)//10% greater than max
		return true;
	if(m_dLocalRotationAngle < m_vecConstraints.m_fY - 0.1 * fRange)//10% smaller than min
		return true;
	return false;
}

//CKinematicJoint=========================================================================================================
CKinematicJoint* CKinematicJoint::CloneNew(const CKinematicJoint& kJoint, CKinematicChain* pParentChain/*=NULL*/)
{
	CKinematicJoint* pNewJoint = new CKinematicJoint(kJoint.m_posLocalCoord, kJoint.m_posGlobalCoord, kJoint.m_iID);
	for(int i = 0; i < kJoint.m_arDOF.size(); ++i)
	{
		CKinematicDOF* pDOF = kJoint.m_arDOF[i];
		CKinematicDOF* pDOFNew = CKinematicDOF::CloneNew(*pDOF, pNewJoint);
		pNewJoint->m_arDOF.push_back(pDOFNew);
	}
	return pNewJoint;
}
CKinematicJoint::CKinematicJoint()
{
	m_iID = -1;
}
CKinematicJoint::CKinematicJoint(CKinematicPos posLocalCoord)
{
	m_posLocalCoord = posLocalCoord;
	m_iID = -1;
}
CKinematicJoint::CKinematicJoint(CKinematicPos posLocalCoord, CKinematicPos posGlobalCoord)
{
	m_posLocalCoord = posLocalCoord;
	m_posGlobalCoord = posGlobalCoord;
	m_iID = -1;
}
CKinematicJoint::CKinematicJoint(CKinematicPos posLocalCoord, CKinematicPos posGlobalCoord, int iID)
{
	m_posLocalCoord = posLocalCoord;
	m_posGlobalCoord = posGlobalCoord;
	m_iID = iID;
}
CKinematicJoint::CKinematicJoint(CKinematicPos posLocalCoord, int iID)
{
	m_posLocalCoord = posLocalCoord;
	m_iID = iID;
}
CKinematicJoint::CKinematicJoint(const CKinematicJoint& kJoint)
{
	for(int i = 0; i < kJoint.m_arDOF.size(); ++i)
	{
		CKinematicDOF* pDOF = kJoint.m_arDOF[i];
		CKinematicDOF* pDOFNew = new CKinematicDOF(*pDOF);
		pDOFNew->m_pParentJoint = this;
		m_arDOF.push_back(pDOFNew);
	}
	m_posLocalCoord = kJoint.m_posLocalCoord;
	m_posGlobalCoord = kJoint.m_posGlobalCoord;
	m_iID = kJoint.m_iID;
}
CKinematicJoint::~CKinematicJoint()
{
	for(int i = 0; i < m_arDOF.size(); ++i)
		delete m_arDOF[i];
}
void CKinematicJoint::AddDOF(CKinematicDOF* pDOF)
{
	if(pDOF == NULL)
		return;
	m_arDOF.push_back(pDOF);
	pDOF->m_pParentJoint = this;
}
int CKinematicJoint::GetActiveDOFNum()
{
	int iActiveDOFNum = 0;
	for(int i = 0; i < m_arDOF.size(); ++i)
	{
		if(m_arDOF[i]->m_bActive)
			iActiveDOFNum ++;
	}
	return iActiveDOFNum;
}
string CKinematicJoint::GetBvhOffsetInfo()
{
	string strOffsetInfo;
	char buffer[100];
	sprintf(buffer, "OFFSET %f %f %f \r\n", m_posLocalCoord.m_fX, m_posLocalCoord.m_fY, m_posLocalCoord.m_fZ);
	strOffsetInfo.append(buffer);
	return strOffsetInfo;
}
string CKinematicJoint::GetBvhOffsetInfoConsistentWithBody(bool bLeft)
{	
	string strOffsetInfo;
	char buffer[100];
	if(bLeft)
		sprintf(buffer, "OFFSET %f %f %f \r\n", -0.012 * m_posLocalCoord.m_fX, -0.012 * m_posLocalCoord.m_fY, 0.012 * m_posLocalCoord.m_fZ);
	else
		sprintf(buffer, "OFFSET %f %f %f \r\n", 0.012 * m_posLocalCoord.m_fX, -0.012 * m_posLocalCoord.m_fY, -0.012 * m_posLocalCoord.m_fZ);

	strOffsetInfo.append(buffer);
	return strOffsetInfo;
}

string CKinematicJoint::GetBvhChannelInfo()
{
	if(m_arDOF.size() == 0)
		return "";

	string strDOFChannelInfo;
	char buffer[100];
	sprintf(buffer, "CHANNELS %d", m_arDOF.size());
	strDOFChannelInfo.append(buffer);
	for(int d = 0; d < m_arDOF.size(); ++d)
	{
		CKinematicDOF* pDOF = m_arDOF[d];
		string strDOF = pDOF->GetBvhChannelInfo();
		strDOFChannelInfo.append(" ");
		strDOFChannelInfo.append(strDOF);
	}
	strDOFChannelInfo.append("\r\n");
	return strDOFChannelInfo;
}

string CKinematicJoint::GetBvhChannelInfoConsistentWithBody()
{
	if(m_arDOF.size() == 0)
		return "";

	string strDOFChannelInfo;
	char buffer[100];
	sprintf(buffer, "CHANNELS %d", m_arDOF.size());
	strDOFChannelInfo.append(buffer);
	for(int d = 0; d < m_arDOF.size(); ++d)
	{
		CKinematicDOF* pDOF = m_arDOF[d];
		string strDOF = pDOF->GetBvhChannelInfo();
		strDOFChannelInfo.append(" ");
		strDOFChannelInfo.append(strDOF);
	}
	strDOFChannelInfo.append("\r\n");
	return strDOFChannelInfo;
}

//CKinematicChain==========================================================================================================
CKinematicChain* CKinematicChain::CloneNew(const CKinematicChain& kChain)
{
	CKinematicChain* pChainNew = new CKinematicChain(kChain.m_posRoot, kChain.m_iID);
	for(int i = 0; i < kChain.m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = kChain.m_arJoint[i];
		CKinematicJoint* pJointNew = CKinematicJoint::CloneNew(*pJoint, pChainNew);
		pChainNew->m_arJoint.push_back(pJointNew);
	}
	return pChainNew;
}
CKinematicChain::CKinematicChain()
{
	m_iID = -1;
}
CKinematicChain::CKinematicChain(CKinematicPos posRoot)
{
	m_posRoot = posRoot;
	m_iID = -1;
}
CKinematicChain::CKinematicChain(CKinematicPos posRoot, int iID)
{
	m_posRoot = posRoot;
	m_iID = iID;
}
CKinematicChain::CKinematicChain(const CKinematicChain& kChain)
{
	m_posRoot = kChain.m_posRoot;
	m_iID = kChain.m_iID;
	for(int i = 0; i < kChain.m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = kChain.m_arJoint[i];
		CKinematicJoint* pJointNew = new CKinematicJoint(*pJoint);
		pJointNew->m_pParentChain = this;
		m_arJoint.push_back(pJointNew);
	}
}
CKinematicChain::~CKinematicChain()
{
	for(int i = 0; i < m_arJoint.size(); ++i)
		delete m_arJoint[i];
}

void CKinematicChain::AddJoint(CKinematicJoint* pJoint)
{
	if(pJoint == NULL)
		return;

	pJoint->m_pParentChain = this;
	m_arJoint.push_back(pJoint);
}
void CKinematicChain::AddDOF(CKinematicDOF* pDOF, int iIDJoint)
{
	if(pDOF == NULL)
		return;

	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];
		if(pJoint->m_iID != iIDJoint)
			continue;
		pJoint->m_arDOF.push_back(pDOF);
		pDOF->m_pParentJoint = pJoint;
		return;
	}
}
CKinematicJoint* CKinematicChain:: GetJointByID(int iJointID)
{
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];
		if(pJoint == NULL)
			continue;
		if(pJoint->m_iID == iJointID)
			return pJoint;
	}
	return NULL;
}
CKinematicDOF* CKinematicChain::GetDOFByID(int iDOFID)
{
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];
		if(pJoint == NULL)
			continue;

		for(int j = 0; j < pJoint->m_arDOF.size(); ++j)
		{
			CKinematicDOF* pDOF = pJoint->m_arDOF[j];
			if(pDOF == NULL)
				continue;
			if(pDOF->m_iID == iDOFID)
				return pDOF;
		}
	}
	return NULL;
}
CKinematicDOF* CKinematicChain::GetDOFByID(int iJointID, int iDOFID)
{
	CKinematicJoint* pJoint = GetJointByID(iJointID);
	if(pJoint == NULL)
		return NULL;
	for(int i = 0; i < pJoint->m_arDOF.size(); ++i)
	{
		CKinematicDOF* pDOF = pJoint->m_arDOF[i];
		if(pDOF == NULL)
			return NULL;

		if(pDOF->m_iID == iDOFID)
			return pDOF;
	}
	return NULL;
}

int CKinematicChain::GetJointNum()
{
	return m_arJoint.size();
}
int CKinematicChain::GetDOFNum()
{
	int iDOFNum = 0;
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];
		iDOFNum += pJoint->m_arDOF.size();
	}
	return iDOFNum;
}
int CKinematicChain::GetActiveDOFNum()
{
	int iDOFActiveNum = 0;
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];
		iDOFActiveNum += pJoint->GetActiveDOFNum();
	}
	return iDOFActiveNum;
}
CKinematicDOF* CKinematicChain::GetDOFAt(int iDOF)
{
	if(iDOF < 0)
		return NULL;

	int iDOFNum = 0;
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];
		if(iDOF > iDOFNum + pJoint->m_arDOF.size())
		{
			iDOFNum = iDOFNum + pJoint->m_arDOF.size();
			continue;
		}
		for(int j = 0; j < pJoint->m_arDOF.size(); ++j)
		{
			if(iDOF == iDOFNum)
				return pJoint->m_arDOF[j];			
			iDOFNum ++;
		}
	}
	return NULL;
}
void CKinematicChain::SetDOFAt(int iDOF, CKinematicDOF* pDOF)
{	
	if(iDOF < 0)
		return;

	int iDOFNum = 0;
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];
		if(iDOF > iDOFNum + pJoint->m_arDOF.size())
		{
			iDOFNum = iDOFNum + pJoint->m_arDOF.size();
			continue;
		}
		for(int j = 0; j < pJoint->m_arDOF.size(); ++j)
		{
			if(iDOF == iDOFNum)
			{
				delete pJoint->m_arDOF[j];
				pJoint->m_arDOF[j] = pDOF;
				return;
			}
			iDOFNum ++;
		}
	}
}
CKinematicPos CKinematicChain::GetLocalPosOfDOFAt(int iDOF)
{
	if(iDOF < 0)
		return CKinematicPos();

	int iDOFNum = 0;
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];
		if(iDOF==iDOFNum)
			return pJoint->m_posLocalCoord;
		iDOFNum += pJoint->m_arDOF.size();
	}
	return CKinematicPos();
}
void CKinematicChain::SetGlobalPosOfDOFAt(int iDOF, CKinematicPos posGlobal)
{
	if(iDOF < 0)
		return;

	int iDOFNum = 0;
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];
		if(iDOF>=iDOFNum && iDOF < (iDOFNum+pJoint->m_arDOF.size()))
		{
			pJoint->m_posGlobalCoord = posGlobal;
			return;
		}
		iDOFNum += pJoint->m_arDOF.size();
	}
	if(iDOF>=iDOFNum)
	{
		CKinematicJoint* pJoint = m_arJoint[m_arJoint.size()-1];
		pJoint->m_posGlobalCoord = posGlobal;
	}
	return;
}
/*please notice that in C++, matrix are stored first by row, then by column
**but in matlab, matrix are stored first by column, then by row
**so the matrix looks like a transpose*/
void CKinematicChain::SolveToReach(CKinematicPos posGoal)
{
	m_posGoal = posGoal;

	if(GetEndDistanceToGoal() < 0.1)
		return;

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arGoalPos = new double[3];
	arGoalPos[0] = posGoal.m_fX; arGoalPos[1] = posGoal.m_fY; arGoalPos[2] = posGoal.m_fZ;
	mxArray* pMxGoalPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxGoalPos, "Goal_global_pos");
	memcpy(mxGetPr(pMxGoalPos), (double*)arGoalPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Goal_global_pos", pMxGoalPos);

	double* arRootPos = new double[3];
	arRootPos[0] = m_posRoot.m_fX; arRootPos[1] = m_posRoot.m_fY; arRootPos[2] = m_posRoot.m_fZ;
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iDOFNum = GetDOFNum();
	double* arJointAngle = new double[iDOFNum];
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];
	CKinematicJoint* pParent = NULL;
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		arJointAngle[i] = pDOF->m_dLocalRotationAngle * 3.1415926 / 180;
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;
		
		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}
	mxArray* pMxLocalAngle = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxLocalAngle, "Joint_angle");
	memcpy((char*)mxGetPr(pMxLocalAngle), (char*)arJointAngle, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_angle", pMxLocalAngle);

	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	//evaluate command string
	char strCmd[800];
	sprintf(strCmd, "[Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3D(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos, Goal_global_pos, 0);", iDOFNum);
	engEvalString(pMatlabEngine,strCmd);
	
	//output
	double* arJointAngleNew =  new double[iDOFNum];
	mxArray* pMxJointAngleNew = engGetVariable(pMatlabEngine, "Joint_angle");
	memcpy((char*)arJointAngleNew,(char*)mxGetPr(pMxJointAngleNew), iDOFNum*sizeof(double));

	double* arJointGlobalPos =  new double[(iDOFNum+1)*3];
	mxArray* pMxGlobalPos = engGetVariable(pMatlabEngine, "Joint_global_pos");
	memcpy((char*)arJointGlobalPos,(char*)mxGetPr(pMxGlobalPos), 3*(iDOFNum+1)*sizeof(double));

	double* arJointGlobalAxis = new double[iDOFNum*3];
	mxArray* pMxGlobalAxis = engGetVariable(pMatlabEngine, "Joint_global_axis");
	memcpy((char*)arJointGlobalAxis,(char*)mxGetPr(pMxGlobalAxis), 3*iDOFNum*sizeof(double));

	//populate
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);		;
		pDOF->m_dLocalRotationAngle = arJointAngleNew[i]  * 180 / 3.1415926;
		pDOF->m_vecGlobalAxis.m_fX = arJointGlobalAxis[0*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fY = arJointGlobalAxis[1*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fZ = arJointGlobalAxis[2*iDOFNum+i];

		CKinematicPos posGlobal(arJointGlobalPos[0*(iDOFNum+1)+i], arJointGlobalPos[1*(iDOFNum+1)+i], arJointGlobalPos[2*(iDOFNum+1)+i]);
		pDOF->m_pParentJoint->m_posGlobalCoord = posGlobal;

		if(i == iDOFNum-1)
		{
			CKinematicPos posGlobalEnd(arJointGlobalPos[0*(iDOFNum+1)+i+1], arJointGlobalPos[1*(iDOFNum+1)+i+1], arJointGlobalPos[2*(iDOFNum+1)+i+1]);
			m_arJoint[m_arJoint.size()-1]->m_posGlobalCoord = posGlobalEnd;
		}
	}
	/*char msg[300];
	sprintf(msg, "(%f, %f, %f) (%f, %f, %f) (%f, %f, %f) (%f, %f, %f) (%f, %f, %f) (%f, %f, %f)\
				 [%f, %f, %f] [%f, %f, %f] [%f, %f, %f] [%f, %f, %f] [%f, %f, %f] [%f, %f, %f] [%f, %f, %f]",
				 arJointGlobalAxis[0*iDOFNum+0], arJointGlobalAxis[1*iDOFNum+0], arJointGlobalAxis[2*iDOFNum+0],  arJointGlobalAxis[0*iDOFNum+1], arJointGlobalAxis[1*iDOFNum+1], arJointGlobalAxis[2*iDOFNum+1],
				 arJointGlobalAxis[0*iDOFNum+2], arJointGlobalAxis[1*iDOFNum+2], arJointGlobalAxis[2*iDOFNum+2],  arJointGlobalAxis[0*iDOFNum+3], arJointGlobalAxis[1*iDOFNum+3], arJointGlobalAxis[2*iDOFNum+3],
				 arJointGlobalAxis[0*iDOFNum+4], arJointGlobalAxis[1*iDOFNum+4], arJointGlobalAxis[2*iDOFNum+4],  arJointGlobalAxis[0*iDOFNum+5], arJointGlobalAxis[1*iDOFNum+5], arJointGlobalAxis[2*iDOFNum+5],
				 arJointGlobalPos[0*(iDOFNum+1)+0], arJointGlobalPos[1*(iDOFNum+1)+0], arJointGlobalPos[2*(iDOFNum+1)+0],   arJointGlobalPos[0*(iDOFNum+1)+1], arJointGlobalPos[1*(iDOFNum+1)+1], arJointGlobalPos[2*(iDOFNum+1)+1],
				 arJointGlobalPos[0*(iDOFNum+1)+2], arJointGlobalPos[1*(iDOFNum+1)+2], arJointGlobalPos[2*(iDOFNum+1)+2],   arJointGlobalPos[0*(iDOFNum+1)+3], arJointGlobalPos[1*(iDOFNum+1)+3], arJointGlobalPos[2*(iDOFNum+1)+3],
				 arJointGlobalPos[0*(iDOFNum+1)+4], arJointGlobalPos[1*(iDOFNum+1)+4], arJointGlobalPos[2*(iDOFNum+1)+4],   arJointGlobalPos[0*(iDOFNum+1)+5], arJointGlobalPos[1*(iDOFNum+1)+5], arJointGlobalPos[2*(iDOFNum+1)+5],
				 arJointGlobalPos[0*(iDOFNum+1)+6], arJointGlobalPos[1*(iDOFNum+1)+6], arJointGlobalPos[2*(iDOFNum+1)+6]);
	::MessageBoxA(NULL,  msg, L"global info", MB_OK);*/
	
	//destroy
	delete arGoalPos;
	delete arRootPos;
	delete arJointAngle;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointAngleNew;	
	delete arJointGlobalPos;
	delete arJointGlobalAxis;
	mxDestroyArray(pMxGoalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAngle);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxJointAngleNew);	
	mxDestroyArray(pMxGlobalPos);
	mxDestroyArray(pMxGlobalAxis);
}

void CKinematicChain::SolveToReachWithWeightConstraints(CKinematicPos posGoal)
{
	m_posGoal = posGoal;

	if(GetEndDistanceToGoal() < 0.1)
		return;

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arGoalPos = new double[3];
	arGoalPos[0] = posGoal.m_fX; arGoalPos[1] = posGoal.m_fY; arGoalPos[2] = posGoal.m_fZ;
	mxArray* pMxGoalPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxGoalPos, "Goal_global_pos");
	memcpy(mxGetPr(pMxGoalPos), (double*)arGoalPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Goal_global_pos", pMxGoalPos);

	double* arRootPos = new double[3];
	arRootPos[0] = m_posRoot.m_fX; arRootPos[1] = m_posRoot.m_fY; arRootPos[2] = m_posRoot.m_fZ;
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iDOFNum = GetDOFNum();
	double* arJointAngle = new double[iDOFNum];
	double* arJointWeight = new double[iDOFNum];
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];
	CKinematicJoint* pParent = NULL;
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		arJointAngle[i] = pDOF->m_dLocalRotationAngle * 3.1415926 / 180;
		arJointWeight[i] = pDOF->m_dWeight;
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;		
		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}
	mxArray* pMxLocalAngle = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxLocalAngle, "Joint_angle");
	memcpy((char*)mxGetPr(pMxLocalAngle), (char*)arJointAngle, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_angle", pMxLocalAngle);

	mxArray* pMxJointWeight = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxJointWeight, "Joint_weight");//dan hang ju zhen, heng guo lai de
	memcpy((char*)mxGetPr(pMxJointWeight), (char*)arJointWeight, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_weight", pMxJointWeight);

	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	//evaluate command string
	char strCmd[800];
	sprintf(strCmd, "[Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3DWithWeight(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos, Joint_weight, Goal_global_pos, 0);", iDOFNum);
	engEvalString(pMatlabEngine,strCmd);
	
	//output
	double* arJointAngleNew =  new double[iDOFNum];
	mxArray* pMxJointAngleNew = engGetVariable(pMatlabEngine, "Joint_angle");
	memcpy((char*)arJointAngleNew,(char*)mxGetPr(pMxJointAngleNew), iDOFNum*sizeof(double));

	double* arJointGlobalPos =  new double[(iDOFNum+1)*3];
	mxArray* pMxGlobalPos = engGetVariable(pMatlabEngine, "Joint_global_pos");
	memcpy((char*)arJointGlobalPos,(char*)mxGetPr(pMxGlobalPos), 3*(iDOFNum+1)*sizeof(double));

	double* arJointGlobalAxis = new double[iDOFNum*3];
	mxArray* pMxGlobalAxis = engGetVariable(pMatlabEngine, "Joint_global_axis");
	memcpy((char*)arJointGlobalAxis,(char*)mxGetPr(pMxGlobalAxis), 3*iDOFNum*sizeof(double));

	//populate
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);		;
		pDOF->m_dLocalRotationAngle = arJointAngleNew[i]  * 180 / 3.1415926;
		pDOF->m_vecGlobalAxis.m_fX = arJointGlobalAxis[0*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fY = arJointGlobalAxis[1*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fZ = arJointGlobalAxis[2*iDOFNum+i];

		CKinematicPos posGlobal(arJointGlobalPos[0*(iDOFNum+1)+i], arJointGlobalPos[1*(iDOFNum+1)+i], arJointGlobalPos[2*(iDOFNum+1)+i]);
		pDOF->m_pParentJoint->m_posGlobalCoord = posGlobal;

		if(i == iDOFNum-1)
		{
			CKinematicPos posGlobalEnd(arJointGlobalPos[0*(iDOFNum+1)+i+1], arJointGlobalPos[1*(iDOFNum+1)+i+1], arJointGlobalPos[2*(iDOFNum+1)+i+1]);
			m_arJoint[m_arJoint.size()-1]->m_posGlobalCoord = posGlobalEnd;
		}
	}
	
	//destroy
	delete arGoalPos;
	delete arRootPos;
	delete arJointAngle;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointAngleNew;	
	delete arJointGlobalPos;
	delete arJointGlobalAxis;
	delete arJointWeight;
	mxDestroyArray(pMxGoalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAngle);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxJointAngleNew);	
	mxDestroyArray(pMxGlobalPos);
	mxDestroyArray(pMxGlobalAxis);
	mxDestroyArray(pMxJointWeight);
}
void CKinematicChain::SolveToReachWithRangeConstraints(CKinematicPos posGoal)
{
	m_posGoal = posGoal;

	if(GetEndDistanceToGoal() < 0.1)
		return;

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arGoalPos = new double[3];
	arGoalPos[0] = posGoal.m_fX; arGoalPos[1] = posGoal.m_fY; arGoalPos[2] = posGoal.m_fZ;
	mxArray* pMxGoalPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxGoalPos, "Goal_global_pos");
	memcpy(mxGetPr(pMxGoalPos), (double*)arGoalPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Goal_global_pos", pMxGoalPos);

	double* arRootPos = new double[3];
	arRootPos[0] = m_posRoot.m_fX; arRootPos[1] = m_posRoot.m_fY; arRootPos[2] = m_posRoot.m_fZ;
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iDOFNum = GetDOFNum();
	double* arJointAngle = new double[iDOFNum];
	double* arJointConstraints = new double[iDOFNum*3];
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];
	CKinematicJoint* pParent = NULL;
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		arJointAngle[i] = pDOF->m_dLocalRotationAngle * 3.1415926 / 180;
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;		
		arJointConstraints[0*iDOFNum+i] = pDOF->m_vecConstraints.m_fX;//alpha scale
		arJointConstraints[1*iDOFNum+i] = pDOF->m_vecConstraints.m_fY  * 3.1415926 / 180;//min
		arJointConstraints[2*iDOFNum+i] = pDOF->m_vecConstraints.m_fZ  * 3.1415926 / 180;//max
		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}
	mxArray* pMxLocalAngle = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxLocalAngle, "Joint_angle");
	memcpy((char*)mxGetPr(pMxLocalAngle), (char*)arJointAngle, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_angle", pMxLocalAngle);

	mxArray* pMxJointConstraints = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxJointConstraints, "Joint_constraints");
	memcpy((char*)mxGetPr(pMxJointConstraints), (char*)arJointConstraints, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_constraints", pMxJointConstraints);

	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	//evaluate command string
	char strCmd[800];
	sprintf(strCmd, "[Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3DWithRangeConstraints(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos, Joint_constraints, Goal_global_pos, 0);", iDOFNum);
	engEvalString(pMatlabEngine,strCmd);
	
	//output
	double* arJointAngleNew =  new double[iDOFNum];
	mxArray* pMxJointAngleNew = engGetVariable(pMatlabEngine, "Joint_angle");
	memcpy((char*)arJointAngleNew,(char*)mxGetPr(pMxJointAngleNew), iDOFNum*sizeof(double));

	double* arJointGlobalPos =  new double[(iDOFNum+1)*3];
	mxArray* pMxGlobalPos = engGetVariable(pMatlabEngine, "Joint_global_pos");
	memcpy((char*)arJointGlobalPos,(char*)mxGetPr(pMxGlobalPos), 3*(iDOFNum+1)*sizeof(double));

	double* arJointGlobalAxis = new double[iDOFNum*3];
	mxArray* pMxGlobalAxis = engGetVariable(pMatlabEngine, "Joint_global_axis");
	memcpy((char*)arJointGlobalAxis,(char*)mxGetPr(pMxGlobalAxis), 3*iDOFNum*sizeof(double));

	//populate
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);		;
		pDOF->m_dLocalRotationAngle = arJointAngleNew[i]  * 180 / 3.1415926;
		pDOF->m_vecGlobalAxis.m_fX = arJointGlobalAxis[0*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fY = arJointGlobalAxis[1*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fZ = arJointGlobalAxis[2*iDOFNum+i];

		CKinematicPos posGlobal(arJointGlobalPos[0*(iDOFNum+1)+i], arJointGlobalPos[1*(iDOFNum+1)+i], arJointGlobalPos[2*(iDOFNum+1)+i]);
		pDOF->m_pParentJoint->m_posGlobalCoord = posGlobal;

		if(i == iDOFNum-1)
		{
			CKinematicPos posGlobalEnd(arJointGlobalPos[0*(iDOFNum+1)+i+1], arJointGlobalPos[1*(iDOFNum+1)+i+1], arJointGlobalPos[2*(iDOFNum+1)+i+1]);
			m_arJoint[m_arJoint.size()-1]->m_posGlobalCoord = posGlobalEnd;
		}
	}
	
	//destroy
	delete arGoalPos;
	delete arRootPos;
	delete arJointAngle;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointAngleNew;	
	delete arJointGlobalPos;
	delete arJointGlobalAxis;
	delete arJointConstraints;
	mxDestroyArray(pMxGoalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAngle);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxJointAngleNew);	
	mxDestroyArray(pMxGlobalPos);
	mxDestroyArray(pMxGlobalAxis);
	mxDestroyArray(pMxJointConstraints);
}
void CKinematicChain::SolveToReachWithCombinedConstraints(CKinematicPos posGoal)
{	
	m_posGoal = posGoal;

	if(GetEndDistanceToGoal() < 0.1)
		return;

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arGoalPos = new double[3];
	arGoalPos[0] = posGoal.m_fX; arGoalPos[1] = posGoal.m_fY; arGoalPos[2] = posGoal.m_fZ;
	mxArray* pMxGoalPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxGoalPos, "Goal_global_pos");
	memcpy(mxGetPr(pMxGoalPos), (double*)arGoalPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Goal_global_pos", pMxGoalPos);

	double* arRootPos = new double[3];
	arRootPos[0] = m_posRoot.m_fX; arRootPos[1] = m_posRoot.m_fY; arRootPos[2] = m_posRoot.m_fZ;
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iDOFNum = GetDOFNum();
	double* arJointAngle = new double[iDOFNum];
	double* arJointWeight = new double[iDOFNum];
	double* arJointConstraints = new double[iDOFNum*3];
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];
	CKinematicJoint* pParent = NULL;
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		arJointAngle[i] = pDOF->m_dLocalRotationAngle * 3.1415926 / 180;		
		arJointWeight[i] = pDOF->m_dWeight;
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;		
		arJointConstraints[0*iDOFNum+i] = pDOF->m_vecConstraints.m_fX;//alpha scale
		arJointConstraints[1*iDOFNum+i] = pDOF->m_vecConstraints.m_fY  * 3.1415926 / 180;//min
		arJointConstraints[2*iDOFNum+i] = pDOF->m_vecConstraints.m_fZ  * 3.1415926 / 180;//max
		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}
	mxArray* pMxLocalAngle = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxLocalAngle, "Joint_angle");
	memcpy((char*)mxGetPr(pMxLocalAngle), (char*)arJointAngle, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_angle", pMxLocalAngle);

	mxArray* pMxJointWeight = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxJointWeight, "Joint_weight");//dan hang ju zhen, heng guo lai de
	memcpy((char*)mxGetPr(pMxJointWeight), (char*)arJointWeight, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_weight", pMxJointWeight);

	mxArray* pMxJointConstraints = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxJointConstraints, "Joint_constraints");
	memcpy((char*)mxGetPr(pMxJointConstraints), (char*)arJointConstraints, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_constraints", pMxJointConstraints);

	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	//evaluate command string
	char strCmd[800];
	sprintf(strCmd, " [Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3DWithCombinedConstraints(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos,  Joint_weight, Joint_constraints, Goal_global_pos, 0);", iDOFNum);
	engEvalString(pMatlabEngine,strCmd);
	
	//output
	double* arJointAngleNew =  new double[iDOFNum];
	mxArray* pMxJointAngleNew = engGetVariable(pMatlabEngine, "Joint_angle");
	memcpy((char*)arJointAngleNew,(char*)mxGetPr(pMxJointAngleNew), iDOFNum*sizeof(double));

	double* arJointGlobalPos =  new double[(iDOFNum+1)*3];
	mxArray* pMxGlobalPos = engGetVariable(pMatlabEngine, "Joint_global_pos");
	memcpy((char*)arJointGlobalPos,(char*)mxGetPr(pMxGlobalPos), 3*(iDOFNum+1)*sizeof(double));

	double* arJointGlobalAxis = new double[iDOFNum*3];
	mxArray* pMxGlobalAxis = engGetVariable(pMatlabEngine, "Joint_global_axis");
	memcpy((char*)arJointGlobalAxis,(char*)mxGetPr(pMxGlobalAxis), 3*iDOFNum*sizeof(double));

	//populate wangyy - adjust angle to (-180, 180]
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		pDOF->m_dLocalRotationAngle = GloveUtil::NormalizeDegree(arJointAngleNew[i]  * 180 / 3.1415926);
		pDOF->m_vecGlobalAxis.m_fX = arJointGlobalAxis[0*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fY = arJointGlobalAxis[1*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fZ = arJointGlobalAxis[2*iDOFNum+i];

		CKinematicPos posGlobal(arJointGlobalPos[0*(iDOFNum+1)+i], arJointGlobalPos[1*(iDOFNum+1)+i], arJointGlobalPos[2*(iDOFNum+1)+i]);
		pDOF->m_pParentJoint->m_posGlobalCoord = posGlobal;

		if(i == iDOFNum-1)
		{
			CKinematicPos posGlobalEnd(arJointGlobalPos[0*(iDOFNum+1)+i+1], arJointGlobalPos[1*(iDOFNum+1)+i+1], arJointGlobalPos[2*(iDOFNum+1)+i+1]);
			m_arJoint[m_arJoint.size()-1]->m_posGlobalCoord = posGlobalEnd;
		}
	}
	
	//destroy
	delete arGoalPos;
	delete arRootPos;
	delete arJointAngle;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointAngleNew;	
	delete arJointGlobalPos;
	delete arJointGlobalAxis;
	delete arJointConstraints;
	delete arJointWeight;	
	mxDestroyArray(pMxGoalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAngle);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxJointAngleNew);	
	mxDestroyArray(pMxGlobalPos);
	mxDestroyArray(pMxGlobalAxis);
	mxDestroyArray(pMxJointConstraints);	
	mxDestroyArray(pMxJointWeight);
}
void CKinematicChain::IKSolver_stablized(CKinematicPos posGoal, float fTolerance, std::vector<float> arWeight)
{
	
	m_posGoal = posGoal;

	if(GetEndDistanceToGoal() < 0.1)
		return;

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arGoalPos = new double[3];
	arGoalPos[0] = posGoal.m_fX; arGoalPos[1] = posGoal.m_fY; arGoalPos[2] = posGoal.m_fZ;
	mxArray* pMxGoalPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxGoalPos, "Goal_global_pos");
	memcpy(mxGetPr(pMxGoalPos), (double*)arGoalPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Goal_global_pos", pMxGoalPos);

	double* arRootPos = new double[3];
	arRootPos[0] = m_posRoot.m_fX; arRootPos[1] = m_posRoot.m_fY; arRootPos[2] = m_posRoot.m_fZ;
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iDOFNum = GetDOFNum();
	double* arJointAngle = new double[iDOFNum];
	double* arJointWeight = new double[iDOFNum];
	double* arJointConstraints = new double[iDOFNum*3];
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];
	CKinematicJoint* pParent = NULL;
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		arJointAngle[i] = pDOF->m_dLocalRotationAngle * 3.1415926 / 180;		
		arJointWeight[i] = pDOF->m_dWeight;
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;		
		arJointConstraints[0*iDOFNum+i] = pDOF->m_vecConstraints.m_fX;//alpha scale
		arJointConstraints[1*iDOFNum+i] = pDOF->m_vecConstraints.m_fY  * 3.1415926 / 180;//min
		arJointConstraints[2*iDOFNum+i] = pDOF->m_vecConstraints.m_fZ  * 3.1415926 / 180;//max
		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}
	mxArray* pMxLocalAngle = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxLocalAngle, "Joint_angle");
	memcpy((char*)mxGetPr(pMxLocalAngle), (char*)arJointAngle, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_angle", pMxLocalAngle);

	mxArray* pMxJointWeight = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxJointWeight, "Joint_weight");//dan hang ju zhen, heng guo lai de
	memcpy((char*)mxGetPr(pMxJointWeight), (char*)arJointWeight, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_weight", pMxJointWeight);

	mxArray* pMxJointConstraints = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxJointConstraints, "Joint_constraints");
	memcpy((char*)mxGetPr(pMxJointConstraints), (char*)arJointConstraints, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_constraints", pMxJointConstraints);

	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	//evaluate command string
	char strCmd[800];
	sprintf(strCmd, " [Joint_angle, Joint_global_pos, Joint_global_axis] = IKSolver_stablized(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos,  Joint_weight, Joint_constraints, Goal_global_pos, 0, %f);", iDOFNum, fTolerance);
	engEvalString(pMatlabEngine,strCmd);
	
	//output
	double* arJointAngleNew =  new double[iDOFNum];
	mxArray* pMxJointAngleNew = engGetVariable(pMatlabEngine, "Joint_angle");
	memcpy((char*)arJointAngleNew,(char*)mxGetPr(pMxJointAngleNew), iDOFNum*sizeof(double));

	double* arJointGlobalPos =  new double[(iDOFNum+1)*3];
	mxArray* pMxGlobalPos = engGetVariable(pMatlabEngine, "Joint_global_pos");
	memcpy((char*)arJointGlobalPos,(char*)mxGetPr(pMxGlobalPos), 3*(iDOFNum+1)*sizeof(double));

	double* arJointGlobalAxis = new double[iDOFNum*3];
	mxArray* pMxGlobalAxis = engGetVariable(pMatlabEngine, "Joint_global_axis");
	memcpy((char*)arJointGlobalAxis,(char*)mxGetPr(pMxGlobalAxis), 3*iDOFNum*sizeof(double));

	//populate wangyy - adjust angle to (-180, 180]
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		pDOF->m_dLocalRotationAngle = GloveUtil::NormalizeDegree(arJointAngleNew[i]  * 180 / 3.1415926);
		pDOF->m_vecGlobalAxis.m_fX = arJointGlobalAxis[0*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fY = arJointGlobalAxis[1*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fZ = arJointGlobalAxis[2*iDOFNum+i];

		CKinematicPos posGlobal(arJointGlobalPos[0*(iDOFNum+1)+i], arJointGlobalPos[1*(iDOFNum+1)+i], arJointGlobalPos[2*(iDOFNum+1)+i]);
		pDOF->m_pParentJoint->m_posGlobalCoord = posGlobal;

		if(i == iDOFNum-1)
		{
			CKinematicPos posGlobalEnd(arJointGlobalPos[0*(iDOFNum+1)+i+1], arJointGlobalPos[1*(iDOFNum+1)+i+1], arJointGlobalPos[2*(iDOFNum+1)+i+1]);
			m_arJoint[m_arJoint.size()-1]->m_posGlobalCoord = posGlobalEnd;
		}
	}
	
	//destroy
	delete arGoalPos;
	delete arRootPos;
	delete arJointAngle;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointAngleNew;	
	delete arJointGlobalPos;
	delete arJointGlobalAxis;
	delete arJointConstraints;
	delete arJointWeight;
	
	mxDestroyArray(pMxGoalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAngle);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxJointAngleNew);	
	mxDestroyArray(pMxGlobalPos);
	mxDestroyArray(pMxGlobalAxis);
	mxDestroyArray(pMxJointConstraints);	
	mxDestroyArray(pMxJointWeight);

}
void CKinematicChain::SolveToReachWithCombinedConstraintsDLS(CKinematicPos posGoal)
{	
	m_posGoal = posGoal;

	if(GetEndDistanceToGoal() < 0.1)
		return;

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arGoalPos = new double[3];
	arGoalPos[0] = posGoal.m_fX; arGoalPos[1] = posGoal.m_fY; arGoalPos[2] = posGoal.m_fZ;
	mxArray* pMxGoalPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxGoalPos, "Goal_global_pos");
	memcpy(mxGetPr(pMxGoalPos), (double*)arGoalPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Goal_global_pos", pMxGoalPos);

	double* arRootPos = new double[3];
	arRootPos[0] = m_posRoot.m_fX; arRootPos[1] = m_posRoot.m_fY; arRootPos[2] = m_posRoot.m_fZ;
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iDOFNum = GetDOFNum();
	double* arJointAngle = new double[iDOFNum];
	double* arJointWeight = new double[iDOFNum];
	double* arJointConstraints = new double[iDOFNum*3];
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];
	CKinematicJoint* pParent = NULL;
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		arJointAngle[i] = pDOF->m_dLocalRotationAngle * 3.1415926 / 180;		
		arJointWeight[i] = pDOF->m_dWeight;
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;		
		arJointConstraints[0*iDOFNum+i] = pDOF->m_vecConstraints.m_fX;//alpha scale
		arJointConstraints[1*iDOFNum+i] = pDOF->m_vecConstraints.m_fY  * 3.1415926 / 180;//min
		arJointConstraints[2*iDOFNum+i] = pDOF->m_vecConstraints.m_fZ  * 3.1415926 / 180;//max
		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}
	mxArray* pMxLocalAngle = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxLocalAngle, "Joint_angle");
	memcpy((char*)mxGetPr(pMxLocalAngle), (char*)arJointAngle, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_angle", pMxLocalAngle);

	mxArray* pMxJointWeight = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxJointWeight, "Joint_weight");//dan hang ju zhen, heng guo lai de
	memcpy((char*)mxGetPr(pMxJointWeight), (char*)arJointWeight, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_weight", pMxJointWeight);

	mxArray* pMxJointConstraints = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxJointConstraints, "Joint_constraints");
	memcpy((char*)mxGetPr(pMxJointConstraints), (char*)arJointConstraints, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_constraints", pMxJointConstraints);

	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	//evaluate command string
	char strCmd[800];
	//sprintf(strCmd, " [Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3DWithCombinedConstraints(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos,  Joint_weight, Joint_constraints, Goal_global_pos, 0);", iDOFNum);
	sprintf(strCmd, " [Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3DConstrainedDLS(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos,  Joint_weight, Joint_constraints, Goal_global_pos, 0);", iDOFNum);
	engEvalString(pMatlabEngine,strCmd);
	
	//output
	double* arJointAngleNew =  new double[iDOFNum];
	mxArray* pMxJointAngleNew = engGetVariable(pMatlabEngine, "Joint_angle");
	memcpy((char*)arJointAngleNew,(char*)mxGetPr(pMxJointAngleNew), iDOFNum*sizeof(double));

	double* arJointGlobalPos =  new double[(iDOFNum+1)*3];
	mxArray* pMxGlobalPos = engGetVariable(pMatlabEngine, "Joint_global_pos");
	memcpy((char*)arJointGlobalPos,(char*)mxGetPr(pMxGlobalPos), 3*(iDOFNum+1)*sizeof(double));

	double* arJointGlobalAxis = new double[iDOFNum*3];
	mxArray* pMxGlobalAxis = engGetVariable(pMatlabEngine, "Joint_global_axis");
	memcpy((char*)arJointGlobalAxis,(char*)mxGetPr(pMxGlobalAxis), 3*iDOFNum*sizeof(double));

	//populate wangyy - adjust angle to (-180, 180]
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		pDOF->m_dLocalRotationAngle = GloveUtil::NormalizeDegree(arJointAngleNew[i]  * 180 / 3.1415926);
		pDOF->m_vecGlobalAxis.m_fX = arJointGlobalAxis[0*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fY = arJointGlobalAxis[1*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fZ = arJointGlobalAxis[2*iDOFNum+i];

		CKinematicPos posGlobal(arJointGlobalPos[0*(iDOFNum+1)+i], arJointGlobalPos[1*(iDOFNum+1)+i], arJointGlobalPos[2*(iDOFNum+1)+i]);
		pDOF->m_pParentJoint->m_posGlobalCoord = posGlobal;

		if(i == iDOFNum-1)
		{
			CKinematicPos posGlobalEnd(arJointGlobalPos[0*(iDOFNum+1)+i+1], arJointGlobalPos[1*(iDOFNum+1)+i+1], arJointGlobalPos[2*(iDOFNum+1)+i+1]);
			m_arJoint[m_arJoint.size()-1]->m_posGlobalCoord = posGlobalEnd;
		}
	}
	
	//destroy
	delete arGoalPos;
	delete arRootPos;
	delete arJointAngle;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointAngleNew;	
	delete arJointGlobalPos;
	delete arJointGlobalAxis;
	delete arJointConstraints;
	delete arJointWeight;
	
	mxDestroyArray(pMxGoalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAngle);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxJointAngleNew);	
	mxDestroyArray(pMxGlobalPos);
	mxDestroyArray(pMxGlobalAxis);
	mxDestroyArray(pMxJointConstraints);	
	mxDestroyArray(pMxJointWeight);
}

//not all DOF are involved, some are supposed to be rigid
//if all involved including virtual joint, no need to call this
void CKinematicChain::SolveToReachWithCombinedConstraintsDLS_thumb_activeOnly(CKinematicPos posGoal)
{
	m_posGoal = posGoal;

	if(GetEndDistanceToGoal() < 0.1)
		return;

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arGoalPos = new double[3];
	arGoalPos[0] = posGoal.m_fX; arGoalPos[1] = posGoal.m_fY; arGoalPos[2] = posGoal.m_fZ;
	mxArray* pMxGoalPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxGoalPos, "Goal_global_pos");
	memcpy(mxGetPr(pMxGoalPos), (double*)arGoalPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Goal_global_pos", pMxGoalPos);

	double* arRootPos = new double[3];
	arRootPos[0] = m_posRoot.m_fX; arRootPos[1] = m_posRoot.m_fY; arRootPos[2] = m_posRoot.m_fZ;
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iDOFNum = GetDOFNum();
	double* arJointAngle = new double[iDOFNum];
	double* arJointWeight = new double[iDOFNum];
	double* arJointConstraints = new double[iDOFNum*3];
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];
	double* arJointDOFActive = new double[iDOFNum];
	CKinematicJoint* pParent = NULL;
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		//dof active flag
		arJointDOFActive[i] = pDOF->m_bActive ? 1 : -1;

		arJointAngle[i] = pDOF->m_dLocalRotationAngle * 3.1415926 / 180;		
		arJointWeight[i] = pDOF->m_dWeight;
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;		
		arJointConstraints[0*iDOFNum+i] = pDOF->m_vecConstraints.m_fX;//alpha scale
		arJointConstraints[1*iDOFNum+i] = pDOF->m_vecConstraints.m_fY  * 3.1415926 / 180;//min
		arJointConstraints[2*iDOFNum+i] = pDOF->m_vecConstraints.m_fZ  * 3.1415926 / 180;//max
		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}
	mxArray* pMxDOFActive = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxDOFActive, "Joint_dof_active");
	memcpy((char*)mxGetPr(pMxDOFActive), (char*)arJointDOFActive, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_dof_active", pMxDOFActive);

	mxArray* pMxLocalAngle = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxLocalAngle, "Joint_angle");
	memcpy((char*)mxGetPr(pMxLocalAngle), (char*)arJointAngle, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_angle", pMxLocalAngle);

	mxArray* pMxJointWeight = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxJointWeight, "Joint_weight");//dan hang ju zhen, heng guo lai de
	memcpy((char*)mxGetPr(pMxJointWeight), (char*)arJointWeight, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_weight", pMxJointWeight);

	mxArray* pMxJointConstraints = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxJointConstraints, "Joint_constraints");
	memcpy((char*)mxGetPr(pMxJointConstraints), (char*)arJointConstraints, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_constraints", pMxJointConstraints);

	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	//evaluate command string
	char strCmd[800];
	//sprintf(strCmd, " [Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3DWithCombinedConstraints(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos,  Joint_weight, Joint_constraints, Goal_global_pos, 0);", iDOFNum);
	sprintf(strCmd, " [Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3DConstrainedDLS_thumb_activeOnly(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos,  Joint_weight, Joint_constraints, Joint_dof_active, Goal_global_pos, 0);", iDOFNum);
	engEvalString(pMatlabEngine,strCmd);
	
	//output
	double* arJointAngleNew =  new double[iDOFNum];
	mxArray* pMxJointAngleNew = engGetVariable(pMatlabEngine, "Joint_angle");
	memcpy((char*)arJointAngleNew,(char*)mxGetPr(pMxJointAngleNew), iDOFNum*sizeof(double));

	double* arJointGlobalPos =  new double[(iDOFNum+1)*3];
	mxArray* pMxGlobalPos = engGetVariable(pMatlabEngine, "Joint_global_pos");
	memcpy((char*)arJointGlobalPos,(char*)mxGetPr(pMxGlobalPos), 3*(iDOFNum+1)*sizeof(double));

	double* arJointGlobalAxis = new double[iDOFNum*3];
	mxArray* pMxGlobalAxis = engGetVariable(pMatlabEngine, "Joint_global_axis");
	memcpy((char*)arJointGlobalAxis,(char*)mxGetPr(pMxGlobalAxis), 3*iDOFNum*sizeof(double));

	//populate wangyy - adjust angle to (-180, 180]
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		pDOF->m_dLocalRotationAngle = GloveUtil::NormalizeDegree(arJointAngleNew[i]  * 180 / 3.1415926);
		pDOF->m_vecGlobalAxis.m_fX = arJointGlobalAxis[0*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fY = arJointGlobalAxis[1*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fZ = arJointGlobalAxis[2*iDOFNum+i];

		CKinematicPos posGlobal(arJointGlobalPos[0*(iDOFNum+1)+i], arJointGlobalPos[1*(iDOFNum+1)+i], arJointGlobalPos[2*(iDOFNum+1)+i]);
		pDOF->m_pParentJoint->m_posGlobalCoord = posGlobal;

		if(i == iDOFNum-1)
		{
			CKinematicPos posGlobalEnd(arJointGlobalPos[0*(iDOFNum+1)+i+1], arJointGlobalPos[1*(iDOFNum+1)+i+1], arJointGlobalPos[2*(iDOFNum+1)+i+1]);
			m_arJoint[m_arJoint.size()-1]->m_posGlobalCoord = posGlobalEnd;
		}
	}
	
	//destroy
	delete arGoalPos;
	delete arRootPos;
	delete arJointDOFActive;
	delete arJointAngle;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointAngleNew;	
	delete arJointGlobalPos;
	delete arJointGlobalAxis;
	delete arJointConstraints;
	delete arJointWeight;
	
	mxDestroyArray(pMxGoalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAngle);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxJointAngleNew);	
	mxDestroyArray(pMxGlobalPos);
	mxDestroyArray(pMxGlobalAxis);
	mxDestroyArray(pMxJointConstraints);	
	mxDestroyArray(pMxJointWeight);
	mxDestroyArray(pMxDOFActive);

}
void CKinematicChain::SolveToReachWithCombinedConstraintsDLSFromPalm(CKinematicPos posGoal)
{	
	m_posGoal = posGoal;

	if(GetEndDistanceToGoal() < 0.1)
		return;

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arGoalPos = new double[3];
	arGoalPos[0] = posGoal.m_fX; arGoalPos[1] = posGoal.m_fY; arGoalPos[2] = posGoal.m_fZ;
	mxArray* pMxGoalPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxGoalPos, "Goal_global_pos");
	memcpy(mxGetPr(pMxGoalPos), (double*)arGoalPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Goal_global_pos", pMxGoalPos);

	double* arRootPos = new double[3];
	arRootPos[0] = m_posRoot.m_fX; arRootPos[1] = m_posRoot.m_fY; arRootPos[2] = m_posRoot.m_fZ;
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iDOFNum = GetDOFNum();
	double* arJointAngle = new double[iDOFNum];
	double* arJointWeight = new double[iDOFNum];
	double* arJointConstraints = new double[iDOFNum*3];
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];
	CKinematicJoint* pParent = NULL;
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		arJointAngle[i] = pDOF->m_dLocalRotationAngle * 3.1415926 / 180;		
		arJointWeight[i] = pDOF->m_dWeight;
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;		
		arJointConstraints[0*iDOFNum+i] = pDOF->m_vecConstraints.m_fX;//alpha scale
		arJointConstraints[1*iDOFNum+i] = pDOF->m_vecConstraints.m_fY  * 3.1415926 / 180;//min
		arJointConstraints[2*iDOFNum+i] = pDOF->m_vecConstraints.m_fZ  * 3.1415926 / 180;//max
		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}
	mxArray* pMxLocalAngle = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxLocalAngle, "Joint_angle");
	memcpy((char*)mxGetPr(pMxLocalAngle), (char*)arJointAngle, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_angle", pMxLocalAngle);

	mxArray* pMxJointWeight = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxJointWeight, "Joint_weight");//dan hang ju zhen, heng guo lai de
	memcpy((char*)mxGetPr(pMxJointWeight), (char*)arJointWeight, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_weight", pMxJointWeight);

	mxArray* pMxJointConstraints = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxJointConstraints, "Joint_constraints");
	memcpy((char*)mxGetPr(pMxJointConstraints), (char*)arJointConstraints, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_constraints", pMxJointConstraints);

	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	//evaluate command string
	char strCmd[800];
	sprintf(strCmd, " [Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3DConstrainedDLSFromPalm(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos,  Joint_weight, Joint_constraints, Goal_global_pos, 0);", iDOFNum);
	engEvalString(pMatlabEngine,strCmd);
	
	//output
	double* arJointAngleNew =  new double[iDOFNum];
	mxArray* pMxJointAngleNew = engGetVariable(pMatlabEngine, "Joint_angle");
	memcpy((char*)arJointAngleNew,(char*)mxGetPr(pMxJointAngleNew), iDOFNum*sizeof(double));

	double* arJointGlobalPos =  new double[(iDOFNum+1)*3];
	mxArray* pMxGlobalPos = engGetVariable(pMatlabEngine, "Joint_global_pos");
	memcpy((char*)arJointGlobalPos,(char*)mxGetPr(pMxGlobalPos), 3*(iDOFNum+1)*sizeof(double));

	double* arJointGlobalAxis = new double[iDOFNum*3];
	mxArray* pMxGlobalAxis = engGetVariable(pMatlabEngine, "Joint_global_axis");
	memcpy((char*)arJointGlobalAxis,(char*)mxGetPr(pMxGlobalAxis), 3*iDOFNum*sizeof(double));

	//populate wangyy - adjust angle to (-180, 180]
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		pDOF->m_dLocalRotationAngle = GloveUtil::NormalizeDegree(arJointAngleNew[i]  * 180 / 3.1415926);
		pDOF->m_vecGlobalAxis.m_fX = arJointGlobalAxis[0*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fY = arJointGlobalAxis[1*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fZ = arJointGlobalAxis[2*iDOFNum+i];

		CKinematicPos posGlobal(arJointGlobalPos[0*(iDOFNum+1)+i], arJointGlobalPos[1*(iDOFNum+1)+i], arJointGlobalPos[2*(iDOFNum+1)+i]);
		pDOF->m_pParentJoint->m_posGlobalCoord = posGlobal;

		if(i == iDOFNum-1)
		{
			CKinematicPos posGlobalEnd(arJointGlobalPos[0*(iDOFNum+1)+i+1], arJointGlobalPos[1*(iDOFNum+1)+i+1], arJointGlobalPos[2*(iDOFNum+1)+i+1]);
			m_arJoint[m_arJoint.size()-1]->m_posGlobalCoord = posGlobalEnd;
		}
	}
	
	//destroy
	delete arGoalPos;
	delete arRootPos;
	delete arJointAngle;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointAngleNew;	
	delete arJointGlobalPos;
	delete arJointGlobalAxis;
	delete arJointConstraints;
	delete arJointWeight;
	
	mxDestroyArray(pMxGoalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAngle);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxJointAngleNew);	
	mxDestroyArray(pMxGlobalPos);
	mxDestroyArray(pMxGlobalAxis);
	mxDestroyArray(pMxJointConstraints);	
	mxDestroyArray(pMxJointWeight);
}
void CKinematicChain::SolveToReachWithCombinedConstraints_thumb(CKinematicPos posGoal, float fA, float fB)
{	
	m_posGoal = posGoal;

	if(GetEndDistanceToGoal() < 0.1)
		return;

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arGoalPos = new double[3];
	arGoalPos[0] = posGoal.m_fX; arGoalPos[1] = posGoal.m_fY; arGoalPos[2] = posGoal.m_fZ;
	mxArray* pMxGoalPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxGoalPos, "Goal_global_pos");
	memcpy(mxGetPr(pMxGoalPos), (double*)arGoalPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Goal_global_pos", pMxGoalPos);

	double* arRootPos = new double[3];
	arRootPos[0] = m_posRoot.m_fX; arRootPos[1] = m_posRoot.m_fY; arRootPos[2] = m_posRoot.m_fZ;
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iDOFNum = GetDOFNum();
	double* arJointAngle = new double[iDOFNum];
	double* arJointWeight = new double[iDOFNum];
	double* arJointConstraints = new double[iDOFNum*3];
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];
	CKinematicJoint* pParent = NULL;
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		arJointAngle[i] = pDOF->m_dLocalRotationAngle * 3.1415926 / 180;		
		arJointWeight[i] = pDOF->m_dWeight;
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;		
		arJointConstraints[0*iDOFNum+i] = pDOF->m_vecConstraints.m_fX;//alpha scale
		arJointConstraints[1*iDOFNum+i] = pDOF->m_vecConstraints.m_fY  * 3.1415926 / 180;//min
		arJointConstraints[2*iDOFNum+i] = pDOF->m_vecConstraints.m_fZ  * 3.1415926 / 180;//max
		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}
	mxArray* pMxLocalAngle = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxLocalAngle, "Joint_angle");
	memcpy((char*)mxGetPr(pMxLocalAngle), (char*)arJointAngle, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_angle", pMxLocalAngle);

	mxArray* pMxJointWeight = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxJointWeight, "Joint_weight");//dan hang ju zhen, heng guo lai de
	memcpy((char*)mxGetPr(pMxJointWeight), (char*)arJointWeight, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_weight", pMxJointWeight);

	mxArray* pMxJointConstraints = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxJointConstraints, "Joint_constraints");
	memcpy((char*)mxGetPr(pMxJointConstraints), (char*)arJointConstraints, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_constraints", pMxJointConstraints);

	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	//evaluate command string
	char strCmd[800];
	sprintf(strCmd, " [Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3DWithCombinedConstraints_virtualThumb(%f, %f, Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos,  Joint_weight, Joint_constraints, Goal_global_pos, 1);", fA, fB, iDOFNum);
	engEvalString(pMatlabEngine,strCmd);
	
	//output
	double* arJointAngleNew =  new double[iDOFNum];
	mxArray* pMxJointAngleNew = engGetVariable(pMatlabEngine, "Joint_angle");
	memcpy((char*)arJointAngleNew,(char*)mxGetPr(pMxJointAngleNew), iDOFNum*sizeof(double));

	double* arJointGlobalPos =  new double[(iDOFNum+1)*3];
	mxArray* pMxGlobalPos = engGetVariable(pMatlabEngine, "Joint_global_pos");
	memcpy((char*)arJointGlobalPos,(char*)mxGetPr(pMxGlobalPos), 3*(iDOFNum+1)*sizeof(double));

	double* arJointGlobalAxis = new double[iDOFNum*3];
	mxArray* pMxGlobalAxis = engGetVariable(pMatlabEngine, "Joint_global_axis");
	memcpy((char*)arJointGlobalAxis,(char*)mxGetPr(pMxGlobalAxis), 3*iDOFNum*sizeof(double));

	//populate
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);		;
		pDOF->m_dLocalRotationAngle = arJointAngleNew[i]  * 180 / 3.1415926;
		pDOF->m_vecGlobalAxis.m_fX = arJointGlobalAxis[0*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fY = arJointGlobalAxis[1*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fZ = arJointGlobalAxis[2*iDOFNum+i];

		CKinematicPos posGlobal(arJointGlobalPos[0*(iDOFNum+1)+i], arJointGlobalPos[1*(iDOFNum+1)+i], arJointGlobalPos[2*(iDOFNum+1)+i]);
		pDOF->m_pParentJoint->m_posGlobalCoord = posGlobal;

		if(i == iDOFNum-1)
		{
			CKinematicPos posGlobalEnd(arJointGlobalPos[0*(iDOFNum+1)+i+1], arJointGlobalPos[1*(iDOFNum+1)+i+1], arJointGlobalPos[2*(iDOFNum+1)+i+1]);
			m_arJoint[m_arJoint.size()-1]->m_posGlobalCoord = posGlobalEnd;
		}
	}
	
	//destroy
	delete arGoalPos;
	delete arRootPos;
	delete arJointAngle;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointAngleNew;	
	delete arJointGlobalPos;
	delete arJointGlobalAxis;
	delete arJointConstraints;
	delete arJointWeight;
	
	mxDestroyArray(pMxGoalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAngle);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxJointAngleNew);	
	mxDestroyArray(pMxGlobalPos);
	mxDestroyArray(pMxGlobalAxis);
	mxDestroyArray(pMxJointConstraints);	
	mxDestroyArray(pMxJointWeight);
}
void CKinematicChain::SolveToReachWithForClipByConJ(CRawClip& inputClipRadian, CRawClip& outputClipRadian, std::vector<CKinematicPos>& arGoal, std::vector<float>& arGain, std::vector<float>& arOffset, std::vector<int>& arFree)
{
	/*function [concatenated_g_o] = embeded_SolveJointRotation3D(Root_pos, Joint_num, Frame_num, Joint_free, Joint_local_axis, Joint_local_pos, Joint_init_gain, Joint_init_offset, Sensor_of_frames, Goal_of_frames)*/
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arRootPos = new double[3];
	arRootPos[0] = m_posRoot.m_fX; arRootPos[1] = m_posRoot.m_fY; arRootPos[2] = m_posRoot.m_fZ;
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iDOFNum = GetDOFNum();
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];
	double* arJointFree = new double[iDOFNum];
	double* arJointInitGain = new double[iDOFNum];
	double* arJointInitOffset = new double[iDOFNum];

	CKinematicJoint* pParent = NULL;
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;
		arJointFree[i] = arFree[i];
		arJointInitGain[i] = arGain[i];
		arJointInitOffset[i] = arOffset[i];
		
		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}
	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	mxArray* pMxFree = mxCreateDoubleMatrix(iDOFNum, 1, mxREAL);
	mxSetClassName(pMxFree, "Joint_free");
	memcpy((char*)mxGetPr(pMxFree), (char*)arJointFree, (iDOFNum)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_free", pMxFree);

	mxArray* pMxInitGain = mxCreateDoubleMatrix(iDOFNum, 1, mxREAL);
	mxSetClassName(pMxInitGain, "Joint_init_gain");
	memcpy((char*)mxGetPr(pMxInitGain), (char*)arJointInitGain, (iDOFNum)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_init_gain", pMxInitGain);

	mxArray* pMxInitOffset = mxCreateDoubleMatrix(iDOFNum, 1, mxREAL);
	mxSetClassName(pMxInitOffset, "Joint_init_offset");
	memcpy((char*)mxGetPr(pMxInitOffset), (char*)arJointInitOffset, (iDOFNum)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_init_offset", pMxInitOffset);
	
	//Sensor_of frames = (Joint_num, Frame_num),  Goal_of_frames = (3, Frame_num)
	int iFrameNum = inputClipRadian.m_arFrame.size();
	double* arSensorOfFrames = new double[iDOFNum*iFrameNum];
	double* arGoalOfFrames = new double[3*iFrameNum];
	for(int f = 0; f < iFrameNum; ++f)
	{
		/*0*iDOFNum+i
			[i][0]
		1*iDOFNum+i
			[i][1]
		lie * hang shu + hang*/
		CRawFrame sensorFrameRadian = inputClipRadian.m_arFrame[f];
		for(int j = 0; j < sensorFrameRadian.m_arData.size(); ++j)
		{			
			arSensorOfFrames[f*iDOFNum+j] = sensorFrameRadian.m_arData[j];
		}
		CKinematicPos posGoal = arGoal[f];		
		arGoalOfFrames[f*3+0] = posGoal.m_fX;
		arGoalOfFrames[f*3+1] = posGoal.m_fY;
		arGoalOfFrames[f*3+2] = posGoal.m_fZ;		
	}
	mxArray* pMxSensorOfFrames = mxCreateDoubleMatrix(iDOFNum, iFrameNum, mxREAL);
	mxSetClassName(pMxSensorOfFrames, "Sensor_of_frames");
	memcpy(mxGetPr(pMxSensorOfFrames), (double*)arSensorOfFrames, iDOFNum*iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Sensor_of_frames", pMxSensorOfFrames);

	mxArray* pMxGoalOfFrames = mxCreateDoubleMatrix(3, iFrameNum, mxREAL);
	mxSetClassName(pMxGoalOfFrames, "Goal_of_frames");
	memcpy(mxGetPr(pMxGoalOfFrames), (double*)arGoalOfFrames, 3*iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Goal_of_frames", pMxGoalOfFrames);

	//evaluate command string
	char strCmd[800];
	sprintf(strCmd, "[concatenated_g_o] = embeded_SolveJointRotation3D(Root_pos, %d, %d, Joint_free, Joint_local_axis, Joint_local_pos, Joint_init_gain, Joint_init_offset, Sensor_of_frames, Goal_of_frames);", iDOFNum, iFrameNum);
	engEvalString(pMatlabEngine,strCmd);
	
	//output
	double* arConcatenated_g_o =  new double[2*iFrameNum*iDOFNum];
	mxArray* pMxConcatenated_g_o = engGetVariable(pMatlabEngine, "concatenated_g_o");
	memcpy((char*)arConcatenated_g_o,(char*)mxGetPr(pMxConcatenated_g_o), 2*iFrameNum*iDOFNum*sizeof(double));

	//populate result to outputClip
	outputClipRadian.m_arFrame.clear();
	for(int f = 0; f < iFrameNum; ++f)
	{
		CRawFrame sensorFrameRadian = inputClipRadian.m_arFrame[f];
		CRawFrame outputFrameRadian;
		int iBase = f*2*iDOFNum;
		assert(iDOFNum == sensorFrameRadian.m_arData.size());
		for(int j = 0; j < sensorFrameRadian.m_arData.size(); ++j)
		{			
			double dSensorData = sensorFrameRadian.m_arData[j];			
			double dOffset = arConcatenated_g_o[iBase+j];
			double dGain = arConcatenated_g_o[iBase+iDOFNum+j];
			outputFrameRadian.m_arData.push_back(dGain*dSensorData+dOffset);
		}
		outputClipRadian.m_arFrame.push_back(outputFrameRadian);
	}		
	//destroy
	delete arRootPos;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointFree;
	delete arJointInitGain;
	delete arJointInitOffset;
	delete arSensorOfFrames;
	delete arGoalOfFrames;
	delete arConcatenated_g_o;

	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxFree);
	mxDestroyArray(pMxInitGain);
	mxDestroyArray(pMxInitOffset);
	mxDestroyArray(pMxSensorOfFrames);
	mxDestroyArray(pMxGoalOfFrames);
	mxDestroyArray(pMxConcatenated_g_o);	
}
double CKinematicChain::GetPosProbabilityFromPalm(CKinematicPos posEnd)
{
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arGoalPos = new double[3];
	arGoalPos[0] = posEnd.m_fX; arGoalPos[1] = posEnd.m_fY; arGoalPos[2] = posEnd.m_fZ;
	mxArray* pMxGoalPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxGoalPos, "Goal_global_pos");
	memcpy(mxGetPr(pMxGoalPos), (double*)arGoalPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Goal_global_pos", pMxGoalPos);

	double* arRootPos = new double[3];
	float fRootAbd = m_arJoint[0]->m_arDOF[0]->m_dLocalRotationAngle;	
	CKinematicJoint* pPseudoRootJoint = m_arJoint[1];
	arRootPos[0] = pPseudoRootJoint->m_posLocalCoord.m_fX * cos(fRootAbd * 3.1415926 / 180); 
	arRootPos[1] = pPseudoRootJoint->m_posLocalCoord.m_fY;
	arRootPos[2] = pPseudoRootJoint->m_posLocalCoord.m_fX * sin(fRootAbd * 3.1415926 / 180); 
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iStartDOFIdx = 2;
	int iDOFNum = GetDOFNum() - iStartDOFIdx;
	double* arJointAngle = new double[iDOFNum];
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];	
	double* arJointConstraints = new double[iDOFNum*3];
	double* arVariance = new double[iDOFNum];
	CKinematicJoint* pParent = NULL;

	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i + iStartDOFIdx);
		if(i == 0)
			arJointAngle[i] = (pDOF->m_dLocalRotationAngle + fRootAbd) * 3.1415926 / 180;
		else
			arJointAngle[i] = pDOF->m_dLocalRotationAngle * 3.1415926 / 180;

		arVariance[i] = pDOF->m_fVariance * 3.1415926 / 180;//call in radian
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;
			
		arJointConstraints[0*iDOFNum+i] = pDOF->m_vecConstraints.m_fX;//alpha scale
		arJointConstraints[1*iDOFNum+i] = pDOF->m_vecConstraints.m_fY  * 3.1415926 / 180;//min
		arJointConstraints[2*iDOFNum+i] = pDOF->m_vecConstraints.m_fZ  * 3.1415926 / 180;//max
		
		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}

	mxArray* pMxJointConstraints = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxJointConstraints, "Joint_constraints");
	memcpy((char*)mxGetPr(pMxJointConstraints), (char*)arJointConstraints, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_constraints", pMxJointConstraints);

	mxArray* pMxLocalAngle = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxLocalAngle, "Joint_init_angle");
	memcpy((char*)mxGetPr(pMxLocalAngle), (char*)arJointAngle, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_init_angle", pMxLocalAngle);

	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	mxArray* pMxVariance = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxVariance, "Joint_std");
	memcpy((char*)mxGetPr(pMxVariance), (char*)arVariance, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_std", pMxVariance);

	//evaluate command string
	char strCmd[800];
	sprintf(strCmd, "[P_pos] = POS_Probability_DLS_WithConstraints(Root_pos, %d, Joint_init_angle, Joint_local_axis, Joint_local_pos, Joint_constraints, Joint_std, Goal_global_pos)", iDOFNum);
	//sprintf(strCmd, "[Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3D(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos, Goal_global_pos, 0);", iDOFNum);
	engEvalString(pMatlabEngine,strCmd);
	
	//output
	double fPpos =  0;
	mxArray* pMxPpos = engGetVariable(pMatlabEngine, "P_pos");
	memcpy((char*)(&fPpos),(char*)mxGetPr(pMxPpos), sizeof(double));

	//destroy
	delete arGoalPos;
	delete arRootPos;
	delete arJointAngle;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointConstraints;
	
	mxDestroyArray(pMxGoalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAngle);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxJointConstraints);
	return fPpos;

}
double CKinematicChain::GetPosProbability(CKinematicPos posEnd)
{
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arGoalPos = new double[3];
	arGoalPos[0] = posEnd.m_fX; arGoalPos[1] = posEnd.m_fY; arGoalPos[2] = posEnd.m_fZ;
	mxArray* pMxGoalPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxGoalPos, "Goal_global_pos");
	memcpy(mxGetPr(pMxGoalPos), (double*)arGoalPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Goal_global_pos", pMxGoalPos);

	double* arRootPos = new double[3];
	CKinematicJoint* pPseudoRootJoint = m_arJoint[0];
	arRootPos[0] = pPseudoRootJoint->m_posLocalCoord.m_fX; arRootPos[1] = pPseudoRootJoint->m_posLocalCoord.m_fY; arRootPos[2] = pPseudoRootJoint->m_posLocalCoord.m_fZ;
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iDOFNum = GetDOFNum();
	double* arJointAngle = new double[iDOFNum];
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];	
	double* arJointConstraints = new double[iDOFNum*3];
	double* arVariance = new double[iDOFNum];
	CKinematicJoint* pParent = NULL;
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		arJointAngle[i] = pDOF->m_dLocalRotationAngle * 3.1415926 / 180;
		arVariance[i] = pDOF->m_fVariance * 3.1415926 / 180;//call in radian
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;
			
		arJointConstraints[0*iDOFNum+i] = pDOF->m_vecConstraints.m_fX;//alpha scale
		arJointConstraints[1*iDOFNum+i] = pDOF->m_vecConstraints.m_fY  * 3.1415926 / 180;//min
		arJointConstraints[2*iDOFNum+i] = pDOF->m_vecConstraints.m_fZ  * 3.1415926 / 180;//max
		
		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}

	mxArray* pMxJointConstraints = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxJointConstraints, "Joint_constraints");
	memcpy((char*)mxGetPr(pMxJointConstraints), (char*)arJointConstraints, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_constraints", pMxJointConstraints);

	mxArray* pMxLocalAngle = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxLocalAngle, "Joint_init_angle");
	memcpy((char*)mxGetPr(pMxLocalAngle), (char*)arJointAngle, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_init_angle", pMxLocalAngle);

	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	mxArray* pMxVariance = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxVariance, "Joint_std");
	memcpy((char*)mxGetPr(pMxVariance), (char*)arVariance, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_std", pMxVariance);

	//evaluate command string
	char strCmd[800];
	sprintf(strCmd, "[P_pos] = POS_Probability_DLS_WithConstraints(Root_pos, %d, Joint_init_angle, Joint_local_axis, Joint_local_pos, Joint_constraints, Joint_std, Goal_global_pos)", iDOFNum);
	//sprintf(strCmd, "[Joint_angle, Joint_global_pos, Joint_global_axis] = SolveJointRotation3D(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos, Goal_global_pos, 0);", iDOFNum);
	engEvalString(pMatlabEngine,strCmd);
	
	//output
	double fPpos =  0;
	mxArray* pMxPpos = engGetVariable(pMatlabEngine, "P_pos");
	memcpy((char*)(&fPpos),(char*)mxGetPr(pMxPpos), sizeof(double));

	//destroy
	delete arGoalPos;
	delete arRootPos;
	delete arJointAngle;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointConstraints;
	
	mxDestroyArray(pMxGoalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAngle);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxJointConstraints);
	return fPpos;

}
void CKinematicChain::PopulateGlobalPosAndAxis()
{
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	//input
	double* arRootPos = new double[3];
	arRootPos[0] = m_posRoot.m_fX; arRootPos[1] = m_posRoot.m_fY; arRootPos[2] = m_posRoot.m_fZ;
	mxArray* pMxRootPos = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxRootPos, "Root_pos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "Root_pos", pMxRootPos);

	int iDOFNum = GetDOFNum();
	double* arJointAngle = new double[iDOFNum];
	double* arJointLocalAxis = new double[iDOFNum*3];
	double* arJointLocalPos = new double[(iDOFNum+1)*3];
	CKinematicJoint* pParent = NULL;
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		arJointAngle[i] = pDOF->m_dLocalRotationAngle * 3.1415926 / 180;
		arJointLocalAxis[0*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fX; 
		arJointLocalAxis[1*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fY; 
		arJointLocalAxis[2*iDOFNum+i] = pDOF->m_vecLocalAxis.m_fZ;

		if(pDOF->m_pParentJoint != pParent)//first dof of the joint
		{
			CKinematicPos posLocal = pDOF->m_pParentJoint->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i] = posLocal.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i] = posLocal.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i] = posLocal.m_fZ;
			pParent = pDOF->m_pParentJoint;
		}
		else //following dof
		{
			arJointLocalPos[0*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[1*(iDOFNum+1)+i] = 0; 
			arJointLocalPos[2*(iDOFNum+1)+i] = 0;
		}
		if(i == iDOFNum-1)
		{
			CKinematicJoint* pJointEnd = m_arJoint[m_arJoint.size()-1];
			CKinematicPos posLocalEnd = pJointEnd->m_posLocalCoord;
			arJointLocalPos[0*(iDOFNum+1)+i+1] = posLocalEnd.m_fX; 
			arJointLocalPos[1*(iDOFNum+1)+i+1] = posLocalEnd.m_fY; 
			arJointLocalPos[2*(iDOFNum+1)+i+1] = posLocalEnd.m_fZ;
		}
	}
	mxArray* pMxLocalAngle = mxCreateDoubleMatrix(1, iDOFNum, mxREAL);
	mxSetClassName(pMxLocalAngle, "Joint_angle");
	memcpy((char*)mxGetPr(pMxLocalAngle), (char*)arJointAngle, iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_angle", pMxLocalAngle);

	mxArray* pMxLocalAxis = mxCreateDoubleMatrix(iDOFNum, 3, mxREAL);
	mxSetClassName(pMxLocalAxis, "Joint_local_axis");
	memcpy((char*)mxGetPr(pMxLocalAxis), (char*)arJointLocalAxis, 3*iDOFNum*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_axis", pMxLocalAxis);

	mxArray* pMxLocalPos = mxCreateDoubleMatrix(iDOFNum+1, 3, mxREAL);
	mxSetClassName(pMxLocalPos, "Joint_local_pos");
	memcpy((char*)mxGetPr(pMxLocalPos), (char*)arJointLocalPos, 3*(iDOFNum+1)*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_local_pos", pMxLocalPos);

	//evaluate command string
	char strCmd[800];
	sprintf(strCmd, "[Joint_global_pos, Joint_global_axis]=GetGlobalJointPosAndAxis(Root_pos, %d, Joint_angle, Joint_local_axis, Joint_local_pos); ", iDOFNum);
	engEvalString(pMatlabEngine,strCmd);	

	//output
	double* arJointGlobalPos =  new double[(iDOFNum+1)*3];
	mxArray* pMxGlobalPos = engGetVariable(pMatlabEngine, "Joint_global_pos");
	memcpy((char*)arJointGlobalPos,(char*)mxGetPr(pMxGlobalPos), 3*(iDOFNum+1)*sizeof(double));

	double* arJointGlobalAxis = new double[iDOFNum*3];
	mxArray* pMxGlobalAxis = engGetVariable(pMatlabEngine, "Joint_global_axis");
	memcpy((char*)arJointGlobalAxis,(char*)mxGetPr(pMxGlobalAxis), 3*iDOFNum*sizeof(double));

	//populate
	for(int i = 0; i < iDOFNum; ++i)
	{
		CKinematicDOF* pDOF = GetDOFAt(i);
		pDOF->m_vecGlobalAxis.m_fX = arJointGlobalAxis[0*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fY = arJointGlobalAxis[1*iDOFNum+i];
		pDOF->m_vecGlobalAxis.m_fZ = arJointGlobalAxis[2*iDOFNum+i];

		CKinematicPos posGlobal(arJointGlobalPos[0*(iDOFNum+1)+i], arJointGlobalPos[1*(iDOFNum+1)+i], arJointGlobalPos[2*(iDOFNum+1)+i]);
		pDOF->m_pParentJoint->m_posGlobalCoord = posGlobal;

		if(i == iDOFNum-1)
		{
			CKinematicPos posGlobalEnd(arJointGlobalPos[0*(iDOFNum+1)+i+1], arJointGlobalPos[1*(iDOFNum+1)+i+1], arJointGlobalPos[2*(iDOFNum+1)+i+1]);
			m_arJoint[m_arJoint.size()-1]->m_posGlobalCoord = posGlobalEnd;
		}
	}
	/*char msg[300];
	sprintf(msg, "(%f, %f, %f) (%f, %f, %f) (%f, %f, %f) (%f, %f, %f) (%f, %f, %f) (%f, %f, %f)\
				 [%f, %f, %f] [%f, %f, %f] [%f, %f, %f] [%f, %f, %f] [%f, %f, %f] [%f, %f, %f] [%f, %f, %f]",
				 arJointGlobalAxis[0*iDOFNum+0], arJointGlobalAxis[1*iDOFNum+0], arJointGlobalAxis[2*iDOFNum+0],  arJointGlobalAxis[0*iDOFNum+1], arJointGlobalAxis[1*iDOFNum+1], arJointGlobalAxis[2*iDOFNum+1],
				 arJointGlobalAxis[0*iDOFNum+2], arJointGlobalAxis[1*iDOFNum+2], arJointGlobalAxis[2*iDOFNum+2],  arJointGlobalAxis[0*iDOFNum+3], arJointGlobalAxis[1*iDOFNum+3], arJointGlobalAxis[2*iDOFNum+3],
				 arJointGlobalAxis[0*iDOFNum+4], arJointGlobalAxis[1*iDOFNum+4], arJointGlobalAxis[2*iDOFNum+4],  arJointGlobalAxis[0*iDOFNum+5], arJointGlobalAxis[1*iDOFNum+5], arJointGlobalAxis[2*iDOFNum+5],
				 arJointGlobalPos[0*(iDOFNum+1)+0], arJointGlobalPos[1*(iDOFNum+1)+0], arJointGlobalPos[2*(iDOFNum+1)+0],   arJointGlobalPos[0*(iDOFNum+1)+1], arJointGlobalPos[1*(iDOFNum+1)+1], arJointGlobalPos[2*(iDOFNum+1)+1],
				 arJointGlobalPos[0*(iDOFNum+1)+2], arJointGlobalPos[1*(iDOFNum+1)+2], arJointGlobalPos[2*(iDOFNum+1)+2],   arJointGlobalPos[0*(iDOFNum+1)+3], arJointGlobalPos[1*(iDOFNum+1)+3], arJointGlobalPos[2*(iDOFNum+1)+3],
				 arJointGlobalPos[0*(iDOFNum+1)+4], arJointGlobalPos[1*(iDOFNum+1)+4], arJointGlobalPos[2*(iDOFNum+1)+4],   arJointGlobalPos[0*(iDOFNum+1)+5], arJointGlobalPos[1*(iDOFNum+1)+5], arJointGlobalPos[2*(iDOFNum+1)+5],
				 arJointGlobalPos[0*(iDOFNum+1)+6], arJointGlobalPos[1*(iDOFNum+1)+6], arJointGlobalPos[2*(iDOFNum+1)+6]);
	::MessageBox(NULL, msg, L"global info", MB_OK);*/
	
	//destroy
	delete arRootPos;
	delete arJointAngle;
	delete arJointLocalAxis;
	delete arJointLocalPos;	
	delete arJointGlobalPos;
	delete arJointGlobalAxis;	
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxLocalAngle);
	mxDestroyArray(pMxLocalAxis);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxGlobalPos);
	mxDestroyArray(pMxGlobalAxis);
}
void CKinematicChain::VisualizeMatlab()
{
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	double* arJointPos = new double[m_arJoint.size()*3];
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];
		arJointPos[0*m_arJoint.size()+i] = pJoint->m_posGlobalCoord.m_fX;
		arJointPos[1*m_arJoint.size()+i] = pJoint->m_posGlobalCoord.m_fY;
		arJointPos[2*m_arJoint.size()+i] = pJoint->m_posGlobalCoord.m_fZ;
	}
	mxArray* pJointPosMatrix = mxCreateDoubleMatrix(m_arJoint.size(), 3, mxREAL);
	mxSetClassName(pJointPosMatrix, "Joint_pos");
	memcpy((char*)mxGetPr(pJointPosMatrix), (char*)arJointPos, m_arJoint.size()*3*sizeof(double));
	engPutVariable(pMatlabEngine, "Joint_pos", pJointPosMatrix);
	char strCmd[100];
	sprintf(strCmd, "VisualizeIK3D(Joint_pos, %d);", m_arJoint.size()-1);
	engEvalString(pMatlabEngine, strCmd);
	
	delete arJointPos;
	mxDestroyArray(pJointPosMatrix);
}
#include <gl/glaux.h>
#include <gl/glut.h>
void CKinematicChain::Render()
{	
	RenderLocalRotation();
	RenderGlobalPos();
}

void CKinematicChain::RenderGlobalPos()
{
	glLineWidth(2);
	//link
	glBegin(GL_LINE_STRIP);
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];
		glVertex3f(pJoint->m_posGlobalCoord.m_fX, pJoint->m_posGlobalCoord.m_fY, pJoint->m_posGlobalCoord.m_fZ);		
	}
	glEnd();

	//joint
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];
		glTranslatef(pJoint->m_posGlobalCoord.m_fX, pJoint->m_posGlobalCoord.m_fY, pJoint->m_posGlobalCoord.m_fZ);
		glutSolidSphere(0.2, 9, 9);
		glTranslatef(-pJoint->m_posGlobalCoord.m_fX, -pJoint->m_posGlobalCoord.m_fY, -pJoint->m_posGlobalCoord.m_fZ);
	}
	
	//goal
	glTranslatef(m_posGoal.m_fX, m_posGoal.m_fY, m_posGoal.m_fZ);
	glutSolidCube(0.5);
	glTranslatef(-m_posGoal.m_fX, -m_posGoal.m_fY, -m_posGoal.m_fZ);
}
//see clearly each dof axis
void CKinematicChain::RenderLocalRotation()
{
	glPushMatrix();
	glTranslatef(m_posRoot.m_fX, m_posRoot.m_fY, m_posRoot.m_fZ);
	GLUquadricObj *pobj = gluNewQuadric();
	
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJoint = m_arJoint[i];	
		glTranslatef(pJoint->m_posLocalCoord.m_fX, pJoint->m_posLocalCoord.m_fY,pJoint->m_posLocalCoord.m_fZ);		
		for(int j = 0; j < pJoint->m_arDOF.size(); ++j)
		{
			CKinematicDOF* pDOF = pJoint->m_arDOF[j];
			glRotated(pDOF->m_dLocalRotationAngle, pDOF->m_vecLocalAxis.m_fX, pDOF->m_vecLocalAxis.m_fY, pDOF->m_vecLocalAxis.m_fZ);

			if(pDOF->m_vecLocalAxis.m_fX==1)
				glRotated(90, 0, 1, 0);
			if(pDOF->m_vecLocalAxis.m_fY == 1)
				glRotated(-90, 1, 0, 0);
			
			gluCylinder (pobj, 0.2, 0.2, 1.0, 4, 4);
			
			if(pDOF->m_vecLocalAxis.m_fX==1)
				glRotated(-90, 0, 1, 0);
			if(pDOF->m_vecLocalAxis.m_fY==1)
				glRotated(90, 1, 0, 0);			
		}
	}
	glPopMatrix();
}
float CKinematicChain::GetEndDistanceToGoal()
{
	CKinematicPos posEnd = m_arJoint[m_arJoint.size()-1]->m_posGlobalCoord;
	return sqrt((m_posGoal.m_fX-posEnd.m_fX)*(m_posGoal.m_fX-posEnd.m_fX)+
		(m_posGoal.m_fY-posEnd.m_fY)*(m_posGoal.m_fY-posEnd.m_fY)+
		(m_posGoal.m_fZ-posEnd.m_fZ)*(m_posGoal.m_fZ-posEnd.m_fZ));
}
string CKinematicChain::GetBvhHeader(string strNamePrefix, int iStartIdx, string strTab)
{
	string strBvhHeader;	
	std::vector<string> arRightBracket;
	string strRightBracket;
	for(int j = iStartIdx; j < m_arJoint.size(); ++j)
	{
		CKinematicJoint* pJoint = m_arJoint[j];
		if(pJoint->m_arDOF.size() == 0)
		{
			//End Site
			strBvhHeader.append(strTab); strBvhHeader.append("End Site\r\n");
			strBvhHeader.append(strTab); strBvhHeader.append("{\r\n");
			strRightBracket.assign(strTab); strRightBracket.append("}\r\n");
			arRightBracket.push_back(strRightBracket);
			strTab += "\t";

			//OFFSET
			strBvhHeader.append(strTab); strBvhHeader.append(pJoint->GetBvhOffsetInfo());
		}
		else
		{
			//JOINT
			char buffer[5];
			strBvhHeader.append(strTab); strBvhHeader.append("JOINT ");
			strBvhHeader.append(strNamePrefix);
			sprintf(buffer, "_%d", j);
			strBvhHeader.append(buffer); strBvhHeader.append("\r\n");
			strBvhHeader.append(strTab); strBvhHeader.append("{\r\n");					
			strRightBracket.assign(strTab); strRightBracket.append("}\r\n");
			arRightBracket.push_back(strRightBracket);
			strTab +=  "\t";

			//OFFSET
			strBvhHeader.append(strTab); strBvhHeader.append(pJoint->GetBvhOffsetInfo());

			//CHANNELS
			strBvhHeader.append(strTab); strBvhHeader.append(pJoint->GetBvhChannelInfo());
		}
	}
	for(int j = arRightBracket.size()-1; j >=0 ; --j)
		strBvhHeader.append(arRightBracket[j]);

	return strBvhHeader;
}
string CKinematicChain::GetBvhHeaderConsistentWithBody(bool bLeft, string strNamePrefix, int iStartIdx, string strTab)
{
	string strBvhHeader;	
	std::vector<string> arRightBracket;
	string strRightBracket;
	for(int j = iStartIdx; j < m_arJoint.size(); ++j)
	{
		CKinematicJoint* pJoint = m_arJoint[j];
		if(pJoint->m_arDOF.size() == 0)
		{
			//End Site
			strBvhHeader.append(strTab); strBvhHeader.append("End Site\r\n");
			strBvhHeader.append(strTab); strBvhHeader.append("{\r\n");
			strRightBracket.assign(strTab); strRightBracket.append("}\r\n");
			arRightBracket.push_back(strRightBracket);
			strTab += "\t";

			//OFFSET
			strBvhHeader.append(strTab); strBvhHeader.append(pJoint->GetBvhOffsetInfoConsistentWithBody(bLeft));
		}
		else
		{
			//JOINT
			char buffer[5];
			strBvhHeader.append(strTab); strBvhHeader.append("JOINT ");
			strBvhHeader.append(strNamePrefix);
			sprintf(buffer, "_%d", j);
			strBvhHeader.append(buffer); strBvhHeader.append("\r\n");
			strBvhHeader.append(strTab); strBvhHeader.append("{\r\n");					
			strRightBracket.assign(strTab); strRightBracket.append("}\r\n");
			arRightBracket.push_back(strRightBracket);
			strTab +=  "\t";

			//OFFSET
			strBvhHeader.append(strTab); strBvhHeader.append(pJoint->GetBvhOffsetInfoConsistentWithBody(bLeft));

			//CHANNELS
			strBvhHeader.append(strTab); strBvhHeader.append(pJoint->GetBvhChannelInfoConsistentWithBody());
		}
	}
	for(int j = arRightBracket.size()-1; j >=0 ; --j)
		strBvhHeader.append(arRightBracket[j]);

	return strBvhHeader;

}
string CKinematicChain::GetBvhData()
{
	string strBvhData = "";
	char buffer[50];
	for(int j = 0; j < m_arJoint.size(); ++ j)
	{
		CKinematicJoint* pJoint = m_arJoint[j];
		for(int d = 0; d < pJoint->m_arDOF.size(); ++d)
		{
			CKinematicDOF* pDOF = pJoint->m_arDOF[d];
			sprintf(buffer, "%f ", pDOF->m_dLocalRotationAngle);
			strBvhData.append(buffer);
		}
	}
	return strBvhData;
}
//failed IK means: 1. cannot reach goal 2. reach goal but violating constraints
bool CKinematicChain::IsFailedIK()
{
	PopulateGlobalPosAndAxis();
	if(GetEndDistanceToGoal() > 4)
		return true;

	for(int j = 0; j < m_arJoint.size(); ++j)
	{
		CKinematicJoint* pJoint = m_arJoint[j];
		for(int d = 0; d < pJoint->m_arDOF.size(); ++d)
		{
			CKinematicDOF* pDOF = pJoint->m_arDOF[d];
			if(pDOF->IsViolateConstraints())
				return true;
		}
	}
	return false;
}

float CKinematicChain::GetChainLength()
{
	float fChainLength = 0;
	for(int i = 0; i < m_arJoint.size(); ++i)
	{
		CKinematicJoint* pJt = m_arJoint[i];
		fChainLength += pJt->m_posLocalCoord.GetEuclideanLength();
	}
	return fChainLength;
}