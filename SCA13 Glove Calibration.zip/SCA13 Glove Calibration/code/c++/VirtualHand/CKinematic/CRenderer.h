#pragma once
#include <gl/glaux.h>
#include <gl/glut.h>
#include "..\CRenderer.h"

#include "CKinematicChain.h"
class CKinematicChainRenderer : COpenGLRenderer
{
public:
	CKinematicChainRenderer();
	CKinematicChainRenderer(CKinematicChain* pChain);
	virtual void Render();
	CKinematicChain* m_pChain;

};
#include "CKinematicHand.h"
class CKinematicHandRenderer : COpenGLRenderer
{
public:
	CKinematicHandRenderer();
	CKinematicHandRenderer(CKinematicHand* pHand);
	virtual void Render();

	CKinematicHand* m_pHand;	
	bool m_bShowProb;
	bool m_bHighlightActive;

	CKinematicPoint m_clrThumb;
	CKinematicPoint m_clrIndex;
	CKinematicPoint m_clrMid;
	CKinematicPoint m_clrRing;
	CKinematicPoint m_clrPinky;
};
					 