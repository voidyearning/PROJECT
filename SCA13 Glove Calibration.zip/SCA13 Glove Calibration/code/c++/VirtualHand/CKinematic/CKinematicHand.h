#pragma once
#include "..\GloveAnimation.h"
#include "..\RawAnimation.h"
#include "CKinematicChain.h"
#include <string>
#include <vector>

#define FLAG_ACTIVE_NONE		0x0000
#define FLAG_ACTIVE_THUMB	0x0001
#define FLAG_ACTIVE_INDEX	0x0002
#define FLAG_ACTIVE_MID		0x0004
#define FLAG_ACTIVE_RING		0x0008
#define FLAG_ACTIVE_PINKY		0x0010


using namespace std;
class CKinematicHand
{
public:	
	CKinematicHand();
	vector<CKinematicChain*> m_arChain;
	enum HAND_CHAIN_ID{E_CHAIN_THUMB = 4, E_CHAIN_INDEX, E_CHAIN_MID, E_CHAIN_RING, E_CHAIN_PINKY};
	enum HAND_JOINT_ID {E_JOINT_THUMB_ROOT=10, E_JOINT_THUMB_ABDUCT, E_JOINT_THUMB_VIRTUAL_TWIST, E_JOINT_THUMB_FLEX_1, E_JOINT_THUMB_FLEX_2, E_JOINT_THUMB_END,
	E_JOINT_INDEX_PALM, E_JOINT_INDEX_PROXIMAL, E_JOINT_INDEX_MID, E_JOINT_INDEX_DISTAL, E_JOINT_INDEX_END, 
	E_JOINT_MID_PALM, E_JOINT_MID_PROXIMAL, E_JOINT_MID_MID, E_JOINT_MID_DISTAL, E_JOINT_MID_END,
	E_JOINT_RING_PALM, E_JOINT_RING_PROXIMAL, E_JOINT_RING_MID, E_JOINT_RING_DISTAL,E_JOINT_RING_END,
	E_JOINT_PINKY_PALM, E_JOINT_PINKY_PROXIMAL, E_JOINT_PINKY_MID, E_JOINT_PINKY_DISTAL, E_JOINT_PINKY_END};

	enum HAND_DOF_ID{E_DOF_ROLL_X = 1, E_DOF_ABDUCT_Y = 2,  E_DOF_FLEX_Z = 3};

	virtual void ConstructHand() = 0;
	virtual void Reset() = 0;
	virtual void LoadHandSize(string strPath) = 0;
	virtual void SaveHandSize(string strPath) = 0;
	virtual void LoadHandPose(string strPath) = 0;
	virtual void Render() = 0;
	virtual CKinematicChain* GetChain(enum CKinematicHand::HAND_CHAIN_ID eChainId);
	virtual CKinematicJoint* GetJoint(enum HAND_JOINT_ID) = 0;
	virtual CKinematicDOF* GetDOF(enum HAND_JOINT_ID, enum HAND_DOF_ID) = 0;
	virtual string GetBvhHeader();
	virtual string GetBvhHeaderConsistentWithBody();
	virtual string GetBvhData();
	virtual string GetASF();

	virtual void SetDefaultPose(){};
	virtual void SetFlatPose(){};
	virtual void SetFistPose(){};
	virtual void SetSpreadPose(){};
	virtual void UpdateFromSensorData(const std::vector<float>& arSensorData){};
	virtual void UpdateToSensorData(std::vector<float>& arSensorData){};
	virtual void UpdateFromKinematicData(const std::vector<float>& arKinData);
	virtual void UpdateToKinematicData(std::vector<float>& arKinData);

	virtual void UpdateFingerFromSensorData(enum HAND_CHAIN_ID, const std::vector<float>& arSensorData) {};
	virtual void UpdateFingerToSensorData(enum HAND_CHAIN_ID, std::vector<float>& arSensorData){};
	virtual void UpdateFingerFromKinematicData(enum HAND_CHAIN_ID, const std::vector<float>& arKinData);
	virtual void UpdateFingerToKinematicData(enum HAND_CHAIN_ID, std::vector<float>& arKinData);

	virtual void PopulateGlobalPosAndAxis();
	virtual void PleaseTouch(IK_FINGER_TOUCHING_TYPE eTouchingType);
	void PleaseTouchAt(CKinematicPos posGoal);
	void PleaseTouchAt(IK_FINGER_TOUCHING_TYPE eTouchingType, CKinematicPos posGoal);
	virtual void PleaseTouchClip(IK_FINGER_TOUCHING_TYPE eTouchingType, std::vector<float>& arGain, std::vector<float>& arOffset, CGlvClip& inputClip, CRawClip& outputClip);
	void MoveGoalToFingerTip();

	void SetActiveFlag(short sActiveFinger);
	void UnsetActiveFlag(short sActiveFinger);
	bool IsFingerActive(short sActiveFinger);
	double GetActiveProbability(CKinematicPos posEnd);
	void GetActiveEndEffectorRange(CKinematicPoint& posMin, CKinematicPoint& posMax);
	int GetActiveChainCount();
	void GetActiveChain(std::vector<CKinematicChain*>& arActiveChain);

	virtual void ExportTrajectory(CRawClip clipRaw, int iTrjIndex, std::string strPath);
	virtual void ExportTipDistance(CRawClip clipRaw, IK_FINGER_TOUCHING_TYPE eTouchingType, std::string strPath);
	
	short m_sFlagActiveFinger;
	float m_fA;
	float m_fB;

	void ik_thumb_reach(CKinematicPos posGoal, float fTolerance, std::vector<float> arWeight);
};

class CKinematicHandLeft : public CKinematicHand
{
	public:
	CKinematicHandLeft();
	
	virtual void ConstructHand();
	virtual void DestructHand();
	virtual void Reset();

	virtual void LoadHandSize(string strPath);
	virtual void SaveHandSize(string strPath);
	virtual void LoadHandPose(string strPath);
	virtual void Render();

	virtual void SetDefaultPose();
	virtual void SetFlatPose();
	virtual void SetFistPose();
	virtual void SetSpreadPose();
	virtual void UpdateFromSensorData(const std::vector<float>& arSensorData);
	virtual void UpdateToSensorData(std::vector<float>& arSensorData);
	virtual void UpdateFingerFromSensorData(enum HAND_CHAIN_ID, const std::vector<float>& arSensorData);
	virtual void UpdateFingerToSensorData(enum HAND_CHAIN_ID, std::vector<float>& arSensorData);

	virtual CKinematicJoint* GetJoint(enum HAND_JOINT_ID id);
	virtual CKinematicDOF* GetDOF(enum HAND_JOINT_ID, enum HAND_DOF_ID);
};

class CKinematicHandRight : public CKinematicHand
{
	public:
	CKinematicHandRight();
	
	virtual void ConstructHand();
	virtual void DestructHand();
	virtual void Reset();

	virtual void LoadHandSize(string strPath);	
	virtual void SaveHandSize(string strPath);
	virtual void LoadHandPose(string strPath);
	virtual void Render();

	virtual void SetDefaultPose();
	virtual void SetFlatPose();
	virtual void SetFistPose();
	virtual void SetSpreadPose();
	virtual void UpdateFromSensorData(const std::vector<float>& arSensorData);
	virtual void UpdateToSensorData(std::vector<float>& arSensorData);
	virtual void UpdateFingerFromSensorData(enum HAND_CHAIN_ID, const std::vector<float>& arSensorData) ;
	virtual void UpdateFingerToSensorData(enum HAND_CHAIN_ID, std::vector<float>& arSensorData);

	virtual CKinematicJoint* GetJoint(enum HAND_JOINT_ID);
	virtual CKinematicDOF* GetDOF(enum HAND_JOINT_ID, enum HAND_DOF_ID);	
};