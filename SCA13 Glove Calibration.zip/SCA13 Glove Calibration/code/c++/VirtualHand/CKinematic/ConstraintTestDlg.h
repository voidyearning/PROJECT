#pragma once
#include "..\OpenGLWnd.h"

#include "CKinematicChain.h"
#include "CRenderer.h"
#include "CKinematicHand.h"
#include <vector>
#include "..\Resource.h"

// CConstraintTestDlg dialog

class CConstraintTestDlg : public CDialog
{
	DECLARE_DYNAMIC(CConstraintTestDlg)

public:
	CConstraintTestDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CConstraintTestDlg();
	virtual BOOL OnInitDialog();

// Dialog Data
	enum { IDD = IDD_DIALOG_CONSTRAINT_TEST };

	COpenGLWnd m_wndOpenGLNoConstraints;
	COpenGLWnd m_wndOpenGLWeightConstraints;
	COpenGLWnd m_wndOpenGLRangeConstraints;

	CKinematicChain* m_pChainNoConstraints;
	CKinematicChain* m_pChainWeightConstraints;
	CKinematicChain* m_pChainRangeConstraints;

	CKinematicChainRenderer* m_pChainRendererNoConstraints;
	CKinematicChainRenderer* m_pChainRendererWeightConstraints;
	CKinematicChainRenderer* m_pChainRendererRangeConstraints;

	CKinematicPos m_posGoal;

	void CreateChain();
	void ResetChain(CKinematicChain* pChain);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonReset();
	afx_msg void OnBnClickedButtonReachGoal();
	afx_msg void OnEnChangeEditGoal();
	afx_msg void OnEnChangeEditFlexDistalW();
	afx_msg void OnEnChangeEditFlexMidW();
	afx_msg void OnEnChangeEditFlexProxW();
	afx_msg void OnEnChangeEditAbdProxW();
	afx_msg void OnEnChangeEditAbdRootW();
	afx_msg void OnEnChangeEditFlexRootW();
	afx_msg void OnEnChangeEditFlexRootC();
	afx_msg void OnEnChangeEditAbdRootC();
	afx_msg void OnEnChangeEditAbdProxC();
	afx_msg void OnEnChangeEditFlexProxC();
	afx_msg void OnEnChangeEditFlexMidC();
	afx_msg void OnEnChangeEditFlexDistalC();
};
