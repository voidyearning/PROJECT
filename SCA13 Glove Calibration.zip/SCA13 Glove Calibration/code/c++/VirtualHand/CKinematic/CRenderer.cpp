#include "CRenderer.h"
#include "..\RGBColor.h"

CKinematicChainRenderer::CKinematicChainRenderer()
{
	m_pChain = NULL;
}
CKinematicChainRenderer::CKinematicChainRenderer(CKinematicChain* pChain)
{
	m_pChain = pChain;
}
void CKinematicChainRenderer::Render()
{
	if(m_pChain)
		m_pChain->Render();
}
CKinematicHandRenderer::CKinematicHandRenderer()
{
	m_pHand = NULL;
	
	m_bShowProb = false;
	m_bHighlightActive = false;

	m_clrThumb = CKinematicPoint(RGB_THUMB);
	m_clrIndex = CKinematicPoint(RGB_INDEX);
	m_clrMid = CKinematicPoint(RGB_MIDDLE);
	m_clrRing = CKinematicPoint(RGB_RING);
	m_clrPinky = CKinematicPoint(RGB_PINKY);
}
CKinematicHandRenderer::CKinematicHandRenderer(CKinematicHand* pHand)
{
	m_pHand = pHand;
	
	m_bShowProb = false;
	m_bHighlightActive = false;

	m_clrThumb = CKinematicPoint(RGB_THUMB);
	m_clrIndex = CKinematicPoint(RGB_INDEX);
	m_clrMid = CKinematicPoint(RGB_MIDDLE);
	m_clrRing = CKinematicPoint(RGB_RING);
	m_clrPinky = CKinematicPoint(RGB_PINKY);
}
void CKinematicHandRenderer::Render()
{
	if(m_pHand)
		m_pHand->Render();
}