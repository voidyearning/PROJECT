 // GloveCalibDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GloveCalibDlg.h"
#include "GloveUtil.h"
#include "GloveAnimation.h"

CGloveCalibDlg::CGloveCalibDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGloveCalibDlg::IDD, pParent)
{
	m_pHandLeft = new CHandSkeletonKin();
	m_pHandRight = new CHandSkeletonKin(true);
	m_pHandRendererLeft = new COpenGLHandRendererKin(m_pHandLeft);	
	m_pHandRendererRight = new COpenGLHandRendererKin(m_pHandRight);

	m_pHandRendererCap = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_pHandRendererReal = new COpenGLHandRendererKin(new CHandSkeletonKin());
	m_pGlvMgrLeft = CGloveMocapMgr::GetGloveMgr(LEFT_HAND);
	m_pGlvMgrRight = CGloveMocapMgr::GetGloveMgr(RIGHT_HAND);
	m_bShowRadian = true;
}

CGloveCalibDlg::~CGloveCalibDlg()
{
	if(m_pHandRendererLeft)
	{
		delete m_pHandRendererLeft->m_pHand;
		delete m_pHandRendererLeft;
	}

	if(m_pHandRendererRight)
	{
		delete m_pHandRendererRight->m_pHand;
		delete m_pHandRendererRight;
	}

	if(m_pHandRendererCap)
	{
		delete m_pHandRendererCap->m_pHand;
		delete m_pHandRendererCap;
	}

	if(m_pHandRendererReal)
	{
		delete m_pHandRendererReal->m_pHand;
		delete m_pHandRendererReal;
	}
}

void CGloveCalibDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CGloveCalibDlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONNECT, &CGloveCalibDlg::OnBnClickedConnect)
	ON_BN_CLICKED(IDC_BTN_DISCONNECT, &CGloveCalibDlg::OnBnClickedBtnDisconnect)
	ON_BN_CLICKED(IDC_RADIO_RIGHTHAND, &CGloveCalibDlg::OnBnClickedRadioRighthand)
	ON_BN_CLICKED(IDC_RADIO_LEFTHAND, &CGloveCalibDlg::OnBnClickedRadioLefthand)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CGloveCalibDlg::OnBnClickedButtonReset)
	ON_BN_CLICKED(IDC_BUTTON_CAP1, &CGloveCalibDlg::OnBnClickedButtonCap1)
	ON_BN_CLICKED(IDC_BUTTON_REAL1, &CGloveCalibDlg::OnBnClickedButtonReal1)
	ON_BN_CLICKED(IDC_BUTTON_CAP2, &CGloveCalibDlg::OnBnClickedButtonCap2)
	ON_BN_CLICKED(IDC_BUTTON_REAL2, &CGloveCalibDlg::OnBnClickedButtonReal2)
	ON_BN_CLICKED(IDC_BUTTON_AUTOCALIB, &CGloveCalibDlg::OnBnClickedButtonAutocalib)
	ON_EN_CHANGE(IDC_EDIT_THUMB_TMJ_G, &CGloveCalibDlg::OnEnChangeEditThumbTmjG)
	ON_EN_CHANGE(IDC_EDIT_THUMB_TMJ_O, &CGloveCalibDlg::OnEnChangeEditThumbTmjO)
	ON_EN_CHANGE(IDC_EDIT_THUMB_MPJ_G, &CGloveCalibDlg::OnEnChangeEditThumbMpjG)
	ON_EN_CHANGE(IDC_EDIT_THUMB_MPJ_O, &CGloveCalibDlg::OnEnChangeEditThumbMpjO)
	ON_EN_CHANGE(IDC_EDIT_THUMB_IJ_G, &CGloveCalibDlg::OnEnChangeEditThumbIjG)
	ON_EN_CHANGE(IDC_EDIT_THUMB_IJ_O, &CGloveCalibDlg::OnEnChangeEditThumbIjO)
	ON_EN_CHANGE(IDC_EDIT_THUMB_ABD_G, &CGloveCalibDlg::OnEnChangeEditThumbAbdG)
	ON_EN_CHANGE(IDC_EDIT_THUMB_ABD_O, &CGloveCalibDlg::OnEnChangeEditThumbAbdO)
	ON_EN_CHANGE(IDC_EDIT_INDEX_MPJ_G, &CGloveCalibDlg::OnEnChangeEditIndexMpjG)
	ON_EN_CHANGE(IDC_EDIT_INDEX_MPJ_O, &CGloveCalibDlg::OnEnChangeEditIndexMpjO)
	ON_EN_CHANGE(IDC_EDIT_INDEX_PIJ_G, &CGloveCalibDlg::OnEnChangeEditIndexPijG)
	ON_EN_CHANGE(IDC_EDIT_INDEX_PIJ_O, &CGloveCalibDlg::OnEnChangeEditIndexPijO)
	ON_EN_CHANGE(IDC_EDIT_INDEX_DIJ_G, &CGloveCalibDlg::OnEnChangeEditIndexDijG)
	ON_EN_CHANGE(IDC_EDIT_INDEX_DIJ_O, &CGloveCalibDlg::OnEnChangeEditIndexDijO)
	ON_EN_CHANGE(IDC_EDIT_INDEX_ABD_G, &CGloveCalibDlg::OnEnChangeEditIndexAbdG)
	ON_EN_CHANGE(IDC_EDIT_INDEX_ABD_O, &CGloveCalibDlg::OnEnChangeEditIndexAbdO)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_MPJ_G, &CGloveCalibDlg::OnEnChangeEditMiddleMpjG)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_MPJ_O, &CGloveCalibDlg::OnEnChangeEditMiddleMpjO)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_PIJ_G, &CGloveCalibDlg::OnEnChangeEditMiddlePijG)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_PIJ_O, &CGloveCalibDlg::OnEnChangeEditMiddlePijO)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_DIJ_G, &CGloveCalibDlg::OnEnChangeEditMiddleDijG)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_DIJ_O, &CGloveCalibDlg::OnEnChangeEditMiddleDijO)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_ABD_G, &CGloveCalibDlg::OnEnChangeEditMiddleAbdG)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_ABD_O, &CGloveCalibDlg::OnEnChangeEditMiddleAbdO)
	ON_EN_CHANGE(IDC_EDIT_RING_MPJ_G, &CGloveCalibDlg::OnEnChangeEditRingMpjG)
	ON_EN_CHANGE(IDC_EDIT_RING_MPJ_O, &CGloveCalibDlg::OnEnChangeEditRingMpjO)
	ON_EN_CHANGE(IDC_EDIT_RING_PIJ_G, &CGloveCalibDlg::OnEnChangeEditRingPijG)
	ON_EN_CHANGE(IDC_EDIT_RING_PIJ_O, &CGloveCalibDlg::OnEnChangeEditRingPijO)
	ON_EN_CHANGE(IDC_EDIT_RING_DIJ_G, &CGloveCalibDlg::OnEnChangeEditRingDijG)
	ON_EN_CHANGE(IDC_EDIT_RING_DIJ_O, &CGloveCalibDlg::OnEnChangeEditRingDijO)
	ON_EN_CHANGE(IDC_EDIT_RING_ABD_G, &CGloveCalibDlg::OnEnChangeEditRingAbdG)
	ON_EN_CHANGE(IDC_EDIT_RING_ABD_O, &CGloveCalibDlg::OnEnChangeEditRingAbdO)
	ON_EN_CHANGE(IDC_EDIT_PINKY_MPJ_G, &CGloveCalibDlg::OnEnChangeEditPinkyMpjG)
	ON_EN_CHANGE(IDC_EDIT_PINKY_MPJ_O, &CGloveCalibDlg::OnEnChangeEditPinkyMpjO)
	ON_EN_CHANGE(IDC_EDIT_PINKY_PIJ_G, &CGloveCalibDlg::OnEnChangeEditPinkyPijG)
	ON_EN_CHANGE(IDC_EDIT_PINKY_PIJ_O, &CGloveCalibDlg::OnEnChangeEditPinkyPijO)
	ON_EN_CHANGE(IDC_EDIT_PINKY_DIJ_G, &CGloveCalibDlg::OnEnChangeEditPinkyDijG)
	ON_EN_CHANGE(IDC_EDIT_PINKY_DIJ_O, &CGloveCalibDlg::OnEnChangeEditPinkyDijO)
	ON_EN_CHANGE(IDC_EDIT_PINKY_ABD_G, &CGloveCalibDlg::OnEnChangeEditPinkyAbdG)
	ON_EN_CHANGE(IDC_EDIT_PINKY_ABD_O, &CGloveCalibDlg::OnEnChangeEditPinkyAbdO)
	ON_STN_CLICKED(IDC_STATIC_MAIN_LEFT, &CGloveCalibDlg::OnStnClickedStaticMainLeft)
	ON_STN_CLICKED(IDC_STATIC_MAIN_RIGHT, &CGloveCalibDlg::OnStnClickedStaticMainRight)
	ON_STN_CLICKED(IDC_STATIC_CAP, &CGloveCalibDlg::OnStnClickedStaticCap)
	ON_STN_CLICKED(IDC_STATIC_REAL, &CGloveCalibDlg::OnStnClickedStaticReal)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_CALIB, &CGloveCalibDlg::OnBnClickedButtonLoadCalib)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_CALIB, &CGloveCalibDlg::OnBnClickedButtonSaveCalib)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_HANDSIZE, &CGloveCalibDlg::OnBnClickedButtonLoadHandsize)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_HANDSIZE, &CGloveCalibDlg::OnBnClickedButtonSaveHandsize)
	ON_EN_CHANGE(IDC_EDIT_PALM_ARC_G, &CGloveCalibDlg::OnEnChangeEditPalmArcG)
	ON_EN_CHANGE(IDC_EDIT_PALM_ARC_O, &CGloveCalibDlg::OnEnChangeEditPalmArcO)
	ON_EN_CHANGE(IDC_EDIT_PALM_FLEX_G, &CGloveCalibDlg::OnEnChangeEditPalmFlexG)
	ON_EN_CHANGE(IDC_EDIT_PALM_FLEX_O, &CGloveCalibDlg::OnEnChangeEditPalmFlexO)
	ON_EN_CHANGE(IDC_EDIT_PALM_ABD_G, &CGloveCalibDlg::OnEnChangeEditPalmAbdG)
	ON_EN_CHANGE(IDC_EDIT_PALM_ABD_O, &CGloveCalibDlg::OnEnChangeEditPalmAbdO)
	ON_BN_CLICKED(IDC_RADIO_RADIAN, &CGloveCalibDlg::OnBnClickedRadioRadian)
	ON_BN_CLICKED(IDC_RADIO_DEGREE, &CGloveCalibDlg::OnBnClickedRadioDegree)
	ON_BN_CLICKED(IDC_BUTTON_LINEAR_HP_2_TR, &CGloveCalibDlg::OnBnClickedButtonLinearHp2Tr)
	ON_BN_CLICKED(IDC_RADIO_UNCALIB_RAW, &CGloveCalibDlg::OnBnClickedRadioUncalibRaw)
	ON_BN_CLICKED(IDC_RADIO_LINEAR_CALIB_VC, &CGloveCalibDlg::OnBnClickedRadioLinearCalibVc)
	ON_BN_CLICKED(IDC_RADIO_LINEAR_CALIB_MATLAB, &CGloveCalibDlg::OnBnClickedRadioLinearCalibMatlab)
	ON_BN_CLICKED(IDC_RADIO_GPR_CALIB_FITC_MATLAB2, &CGloveCalibDlg::OnBnClickedRadioGprCalibFitcMatlab2)
END_MESSAGE_MAP()

void CGloveCalibDlg::WriteCalibrationToMgr(CGloveCalibration calibration)
{
	if(m_eAdjustHandness == LEFT_HAND)
	{
		for(int i = 0 ; i < calibration.m_arAdjustItem.size(); ++i)
		{
			CGloveCalibrationItem item = calibration.m_arAdjustItem[i];
			m_pGlvMgrLeft->SetAdjustGain(i, item.m_fGain);
			m_pGlvMgrLeft->SetAdjustOffset(i, item.m_fOffset);
		}
	}
	else
	{
		for(int i = 0 ; i < calibration.m_arAdjustItem.size(); ++i)
		{
			CGloveCalibrationItem item = calibration.m_arAdjustItem[i];
			m_pGlvMgrRight->SetAdjustGain(i, item.m_fGain);
			m_pGlvMgrRight->SetAdjustOffset(i, item.m_fOffset);
		}
	}
}

void CGloveCalibDlg::UpdateEditsFromCalibration()
{
	for(int i = 0; i < 23 /*m_glvCalib.m_arItem.size()*/; ++i)
	{
		CGloveCalibrationItem item = m_pGlvCalib->m_arAdjustItem[i];
		CString strFormat = L"";
		strFormat.Format(L"%2.2f", item.m_fGain); 
		GetDlgItem(IDC_EDIT_THUMB_TMJ_G + i)->SetWindowText(strFormat);

		strFormat = L"";
		strFormat.Format(L"%2.2f", item.m_fOffset);
		GetDlgItem(IDC_EDIT_THUMB_TMJ_O + i)->SetWindowText(strFormat);
	}
}
void CGloveCalibDlg::UpdateCalibrationFromEdits(int iIndex, CString strValue, bool bGain)
{
	if(iIndex <0 || iIndex > m_pGlvCalib->m_arAdjustItem.size())
		return;
	float fValue = _wtof(strValue);
	if(bGain)
		m_pGlvCalib->m_arAdjustItem[iIndex].m_fGain = fValue;
	else
		m_pGlvCalib->m_arAdjustItem[iIndex].m_fOffset = fValue;
	//WriteCalibrationToMgr();
}
BOOL CGloveCalibDlg::OnInitDialog()
{
	InitGainAndOffsetUI();
	m_eAdjustHandness = LEFT_HAND;
	m_pGlvCalib = m_pGlvMgrLeft->m_pCalib; //.InitAdjustCalibration();
	((CButton*)GetDlgItem(IDC_RADIO_LEFTHAND))->SetCheck(1);
//	WriteCalibrationToMgr();
	UpdateEditsFromCalibration();

	//main left
	CRect rcMain_l;
	::GetClientRect(GetDlgItem(IDC_STATIC_MAIN_LEFT)->m_hWnd, rcMain_l);
	m_wndOpenGLMainLeft.Create(NULL,
						NULL,
						WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE,						       
						rcMain_l,  
						this,  
						0);    
	m_wndOpenGLMainLeft.SetRender((COpenGLRenderer*)m_pHandRendererLeft);	
	m_wndOpenGLMainLeft.Invalidate(1);
	::SetFocus(m_wndOpenGLMainLeft.m_hWnd);

	CRect rcMain_r;
	::GetClientRect(GetDlgItem(IDC_STATIC_MAIN_RIGHT)->m_hWnd, rcMain_r);
	rcMain_r.OffsetRect(rcMain_l.right+1, 0);
	m_wndOpenGLMainRight.Create(NULL,
						NULL,
						WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE,						       
						rcMain_r,  
						this,  
						0);    
	m_wndOpenGLMainRight.SetRender((COpenGLRenderer*)m_pHandRendererRight);	
	m_wndOpenGLMainRight.Invalidate(1);
	::SetFocus(m_wndOpenGLMainRight.m_hWnd);

	//captured
	CRect rcCap;
	::GetClientRect(GetDlgItem(IDC_STATIC_CAP)->m_hWnd, rcCap);
	rcCap.OffsetRect(rcMain_r.left, rcMain_r.bottom+15);
	
	m_wndOpenGLCap.Create(NULL,
						NULL,
						WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE,						       
						rcCap,  
						this,  
						0);    
	m_wndOpenGLCap.SetRender((COpenGLRenderer*)m_pHandRendererCap);
	m_wndOpenGLCap.Invalidate(1);
	::BringWindowToTop(m_wndOpenGLCap.m_hWnd);

	//real
	CRect rcReal;
	::GetClientRect(GetDlgItem(IDC_STATIC_REAL)->m_hWnd, rcReal);	
	rcReal.OffsetRect(rcCap.right+1, rcCap.top);
	m_wndOpenGLReal.Create(NULL,
						NULL,
						WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE,						       
						rcReal,  
						this,  
						0);    
	m_wndOpenGLReal.SetRender((COpenGLRenderer*)m_pHandRendererReal);
	m_wndOpenGLReal.Invalidate(1);
	::BringWindowToTop(m_wndOpenGLReal.m_hWnd);
	
	return TRUE;
}
void CGloveCalibDlg::InitGainAndOffsetUI()
{
	m_arGainEdit.clear();
	m_arOffsetEdit.clear();
	m_arInfoStatic.clear();

	for(int i = 0; i < 20; ++i)
	{
		m_arGainEdit.push_back((CEdit*)GetDlgItem(IDC_EDIT_THUMB_TMJ_G + i));
		m_arOffsetEdit.push_back((CEdit*)GetDlgItem(IDC_EDIT_THUMB_TMJ_O + i));
		m_arInfoStatic.push_back((CStatic*)GetDlgItem(IDC_STATIC_THUMB_TMJ + i));
	}
}
void CGloveCalibDlg::OnBnClickedConnect()
{
	m_pGlvMgrLeft->Connect();
	m_pGlvMgrRight->Connect();
	SetTimer(TIMER_EVENT_ID3, 100, NULL);
}

void CGloveCalibDlg::OnBnClickedBtnDisconnect()
{
	KillTimer(TIMER_EVENT_ID3);
}

void CGloveCalibDlg::OnBnClickedRadioRighthand()
{
	CButton* pRadio = (CButton*)GetDlgItem(IDC_RADIO_RIGHTHAND);
	if(pRadio->GetCheck() != 0)
	{
		m_eAdjustHandness = RIGHT_HAND;
		::SetFocus(m_wndOpenGLMainRight.m_hWnd);

		m_pHandRendererCap->m_pHand->InitMotionRight();
		m_pHandRendererCap->m_pHand->m_bRightHand = true;
		m_wndOpenGLCap.Invalidate(1);

		m_pHandRendererReal->m_pHand->InitMotionRight();
		m_pHandRendererReal->m_pHand->m_bRightHand = true;
		m_wndOpenGLReal.Invalidate(1);

		m_pGlvCalib = m_pGlvMgrRight->m_pCalib;
		UpdateEditsFromCalibration();
	}
}

void CGloveCalibDlg::OnBnClickedRadioLefthand()
{
	CButton* pRadio = (CButton*)GetDlgItem(IDC_RADIO_LEFTHAND);
	if(pRadio->GetCheck() != 0)
	{
		m_eAdjustHandness = LEFT_HAND;
		::SetFocus(m_wndOpenGLMainLeft.m_hWnd);

		m_pHandRendererCap->m_pHand->InitMotionLeft();
		m_pHandRendererCap->m_pHand->m_bRightHand = false;
		m_wndOpenGLCap.Invalidate(1);

		m_pHandRendererReal->m_pHand->InitMotionLeft();
		m_pHandRendererReal->m_pHand->m_bRightHand = false;
		m_wndOpenGLReal.Invalidate(1);

		m_pGlvCalib = m_pGlvMgrLeft->m_pCalib;
		UpdateEditsFromCalibration();
	}
}

void CGloveCalibDlg::OnTimer(UINT_PTR nIDEvent)
{
	if(nIDEvent != TIMER_EVENT_ID3)
		return;

	std::vector<float> arDataLeft;
	std::vector<float> arDataRight;
	CRawFrame frmRaw_l, frmRaw_r, frmCalibrated_l, frmCalibrated_r;
	CGlvFrame frmGlv_l, frmGlv_r;
	switch(m_eCalibMode)
	{
	case E_CALIB_MODE::e_uncalibrated_raw:
		arDataLeft = m_pGlvMgrLeft->RetrieveSensorData();
		frmGlv_l = GloveUtil::GloveDataToFrame(arDataLeft);
		m_pHandRendererLeft->m_pHand->UpdateFromSensorData(frmGlv_l.m_arData);

		arDataRight = m_pGlvMgrRight->RetrieveSensorData();
		frmGlv_r = GloveUtil::GloveDataToFrame(arDataRight);
		m_pHandRendererRight->m_pHand->UpdateFromSensorData(frmGlv_r.m_arData);
		break;	
	case E_CALIB_MODE::e_linear_calib_matlab:
		arDataLeft = m_pGlvMgrLeft->RetrieveSensorData();
		frmGlv_l = GloveUtil::GloveDataToFrame(arDataLeft);
		frmRaw_l = GloveUtil::GlvToRaw(frmGlv_l, true);
		frmCalibrated_l = MatlabUtil::GPRCalibrate_linear(frmRaw_l, true);
		m_pHandRendererLeft->m_pHand->UpdateFromKinematicData(frmCalibrated_l.m_arData);

		arDataRight = m_pGlvMgrRight->RetrieveSensorData();
		frmGlv_r = GloveUtil::GloveDataToFrame(arDataRight);
		frmRaw_r = GloveUtil::GlvToRaw(frmGlv_r, false);
		frmCalibrated_r = MatlabUtil::GPRCalibrate_linear(frmRaw_r, false);
		m_pHandRendererRight->m_pHand->UpdateFromKinematicData(frmCalibrated_r.m_arData);
		break;
		
	case E_CALIB_MODE::e_gpr_calib_fitc_matlab:
		arDataLeft = m_pGlvMgrLeft->RetrieveSensorData();
		frmGlv_l = GloveUtil::GloveDataToFrame(arDataLeft);
		frmRaw_l = GloveUtil::GlvToRaw(frmGlv_l, true);
		frmCalibrated_l = MatlabUtil::GPRCalibrate_FK_fitc(frmRaw_l, true);
		m_pHandRendererLeft->m_pHand->UpdateFromKinematicData(frmCalibrated_l.m_arData);

		arDataRight = m_pGlvMgrRight->RetrieveSensorData();
		frmGlv_r = GloveUtil::GloveDataToFrame(arDataRight);
		frmRaw_r = GloveUtil::GlvToRaw(frmGlv_r, false);
		frmCalibrated_r = MatlabUtil::GPRCalibrate_FK_fitc(frmRaw_r, false);
		m_pHandRendererRight->m_pHand->UpdateFromKinematicData(frmCalibrated_r.m_arData);
		break;
	case E_CALIB_MODE::e_linear_calib_vc:
	default:
		arDataLeft = m_pGlvMgrLeft->RetrieveAdjustedDataLinear();
		frmGlv_l = GloveUtil::GloveDataToFrame(arDataLeft);
		m_pHandRendererLeft->m_pHand->UpdateFromSensorData(frmGlv_l.m_arData);

		arDataRight = m_pGlvMgrRight->RetrieveAdjustedDataLinear();
		frmGlv_r = GloveUtil::GloveDataToFrame(arDataRight);
		m_pHandRendererRight->m_pHand->UpdateFromSensorData(frmGlv_r.m_arData);
		break;
	}
	m_wndOpenGLMainLeft.OnDraw(NULL);
	m_wndOpenGLMainRight.OnDraw(NULL);

	CString strData = L"";
	if(m_eAdjustHandness == LEFT_HAND)
	{
		if(m_bShowRadian)
			strData = GloveUtil::GloveDataToStringRadian(arDataLeft);
		else
			strData = GloveUtil::GloveDataToStringDegree(arDataLeft);
	}
	else 
	{
		if(m_bShowRadian)
			strData = GloveUtil::GloveDataToStringRadian(arDataRight);
		else
			strData = GloveUtil::GloveDataToStringDegree(arDataRight);
	}
	GetDlgItem(IDC_EDIT_GLOVEDATA)->SetWindowText(strData);
}

void CGloveCalibDlg::OnBnClickedButtonReset()
{
	m_pGlvCalib->InitAdjustCalibration();
	UpdateEditsFromCalibration();
}

void CGloveCalibDlg::OnBnClickedButtonCap1()
{
	std::vector<float> arData;
	if(m_eAdjustHandness == LEFT_HAND)
		arData = m_pGlvMgrLeft->RetrieveAdjustedDataLinear();
	else
		arData = m_pGlvMgrRight->RetrieveAdjustedDataLinear();
	
	m_frmCap1 = GloveUtil::GloveDataToFrame(arData);
	m_pHandRendererCap->m_pHand->UpdateFromSensorData(m_frmCap1.m_arData);
	m_wndOpenGLCap.OnDraw(NULL);
}

void CGloveCalibDlg::OnBnClickedButtonReal1()
{
	CFileDialog dlgFile(TRUE, L"Glove Frame File(*.gfm)|*.gfm", NULL, 4|2, L"Glove Frame File(*.gfm)|*.gfm||");
	if(IDOK == dlgFile.DoModal())
	{
		m_frmReal1.LoadFromFileAngle(GloveUtil::ToChar(dlgFile.GetFileName()));		
		m_pHandRendererReal->m_pHand->UpdateFromSensorData(m_frmReal1.m_arData);
		m_wndOpenGLReal.OnDraw(NULL);
	}
}

void CGloveCalibDlg::OnBnClickedButtonCap2()
{
	std::vector<float> arData;
	if(m_eAdjustHandness == LEFT_HAND)
		arData = m_pGlvMgrLeft->RetrieveAdjustedDataLinear();
	else
		arData = m_pGlvMgrRight->RetrieveAdjustedDataLinear();

	m_frmCap2 = GloveUtil::GloveDataToFrame(arData);	
	m_pHandRendererCap->m_pHand->UpdateFromSensorData(m_frmCap2.m_arData);
	m_wndOpenGLCap.OnDraw(NULL);
}

void CGloveCalibDlg::OnBnClickedButtonReal2()
{
	CFileDialog dlgFile(TRUE, L"Glove Frame File(*.gfm)|*.gfm", NULL, 4|2, L"Glove Frame File(*.gfm)|*.gfm||");
	if(IDOK == dlgFile.DoModal())
	{
		m_frmReal2.LoadFromFileAngle(GloveUtil::ToChar(dlgFile.GetFileName()));				
		m_pHandRendererReal->m_pHand->UpdateFromSensorData(m_frmReal2.m_arData);
		m_wndOpenGLReal.OnDraw(NULL);
	}
}

void CGloveCalibDlg::OnBnClickedButtonAutocalib()
{
	CGloveCalibration calibration = GloveUtil::AutoCalibrate(*m_pGlvCalib, m_frmCap1, m_frmReal1, m_frmCap2, m_frmReal2);
	WriteCalibrationToMgr(calibration);
	UpdateEditsFromCalibration();
}


void CGloveCalibDlg::OnEnChangeEditThumbTmjG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_THUMB_TMJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_THUMB_TMJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditThumbTmjO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_THUMB_TMJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_THUMB_TMJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditThumbMpjG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_THUMB_MPJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_THUMB_MPJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditThumbMpjO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_THUMB_MPJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_THUMB_MPJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditThumbIjG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_THUMB_IJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_THUMB_IJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditThumbIjO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_THUMB_IJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_THUMB_IJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditThumbAbdG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_THUMB_ABD_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_THUMB_ABD_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditThumbAbdO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_THUMB_ABD_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_THUMB_ABD_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditIndexMpjG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_INDEX_MPJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_INDEX_MPJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditIndexMpjO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_INDEX_MPJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_INDEX_MPJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditIndexPijG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_INDEX_PIJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_INDEX_PIJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditIndexPijO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_INDEX_PIJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_INDEX_PIJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditIndexDijG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_INDEX_DIJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_INDEX_DIJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditIndexDijO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_INDEX_DIJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_INDEX_DIJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditIndexAbdG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_INDEX_ABD_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_INDEX_ABD_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditIndexAbdO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_INDEX_ABD_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_INDEX_ABD_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditMiddleMpjG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_MIDDLE_MPJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_MIDDLE_MPJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditMiddleMpjO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_MIDDLE_MPJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_MIDDLE_MPJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditMiddlePijG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_MIDDLE_PIJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_MIDDLE_PIJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditMiddlePijO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_MIDDLE_PIJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_MIDDLE_PIJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditMiddleDijG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_MIDDLE_DIJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_MIDDLE_DIJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditMiddleDijO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_MIDDLE_DIJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_MIDDLE_DIJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditMiddleAbdG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_MIDDLE_ABD_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_MIDDLE_ABD_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditMiddleAbdO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_MIDDLE_ABD_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_MIDDLE_ABD_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditRingMpjG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_RING_MPJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_RING_MPJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditRingMpjO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_RING_MPJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_RING_MPJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditRingPijG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_RING_PIJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_RING_PIJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditRingPijO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_RING_PIJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_RING_PIJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditRingDijG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_RING_DIJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_RING_DIJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditRingDijO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_RING_DIJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_RING_DIJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditRingAbdG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_RING_ABD_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_RING_ABD_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditRingAbdO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_RING_ABD_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_RING_ABD_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditPinkyMpjG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PINKY_MPJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PINKY_MPJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditPinkyMpjO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PINKY_MPJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PINKY_MPJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditPinkyPijG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PINKY_PIJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PINKY_PIJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditPinkyPijO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PINKY_PIJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PINKY_PIJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditPinkyDijG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PINKY_DIJ_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PINKY_DIJ_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditPinkyDijO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PINKY_DIJ_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PINKY_DIJ_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditPinkyAbdG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PINKY_ABD_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PINKY_ABD_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditPinkyAbdO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PINKY_ABD_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PINKY_ABD_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditPalmArcG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PALM_ARC_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PALM_ARC_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditPalmArcO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PALM_ARC_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PALM_ARC_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditPalmFlexG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PALM_FLEX_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PALM_FLEX_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditPalmFlexO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PALM_FLEX_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PALM_FLEX_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}

void CGloveCalibDlg::OnEnChangeEditPalmAbdG()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PALM_ABD_G)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PALM_ABD_G - IDC_EDIT_THUMB_TMJ_G, strValue, true);
}

void CGloveCalibDlg::OnEnChangeEditPalmAbdO()
{
	CString strValue;
	GetDlgItem(IDC_EDIT_PALM_ABD_O)->GetWindowText(strValue);
	UpdateCalibrationFromEdits(IDC_EDIT_PALM_ABD_O - IDC_EDIT_THUMB_TMJ_O, strValue, false);
}


void CGloveCalibDlg::OnStnClickedStaticMainLeft()
{
	::SetFocus(m_wndOpenGLMainLeft.m_hWnd);
}

void CGloveCalibDlg::OnStnClickedStaticMainRight()
{
	::SetFocus(m_wndOpenGLMainRight.m_hWnd);
}

void CGloveCalibDlg::OnStnClickedStaticCap()
{
	::SetFocus(m_wndOpenGLCap.m_hWnd);
}

void CGloveCalibDlg::OnStnClickedStaticReal()
{
	::SetFocus(m_wndOpenGLReal.m_hWnd);
}

void CGloveCalibDlg::OnBnClickedButtonLoadCalib()
{
	CFileDialog dlgFile(TRUE, L"Glove Calibration File(*.gcb)|*.gcb", NULL, 4|2, L"Glove Calibration File(*.gcb)|*.gcb||");
	if(IDOK == dlgFile.DoModal())
	{
		char* pPath = GloveUtil::ToChar(dlgFile.GetPathName());
		m_pGlvCalib->LoadFromFile(pPath);
		//write base
		if(m_pGlvMgrLeft)
			m_pGlvMgrLeft->WriteBaseCalibration();
		if(m_pGlvMgrRight)
			m_pGlvMgrRight->WriteBaseCalibration();

		delete pPath;
		UpdateEditsFromCalibration();
	}
}

void CGloveCalibDlg::OnBnClickedButtonSaveCalib()
{
	CFileDialog dlgFile(FALSE, L"Glove Calibration File(*.gcb)|*.gcb", L"", 4|2, L"Glove Calibration File(*.gcb)|*.gcb||");
	if(IDOK == dlgFile.DoModal())
	{
		char* pPath = GloveUtil::ToChar(dlgFile.GetPathName());
		m_pGlvCalib->SaveToFile(pPath);
		delete pPath;
	}
}
void CGloveCalibDlg::OnBnClickedButtonLinearHp2Tr()
{
	CButton* pRadio = (CButton*)GetDlgItem(IDC_RADIO_LEFTHAND);
	bool bLeft = pRadio->GetCheck() == true;
	m_pGlvCalib->WriteToTrHp("", bLeft);
}

void CGloveCalibDlg::OnBnClickedButtonLoadHandsize()
{
	CFileDialog dlgFile(TRUE, L"Glove Handsize File(*.gsz)|*.gsz", NULL, 4|2, L"Glove Handsize File(*.gsz)|*.gsz||");
	if(IDOK == dlgFile.DoModal())
	{
		if(m_eAdjustHandness == LEFT_HAND)
		{
			m_pHandRendererLeft->m_pHand->LoadSizeFromFile(dlgFile.GetPathName());
			m_wndOpenGLMainLeft.OnDraw(NULL);
		}
		else
		{
			m_pHandRendererRight->m_pHand->LoadSizeFromFile(dlgFile.GetPathName());
			m_wndOpenGLMainRight.OnDraw(NULL);
		}
		m_wndOpenGLCap.OnDraw(NULL);
		m_wndOpenGLReal.OnDraw(NULL);
	}
}

void CGloveCalibDlg::OnBnClickedButtonSaveHandsize()
{
	CFileDialog dlgFile(FALSE, L"Glove Handsize File(*.gsz)|*.gsz", L"", 4|2, L"Glove Handsize File(*.gsz)|*.gsz||");
	if(IDOK == dlgFile.DoModal())
	{
		if(m_eAdjustHandness == LEFT_HAND)
			m_pHandRendererLeft->m_pHand->SaveSizeToFile(dlgFile.GetPathName());
		else
			m_pHandRendererRight->m_pHand->SaveSizeToFile(dlgFile.GetPathName());
	}
}
void CGloveCalibDlg::OnBnClickedRadioRadian()
{
	CButton* pBtn = (CButton*)GetDlgItem(IDC_RADIO_RADIAN);
	if(pBtn->GetCheck() != 0)
		m_bShowRadian = true;
	else
		m_bShowRadian = false;
}

void CGloveCalibDlg::OnBnClickedRadioDegree()
{
	CButton* pBtn = (CButton*)GetDlgItem(IDC_RADIO_DEGREE);
	if(pBtn->GetCheck() != 0)
		m_bShowRadian = false;
	else
		m_bShowRadian = true;
}
#include "CKinematic\IKSolverDlg.h"
void CGloveCalibDlg::OnBnClickedButtonKinProp()
{	
	CKinematicHand* pHand = NULL;
	if(m_eAdjustHandness == LEFT_HAND) 
		pHand = m_pHandLeft->m_pHand;
	else 
		pHand = m_pHandRight->m_pHand;
	CIKSolverDlg2 dlg(pHand);
	dlg.DoModal();
	Invalidate(1);
}


void CGloveCalibDlg::OnBnClickedRadioUncalibRaw()
{
	m_eCalibMode = E_CALIB_MODE::e_uncalibrated_raw;
}

void CGloveCalibDlg::OnBnClickedRadioLinearCalibVc()
{
	m_eCalibMode = E_CALIB_MODE::e_linear_calib_vc;
}

void CGloveCalibDlg::OnBnClickedRadioLinearCalibMatlab()
{
	m_eCalibMode = E_CALIB_MODE::e_linear_calib_matlab;
}

void CGloveCalibDlg::OnBnClickedRadioGprCalibFitcMatlab2()
{
	m_eCalibMode = E_CALIB_MODE::e_gpr_calib_fitc_matlab;
}
