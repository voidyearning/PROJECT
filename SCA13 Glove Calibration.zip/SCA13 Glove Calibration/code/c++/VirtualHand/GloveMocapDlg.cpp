// GloveMocapDlg.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "GloveMocapDlg.h"
#include "GloveUtil.h"


// CGloveMocapDlg dialog

IMPLEMENT_DYNAMIC(CGloveMocapDlg, CDialog)

CGloveMocapDlg::CGloveMocapDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGloveMocapDlg::IDD, pParent)
{

}

CGloveMocapDlg::~CGloveMocapDlg()
{
}

void CGloveMocapDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CGloveMocapDlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_BRW, &CGloveMocapDlg::OnBnClickedBtnBrw)
	ON_CBN_SELCHANGE(IDC_COMBO_FREQ, &CGloveMocapDlg::OnCbnSelchangeComboFreq)
	ON_CBN_SELCHANGE(IDC_COMBO_FILER, &CGloveMocapDlg::OnCbnSelchangeComboFiler)
	ON_BN_CLICKED(IDC_BTN_START, &CGloveMocapDlg::OnBnClickedBtnStart)
	ON_BN_CLICKED(IDC_BTN_STOP, &CGloveMocapDlg::OnBnClickedBtnStop)
	ON_WM_TIMER()
	ON_EN_CHANGE(IDC_EDIT_FILE, &CGloveMocapDlg::OnEnChangeEditFile)
	ON_EN_CHANGE(IDC_EDIT_NAME, &CGloveMocapDlg::OnEnChangeEditName)
	ON_BN_CLICKED(IDC_RADIO_LEFT, &CGloveMocapDlg::OnBnClickedRadioLeft)
	ON_BN_CLICKED(IDC_RADIO_RIGHT, &CGloveMocapDlg::OnBnClickedRadioRight)
	ON_BN_CLICKED(IDC_RADIO_BOTH, &CGloveMocapDlg::OnBnClickedRadioBoth)
	ON_BN_CLICKED(IDC_BUTTON_RECORD_POSE, &CGloveMocapDlg::OnBnClickedButtonRecordPose)
	ON_BN_CLICKED(IDC_BUTTON_STANDARD_DATA, &CGloveMocapDlg::OnBnClickedButtonStandardData)
	ON_BN_CLICKED(IDC_BUTTON_DETECT_STATIC_GAP, &CGloveMocapDlg::OnBnClickedButtonDetectStaticGap)
	ON_BN_CLICKED(IDC_BUTTON_TO_DATA, &CGloveMocapDlg::OnBnClickedButtonToData)
END_MESSAGE_MAP()

BOOL CGloveMocapDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	Init();	
	return TRUE;  // return TRUE  unless you set the focus to a control
}
void CGloveMocapDlg::Init()
{
	m_pGlvMgrLeft = CGloveMocapMgr::GetGloveMgr(LEFT_HAND);
	m_pGlvMgrRight = CGloveMocapMgr::GetGloveMgr(RIGHT_HAND);

	CRect rcWokao, rcParent;
	GetDlgItem(IDC_STATIC_WOKAO_RECT)->GetWindowRect(rcWokao);
	GetWindowRect(rcParent);
	rcWokao.MoveToXY(rcWokao.left-rcParent.left, rcWokao.top-rcParent.top);
	m_pWokao = new CWokaoWnd(this);
	m_pWokao->Create(IDD_DIALOG_WOKAO, this);//Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rcWokao, this, 0);
	m_pWokao->MoveWindow(rcWokao.left, rcWokao.top, rcWokao.Width(), rcWokao.Height());
	//m_pWokao->ShowWindow(1);
	//m_pWokao->SetWindowPos(NULL, rcWokao.left, rcWokao.top, rcWokao.Width(), rcWokao.Height(), NULL);
	
	m_eMocapFreq = GLV_MOCAP_FREQ::FREQ_30;
	CComboBox* pComboFreq = (CComboBox*)GetDlgItem(IDC_COMBO_FREQ);
	if(pComboFreq)
	{
		pComboFreq->AddString(L"30");
		pComboFreq->AddString(L"45");		
		pComboFreq->AddString(L"60");		
		pComboFreq->AddString(L"90");		
		pComboFreq->AddString(L"120");
		pComboFreq->AddString(L"others");
		pComboFreq->SelectString(0, L"30");
	}

	m_eMocapFile = GLV_MOCAP_FILE::FILE_TXT;
	CComboBox* pComboFiler = (CComboBox*)GetDlgItem(IDC_COMBO_FILER);
	if(pComboFiler)
	{
		pComboFiler->AddString(L"txt");
		pComboFiler->AddString(L"xml");
		pComboFiler->AddString(L"others");
		pComboFiler->SelectString(0, L"txt");
	}

	m_eMocapHandness = GLV_MOCAP_HANDNESS::BOTH_HANDS;
	CButton* pRadio = (CButton*)GetDlgItem(IDC_RADIO_LEFT);
	if(pRadio)
		pRadio->SetCheck(0);
	pRadio = (CButton*)GetDlgItem(IDC_RADIO_RIGHT);
	if(pRadio)
		pRadio->SetCheck(0);
	pRadio = (CButton*)GetDlgItem(IDC_RADIO_BOTH);
	if(pRadio)
		pRadio->SetCheck(1);

	CString strFile = L"";
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FILE);
	if(pEdit)
	{
		TCHAR arDir[256] = L"\0";
		int iLenDir = ::GetCurrentDirectory(256, arDir);
		strFile = CString(arDir, iLenDir);
		pEdit->SetWindowText(strFile);
	}

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_NAME);
	if(pEdit)
		pEdit->SetWindowText(L"glvCap");
	
	strFile += L"\\glvCap.glv";
	SetPath(strFile);

	GetDlgItem(IDC_BTN_STOP)->EnableWindow(FALSE);
}
CString CGloveMocapDlg::UpdatePath()
{
	CString strDir = L"";
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FILE);
	if(pEdit)
		pEdit->GetWindowText(strDir);

	strDir.Trim();

	CString strName = L"";
	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_NAME);
	if(pEdit)
		pEdit->GetWindowText(strName);
	
	CString strFile = strDir + L"\\" + strName + L".glv";
	SetPath(strFile);

	return strFile;
}
void CGloveMocapDlg::SetPath(CString strName)
{
	int idxPath = strName.Find(_T(".glv"));
	CString strPath = strName.Mid(0, idxPath);
    CString strName_l = strPath + L"_l.glv";
	CString strName_r = strPath + L"_r.glv";

	std::string strPath_l;
	wchar_t* wText_l = strName_l.GetBuffer(0);
	DWORD dwNum_l = WideCharToMultiByte(CP_OEMCP,NULL,wText_l,-1,NULL,0,NULL,FALSE);
	char *psText_l;
	psText_l = new char[dwNum_l];
	WideCharToMultiByte (CP_OEMCP,NULL,wText_l,-1,psText_l,dwNum_l,NULL,FALSE);
	strPath_l = psText_l;
	delete []psText_l;
	m_pGlvMgrLeft->SetName(strPath_l);

	std::string strPath_r;
	wchar_t* wText_r = strName_r.GetBuffer(0);
	DWORD dwNum_r = WideCharToMultiByte(CP_OEMCP,NULL,wText_r,-1,NULL,0,NULL,FALSE);
	char *psText_r;
	psText_r = new char[dwNum_r];
	WideCharToMultiByte (CP_OEMCP,NULL,wText_r,-1,psText_r,dwNum_r,NULL,FALSE);
	strPath_r = psText_r;
	delete []psText_r;
	m_pGlvMgrRight->SetName(strPath_r);
}

#include "stdio.h"
void CGloveMocapDlg::OnBnClickedBtnBrw()
{
	CString strPath = L"";
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FILE);
	if(pEdit)
		pEdit->GetWindowText(strPath);

	strPath = GloveUtil::ShowFolderDlg(L"Home directory of captured glove data");
	pEdit->SetWindowText(strPath);
	UpdatePath();
}

void CGloveMocapDlg::OnCbnSelchangeComboFreq()
{
	CComboBox* pComboFreq = (CComboBox*)GetDlgItem(IDC_COMBO_FREQ);
	if(!pComboFreq)
		return;
	m_eMocapFreq = (GLV_MOCAP_FREQ)pComboFreq->GetCurSel();
}

void CGloveMocapDlg::OnCbnSelchangeComboFiler()
{
	CComboBox* pComboFile = (CComboBox*)GetDlgItem(IDC_COMBO_FILER);
	if(!pComboFile)
		return;
	m_eMocapFile = (GLV_MOCAP_FILE)pComboFile ->GetCurSel();
}

void CGloveMocapDlg::OnBnClickedBtnStart()
{
	GetDlgItem(IDC_BTN_START)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_STOP)->EnableWindow(TRUE);
	
	switch(m_eMocapHandness)
	{
	case GLV_MOCAP_HANDNESS::LEFT_HAND:
		if(!m_pGlvMgrLeft->IsConnected())
			m_pGlvMgrLeft->Connect();
		break;
	case GLV_MOCAP_HANDNESS::RIGHT_HAND:
		if(!m_pGlvMgrRight->IsConnected())
			m_pGlvMgrRight->Connect();
		break;
	case GLV_MOCAP_HANDNESS::BOTH_HANDS:
		if(!m_pGlvMgrLeft->IsConnected())
			m_pGlvMgrLeft->Connect();
		if(!m_pGlvMgrRight->IsConnected())
			m_pGlvMgrRight->Connect();
	}
	
	SetTimer(TIMER_EVENT_ID, GetTimerInterval(TIMER_EVENT_ID), NULL);
}

void CGloveMocapDlg::OnBnClickedBtnStop()
{
	GetDlgItem(IDC_BTN_START)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_STOP)->EnableWindow(FALSE);

	if(m_eMocapFreq != GLV_MOCAP_FREQ::FREQ_OTHERS)
		KillTimer(TIMER_EVENT_ID);

	string strMsg = "";
	switch(m_eMocapHandness)
	{
	case GLV_MOCAP_HANDNESS::LEFT_HAND:
		strMsg = m_pGlvMgrLeft->EndRecord();
		break;
	case GLV_MOCAP_HANDNESS::RIGHT_HAND:
		strMsg = m_pGlvMgrRight->EndRecord();
		break;
	case GLV_MOCAP_HANDNESS::BOTH_HANDS:
		strMsg = m_pGlvMgrRight->EndRecord();
		strMsg += m_pGlvMgrLeft->EndRecord();
	}
	CString strMsg2(strMsg.c_str());
	GetDlgItem(IDC_STATIC_MSG)->SetWindowText(strMsg2);
}

void CGloveMocapDlg::OnTimer(UINT_PTR nIDEvent)
{
	switch(m_eMocapHandness)
	{
	case GLV_MOCAP_HANDNESS::LEFT_HAND:
		m_pGlvMgrLeft->RecordData();
		break;
	case GLV_MOCAP_HANDNESS::RIGHT_HAND:
		m_pGlvMgrRight->RecordData();
		break;
	case GLV_MOCAP_HANDNESS::BOTH_HANDS:
		m_pGlvMgrLeft->RecordData();
		m_pGlvMgrRight->RecordData();
	}
	CDialog::OnTimer(nIDEvent);
}

int CGloveMocapDlg::GetTimerInterval(UINT_PTR nIDEvent)
{
	if(nIDEvent == TIMER_EVENT_ID)
	{
		int iFreq = 30;
		switch(m_eMocapFreq)
		{
		case GLV_MOCAP_FREQ::FREQ_30: 
			iFreq = 30;
			break;
		case GLV_MOCAP_FREQ::FREQ_45:
			iFreq = 45;
			break;
		case GLV_MOCAP_FREQ::FREQ_60:
			iFreq = 60;
			break;
		case GLV_MOCAP_FREQ::FREQ_90:
			iFreq = 90;
			break;
		case GLV_MOCAP_FREQ::FREQ_120:
			iFreq = 120;
			break;
		default:
			iFreq = 30;
		}
		return iFreq;
	}
	return 30;
}

void CGloveMocapDlg::OnEnChangeEditFile()
{
	UpdatePath();
}


void CGloveMocapDlg::OnEnChangeEditName()
{
	UpdatePath();
}

void CGloveMocapDlg::OnBnClickedRadioLeft()
{
	m_eMocapHandness = GLV_MOCAP_HANDNESS::LEFT_HAND;
}

void CGloveMocapDlg::OnBnClickedRadioRight()
{
	m_eMocapHandness = GLV_MOCAP_HANDNESS::RIGHT_HAND;
}

void CGloveMocapDlg::OnBnClickedRadioBoth()
{
	m_eMocapHandness = GLV_MOCAP_HANDNESS::BOTH_HANDS;
}

void CGloveMocapDlg::OnBnClickedButtonRecordPose()
{
	switch(m_eMocapHandness)
	{
	case GLV_MOCAP_HANDNESS::LEFT_HAND:
		if(!m_pGlvMgrLeft->IsConnected()) m_pGlvMgrLeft->Connect();		
		m_pGlvMgrLeft->RecordData();
		break;
	case GLV_MOCAP_HANDNESS::RIGHT_HAND:
		if(!m_pGlvMgrRight->IsConnected()) m_pGlvMgrRight->Connect();		
		m_pGlvMgrRight->RecordData();
		break;
	case GLV_MOCAP_HANDNESS::BOTH_HANDS:
		if(!m_pGlvMgrLeft->IsConnected()) m_pGlvMgrLeft->Connect();
		if(!m_pGlvMgrRight->IsConnected()) m_pGlvMgrRight->Connect();
		m_pGlvMgrLeft->RecordData();
		m_pGlvMgrRight->RecordData();
	}
}

void CGloveMocapDlg::OnBnClickedButtonStandardData()
{
	switch(m_eMocapHandness)
	{
	case GLV_MOCAP_HANDNESS::LEFT_HAND:
		if(!m_pGlvMgrLeft->IsConnected()) m_pGlvMgrLeft->Connect();		
		m_pGlvMgrLeft->WriteStandardBaseCalibration();
		break;
	case GLV_MOCAP_HANDNESS::RIGHT_HAND:
		if(!m_pGlvMgrRight->IsConnected()) m_pGlvMgrRight->Connect();		
		m_pGlvMgrRight->WriteStandardBaseCalibration();
		break;
	case GLV_MOCAP_HANDNESS::BOTH_HANDS:
		if(!m_pGlvMgrLeft->IsConnected()) m_pGlvMgrLeft->Connect();
		if(!m_pGlvMgrRight->IsConnected()) m_pGlvMgrRight->Connect();
		m_pGlvMgrLeft->WriteStandardBaseCalibration();
		m_pGlvMgrRight->WriteStandardBaseCalibration();
	}
}


void CGloveMocapDlg::OnBnClickedButtonDetectStaticGap()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv||");
	if(IDOK == dlgFile.DoModal())
	{
		CBaseClip* pClip = NULL;
		CString strFile = dlgFile.GetFileName();
		if(strFile.Find(L".glv")!=-1)
			pClip = new CGlvClip();
		else
			pClip = new CRawClip();

		pClip->LoadFromFile(GloveUtil::ToChar(strFile));
		STATIC_GAPS gaps = pClip->FindUnchaningData();

		CString strGaps = L"Static Gap: (begFrame, endFrame, length);\r\n";
		for(int i = 0; i < gaps.size(); ++i)
		{
			STATIC_GAP oneGap = gaps[i];
			char buffer[30];
			sprintf(buffer, "(%d, %d, %d)\r\n", oneGap.first, oneGap.second, oneGap.second - oneGap.first /*,(oneGap.first + 1)* 4, (oneGap.second + 1)* 4*/);
			CString strOneGap(buffer);
			strGaps = strGaps + strOneGap;
		}
		::MessageBox(NULL, strGaps, strFile, MB_OK);
	}
}

void CGloveMocapDlg::OnBnClickedButtonToData()
{
	CFileDialog dlgFile(TRUE, L"Glove Capture File(*.glv)|*.glv", NULL, 4|2, L"Glove Capture File(*.glv)|*.glv||");
	if(IDOK == dlgFile.DoModal())
	{	
		std::string strPathOriginal = GloveUtil::ToChar(dlgFile.GetFileName());
		CGlvClip clipGlv;
		clipGlv.LoadFromFile(strPathOriginal);
		clipGlv.ToGlvData(strPathOriginal.append(".data"));
	}
}
