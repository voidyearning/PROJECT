#pragma once
#include <vector>
#include <string>
#include "BaseAnimation.h"
#include "CKinematic\CKinematicChain.h"
#include "GloveSkeleton.h"

class CPtTrajFrame: public CBaseFrame
{
public:
	CPtTrajFrame();
	CPtTrajFrame(CKinematicPoint pos);
	CPtTrajFrame(const CPtTrajFrame& frame);
	CKinematicPoint m_pos;
	float m_fWristAbd;
	float m_fWristFlex;
};

class CPtTrajClip: public CBaseClip
{
public:
	CPtTrajClip();
	CPtTrajClip(CHandSkeletonKin* pHand);
	CPtTrajClip(const CPtTrajClip&);
	std::vector<CPtTrajFrame> m_arFrame;	
	CHandSkeletonKin* m_pHand;
	int m_iBegIdx;
	int m_iEndIdx;

	void SaveToFile(std::string strPath);
	void LoadFromFile(std::string strPath);
	int GetFrameCount();
	CBaseFrame* GetFrameAt(int iFrmIdx);	
	virtual void SetFrameAt(int iFrmIdx, CBaseFrame*);

	void PopulateEndEffectorTrajClip(int iChainIdx, CBaseClip* pMotionClip, int iBegIdx, int iEndIdx);
	void PopulateActiveCOMTrajClip(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx);
	void PopulateActiveMaxProbTrajClip_traverse(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx);
	void PopulateActiveMaxProbTrajClip_approx(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx);
	
	std::vector<CPtTrajClip> GetActiveEndEffectorTrajClip(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx);
	CPtTrajClip GetActiveMaxProbTrajClip_traverse(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx);
	CPtTrajClip GetActiveMaxProbTrajClip_approx(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx);
	CPtTrajClip GetActiveCOMTrajClip(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx);

};