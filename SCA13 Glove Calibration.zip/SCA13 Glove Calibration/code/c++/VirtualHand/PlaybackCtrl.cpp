// PlaybackCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "PlaybackCtrl.h"
#include "GloveAnimation.h"
#include "RawAnimation.h"
#include "GloveUtil.h"
#include "GloveMocapMgr.h"
#include "OneHandCtrl.h"

#define	TIMER_EVENT_PLAYBACK_FILE 16
#define TIMER_EVENT_PLAYBACK_REALTIME 17

// CPlaybackCtrl dialog

IMPLEMENT_DYNAMIC(CPlaybackCtrl, CDialog)

CPlaybackCtrl::CPlaybackCtrl(bool bLeft, CWnd* pParent /*=NULL*/)
	: CDialog(CPlaybackCtrl::IDD, pParent)
{	
	m_bLeft = bLeft;
	m_pClipRaw = new CRawClip();
	m_iCurIdx = 0;
	COpenGLHandRendererKin* pHandRenderer = new COpenGLHandRendererKin(new CHandSkeletonKin(!bLeft));
	m_wndOpenGL.m_pRenderer = (COpenGLRenderer*)pHandRenderer;
	pHandRenderer->m_pHand->UpdateToKinematicData(m_frmRaw.m_arData);
	if(m_bLeft)
		m_pGlvMgr = CGloveMocapMgr::GetGloveMgr(LEFT_HAND);
	else
		m_pGlvMgr = CGloveMocapMgr::GetGloveMgr(RIGHT_HAND);
	if(m_pGlvMgr)
		m_pLinearCalibration = m_pGlvMgr->m_pCalib;
	if(m_pLinearCalibration == NULL)
		m_pLinearCalibration = new CGloveCalibration();
	m_iCalibMethod = 0;
}

CPlaybackCtrl::~CPlaybackCtrl()
{	
	delete m_pClipRaw;
	COpenGLHandRendererKin* pHandRenderer = dynamic_cast<COpenGLHandRendererKin*>(m_wndOpenGL.m_pRenderer);
	delete pHandRenderer->m_pHand;
	delete pHandRenderer;
	if(m_pGlvMgr == NULL || m_pGlvMgr->m_pCalib != m_pLinearCalibration)
		delete m_pLinearCalibration;
}

void CPlaybackCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CPlaybackCtrl::OnInitDialog()
{
	((CButton*)GetDlgItem(IDC_RADIO_PLAYBACK_RAW))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_RADIO_PLAYBACK_LINEAR_CALIBRATED))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_RADIO_PLAYBACK_LMCGPR_CALIBRATED))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_RADIO_PLAYBACK_SPGPS_CALIBRATED))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_CHECK_PLAYBACK_REALTIME))->SetCheck(0);
	
	GetDlgItem(IDC_EDIT_PLAYBACK_CUR_IDX)->SetWindowText(L"0");
	CRect rcWndOpenGL, rcParent;
	GetDlgItem(IDC_STATIC_PLAYBACK_OPENGL_WND)->GetWindowRect(rcWndOpenGL);
	GetWindowRect(rcParent);
	rcWndOpenGL.MoveToXY(rcWndOpenGL.left-rcParent.left, rcWndOpenGL.top-rcParent.top);
	m_wndOpenGL.Create(NULL,
						NULL,
						WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE,						       
						rcWndOpenGL,  
						this,  
						0);  
	m_wndOpenGL.m_bShowOrigin = false;
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.OnDraw(NULL);

	//update
	COneHandCtrl* pParentCtrl = dynamic_cast<COneHandCtrl*>(m_pParentWnd);
	if(pParentCtrl != NULL)
	{
		pParentCtrl->m_ctrlKinematicRotation.m_pFrmRaw = &m_frmRaw;
	}

	return CDialog::OnInitDialog();
}

void CPlaybackCtrl::PlayCurFrame()
{
	if(m_pClipRaw == NULL)
		return;
	
	if(m_iCurIdx >= m_pClipRaw->m_arFrame.size())
		return;

	CRawFrame frmRaw = m_pClipRaw->m_arFrame[m_iCurIdx];
	switch(m_iCalibMethod)
	{
	case 0://raw
		m_frmRaw = frmRaw;
		break;
	case 1://linear
		m_frmRaw = GloveUtil::LinearCalibrateRawToRaw(frmRaw, *m_pLinearCalibration, m_bLeft);
		break;
	case 2://LMC-GPR
		m_frmRaw = MatlabUtil::GPRCalibrate_full(frmRaw, m_bLeft);
		break;
	case 3://SPGPs
		m_frmRaw = MatlabUtil::GPRCalibrate_fitc(frmRaw, m_bLeft);
		break;
	}
	CString strIdx;
	strIdx.Format(L"%d", m_iCurIdx);
	GetDlgItem(IDC_EDIT_PLAYBACK_CUR_IDX)->SetWindowText(strIdx);
	((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromKinematicData(m_frmRaw.m_arData);
	m_wndOpenGL.OnDraw(NULL);
	
	SynchronizeToKinRot();
}

void CPlaybackCtrl::PlayRealtimeFrame()
{
	std::vector<float> arData;
	CRawFrame frmRaw;
	CGlvFrame frmGlv;
	switch(m_iCalibMethod)
	{
	case 0://raw
		arData = m_pGlvMgr->RetrieveSensorData();
		frmGlv = GloveUtil::GloveDataToFrame(arData);
		m_frmRaw = GloveUtil::GlvToRaw(frmGlv, true);
		break;	
	case 1://linear
		arData = m_pGlvMgr->RetrieveAdjustedDataLinear();
		frmGlv = GloveUtil::GloveDataToFrame(arData);
		m_frmRaw = GloveUtil::GlvToRaw(frmGlv, true);
		break;		
	case 2://LMC-GPR
		arData = m_pGlvMgr->RetrieveSensorData();
		frmGlv = GloveUtil::GloveDataToFrame(arData);
		frmRaw = GloveUtil::GlvToRaw(frmGlv, true);
		m_frmRaw = MatlabUtil::GPRCalibrate_full(frmRaw, m_bLeft);
		break;
	case 3://SPGPs		
		arData = m_pGlvMgr->RetrieveSensorData();
		frmGlv = GloveUtil::GloveDataToFrame(arData);
		frmRaw = GloveUtil::GlvToRaw(frmGlv, true);
		m_frmRaw = MatlabUtil::GPRCalibrate_fitc(frmRaw, m_bLeft);
		break;
	}
	((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromKinematicData(m_frmRaw.m_arData);
	m_wndOpenGL.OnDraw(NULL);
	SynchronizeToKinRot();
}
void CPlaybackCtrl::SynchronizeToKinRot()
{
	if(m_pParentWnd == NULL)
		return;

	COneHandCtrl* pParentCtrl = dynamic_cast<COneHandCtrl*>(m_pParentWnd);
	if(pParentCtrl != NULL)
	{
		pParentCtrl->m_ctrlKinematicRotation.m_pFrmRaw = &m_frmRaw;
		pParentCtrl->m_ctrlKinematicRotation.UpdateFrameToUI();
	}
}

void CPlaybackCtrl::RefreshOpenGL()
{
	((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromKinematicData(m_frmRaw.m_arData);
	m_wndOpenGL.OnDraw(NULL);
}

BEGIN_MESSAGE_MAP(CPlaybackCtrl, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_BEG, &CPlaybackCtrl::OnBnClickedButtonPlaybackBeg)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_BACKWARD, &CPlaybackCtrl::OnBnClickedButtonPlaybackBackward)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_PLAY, &CPlaybackCtrl::OnBnClickedButtonPlaybackPlay)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_STOP, &CPlaybackCtrl::OnBnClickedButtonPlaybackStop)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_FORWARD, &CPlaybackCtrl::OnBnClickedButtonPlaybackForward)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_END, &CPlaybackCtrl::OnBnClickedButtonPlaybackEnd)
	ON_EN_CHANGE(IDC_EDIT_PLAYBACK_CUR_IDX, &CPlaybackCtrl::OnEnChangeEditPlaybackCurIdx)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_LOAD_MOTION, &CPlaybackCtrl::OnBnClickedButtonPlaybackLoadMotion)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_SAVE_MOTION, &CPlaybackCtrl::OnBnClickedButtonPlaybackSaveMotion)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_LOAD_POSE, &CPlaybackCtrl::OnBnClickedButtonPlaybackLoadPose)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_SAVE_POSE, &CPlaybackCtrl::OnBnClickedButtonPlaybackSavePose)
	ON_BN_CLICKED(IDC_CHECK_PLAYBACK_REALTIME, &CPlaybackCtrl::OnBnClickedCheckPlaybackRealtime)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_RADIO_PLAYBACK_RAW, &CPlaybackCtrl::OnBnClickedRadioPlaybackRaw)
	ON_BN_CLICKED(IDC_RADIO_PLAYBACK_LINEAR_CALIBRATED, &CPlaybackCtrl::OnBnClickedRadioPlaybackLinearCalibrated)
	ON_BN_CLICKED(IDC_RADIO_PLAYBACK_LMCGPR_CALIBRATED, &CPlaybackCtrl::OnBnClickedRadioPlaybackLmcgprCalibrated)
	ON_BN_CLICKED(IDC_RADIO_PLAYBACK_SPGPS_CALIBRATED, &CPlaybackCtrl::OnBnClickedRadioPlaybackSpgpsCalibrated)
END_MESSAGE_MAP()


// CPlaybackCtrl message handlers

void CPlaybackCtrl::OnBnClickedButtonPlaybackBeg()
{
	if(m_pClipRaw == NULL)
		return;
	m_iCurIdx = 0;
	PlayCurFrame();
}

void CPlaybackCtrl::OnBnClickedButtonPlaybackBackward()
{	
	if(m_pClipRaw == NULL)
		return;
	m_iCurIdx = max(0, m_iCurIdx-1);
	PlayCurFrame();
}

void CPlaybackCtrl::OnBnClickedButtonPlaybackPlay()
{
	if(m_pClipRaw == NULL)
		return;

	SetTimer(TIMER_EVENT_PLAYBACK_FILE, 30, NULL);
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CPlaybackCtrl::OnBnClickedButtonPlaybackStop()
{
	KillTimer(TIMER_EVENT_PLAYBACK_FILE);
}

void CPlaybackCtrl::OnBnClickedButtonPlaybackForward()
{
	if(m_pClipRaw == NULL)
		return;
	m_iCurIdx = min(m_iCurIdx+1, m_pClipRaw->m_arFrame.size()-1);
	PlayCurFrame();
}

void CPlaybackCtrl::OnBnClickedButtonPlaybackEnd()
{
	if(m_pClipRaw == NULL)
		return;
	m_iCurIdx = m_pClipRaw->m_arFrame.size()-1;
	PlayCurFrame();
}

void CPlaybackCtrl::OnEnChangeEditPlaybackCurIdx()
{
	CString strText;
	GetDlgItem(IDC_EDIT_PLAYBACK_CUR_IDX)->GetWindowText(strText);
	int iNewIdx = _wtoi(strText.GetBuffer());
	if(iNewIdx != m_iCurIdx)
	{
		m_iCurIdx = iNewIdx;
		PlayCurFrame();
	}
}

void CPlaybackCtrl::OnBnClickedButtonPlaybackLoadMotion()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv||");
	GetDlgItem(IDC_STATIC_PLAYBACK_END_IDX)->SetWindowText(L"");
	if(IDOK == dlgFile.DoModal())
	{		
		m_pClipRaw->m_arFrame.clear();
		CString strFile = dlgFile.GetFileName();
		if(strFile.Find(L".glv")!=-1)
		{
			CGlvClip clipGlv;
			clipGlv.LoadFromFile(GloveUtil::ToChar(strFile));
			*m_pClipRaw = GloveUtil::GlvToRaw(clipGlv, m_bLeft);
		}
		else
			m_pClipRaw->LoadFromFile(GloveUtil::ToChar(strFile));
		m_iCurIdx = 0;
		CString strEndIdx;
		strEndIdx.Format(L"%d", m_pClipRaw->m_arFrame.size()-1);
		GetDlgItem(IDC_STATIC_PLAYBACK_END_IDX)->SetWindowText(strEndIdx);
		PlayCurFrame();
	}
	::SetFocus(m_wndOpenGL.m_hWnd);
	m_wndOpenGL.Invalidate();
}

void CPlaybackCtrl::OnBnClickedButtonPlaybackSaveMotion()
{
	CFileDialog dlgFile(FALSE, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw|Glove Capture File(*.glv)|*.glv||");
	if(IDOK == dlgFile.DoModal())
	{
		CString strFile = dlgFile.GetFileName();
		m_pClipRaw->SaveToFile(GloveUtil::ToChar(strFile));
	}
	::SetFocus(m_wndOpenGL.m_hWnd);
}

void CPlaybackCtrl::OnBnClickedButtonPlaybackLoadPose()
{
	CFileDialog dlgFile(TRUE, L"Glove Frame File(*.gfm)|*.gfm", NULL, 4|2, L"Glove Frame File(*.gfm)|*.gfm||");
	if(IDOK == dlgFile.DoModal())
	{
		CGlvFrame frame;
		frame.LoadFromFileAngle(GloveUtil::ToChar(dlgFile.GetFileName()));		
		m_frmRaw = GloveUtil::GlvToRaw(frame, m_bLeft);
		((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateFromKinematicData(m_frmRaw.m_arData);
		m_wndOpenGL.OnDraw(NULL);

		//synchronize kin rot		
		SynchronizeToKinRot();
	}
	::SetFocus(m_wndOpenGL.m_hWnd);
}

void CPlaybackCtrl::OnBnClickedButtonPlaybackSavePose()
{
	CFileDialog dlgFile(FALSE, L"Glove Frame File(*.gfm)|*.gfm", NULL, 4|2, L"Glove Frame File(*.gfm)|*.gfm||");
	if(IDOK == dlgFile.DoModal())
	{		
		CGlvFrame frame = CGlvFrame::GetEmptyFrame();
		((COpenGLHandRendererKin*)m_wndOpenGL.m_pRenderer)->m_pHand->UpdateToSensorData(frame.m_arData);
		frame.SaveToFileAngle(GloveUtil::ToChar(dlgFile.GetFileName()));
		m_wndOpenGL.OnDraw(NULL);
	}
	::SetFocus(m_wndOpenGL.m_hWnd);
}

void CPlaybackCtrl::OnBnClickedCheckPlaybackRealtime()
{
	if(((CButton*)GetDlgItem(IDC_CHECK_PLAYBACK_REALTIME))->GetCheck())
	{
		KillTimer(TIMER_EVENT_PLAYBACK_FILE);
		if(m_pGlvMgr == NULL)
			return;
		if(!m_pGlvMgr->IsConnected())
			m_pGlvMgr->Connect();
		SetTimer(TIMER_EVENT_PLAYBACK_REALTIME, 100, NULL);
	}
	else
	{
		KillTimer(TIMER_EVENT_PLAYBACK_REALTIME);
	}
}

void CPlaybackCtrl::OnTimer(UINT_PTR nIDEvent)
{	
	if(nIDEvent == TIMER_EVENT_PLAYBACK_FILE)
	{
		PlayCurFrame();
		m_iCurIdx ++;
		if(m_iCurIdx >= m_pClipRaw->GetFrameCount())
			KillTimer(TIMER_EVENT_PLAYBACK_FILE);
		return CDialog::OnTimer(nIDEvent);
	}

	if(nIDEvent == TIMER_EVENT_PLAYBACK_REALTIME)
	{
		PlayRealtimeFrame();
		return CDialog::OnTimer(nIDEvent);
	}
	CDialog::OnTimer(nIDEvent);
}

void CPlaybackCtrl::OnBnClickedRadioPlaybackRaw()
{
	m_iCalibMethod = 0;
}

void CPlaybackCtrl::OnBnClickedRadioPlaybackLinearCalibrated()
{
	m_iCalibMethod = 1;
}

void CPlaybackCtrl::OnBnClickedRadioPlaybackLmcgprCalibrated()
{
	m_iCalibMethod = 2;
}

void CPlaybackCtrl::OnBnClickedRadioPlaybackSpgpsCalibrated()
{
	m_iCalibMethod = 3;
}
