#include "stdafx.h"
#include "deprecated.h"
#include "GloveAnimation.h"
#include "GloveUtil.h"
#include <fstream>
#include "GloveRenderer.h"
#include "RGBColor.h"
using namespace GloveUtil;

CFingerSkeleton::CFingerSkeleton()
{
	Init();
}
void CFingerSkeleton::Init()
{
	FINGER_TYPE m_eType = GENERAL;

	//3DOF each finger
	m_fMPJ = -30;
	m_fPIJ = -30;
	m_fDIJ = -30;

	m_fEndLen = 5;
	m_fMidLen = 4;
	m_fTipLen = 2;		
}
void CFingerSkeleton::Update(float fMPJ, float fPIJ, float fDIJ, float fAbd, float fELen, float fMLen, float fTLen)
{
	m_fMPJ = fMPJ;
	m_fPIJ = fPIJ;
	m_fDIJ = fDIJ;
	m_fAbd = fAbd;

	m_fEndLen = fELen;
	m_fMidLen = fMLen;
	m_fTipLen = fTLen;	
}
void CFingerSkeleton::Update(float fMPJ, float fPIJ, float fDIJ, float fAbd)
{
	m_fMPJ = fMPJ;
	m_fPIJ = fPIJ;
	m_fDIJ = fDIJ;
	m_fAbd = fAbd;
}
CHandSkeleton::CHandSkeleton()
{
	m_pSkelThumb = new CFingerSkeleton();
	m_pSkelIndex = new CFingerSkeleton();
	m_pSkelMiddle = new CFingerSkeleton();
	m_pSkelRing = new CFingerSkeleton();
	m_pSkelPinky = new CFingerSkeleton();
	m_bRightHand = false;
	
	Init();
}
CHandSkeleton::~CHandSkeleton()
{
	delete m_pSkelThumb;
	delete m_pSkelIndex;
	delete m_pSkelMiddle;
	delete m_pSkelRing;
	delete m_pSkelPinky;
}
void CHandSkeleton::Init()
{
	m_pSkelThumb->m_eType = THUMB;
	m_pSkelIndex->m_eType = INDEX;
	m_pSkelMiddle->m_eType = MIDDLE;
	m_pSkelRing->m_eType = RING;
	m_pSkelPinky->m_eType = PINKY;
	
	InitSize();
	InitMotion();	
}
void CHandSkeleton::InitSize()
{
	//length in cm
	m_fToThumb = 6;
	m_fToIndex = 8.5;
	m_fToMiddle = 8.3;
	m_fToRing = 8;
	m_fToPinky = 7.8;

	m_pSkelThumb->Update(0, 0, 0, 0, 3.5, 2.9, 0);
	m_pSkelIndex->Update(0, 0, 0, 0, 4.0, 2.8, 2.0);
	m_pSkelMiddle->Update(0, 0, 0, 0, 5.3, 3.0, 2.3);
	m_pSkelRing->Update(0, 0, 0, 0, 5.0, 3.0, 2.3);
	m_pSkelPinky->Update(0, 0, 0, 0, 4.0, 2.1, 2.2);
}
void CHandSkeleton::InitMotionLeft()
{	
	m_fPalmThumbAbd = 40;
	m_fPalmIndexAbd = 15;
	m_fPalmMiddleAbd = 0;
	m_fPalmRingAbd = -15;
	m_fPalmPinkyAbd = -30;
	m_fPalmThumbRoll = 10;
	m_arData.clear();

	//thumb
	m_arData.push_back(RadianToDegree(-0.800473));
	m_arData.push_back(RadianToDegree(-0.674372));
	m_arData.push_back(RadianToDegree(-0.0618728));
	m_arData.push_back(RadianToDegree(-0.270116));

	//index
	m_arData.push_back(RadianToDegree(-0.015523));
	m_arData.push_back(RadianToDegree(-0.0648634));
	m_arData.push_back(RadianToDegree(-0.00968046));
	m_arData.push_back(RadianToDegree(-0.313043));

	//middle
	m_arData.push_back(RadianToDegree(-0.114473));
	m_arData.push_back(RadianToDegree(-0.111247));
	m_arData.push_back(RadianToDegree(-0.0149517));
	m_arData.push_back(RadianToDegree(0));

	//ring
	m_arData.push_back(RadianToDegree(-0.141701));
	m_arData.push_back(RadianToDegree(-0.120304));
	m_arData.push_back(RadianToDegree(-0.0158203));
	m_arData.push_back(RadianToDegree(0.181061));

	//pinky
	m_arData.push_back(RadianToDegree(0.0060369));
	m_arData.push_back(RadianToDegree(-0.389312));
	m_arData.push_back(RadianToDegree(-0.0176826));
	m_arData.push_back(RadianToDegree(0.442877));

	//wrist
	m_arData.push_back(RadianToDegree(4.5584));
	m_arData.push_back(RadianToDegree(-0.598752));
	m_arData.push_back(RadianToDegree(0.224832));

	Update();
}
void CHandSkeleton::InitMotionRight()
{
	m_fPalmThumbAbd = -40;
	m_fPalmIndexAbd = -15;
	m_fPalmMiddleAbd = 0;
	m_fPalmRingAbd = 15;
	m_fPalmPinkyAbd = 30;
	m_fPalmThumbRoll = 10;
	m_arData.clear();

	//thumb
	m_arData.push_back(RadianToDegree(-0.640879));
	m_arData.push_back(RadianToDegree(-0.291851));
	m_arData.push_back(RadianToDegree(-0.446049));
	m_arData.push_back(RadianToDegree(-0.270116));

	//index
	m_arData.push_back(RadianToDegree(-0.127806));
	m_arData.push_back(RadianToDegree(-0.0878151));
	m_arData.push_back(RadianToDegree(-0.0124609));
	m_arData.push_back(RadianToDegree(0.143919));

	//middle
	m_arData.push_back(RadianToDegree(-0.357034));
	m_arData.push_back(RadianToDegree(0.0336332));
	m_arData.push_back(RadianToDegree(0.00607962));
	m_arData.push_back(RadianToDegree(0));

	//ring
	m_arData.push_back(RadianToDegree(-0.224798));
	m_arData.push_back(RadianToDegree(-0.0667484));
	m_arData.push_back(RadianToDegree(-0.00992151));
	m_arData.push_back(RadianToDegree(-0.153584));

	//pinky
	m_arData.push_back(RadianToDegree(-0.138846));
	m_arData.push_back(RadianToDegree(-0.0930512));
	m_arData.push_back(RadianToDegree(-0.013048));
	m_arData.push_back(RadianToDegree(-0.451943));

	//wrist
	m_arData.push_back(RadianToDegree(4.5584));
	m_arData.push_back(RadianToDegree(-0.598752));
	m_arData.push_back(RadianToDegree(0.224832));

	Update();
}
void CHandSkeleton::InitMotion()
{
	if(m_bRightHand)
		InitMotionRight();
	else
		InitMotionLeft();
}

void CHandSkeleton::Update(std::vector<float> arData)
{
	m_arData.clear();
	for(int i = 0; i < arData.size(); ++i)
		m_arData.push_back(RadianToDegree(arData[i]));

	Update();
}
void CHandSkeleton::Update()
{
	if(m_arData.size() == 0)
		return;

	m_pSkelThumb->Update(m_arData[CGlvStructre::glv_thumbMPJ], m_arData[CGlvStructre::glv_thumbIJ], 0, m_arData[CGlvStructre::glv_thumbAbduction]);
	m_pSkelIndex->Update(m_arData[CGlvStructre::glv_indexMPJ], m_arData[CGlvStructre::glv_indexPIJ], m_arData[CGlvStructre::glv_indexDIJ], m_arData[CGlvStructre::glv_indexAbduction]);
	m_pSkelMiddle->Update(m_arData[CGlvStructre::glv_middleMPJ], m_arData[CGlvStructre::glv_middlePIJ], m_arData[CGlvStructre::glv_middleDIJ], m_arData[CGlvStructre::glv_middleAbudction]);
	m_pSkelRing->Update(m_arData[CGlvStructre::glv_ringMPJ], m_arData[CGlvStructre::glv_ringPIJ], m_arData[CGlvStructre::glv_ringDIJ], m_arData[CGlvStructre::glv_ringAbduction]);
	m_pSkelPinky->Update(m_arData[CGlvStructre::glv_pinkieMPJ], m_arData[CGlvStructre::glv_pinkiePIJ], m_arData[CGlvStructre::glv_pinkieDIJ], m_arData[CGlvStructre::glv_pinkieAbduction]);

	//m_fPalmThumbAbd = - m_arData[CGlvStructre::glv_thumbAbduction];
	m_fPalmThumbRoll = m_arData[CGlvStructre::glv_thumbTMJ];
		
	m_fWristFlex = m_arData[CGlvStructre::glv_wristPitch];
	m_fWristAbd = m_arData[CGlvStructre::glv_wristYaw];
}
void CHandSkeleton::LoadSizeFromFile(CString strPath)
{
	std::ifstream fin(strPath);

	//palm
	char buf[1024] = {0};
	fin.getline(buf, sizeof(buf));
	CString strLine(buf);
	int iBeg = 0, iEnd = strLine.Find(L",", iBeg);
	CString strToThumb = strLine.Mid(iBeg, iEnd-iBeg);
	m_fToThumb = _wtof(strToThumb.GetBuffer());
	
	iBeg = iEnd+1, iEnd = strLine.Find(L",", iBeg);
	CString strToIndex = strLine.Mid(iBeg, iEnd-iBeg);
	m_fToIndex = _wtof(strToIndex.GetBuffer());

	iBeg = iEnd+1, iEnd = strLine.Find(L",", iBeg);
	CString strToMiddle = strLine.Mid(iBeg, iEnd-iBeg);
	m_fToMiddle = _wtof(strToMiddle.GetBuffer());

	iBeg = iEnd+1, iEnd = strLine.Find(L",", iBeg);
	CString strToRing = strLine.Mid(iBeg, iEnd-iBeg);
	m_fToRing = _wtof(strToRing.GetBuffer());

	iBeg = iEnd+1, iEnd = strLine.GetLength();
	CString strToPinky = strLine.Mid(iBeg, iEnd-iBeg);
	m_fToPinky = _wtof(strToPinky.GetBuffer());
	
	//finger
	for(int i = 0; i < 5; ++ i)
	{
		buf[1023] = '\0';
		fin.getline(buf, sizeof(buf));
		strLine = CString(buf);

		CFingerSkeleton* pSkelFinger = NULL;
		switch(i)
		{
		case 0: pSkelFinger = m_pSkelThumb; break;
		case 1: pSkelFinger = m_pSkelIndex; break;
		case 2: pSkelFinger = m_pSkelMiddle; break;
		case 3: pSkelFinger = m_pSkelRing; break;
		case 4: pSkelFinger = m_pSkelPinky; break;
		}

		iBeg = 0;
		for(int j = 0; j < 3; ++ j)
		{
			iEnd = strLine.Find(L",", iBeg);
			if(iEnd == -1)
				iEnd = strLine.GetLength();
			CString strLen = strLine.Mid(iBeg, iEnd - iBeg);
			switch(j)
			{
			case 0: pSkelFinger->m_fEndLen = _wtof(strLen.GetBuffer()); break;
			case 1: pSkelFinger->m_fMidLen = _wtof(strLen.GetBuffer()); break;
			case 2: pSkelFinger->m_fTipLen = _wtof(strLen.GetBuffer()); break;
			}
			iBeg = iEnd + 1;
		}
	}
}
void CHandSkeleton::SaveSizeToFile(CString strPath)
{
	std::ofstream fout(strPath);
	//palm
	fout << m_fToThumb << "," << m_fToIndex << "," << 
		m_fToMiddle << "," << m_fToRing << "," << m_fToPinky << std::endl;
	//thumb
	fout << m_pSkelThumb->m_fEndLen << "," << m_pSkelThumb->m_fMidLen
		<< "," << m_pSkelThumb->m_fTipLen << std::endl;
	//index
	fout << m_pSkelIndex->m_fEndLen << "," << m_pSkelIndex->m_fMidLen
		<< "," << m_pSkelIndex->m_fTipLen << std::endl;
	//middle
	fout << m_pSkelMiddle->m_fEndLen << "," << m_pSkelMiddle->m_fMidLen
		<< "," << m_pSkelMiddle->m_fTipLen << std::endl;
	//ring
	fout << m_pSkelRing->m_fEndLen << "," << m_pSkelRing->m_fMidLen
		<< "," << m_pSkelRing->m_fTipLen << std::endl;
	//pinky
	fout << m_pSkelPinky->m_fEndLen << "," << m_pSkelPinky->m_fMidLen
		<< "," << m_pSkelPinky->m_fTipLen << std::endl;
	fout.flush();
}


COpenGLFingerRenderer::COpenGLFingerRenderer()
{
	m_fJointSize = 0.5;
	m_bWireframe = false;
	m_pFinger = NULL;
}
COpenGLFingerRenderer::COpenGLFingerRenderer(CFingerSkeleton* pFinger)
{
	m_fJointSize = 0.5;
	m_bWireframe = false;
	m_pFinger = pFinger;
}
COpenGLFingerRenderer::~COpenGLFingerRenderer()
{
}
void COpenGLFingerRenderer::SetWireframe(bool bWireframe)
{
	m_bWireframe = bWireframe;
}
void COpenGLFingerRenderer::SetFinger(CFingerSkeleton* pFinger)
{
	m_pFinger = pFinger;
}
void COpenGLFingerRenderer::Render()
{
	if(m_pFinger == NULL)
		return;

	switch(m_pFinger->m_eType)
	{
	case THUMB: glColor3ub(RGB_THUMB); break;
	case INDEX: glColor3ub(RGB_INDEX); break;
	case MIDDLE: glColor3ub(RGB_MIDDLE); break;
	case RING: glColor3ub(RGB_RING); break;
	case PINKY: glColor3ub(RGB_PINKY); break;
	}

	glPushMatrix();
		
	//end
	RENDER_JOINT(m_fJointSize);
	glRotated(m_pFinger->m_fAbd, 0.0, 1.0, 0.0);
	glRotated(m_pFinger->m_fMPJ, 0.0, 0.0, 1.0);
	RENDER_BONE(m_fJointSize, m_pFinger->m_fEndLen);
	glTranslatef(-m_pFinger->m_fEndLen, 0, 0);

	//mid
	RENDER_JOINT(m_fJointSize);
	glRotated(m_pFinger->m_fPIJ, 0.0, 0.0, 1.0);
	RENDER_BONE(m_fJointSize, m_pFinger->m_fMidLen);
	glTranslatef(-m_pFinger->m_fMidLen, 0, 0);

	//tip
	if(m_pFinger->m_eType != THUMB)
	{
		RENDER_JOINT(m_fJointSize);
		glRotated(m_pFinger->m_fDIJ, 0.0, 0.0, 1.0);
		RENDER_BONE(m_fJointSize, m_pFinger->m_fTipLen);
		glTranslatef(-m_pFinger->m_fTipLen, 0, 0);
	}
	
	RENDER_JOINT(m_fJointSize);
	RENDER_NAIL(m_fJointSize, 0.5);
	glPopMatrix();
}

COpenGLHandRenderer::COpenGLHandRenderer()
{
	m_fJointSize = 0.5;
	m_bWireframe = false;

	m_pHand = NULL;

	m_pThumbRenderer = new COpenGLFingerRenderer(NULL);
	m_pIndexRenderer = new COpenGLFingerRenderer(NULL);
	m_pMiddleRenderer = new COpenGLFingerRenderer(NULL);
	m_pRingRenderer = new COpenGLFingerRenderer(NULL);
	m_pPinkyRenderer = new COpenGLFingerRenderer(NULL);
}
COpenGLHandRenderer::COpenGLHandRenderer(CHandSkeleton* pHand)
{
	m_fJointSize = 0.5;
	m_bWireframe = false;

	m_pHand = pHand;

	m_pThumbRenderer = new COpenGLFingerRenderer(m_pHand->m_pSkelThumb);
	m_pIndexRenderer = new COpenGLFingerRenderer(m_pHand->m_pSkelIndex);
	m_pMiddleRenderer = new COpenGLFingerRenderer(m_pHand->m_pSkelMiddle);
	m_pRingRenderer = new COpenGLFingerRenderer(m_pHand->m_pSkelRing);
	m_pPinkyRenderer = new COpenGLFingerRenderer(m_pHand->m_pSkelPinky);
}

COpenGLHandRenderer::~COpenGLHandRenderer()
{
	delete m_pThumbRenderer;
	delete m_pIndexRenderer;
	delete m_pMiddleRenderer;
	delete m_pRingRenderer;
	delete m_pPinkyRenderer;
}
void DrawCoordinate()
{
	glBegin(GL_LINES);
	
	//red x
	glColor3ub(RGB_RED);
	glVertex3f(0.0f,0.0f,0.0f);
	glVertex3f(10.0f,0.0f,0.0f);
	glVertex3f(10.0f,0.0f,0.0f);
	glVertex3f(9,1,0.0f);
	glVertex3f(10.0f,0.0f,0.0f);
	glVertex3f(9,-1.0f,0.0f);
	
	//green y
	glColor3ub(RGB_GREEN);
	glVertex3f(0.0f,0.0f,0.0f);
	glVertex3f(0.0f,10.0f,0.0f);
	glVertex3f(0.0f,10.0f,0.0f);
	glVertex3f(1,9,0.0f);
	glVertex3f(0.0f,10.0f,0.0f);
	glVertex3f(-1,9,0.0f);
	
	//blue z
	glColor3ub(RGB_BLUE);
	glVertex3f(0.0f,0.0f,0.0f);
	glVertex3f(0.0f,0.0f,10.0f);
	glVertex3f(0.0f,0.0f,10.0f);
	glVertex3f(0.0f,1,9);
	glVertex3f(0.0f,0.0f,10.0f);
	glVertex3f(0.0f,-1,9);

	glEnd();
}
void COpenGLHandRenderer::Render()
{
	if(m_pHand == NULL)
		return;

	glPushMatrix();
	//forearm
	glColor3ub(RGB_FOREARM);
	RENDER_FOREARM(m_fJointSize, 20);

	//hand joint
	glColor3ub(RGB_PALM);
	glRotated(m_pHand->m_fWristFlex, 0.0, 0.0, 1.0);
	glRotated(m_pHand->m_fWristAbd, 0.0, 1.0, 0.0);
	RENDER_JOINT(m_fJointSize);

	//to thumb
	glPushMatrix();
	glRotated(m_pHand->m_fPalmThumbRoll, 1.0, 0.0, 0.0);
	glRotated(m_pHand->m_fPalmThumbAbd, 0.0, 1.0, 0.0);
	glColor3ub(RGB_PALM);
	RENDER_BONE(m_fJointSize, m_pHand->m_fToThumb);
	glTranslatef(-m_pHand->m_fToThumb, 0, 0);
	glRotated(-m_pHand->m_fPalmThumbAbd, 0.0, 1.0, 0.0);
	m_pThumbRenderer->Render();
	glPopMatrix();

	//to index
	glPushMatrix();
	glRotated(m_pHand->m_fPalmIndexAbd, 0.0, 1.0, 0.0);
	glColor3ub(RGB_PALM);
	RENDER_BONE(m_fJointSize, m_pHand->m_fToIndex);
	glTranslatef(-m_pHand->m_fToIndex, 0, 0);
	glRotated(-m_pHand->m_fPalmIndexAbd, 0.0, 1.0, 0.0);
	m_pIndexRenderer->Render();
	glPopMatrix();

	//to middle
	glPushMatrix();
	glRotated(m_pHand->m_fPalmMiddleAbd, 0.0, 1.0, 0.0);
	glColor3ub(RGB_PALM);
	RENDER_BONE(m_fJointSize, m_pHand->m_fToMiddle);
	glTranslatef(-m_pHand->m_fToMiddle, 0, 0);
	glRotated(-m_pHand->m_fPalmMiddleAbd, 0.0, 1.0, 0.0);
	m_pMiddleRenderer->Render();
	glPopMatrix();

	//to ring
	glPushMatrix();
	glRotated(m_pHand->m_fPalmRingAbd, 0.0, 1.0, 0.0);
	glColor3ub(RGB_PALM);
	RENDER_BONE(m_fJointSize, m_pHand->m_fToRing);
	glTranslatef(-m_pHand->m_fToRing, 0, 0);
	glRotated(-m_pHand->m_fPalmRingAbd, 0.0, 1.0, 0.0);
	m_pRingRenderer->Render();
	glPopMatrix();

	//to pinky
	glPushMatrix();
	glRotated(m_pHand->m_fPalmPinkyAbd, 0.0, 1.0, 0.0);
	glColor3ub(RGB_PALM);
	RENDER_BONE(m_fJointSize, m_pHand->m_fToPinky);
	glTranslatef(-m_pHand->m_fToPinky, 0, 0);
	glRotated(-m_pHand->m_fPalmPinkyAbd, 0.0, 1.0, 0.0);
	m_pPinkyRenderer->Render();
	glPopMatrix();

	glPopMatrix();
}

void COpenGLHandRenderer::SetWireframe(bool bWireframe)
{
	m_bWireframe = bWireframe;

	m_pThumbRenderer->SetWireframe(bWireframe);
	m_pIndexRenderer->SetWireframe(bWireframe);
	m_pMiddleRenderer->SetWireframe(bWireframe);
	m_pRingRenderer->SetWireframe(bWireframe);
	m_pPinkyRenderer->SetWireframe(bWireframe);
}
void COpenGLHandRenderer::SetHand(CHandSkeleton* pHand)
{
	m_pHand = pHand;
	
	if(m_pHand)
	{
		m_pThumbRenderer->SetFinger(m_pHand->m_pSkelThumb);
		m_pIndexRenderer->SetFinger(m_pHand->m_pSkelIndex);
		m_pMiddleRenderer->SetFinger(m_pHand->m_pSkelMiddle);
		m_pRingRenderer->SetFinger(m_pHand->m_pSkelRing);
		m_pPinkyRenderer->SetFinger(m_pHand->m_pSkelPinky);
	}
	else
	{
		m_pThumbRenderer->SetFinger(NULL);
		m_pIndexRenderer->SetFinger(NULL);
		m_pMiddleRenderer->SetFinger(NULL);
		m_pRingRenderer->SetFinger(NULL);
		m_pPinkyRenderer->SetFinger(NULL);
	}
}
void COpenGLHandRenderer::UpdateHand(std::vector<float> arData)
{
	if(m_pHand == NULL)
		return;

	m_pHand->Update(arData);
	m_pThumbRenderer->SetFinger(m_pHand->m_pSkelThumb);
	m_pIndexRenderer->SetFinger(m_pHand->m_pSkelIndex);
	m_pMiddleRenderer->SetFinger(m_pHand->m_pSkelMiddle);
	m_pRingRenderer->SetFinger(m_pHand->m_pSkelRing);
	m_pPinkyRenderer->SetFinger(m_pHand->m_pSkelPinky);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
