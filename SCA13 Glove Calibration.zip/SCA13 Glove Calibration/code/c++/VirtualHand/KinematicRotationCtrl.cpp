// KinematicRotationCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "KinematicRotationCtrl.h"
#include "GloveSkeleton.h"
#include "OneHandCtrl.h"
#include "CKinematic\IKSolverDlg.h"


// CKinematicRotationCtrl dialog

IMPLEMENT_DYNAMIC(CKinematicRotationCtrl, CDialog)

CKinematicRotationCtrl::CKinematicRotationCtrl(bool bLeft, CWnd* pParent /*=NULL*/)
	: CDialog(CKinematicRotationCtrl::IDD, pParent)
{
	m_pFrmRaw = NULL;
	m_bRealtimeMocap = false;
	m_bLeft = bLeft;
}

CKinematicRotationCtrl::~CKinematicRotationCtrl()
{
}
BOOL CKinematicRotationCtrl::OnInitDialog()
{
	UpdateFrameToUI();
	return CDialog::OnInitDialog();
}
void CKinematicRotationCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}
void CKinematicRotationCtrl::SetRealtimeMocap(bool bRealtimeMocap)
{
	m_bRealtimeMocap = bRealtimeMocap;
	SetReadOnly(m_bRealtimeMocap);
}

void CKinematicRotationCtrl::SetReadOnly(bool bReadOnly)
{
	((CEdit*)GetDlgItem(IDC_EDIT_THUMB_ROLL_ROTATION_0))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_THUMB_ABD_ROTATION_1))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_THUMB_VIRTUAL_ROTATION_2))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_THUMB_FLEX_PROX_ROTATION_3))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_THUMB_DIST_ROTATION_4))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_INDEX_ABD_PALM_ROTATION_5))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_INDEX_FLEX_PALM_ROTATION_6))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_INDEX_ABD_ROTATION_7))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_INDEX_FLEX_PROX_ROTATION_8))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_INDEX_FLEX_MID_ROTATION_9))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_INDEX_FLEX_DIST_ROTATION_10))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_MIDDLE_ABD_PALM_ROTATION_11))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_MIDDLE_FLEX_PALM_ROTATION_12))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_MIDDLE_ABD_ROTATION_13))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_MIDDLE_FLEX_PROX_ROTATION_14))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_MIDDLE_FLEX_MID_ROTATION_15))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_MIDDLE_FLEX_DIST_ROTATION_16))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_RING_ABD_PALM_ROTATION_17))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_RING_FLEX_PALM_ROTATION_18))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_RING_ABD_ROTATION_19))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_RING_FLEX_PROX_ROTATION_20))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_RING_FLEX_MID_ROTATION_21))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_RING_FLEX_DIST_ROTATION_22))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_PINKY_ABD_PALM_ROTATION_23))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_PINKY_FLEX_PALM_ROTATION_24))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_PINKY_ABD_ROTATION_25))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_PINKY_FLEX_PROX_ROTATION_26))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_PINKY_FLEX_MID_ROTATION_27))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_PINKY_FLEX_DIST_ROTATION_28))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_WRIST_FLEX_ROTATION_29))->SetReadOnly(bReadOnly);
	((CEdit*)GetDlgItem(IDC_EDIT_WRIST_ABD_ROTATION_30))->SetReadOnly(bReadOnly);
}
void CKinematicRotationCtrl::UpdateFrameToUI()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;

	strText.Format(L"%.1f", m_pFrmRaw->m_arData[HAND_SKEL_DOF_THUMB_ROLL]);
	GetDlgItem(IDC_EDIT_THUMB_ROLL_ROTATION_0)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_THUMB_ABD]);
	GetDlgItem(IDC_EDIT_THUMB_ABD_ROTATION_1)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_THUMB_VIRTUAL]);
	GetDlgItem(IDC_EDIT_THUMB_VIRTUAL_ROTATION_2)->SetWindowText(strText);

	strText.Format(L"%.1f", m_pFrmRaw->m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX]);
	GetDlgItem(IDC_EDIT_THUMB_FLEX_PROX_ROTATION_3)->SetWindowText(strText);

	strText.Format(L"%.1f", m_pFrmRaw->m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST]);
	GetDlgItem(IDC_EDIT_THUMB_DIST_ROTATION_4)->SetWindowText(strText);

	strText.Format(L"%.1f", m_pFrmRaw->m_arData[HAND_SKEL_DOF_INDEX_ABD_PALM]);
	GetDlgItem(IDC_EDIT_INDEX_ABD_PALM_ROTATION_5)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_INDEX_FLEX_PALM]);
	GetDlgItem(IDC_EDIT_INDEX_FLEX_PALM_ROTATION_6)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_INDEX_ABD]);
	GetDlgItem(IDC_EDIT_INDEX_ABD_ROTATION_7)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX]);
	GetDlgItem(IDC_EDIT_INDEX_FLEX_PROX_ROTATION_8)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID]);
	GetDlgItem(IDC_EDIT_INDEX_FLEX_MID_ROTATION_9)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST]);
	GetDlgItem(IDC_EDIT_INDEX_FLEX_DIST_ROTATION_10)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_MID_ABD_PALM]);
	GetDlgItem(IDC_EDIT_MIDDLE_ABD_PALM_ROTATION_11)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_MID_FLEX_PALM]);
	GetDlgItem(IDC_EDIT_MIDDLE_FLEX_PALM_ROTATION_12)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_MID_ABD]);
	GetDlgItem(IDC_EDIT_MIDDLE_ABD_ROTATION_13)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_MID_FLEX_PROX]);
	GetDlgItem(IDC_EDIT_MIDDLE_FLEX_PROX_ROTATION_14)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_MID_FLEX_MID]);
	GetDlgItem(IDC_EDIT_MIDDLE_FLEX_MID_ROTATION_15)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_MID_FLEX_DIST]);
	GetDlgItem(IDC_EDIT_MIDDLE_FLEX_DIST_ROTATION_16)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_RING_ABD_PALM]);
	GetDlgItem(IDC_EDIT_RING_ABD_PALM_ROTATION_17)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_RING_FLEX_PALM]);
	GetDlgItem(IDC_EDIT_RING_FLEX_PALM_ROTATION_18)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_RING_ABD]);
	GetDlgItem(IDC_EDIT_RING_ABD_ROTATION_19)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_RING_FLEX_PROX]);
	GetDlgItem(IDC_EDIT_RING_FLEX_PROX_ROTATION_20)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_RING_FLEX_MID]);
	GetDlgItem(IDC_EDIT_RING_FLEX_MID_ROTATION_21)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_RING_FLEX_DIST]);
	GetDlgItem(IDC_EDIT_RING_FLEX_DIST_ROTATION_22)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_PINKY_ABD_PALM]);
	GetDlgItem(IDC_EDIT_PINKY_ABD_PALM_ROTATION_23)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_PINKY_FLEX_PALM]);
	GetDlgItem(IDC_EDIT_PINKY_FLEX_PALM_ROTATION_24)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_PINKY_ABD]);
	GetDlgItem(IDC_EDIT_PINKY_ABD_ROTATION_25)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX]);
	GetDlgItem(IDC_EDIT_PINKY_FLEX_PROX_ROTATION_26)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID]);
	GetDlgItem(IDC_EDIT_PINKY_FLEX_MID_ROTATION_27)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST]);
	GetDlgItem(IDC_EDIT_PINKY_FLEX_DIST_ROTATION_28)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_WRIST_FLEX]);
	GetDlgItem(IDC_EDIT_WRIST_FLEX_ROTATION_29)->SetWindowText(strText);

	strText.Format(L"%.1f",  m_pFrmRaw->m_arData[HAND_SKEL_DOF_WRIST_ABD]);
	GetDlgItem(IDC_EDIT_WRIST_ABD_ROTATION_30)->SetWindowText(strText);
}
void CKinematicRotationCtrl::UpdateUIToFrame()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	
	GetDlgItem(IDC_EDIT_THUMB_ROLL_ROTATION_0)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_THUMB_ROLL] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_THUMB_ABD_ROTATION_1)->GetWindowText(strText);
	 m_pFrmRaw->m_arData[HAND_SKEL_DOF_THUMB_ABD] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_THUMB_VIRTUAL_ROTATION_2)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_THUMB_VIRTUAL] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_THUMB_FLEX_PROX_ROTATION_3)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_THUMB_DIST_ROTATION_4)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_INDEX_ABD_PALM_ROTATION_5)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_INDEX_ABD_PALM] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_INDEX_FLEX_PALM_ROTATION_6)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_INDEX_FLEX_PALM] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_INDEX_ABD_ROTATION_7)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_INDEX_ABD] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_INDEX_FLEX_PROX_ROTATION_8)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_INDEX_FLEX_MID_ROTATION_9)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_INDEX_FLEX_DIST_ROTATION_10)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_MIDDLE_ABD_PALM_ROTATION_11)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_MID_ABD_PALM] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_MIDDLE_FLEX_PALM_ROTATION_12)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_MID_FLEX_PALM] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_MIDDLE_ABD_ROTATION_13)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_MID_ABD] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_MIDDLE_FLEX_PROX_ROTATION_14)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_MID_FLEX_PROX] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_MIDDLE_FLEX_MID_ROTATION_15)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_MID_FLEX_MID] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_MIDDLE_FLEX_DIST_ROTATION_16)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_MID_FLEX_DIST] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_RING_ABD_PALM_ROTATION_17)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_RING_ABD_PALM] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_RING_FLEX_PALM_ROTATION_18)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_RING_FLEX_PALM] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_RING_ABD_ROTATION_19)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_RING_ABD] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_RING_FLEX_PROX_ROTATION_20)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_RING_FLEX_PROX] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_RING_FLEX_MID_ROTATION_21)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_RING_FLEX_MID] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_RING_FLEX_DIST_ROTATION_22)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_RING_FLEX_DIST] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_PINKY_ABD_PALM_ROTATION_23)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_PINKY_ABD_PALM] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_PINKY_FLEX_PALM_ROTATION_24)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_PINKY_FLEX_PALM] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_PINKY_ABD_ROTATION_25)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_PINKY_ABD] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_PINKY_FLEX_PROX_ROTATION_26)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_PINKY_FLEX_MID_ROTATION_27)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_PINKY_FLEX_DIST_ROTATION_28)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_WRIST_FLEX_ROTATION_29)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_WRIST_FLEX] = _wtof(strText.GetBuffer());

	GetDlgItem(IDC_EDIT_WRIST_ABD_ROTATION_30)->GetWindowText(strText);
	m_pFrmRaw->m_arData[HAND_SKEL_DOF_WRIST_ABD] = _wtof(strText.GetBuffer());
}

void CKinematicRotationCtrl::SynchronizePlayback(int iIdx, float fVal)
{
	if(m_pParentWnd == NULL)
		return;
	if(m_pFrmRaw->m_arData[iIdx] == fVal)
		return;
	m_pFrmRaw->m_arData[iIdx] = fVal;
	COneHandCtrl* pParent = dynamic_cast<COneHandCtrl*>(m_pParentWnd);
	if(pParent)
	{
		pParent->m_ctrlPlayback.RefreshOpenGL();
		if(pParent->m_ctrlPlayback.m_pClipRaw != NULL &&
			iIdx != -1 && ((CButton*)GetDlgItem(IDC_CHECK_UPDATE_TO_CLIP))->GetCheck())
		{
			for(int i = 0; i < pParent->m_ctrlPlayback.m_pClipRaw->m_arFrame.size(); ++i)
			{
				pParent->m_ctrlPlayback.m_pClipRaw->m_arFrame[i].m_arData[iIdx] = m_pFrmRaw->m_arData[iIdx];
			}
		}
	}
}
void CKinematicRotationCtrl::TouchFrame(CRawFrame& frmRaw)
{	
	CHandSkeletonKin hand(!m_bLeft);
	hand.UpdateFromKinematicData(frmRaw.m_arData);
	hand.m_pHand->PopulateGlobalPosAndAxis();

	CKinematicPoint ptGoal(0, 0, 0);
	int iActiveCount = 0;
	if(((CButton*)GetDlgItem(IDC_CHECK_INDEX_ACTIVE))->GetCheck())
	{
		ptGoal = hand.m_pHand->m_arChain[1]->GetGlobalEndEffectorPos();
		iActiveCount ++;
	}
	if(((CButton*)GetDlgItem(IDC_CHECK_MIDDLE_ACTIVE))->GetCheck())
	{
		ptGoal += hand.m_pHand->m_arChain[2]->GetGlobalEndEffectorPos();
		iActiveCount ++;
	}
	if(((CButton*)GetDlgItem(IDC_CHECK_RING_ACTIVE))->GetCheck())
	{
		ptGoal += hand.m_pHand->m_arChain[3]->GetGlobalEndEffectorPos();
		iActiveCount ++;
	}
	if(((CButton*)GetDlgItem(IDC_CHECK_PINKY_ACTIVE))->GetCheck())
	{
		ptGoal += hand.m_pHand->m_arChain[4]->GetGlobalEndEffectorPos();
		iActiveCount ++;
	}
	if(iActiveCount == 0)
		return;	
	
	if(((CButton*)GetDlgItem(IDC_CHECK_THUMB_ACTIVE))->GetCheck())
		hand.m_pHand->m_arChain[0]->SolveToReachWithCombinedConstraintsDLS(ptGoal);
	if(((CButton*)GetDlgItem(IDC_CHECK_INDEX_ACTIVE))->GetCheck())
		hand.m_pHand->m_arChain[1]->SolveToReachWithCombinedConstraintsDLSFromPalm(ptGoal);
	if(((CButton*)GetDlgItem(IDC_CHECK_MIDDLE_ACTIVE))->GetCheck())
		hand.m_pHand->m_arChain[2]->SolveToReachWithCombinedConstraintsDLSFromPalm(ptGoal);
	if(((CButton*)GetDlgItem(IDC_CHECK_RING_ACTIVE))->GetCheck())
		hand.m_pHand->m_arChain[3]->SolveToReachWithCombinedConstraintsDLSFromPalm(ptGoal);
	if(((CButton*)GetDlgItem(IDC_CHECK_PINKY_ACTIVE))->GetCheck())
		hand.m_pHand->m_arChain[4]->SolveToReachWithCombinedConstraintsDLSFromPalm(ptGoal);

	frmRaw.m_arData.clear();
	hand.UpdateToKinematicData(frmRaw.m_arData);
}
void CKinematicRotationCtrl::TouchClip(CRawClip& clipRaw)
{
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = clipRaw.m_arFrame[i];
		TouchFrame(frmRaw);
		clipRaw.m_arFrame[i] = frmRaw;
	}
}
BEGIN_MESSAGE_MAP(CKinematicRotationCtrl, CDialog)
	ON_EN_CHANGE(IDC_EDIT_THUMB_ROLL_ROTATION_0, &CKinematicRotationCtrl::OnEnChangeEditThumbRollRotation0)
	ON_EN_CHANGE(IDC_EDIT_THUMB_ABD_ROTATION_1, &CKinematicRotationCtrl::OnEnChangeEditThumbAbdRotation1)
	ON_EN_CHANGE(IDC_EDIT_THUMB_VIRTUAL_ROTATION_2, &CKinematicRotationCtrl::OnEnChangeEditThumbVirtualRotation2)
	ON_EN_CHANGE(IDC_EDIT_THUMB_FLEX_PROX_ROTATION_3, &CKinematicRotationCtrl::OnEnChangeEditThumbFlexProxRotation3)
	ON_EN_CHANGE(IDC_EDIT_THUMB_DIST_ROTATION_4, &CKinematicRotationCtrl::OnEnChangeEditThumbDistRotation4)
	ON_EN_CHANGE(IDC_EDIT_INDEX_ABD_PALM_ROTATION_5, &CKinematicRotationCtrl::OnEnChangeEditIndexAbdPalmRotation5)
	ON_EN_CHANGE(IDC_EDIT_INDEX_FLEX_PALM_ROTATION_6, &CKinematicRotationCtrl::OnEnChangeEditIndexFlexPalmRotation6)
	ON_EN_CHANGE(IDC_EDIT_INDEX_ABD_ROTATION_7, &CKinematicRotationCtrl::OnEnChangeEditIndexAbdRotation7)
	ON_EN_CHANGE(IDC_EDIT_INDEX_FLEX_PROX_ROTATION_8, &CKinematicRotationCtrl::OnEnChangeEditIndexFlexProxRotation8)
	ON_EN_CHANGE(IDC_EDIT_INDEX_FLEX_MID_ROTATION_9, &CKinematicRotationCtrl::OnEnChangeEditIndexFlexMidRotation9)
	ON_EN_CHANGE(IDC_EDIT_INDEX_FLEX_DIST_ROTATION_10, &CKinematicRotationCtrl::OnEnChangeEditIndexFlexDistRotation10)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_ABD_PALM_ROTATION_11, &CKinematicRotationCtrl::OnEnChangeEditMiddleAbdPalmRotation11)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_FLEX_PALM_ROTATION_12, &CKinematicRotationCtrl::OnEnChangeEditMiddleFlexPalmRotation12)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_ABD_ROTATION_13, &CKinematicRotationCtrl::OnEnChangeEditMiddleAbdRotation13)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_FLEX_PROX_ROTATION_14, &CKinematicRotationCtrl::OnEnChangeEditMiddleFlexProxRotation14)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_FLEX_MID_ROTATION_15, &CKinematicRotationCtrl::OnEnChangeEditMiddleFlexMidRotation15)
	ON_EN_CHANGE(IDC_EDIT_MIDDLE_FLEX_DIST_ROTATION_16, &CKinematicRotationCtrl::OnEnChangeEditMiddleFlexDistRotation16)
	ON_EN_CHANGE(IDC_EDIT_RING_ABD_PALM_ROTATION_17, &CKinematicRotationCtrl::OnEnChangeEditRingAbdPalmRotation17)
	ON_EN_CHANGE(IDC_EDIT_RING_FLEX_PALM_ROTATION_18, &CKinematicRotationCtrl::OnEnChangeEditRingFlexPalmRotation18)
	ON_EN_CHANGE(IDC_EDIT_RING_ABD_ROTATION_19, &CKinematicRotationCtrl::OnEnChangeEditRingAbdRotation19)
	ON_EN_CHANGE(IDC_EDIT_RING_FLEX_PROX_ROTATION_20, &CKinematicRotationCtrl::OnEnChangeEditRingFlexProxRotation20)
	ON_EN_CHANGE(IDC_EDIT_RING_FLEX_MID_ROTATION_21, &CKinematicRotationCtrl::OnEnChangeEditRingFlexMidRotation21)
	ON_EN_CHANGE(IDC_EDIT_RING_FLEX_DIST_ROTATION_22, &CKinematicRotationCtrl::OnEnChangeEditRingFlexDistRotation22)
	ON_EN_CHANGE(IDC_EDIT_PINKY_ABD_PALM_ROTATION_23, &CKinematicRotationCtrl::OnEnChangeEditPinkyAbdPalmRotation23)
	ON_EN_CHANGE(IDC_EDIT_PINKY_FLEX_PALM_ROTATION_24, &CKinematicRotationCtrl::OnEnChangeEditPinkyFlexPalmRotation24)
	ON_EN_CHANGE(IDC_EDIT_PINKY_ABD_ROTATION_25, &CKinematicRotationCtrl::OnEnChangeEditPinkyAbdRotation25)
	ON_EN_CHANGE(IDC_EDIT_PINKY_FLEX_PROX_ROTATION_26, &CKinematicRotationCtrl::OnEnChangeEditPinkyFlexProxRotation26)
	ON_EN_CHANGE(IDC_EDIT_PINKY_FLEX_MID_ROTATION_27, &CKinematicRotationCtrl::OnEnChangeEditPinkyFlexMidRotation27)
	ON_EN_CHANGE(IDC_EDIT_PINKY_FLEX_DIST_ROTATION_28, &CKinematicRotationCtrl::OnEnChangeEditPinkyFlexDistRotation28)
	ON_EN_CHANGE(IDC_EDIT_WRIST_FLEX_ROTATION_29, &CKinematicRotationCtrl::OnEnChangeEditWristFlexRotation29)
	ON_EN_CHANGE(IDC_EDIT_WRIST_ABD_ROTATION_30, &CKinematicRotationCtrl::OnEnChangeEditWristAbdRotation30)
	ON_BN_CLICKED(IDC_BUTTON_IK_ACTIVE_TOUCH, &CKinematicRotationCtrl::OnBnClickedButtonIkActiveTouch)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_IK_ADVANCED, &CKinematicRotationCtrl::OnBnClickedButtonIkAdvanced)
END_MESSAGE_MAP()

void CKinematicRotationCtrl::OnEnChangeEditThumbRollRotation0()
{	
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_THUMB_ROLL_ROTATION_0)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_THUMB_ROLL, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditThumbAbdRotation1()
{	
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_THUMB_ABD_ROTATION_1)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_THUMB_ABD, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditThumbVirtualRotation2()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_THUMB_VIRTUAL_ROTATION_2)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_THUMB_VIRTUAL, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditThumbFlexProxRotation3()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_THUMB_FLEX_PROX_ROTATION_3)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_THUMB_FLEX_PROX, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditThumbDistRotation4()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_THUMB_DIST_ROTATION_4)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_THUMB_FLEX_DIST, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditIndexAbdPalmRotation5()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_INDEX_ABD_PALM_ROTATION_5)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_INDEX_ABD_PALM, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditIndexFlexPalmRotation6()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_INDEX_FLEX_PALM_ROTATION_6)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_INDEX_FLEX_PALM, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditIndexAbdRotation7()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_INDEX_ABD_ROTATION_7)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_INDEX_ABD, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditIndexFlexProxRotation8()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_INDEX_FLEX_PROX_ROTATION_8)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_INDEX_FLEX_PROX, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditIndexFlexMidRotation9()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_INDEX_FLEX_MID_ROTATION_9)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_INDEX_FLEX_MID, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditIndexFlexDistRotation10()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_INDEX_FLEX_DIST_ROTATION_10)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_INDEX_FLEX_DIST, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditMiddleAbdPalmRotation11()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_MIDDLE_ABD_PALM_ROTATION_11)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_MID_ABD_PALM, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditMiddleFlexPalmRotation12()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_MIDDLE_FLEX_PALM_ROTATION_12)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_MID_FLEX_PALM, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditMiddleAbdRotation13()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_MIDDLE_ABD_ROTATION_13)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_MID_ABD, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditMiddleFlexProxRotation14()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_MIDDLE_FLEX_PROX_ROTATION_14)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_MID_FLEX_PROX, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditMiddleFlexMidRotation15()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_MIDDLE_FLEX_MID_ROTATION_15)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_MID_FLEX_MID, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditMiddleFlexDistRotation16()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_MIDDLE_FLEX_DIST_ROTATION_16)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_MID_FLEX_DIST, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditRingAbdPalmRotation17()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_RING_ABD_PALM_ROTATION_17)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_RING_ABD_PALM, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditRingFlexPalmRotation18()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_RING_FLEX_PALM_ROTATION_18)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_RING_FLEX_PALM, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditRingAbdRotation19()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_RING_ABD_ROTATION_19)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_RING_ABD, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditRingFlexProxRotation20()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_RING_FLEX_PROX_ROTATION_20)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_RING_FLEX_PROX, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditRingFlexMidRotation21()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_RING_FLEX_MID_ROTATION_21)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_RING_FLEX_MID, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditRingFlexDistRotation22()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_RING_FLEX_DIST_ROTATION_22)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_RING_FLEX_DIST, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditPinkyAbdPalmRotation23()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_PINKY_ABD_PALM_ROTATION_23)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_PINKY_ABD_PALM,  _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditPinkyFlexPalmRotation24()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_PINKY_FLEX_PALM_ROTATION_24)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_PINKY_FLEX_PALM,_wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditPinkyAbdRotation25()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_PINKY_ABD_ROTATION_25)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_PINKY_ABD, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditPinkyFlexProxRotation26()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_PINKY_FLEX_PROX_ROTATION_26)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_PINKY_FLEX_PROX, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditPinkyFlexMidRotation27()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_PINKY_FLEX_MID_ROTATION_27)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_PINKY_FLEX_MID, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditPinkyFlexDistRotation28()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_PINKY_FLEX_DIST_ROTATION_28)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_PINKY_FLEX_DIST,  _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditWristFlexRotation29()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_WRIST_FLEX_ROTATION_29)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_WRIST_FLEX, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnEnChangeEditWristAbdRotation30()
{
	if(m_pFrmRaw == NULL)
		return;

	CString strText;
	GetDlgItem(IDC_EDIT_WRIST_ABD_ROTATION_30)->GetWindowText(strText);
	SynchronizePlayback(HAND_SKEL_DOF_WRIST_ABD, _wtof(strText.GetBuffer()));
}

void CKinematicRotationCtrl::OnBnClickedButtonIkActiveTouch()
{
	COneHandCtrl* pParent = dynamic_cast<COneHandCtrl*>(m_pParentWnd);
	if(((CButton*)GetDlgItem(IDC_CHECK_UPDATE_TO_CLIP))->GetCheck() && m_pParentWnd)
	{
		if(pParent && pParent->m_ctrlPlayback.m_pClipRaw != NULL)
			TouchClip(*pParent->m_ctrlPlayback.m_pClipRaw);
	}
	TouchFrame(*m_pFrmRaw);
	UpdateFrameToUI();
	pParent->m_ctrlPlayback.RefreshOpenGL();
}

HBRUSH CKinematicRotationCtrl::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	if(m_bRealtimeMocap && 
		(pWnd->GetDlgCtrlID() == IDC_EDIT_THUMB_ROLL_ROTATION_0 || 
		pWnd->GetDlgCtrlID() == IDC_EDIT_THUMB_ABD_ROTATION_1 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_THUMB_VIRTUAL_ROTATION_2 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_THUMB_FLEX_PROX_ROTATION_3 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_THUMB_DIST_ROTATION_4 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_INDEX_ABD_PALM_ROTATION_5 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_INDEX_FLEX_PALM_ROTATION_6 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_INDEX_ABD_ROTATION_7 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_INDEX_FLEX_PROX_ROTATION_8 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_INDEX_FLEX_MID_ROTATION_9 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_INDEX_FLEX_DIST_ROTATION_10 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_MIDDLE_ABD_PALM_ROTATION_11 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_MIDDLE_FLEX_PALM_ROTATION_12 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_MIDDLE_ABD_ROTATION_13 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_MIDDLE_FLEX_PROX_ROTATION_14 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_MIDDLE_FLEX_MID_ROTATION_15 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_MIDDLE_FLEX_DIST_ROTATION_16 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_RING_ABD_PALM_ROTATION_17 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_RING_FLEX_PALM_ROTATION_18 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_RING_ABD_ROTATION_19 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_RING_FLEX_PROX_ROTATION_20 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_RING_FLEX_MID_ROTATION_21 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_RING_FLEX_DIST_ROTATION_22 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_PINKY_ABD_PALM_ROTATION_23 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_PINKY_FLEX_PALM_ROTATION_24 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_PINKY_ABD_ROTATION_25 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_PINKY_FLEX_PROX_ROTATION_26 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_PINKY_FLEX_MID_ROTATION_27 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_PINKY_FLEX_DIST_ROTATION_28 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_WRIST_FLEX_ROTATION_29 ||
		pWnd->GetDlgCtrlID() == IDC_EDIT_WRIST_ABD_ROTATION_30))
	{
		pDC->SetTextColor(RGB(255, 0, 0));
	}
	return hbr;
}

void CKinematicRotationCtrl::OnBnClickedButtonIkAdvanced()
{
	COneHandCtrl* pParent = dynamic_cast<COneHandCtrl*>(m_pParentWnd);
	CHandSkeletonKin hand(!m_bLeft);
	hand.UpdateFromKinematicData(m_pFrmRaw->m_arData);
	CIKSolverDlg2 dlg(hand.m_pHand);
	if(IDOK == dlg.DoModal())
	{
		hand.UpdateToKinematicData(m_pFrmRaw->m_arData);
		if(pParent)
			pParent->m_ctrlPlayback.RefreshOpenGL();
	}	
}
