#include "stdafx.h"
#include "RawTimeAnimation.h"
#include <fstream>
#include "math.h"


CRawTimeClip::CRawTimeClip()
{

}
CRawTimeClip::CRawTimeClip(CRawClip clipMotion, CGlvClip clipTime)
{
	m_arTime = clipTime.GetTimeArray();
	m_arFrame = clipMotion.m_arFrame;
}
void CRawTimeClip::LoadFromFile(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	m_arFrame.clear();
	m_arTime.clear();

	while(fin.good())
	{
		char buf[1024] = {0};
		fin.getline(buf, sizeof(buf));
		CRawFrame frm;
		CString strData(buf);
		int iStart = 0, iEnd = strData.Find(L" ");
		CString strTime = strData.Mid(iStart, iEnd - iStart);
		float fTime = _wtof(strTime.GetBuffer());

		iStart = iEnd + 1;
		iEnd = strData.Find(L" ", iStart);
		int iCount = 0;
		while(iEnd > iStart)
		{
			CString strOneData = strData.Mid(iStart, iEnd - iStart);
			strOneData.Trim();
			float fData = _wtof(strOneData);
			frm.m_arData.push_back(fData);
			iStart = iEnd + 1;
			iEnd = strData.Find(L" ", iStart);
		}
		//last one
		CString strOneData = strData.Mid(iStart);
		strOneData.Trim();
		if(!strOneData.IsEmpty())
		{
			float fData = _wtof(strOneData);
			frm.m_arData.push_back(fData);
		}

		if(frm.m_arData.size() != 0)
		{
			m_arFrame.push_back(frm);
			m_arTime.push_back(fTime);
		}
	}
}

void CRawTimeClip::SaveToFile(std::string strPath)
{
	ASSERT(m_arTime.size() == m_arFrame.size());

	std::ofstream fout(strPath.c_str());
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		fout << m_arTime[i];
		CRawFrame frmRaw = m_arFrame[i];
		for(int j = 0; j < frmRaw.m_arData.size(); ++ j)
		{
			fout << " " << frmRaw.m_arData[j];
		}
		fout << std::endl;
	}
	fout.flush();
	fout.close();
}

CRawClip CRawTimeClip::ReSample(float fRateMS, bool bAbsoluteTime)
{
	CRawClip clipResampled;
	int i = 0;
	while(true)
	{
		int iNowTime = i * fRateMS;
		//find the related frames
		int j = 0;
		float fAbsTime = 0, fAbsTimePrev = 0;
		for(; j < m_arTime.size(); ++j)
		{
			fAbsTimePrev = fAbsTime;
			if(bAbsoluteTime)
				fAbsTime = m_arTime[j] * 1000;
			else
				fAbsTime += (m_arTime[j] * 1000);

			if(fAbsTime > iNowTime)
				break;
		}
		//not found, end
		if(j==m_arTime.size())
			break;

		//this should not happen
		if(j==0)
		{
			clipResampled.m_arFrame.push_back(m_arFrame[0]);
			i ++;
			continue;
		}

		CRawFrame frmBeg = m_arFrame[j-1];
		CRawFrame frmEnd = m_arFrame[j];
		float fCoeff = (iNowTime - fAbsTimePrev) / (fAbsTime - fAbsTimePrev);
		CRawFrame frmResampled = CRawFrame::InterpolateBetween(frmBeg, frmEnd, fCoeff);
		clipResampled.m_arFrame.push_back(frmResampled);
		i ++;
	};
	return clipResampled;
}