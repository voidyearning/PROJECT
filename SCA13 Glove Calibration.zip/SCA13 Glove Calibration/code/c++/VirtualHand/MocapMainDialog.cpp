// MocapMainDialog.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "MocapMainDialog.h"


// CMocapMainDialog dialog

IMPLEMENT_DYNAMIC(CMocapMainDialog, CDialog)

CMocapMainDialog::CMocapMainDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMocapMainDialog::IDD, pParent), m_ctrlLeftHand(true), m_ctrlRightHand(false)
{
}

CMocapMainDialog::~CMocapMainDialog()
{
}

void CMocapMainDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CMocapMainDialog::OnInitDialog()
{
	//create sub window and show in accurate location
	CRect rcLeft, rcRight, rcMocap, rcParent, rcParentClient;
	GetDlgItem(IDC_STATIC_LEFT_HAND_CTRL)->GetWindowRect(rcLeft);
	GetDlgItem(IDC_STATIC_RIGHT_HAND_CTRL)->GetWindowRect(rcRight);
	GetDlgItem(IDC_STATIC_MOCAP_CTRL)->GetWindowRect(rcMocap);

	GetWindowRect(rcParent);
	GetClientRect(rcParentClient);
	int iDifference = rcParent.Height() - rcParentClient.Height();
	rcParent.top = rcParent.top + iDifference;

	rcLeft.MoveToXY(rcLeft.left-rcParent.left, rcLeft.top-rcParent.top);
	rcRight.MoveToXY(rcRight.left-rcParent.left, rcRight.top-rcParent.top);
	rcMocap.MoveToXY(rcMocap.left-rcParent.left, rcMocap.top-rcParent.top);

	m_ctrlLeftHand.Create(IDD_CTRL_ONE_HAND_LEFT, this);
	m_ctrlRightHand.Create(IDD_CTRL_ONE_HAND_RIGHT, this);
	m_ctrlMocap.Create(IDD_CTRL_MOCAP, this);

	m_ctrlLeftHand.MoveWindow(rcLeft);
	m_ctrlRightHand.MoveWindow(rcRight);
	m_ctrlMocap.MoveWindow(rcMocap);
	m_ctrlMocap.BringWindowToTop();

	return CDialog::OnInitDialog();
}
BEGIN_MESSAGE_MAP(CMocapMainDialog, CDialog)
END_MESSAGE_MAP()


// CMocapMainDialog message handlers
