#include "stdafx.h"
#include "GloveSkeleton.h"
#include "GloveAnimation.h"
#include "GloveUtil.h"
#include <fstream>
using namespace GloveUtil;


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
CHandSkeletonKin::CHandSkeletonKin()
{
	m_bRightHand = false;
	m_pHand = new CKinematicHandLeft();
	m_fWristAbd = 0;
	m_fWristFlex = 0;
	Init();
}
CHandSkeletonKin::CHandSkeletonKin(bool bRightHand)
{
	m_bRightHand = bRightHand;
	m_fWristAbd = 0;
	m_fWristFlex = 0;
	if(m_bRightHand)
		m_pHand = new CKinematicHandRight();
	else
		m_pHand = new CKinematicHandLeft();
	Init();
}
CHandSkeletonKin::~CHandSkeletonKin()
{
	delete m_pHand;
}

void CHandSkeletonKin::SetActiveFlag(short sActiveFinger)
{
	m_pHand->SetActiveFlag(sActiveFinger);
}
void CHandSkeletonKin::UnsetActiveFlag(short sActiveFinger)
{
	m_pHand->UnsetActiveFlag(sActiveFinger);
}
bool CHandSkeletonKin::IsFingerActive(short sActiveFinger)
{
	return m_pHand->IsFingerActive(sActiveFinger);
}
double CHandSkeletonKin::GetActiveProbability(CKinematicPos posEnd)
{
	return m_pHand->GetActiveProbability(posEnd);
}
void CHandSkeletonKin::Init()
{
	m_fWristAbd = 0;
	m_fWristFlex = 0;
	m_pHand->ConstructHand();
}
void CHandSkeletonKin::InitMotion()
{
	m_fWristAbd = 0;
	m_fWristFlex = 0;
	m_pHand->SetDefaultPose();
}

void CHandSkeletonKin::InitMotionLeft()
{
	if(m_bRightHand == false)
		InitMotion();
	else
	{
		m_bRightHand = false;
		delete m_pHand;
		m_pHand = new CKinematicHandLeft();
		m_pHand->ConstructHand();
	}
}
void CHandSkeletonKin::InitMotionRight()
{
	if(m_bRightHand == true)
		InitMotion();
	else
	{
		m_bRightHand = true;
		delete m_pHand;
		m_pHand = new CKinematicHandRight();
		m_pHand->ConstructHand();
	}
}
void CHandSkeletonKin::UpdateFromFrame(CBaseFrame* pFrame)
{
	if(pFrame == NULL) 
		return;

	CRawFrame* pRawFrame = dynamic_cast<CRawFrame*>(pFrame);
	if(pRawFrame)
		return UpdateFromKinematicData(pRawFrame->m_arData);

	CGlvFrame* pGlvFrame = dynamic_cast<CGlvFrame*>(pFrame);
	if(pGlvFrame)
		return UpdateFromSensorData(pGlvFrame->m_arData);
}
void CHandSkeletonKin::UpdateToFrame(CBaseFrame* pFrame)
{	
	if(pFrame == NULL) 
		return;

	CRawFrame* pRawFrame = dynamic_cast<CRawFrame*>(pFrame);
	if(pRawFrame)
		return UpdateToKinematicData(pRawFrame->m_arData);

	CGlvFrame* pGlvFrame = dynamic_cast<CGlvFrame*>(pFrame);
	if(pGlvFrame)
		return UpdateToSensorData(pGlvFrame->m_arData);
}
void CHandSkeletonKin::UpdateToSensorData(std::vector<float>& arSensorData)
{
	arSensorData[CGlvStructre::glv_wristPitch] = GloveUtil::DegreeToRadian(m_fWristFlex);
	arSensorData[CGlvStructre::glv_wristYaw] = GloveUtil::DegreeToRadian(m_fWristAbd);
	m_pHand->UpdateToSensorData(arSensorData);
}
void CHandSkeletonKin::UpdateFromSensorData(const std::vector<float>& arSensorData)
{
	if(arSensorData.size() == 0)
		return;

	m_fWristFlex = GloveUtil::RadianToDegree(arSensorData[CGlvStructre::glv_wristPitch]);
	m_fWristAbd = GloveUtil::RadianToDegree(arSensorData[CGlvStructre::glv_wristYaw]);

	m_pHand->UpdateFromSensorData(arSensorData);
}

void CHandSkeletonKin::UpdateFromKinematicData(const std::vector<float>& arKinData)
{
	if(arKinData.size() == 0)
		return;

	m_pHand->UpdateFromKinematicData(arKinData);
	m_fWristFlex = arKinData[arKinData.size()-2];
	m_fWristAbd = arKinData[arKinData.size()-1];
}
void CHandSkeletonKin::UpdateToKinematicData(std::vector<float>& arKinData)
{
	m_pHand->UpdateToKinematicData(arKinData);
	arKinData.push_back(m_fWristFlex);
	arKinData.push_back(m_fWristAbd);
}

void CHandSkeletonKin::FingerTouchingSampling(IK_FINGER_TOUCHING_TYPE eTouchingType, CBaseClip* pClipSrc, CBaseClip* pClipDest)
{
	//glv_src -> glv_dest
	if(dynamic_cast<CGlvClip*>(pClipSrc) != NULL && 
		dynamic_cast<CGlvClip*>(pClipDest) != NULL)
	{	
		FingerTouchingSampling(eTouchingType, *(CGlvClip*)pClipSrc, *(CGlvClip*)pClipDest);
		return;
	}
	
	if(dynamic_cast<CGlvClip*>(pClipSrc) != NULL && 
		dynamic_cast<CRawClip*>(pClipDest) != NULL)
	{	
		FingerTouchingSampling(eTouchingType, *(CGlvClip*)pClipSrc, *(CRawClip*)pClipDest);
		return;
	}

	if(dynamic_cast<CRawClip*>(pClipSrc) != NULL && 
		dynamic_cast<CRawClip*>(pClipDest) != NULL)
	{	
		FingerTouchingSampling(eTouchingType, *(CRawClip*)pClipSrc, *(CRawClip*)pClipDest);
		return;
	}

}
std::vector<CKinematicPos> g_arGoal;
void CHandSkeletonKin::SmoothenFingerTouchingSampling(IK_FINGER_TOUCHING_TYPE eTouchingType, CRawClip& inputClip, CRawClip& outputClip)
{
	outputClip.m_arFrame.clear();

	//set finger and thumb
	CKinematicHand::HAND_CHAIN_ID eFingerChainId;
	int iFingerStartIdx = 0;
	switch(eTouchingType)
	{
	case eThumbIndex: eFingerChainId = CKinematicHand::HAND_CHAIN_ID::E_CHAIN_INDEX; 
		iFingerStartIdx = HAND_SKEL_DOF_INDEX_ABD_PALM;break; 
	case eThumbMid: eFingerChainId = CKinematicHand::HAND_CHAIN_ID::E_CHAIN_MID; 	
		iFingerStartIdx = HAND_SKEL_DOF_MID_ABD_PALM; break;
	case eThumbRing: eFingerChainId = CKinematicHand::HAND_CHAIN_ID::E_CHAIN_RING; 
		iFingerStartIdx = HAND_SKEL_DOF_RING_ABD_PALM; break;
	case eThumbPinky: eFingerChainId = CKinematicHand::HAND_CHAIN_ID::E_CHAIN_PINKY; 
		iFingerStartIdx = HAND_SKEL_DOF_PINKY_ABD_PALM; break;
	}
	CKinematicChain* pFingerChain = m_pHand->GetChain(eFingerChainId);
	CKinematicChain* pThumbChain = m_pHand->m_arChain[0];

	//check failed frames
	int iLastSucFinger = 0, iLastSucThumb = 0;//let first frame always be succeeded
	for(int i = 0; i < inputClip.m_arFrame.size(); ++i)
	{
		CRawFrame frmCurInput = inputClip.m_arFrame[i];
		CKinematicPos posGoal = g_arGoal[i];
		m_fWristFlex = GloveUtil::RadianToDegree(frmCurInput.m_arData[HAND_SKEL_DOF_WRIST_FLEX]);
		m_fWristAbd = GloveUtil::RadianToDegree(frmCurInput.m_arData[HAND_SKEL_DOF_WRIST_ABD]);
		m_pHand->UpdateFingerFromKinematicData(CKinematicHand::HAND_CHAIN_ID::E_CHAIN_THUMB, frmCurInput.m_arData);
		m_pHand->UpdateFingerFromKinematicData(eFingerChainId, frmCurInput.m_arData);
		pThumbChain->m_posGoal = posGoal;
		pFingerChain->m_posGoal = posGoal;
		bool bThumbFail = pThumbChain->IsFailedIK(), bFingerFail = pFingerChain->IsFailedIK();

		if(!bThumbFail)
		{
			//do the interpolation for the previous failure gap
			CRawFrame frmLastSucThumb = inputClip.m_arFrame[iLastSucThumb];
			for(int f=iLastSucThumb+1; f < i; ++f)
			{
				double fRatio = (double)(f-iLastSucThumb) / (double)(i-iLastSucThumb);
				CRawFrame frmFailedOutput = outputClip.m_arFrame[f];
				frmFailedOutput.m_arData[HAND_SKEL_DOF_THUMB_ROLL] = fRatio * frmCurInput.m_arData[HAND_SKEL_DOF_THUMB_ROLL] + 
					(1-fRatio) * frmLastSucThumb.m_arData[HAND_SKEL_DOF_THUMB_ROLL];
				frmFailedOutput.m_arData[HAND_SKEL_DOF_THUMB_ABD] = fRatio * frmCurInput.m_arData[HAND_SKEL_DOF_THUMB_ABD] + 
					(1-fRatio) * frmLastSucThumb.m_arData[HAND_SKEL_DOF_THUMB_ABD];
				frmFailedOutput.m_arData[HAND_SKEL_DOF_THUMB_VIRTUAL] = fRatio * frmCurInput.m_arData[HAND_SKEL_DOF_THUMB_VIRTUAL] + 
					(1-fRatio) * frmLastSucThumb.m_arData[HAND_SKEL_DOF_THUMB_VIRTUAL];
				frmFailedOutput.m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX] = fRatio * frmCurInput.m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX] + 
					(1-fRatio) * frmLastSucThumb.m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX];
				frmFailedOutput.m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST] = fRatio * frmCurInput.m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST] + 
					(1-fRatio) * frmLastSucThumb.m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST];
				outputClip.m_arFrame[f] = frmFailedOutput;
			}
			iLastSucThumb = i;
		}
		 
		if(!bFingerFail)
		{
			CRawFrame frmLastSucFinger = inputClip.m_arFrame[iLastSucFinger];
			for(int f=iLastSucFinger+1; f < i; ++f)
			{
				double fRatio = (double)(f-iLastSucFinger) / (double)(i-iLastSucFinger);
				CRawFrame frmFailedOutput = outputClip.m_arFrame[f];
				for(int d = iFingerStartIdx; d < iFingerStartIdx + 6; ++d)
				{
					frmFailedOutput.m_arData[d] = fRatio * frmCurInput.m_arData[d] + (1-fRatio) * frmLastSucFinger.m_arData[d];
				}
				outputClip.m_arFrame[f] = frmFailedOutput;	
			}
			iLastSucFinger = i;
		}
		outputClip.m_arFrame.push_back(frmCurInput);
	}//end of for loop
}
void CHandSkeletonKin::FingerTouchingSampling(IK_FINGER_TOUCHING_TYPE eTouchingType, CGlvClip& inputClip, CGlvClip& outputClip)
{
	for(int i = 0; i < inputClip.m_arFrame.size(); ++i)
	{
		CGlvFrame inputFrame = inputClip.m_arFrame[i];
		UpdateFromSensorData(inputFrame.m_arData);
		m_pHand->PopulateGlobalPosAndAxis();
		m_pHand->PleaseTouch(eTouchingType);
		CGlvFrame outputFrame = CGlvFrame::GetEmptyFrame();
		UpdateToSensorData(outputFrame.m_arData);
		outputFrame.m_fTime = inputFrame.m_fTime;
		outputClip.m_arFrame.push_back(outputFrame);
	}
}
void  CHandSkeletonKin::FingerTouchingSampling(IK_FINGER_TOUCHING_TYPE eTouchingType, CRawClip& inputClip, CRawClip& outputClip)
{
	for(int i = 0; i < inputClip.m_arFrame.size(); ++i)
	{
		CRawFrame inputFrame = inputClip.m_arFrame[i];
		UpdateFromKinematicData(inputFrame.m_arData);
		m_pHand->PopulateGlobalPosAndAxis();
		//find out this most close calibrated one
		float fDistMin = 100000;
		int iIdxMin = -1;
		for(int j = 0; j < i; ++j)
		{
			CRawFrame inputFramePrev = inputClip.m_arFrame[j];
			float fDistThis = inputFramePrev.DistanceToThumb(inputFrame);
			if(fDistThis < fDistMin)
			{
				fDistMin = fDistThis;
				iIdxMin = j;
			}
		}
		//use the calibrated as initial pose
		if(iIdxMin>0)
			inputFrame = outputClip.m_arFrame[iIdxMin];		
		m_pHand->UpdateFingerFromKinematicData(CKinematicHand::HAND_CHAIN_ID::E_CHAIN_THUMB, inputFrame.m_arData);
		m_pHand->PopulateGlobalPosAndAxis();
		m_pHand->PleaseTouch(eTouchingType);		
		CRawFrame outputFrame;
		UpdateToKinematicData(outputFrame.m_arData);
		outputClip.m_arFrame.push_back(outputFrame);
	}
}
void CHandSkeletonKin::FingerTouchingSampling(CIKClip& inputClip, CRawClip& outputClip)
{
	for(int i = 0; i < inputClip.m_arFrame.size(); ++i)
	{
		CIKFrame inputFrame = inputClip.m_arFrame[i];
		UpdateFromKinematicData(inputFrame.m_arData);
		m_pHand->PopulateGlobalPosAndAxis();
		//find out this most close calibrated one
		float fDistMin = 100000;
		int iIdxMin = -1;
		for(int j = 0; j < i; ++j)
		{
			CIKFrame inputFramePrev = inputClip.m_arFrame[j];
			float fDistThis = inputFramePrev.DataDistanceToThumb(inputFrame);
			if(fDistThis < fDistMin)
			{
				fDistMin = fDistThis;
				iIdxMin = j;
			}
		}
		//use the calibrated as initial pose
		//iIdxMin = i-1;//temporary try the prev one
		if(iIdxMin>0)
		{
			CRawFrame frmPreCalibrated = outputClip.m_arFrame[iIdxMin];		
			m_pHand->UpdateFingerFromKinematicData(CKinematicHand::HAND_CHAIN_ID::E_CHAIN_THUMB, frmPreCalibrated.m_arData);
			m_pHand->PopulateGlobalPosAndAxis();
		}
		m_pHand->PleaseTouchAt(CKinematicPoint(inputFrame.m_fGoalX, inputFrame.m_fGoalY, inputFrame.m_fGoalZ));		
		CRawFrame outputFrame;
		UpdateToKinematicData(outputFrame.m_arData);
		outputClip.m_arFrame.push_back(outputFrame);
	}
}
//Wangyy TODO: һ��Ϊʲô�����ô��Լ��һ����
extern bool g_bSmoothenByFK;
extern bool g_bContinuousIK;
extern double g_fRatioToFinger;
void  CHandSkeletonKin::FingerTouchingSampling(IK_FINGER_TOUCHING_TYPE eTouchingType, CGlvClip& inputClip, CRawClip& outputClip)
{
	/*for(int i = 0; i < inputClip.m_arFrame.size(); ++i)
	{
		CGlvFrame inputFrame = inputClip.m_arFrame[i];
		UpdateFromSensorData(inputFrame.m_arData);
		m_pHand->PleaseTouch(eTouchingType);
		CRawFrame outputFrame;
		UpdateToKinematicData(outputFrame.m_arData);
		outputClip.m_arFrame.push_back(outputFrame);
	}*/

	//��һ֡��ʼ״̬ȡinput��״̬
	//֮��֡��ʼ״̬ȡǰһ֡��У���״̬��ֻ��goalȡinput��
	CKinematicHand::HAND_CHAIN_ID eFingerChainId;
	switch(eTouchingType)
	{
	case eThumbIndex: eFingerChainId = CKinematicHand::HAND_CHAIN_ID::E_CHAIN_INDEX; break; 
	case eThumbMid: eFingerChainId = CKinematicHand::HAND_CHAIN_ID::E_CHAIN_MID; 	break;
	case eThumbRing: eFingerChainId = CKinematicHand::HAND_CHAIN_ID::E_CHAIN_RING; break;
	case eThumbPinky: eFingerChainId = CKinematicHand::HAND_CHAIN_ID::E_CHAIN_PINKY; break;
	}
	CKinematicChain* pFingerChain = m_pHand->GetChain(eFingerChainId);
	CKinematicChain* pThumbChain = m_pHand->m_arChain[0];
	
	CRawFrame outputFrame;
	g_arGoal.clear();
	for(int i = 0; i < inputClip.m_arFrame.size(); ++i)
	{
		CGlvFrame inputFrame = inputClip.m_arFrame[i];
		m_fWristFlex = GloveUtil::RadianToDegree(inputFrame.m_arData[CGlvStructre::glv_wristPitch]);
		m_fWristAbd = GloveUtil::RadianToDegree(inputFrame.m_arData[CGlvStructre::glv_wristYaw]);

		m_pHand->UpdateFingerFromSensorData(CKinematicHand::HAND_CHAIN_ID::E_CHAIN_THUMB, inputFrame.m_arData);
		pThumbChain->PopulateGlobalPosAndAxis();
		CKinematicPos posThumbTip = pThumbChain->GetGlobalEndEffectorPos();

		m_pHand->UpdateFingerFromSensorData(eFingerChainId, inputFrame.m_arData);
		pFingerChain->PopulateGlobalPosAndAxis();
		CKinematicPos posFingerTip = pFingerChain->GetGlobalEndEffectorPos();

		//calculate goal pos
		double fRatioToFinger = g_fRatioToFinger;
		CKinematicPos posGoal(fRatioToFinger*posFingerTip.m_fX+(1-fRatioToFinger)*posThumbTip.m_fX, 
			fRatioToFinger*posFingerTip.m_fY + (1-fRatioToFinger)*posThumbTip.m_fY, 
			fRatioToFinger*posFingerTip.m_fZ + (1-fRatioToFinger)*posThumbTip.m_fZ);
		g_arGoal.push_back(posGoal);

		//initial pos
		if(g_bContinuousIK)
		{
			if(i!=0)
			{
				m_pHand->UpdateFingerFromKinematicData(CKinematicHand::HAND_CHAIN_ID::E_CHAIN_THUMB, outputFrame.m_arData);
				m_pHand->UpdateFingerFromKinematicData(eFingerChainId, outputFrame.m_arData);
			}
		}
		//m_pHand->PleaseTouch(eTouchingType);
		m_pHand->PleaseTouchAt(eTouchingType, posGoal);
		/*if(pThumbChain->IsFailedIK() && i != 0)//still cannot reach it
		{
			if(g_bContinuousIK)
				m_pHand->UpdateFingerFromKinematicData(CKinematicHand::HAND_CHAIN_ID::E_CHAIN_THUMB, outputFrame.m_arData);
		}*/

		UpdateToKinematicData(outputFrame.m_arData);
		outputClip.m_arFrame.push_back(outputFrame);
	}
	if(g_bSmoothenByFK)
	{
		CRawClip outputClipSM;
		SmoothenFingerTouchingSampling(eTouchingType, outputClip, outputClipSM);
		outputClip = outputClipSM;
	}
}
void CHandSkeletonKin::FingerTouchingSamplingConcatenated(IK_FINGER_TOUCHING_TYPE eTouchingType, CGlvClip& inputClip, CRawClip& outputClip, std::vector<float>& arGain, std::vector<float>& arOffset)
{
	m_pHand->PleaseTouchClip(eTouchingType, arGain, arOffset, inputClip, outputClip);
}
string CHandSkeletonKin::GetBvhHeader()
{
	return m_pHand->GetBvhHeader();
}
string CHandSkeletonKin::GetASF()
{
	return m_pHand->GetASF();
}
string CHandSkeletonKin::GetBvhHeaderConsistentWithBody()
{
	return m_pHand->GetBvhHeaderConsistentWithBody();
}
string CHandSkeletonKin::GetBvhOneFrame()
{
	string strBvh = "";
	strBvh.append(m_pHand->GetBvhHeader());
	strBvh.append("MOTION\r\nFrame Time: 0.0469999\r\nFrames: 1\r\n");
	char buffer[50];
	sprintf(buffer, "%f %f ", this->m_fWristAbd, this->m_fWristFlex);
	strBvh.append(buffer);
	strBvh.append(m_pHand->GetBvhData());
	return strBvh;
}
void CHandSkeletonKin::LoadSizeFromFile(CString strPath)
{
	if(m_pHand)
		m_pHand->LoadHandSize(GloveUtil::ToChar(strPath));
}
void CHandSkeletonKin::SaveSizeToFile(CString strPath)
{
	if(m_pHand)
		m_pHand->SaveHandSize(GloveUtil::ToChar(strPath));
}
void CHandSkeletonKin::ExportTrajectory(CRawClip clipRaw, int iTrjIndex, std::string strPath)
{
	if(m_pHand)
		m_pHand->ExportTrajectory(clipRaw, iTrjIndex, strPath);
}
void CHandSkeletonKin::ExportTipDistance(CRawClip clipRaw, IK_FINGER_TOUCHING_TYPE eTouchingType, std::string strPath)
{
	if(m_pHand)
		m_pHand->ExportTipDistance(clipRaw, eTouchingType, strPath);
}
void CHandSkeletonKin::ExportBvh(CRawClip clipRaw, std::string strPath)
{
	std::string strHeader = this->GetBvhHeader();
	clipRaw.SaveToBvh(strPath, strHeader);
}

