#include "MatlabUtil.h"
#include "GloveUtil.h"
#include "string.h"
using namespace std;

Engine* CMatlabEngine::s_pMatlabEngine = NULL;


void MatlabUtil::Test1()
{
	int iFrameNum = 10;
	double* arFlexDifference = new double[iFrameNum];	
	double* arAbdSensor = new double[iFrameNum];	
	double* arAbdReal = new double[iFrameNum];
	for(int i = 0; i < iFrameNum; ++i)
	{
		arFlexDifference[i] = i;
		arAbdSensor[i] = -i;
		arAbdReal[i] = i-5;
	}

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	mxArray* pMxFlexDifference = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxFlexDifference, "flexDifference");
	memcpy(mxGetPr(pMxFlexDifference), (double*)arFlexDifference, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "flexDifference", pMxFlexDifference);
	
	mxArray* pMxAbdSensor = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdSensor, "abdSensor");
	memcpy(mxGetPr(pMxAbdSensor), (double*)arAbdSensor, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdSensor", pMxAbdSensor);
	
	mxArray* pMxAbdReal = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdReal, "abdReal");
	memcpy(mxGetPr(pMxAbdReal), (double*)arAbdReal, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdReal", pMxAbdReal);

	char strCmd[200];
	sprintf(strCmd, "figure;scatter3(flexDifference,abdSensor, abdReal);");	
	engEvalString(pMatlabEngine,strCmd);

	//release
    delete arFlexDifference;
	delete arAbdSensor;
	delete arAbdReal;
	mxDestroyArray(pMxFlexDifference);
	mxDestroyArray(pMxAbdSensor);
	mxDestroyArray(pMxAbdReal);
}
void MatlabUtil::Test2()
{
	int iFrameNum = 10;
	double* arAbdReal = new double[iFrameNum];
	for(int i = 0; i < iFrameNum; ++i)
	{
		arAbdReal[i] = -i+5;
	}

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	
	mxArray* pMxAbdReal = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdReal, "abdReal");
	memcpy(mxGetPr(pMxAbdReal), (double*)arAbdReal, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdReal", pMxAbdReal);

	char strCmd[200];
	sprintf(strCmd, "figure;scatter3(flexDifference,abdSensor, abdReal, 'r+');");	
	engEvalString(pMatlabEngine,strCmd);
}

void MatlabUtil::PlotPair(CRawClip& clipSrc, int iIdxSrc, CRawClip& clipDest, int iIdxDest)
{
	if(clipSrc.m_arFrame.size() != clipDest.m_arFrame.size())
		return;
	int iSize = clipSrc.m_arFrame.size();
	double* arSrc = new double [iSize];
	double* arDest = new double [iSize];
	for(int i = 0; i < clipSrc.m_arFrame.size(); ++i)
	{
		CRawFrame frmSrc = clipSrc.m_arFrame[i];
		CRawFrame frmDest = clipDest.m_arFrame[i];
		arSrc[i] = frmSrc.m_arData[iIdxSrc];
		arDest[i] = frmDest.m_arData[iIdxDest];
	}

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	mxArray* pMxSrc = mxCreateDoubleMatrix(1, iSize, mxREAL);
	mxSetClassName(pMxSrc, "arSrc");
	memcpy(mxGetPr(pMxSrc), (double*)arSrc, iSize*sizeof(double));
	engPutVariable(pMatlabEngine, "arSrc", pMxSrc);

	mxArray* pMxDest = mxCreateDoubleMatrix(1, iSize, mxREAL);
	mxSetClassName(pMxDest, "arDest");
	memcpy(mxGetPr(pMxDest), (double*)arDest, iSize*sizeof(double));
	engPutVariable(pMatlabEngine, "arDest", pMxDest);

	engEvalString(pMatlabEngine, "plot(arSrc, arDest)");

	delete arSrc;
	delete arDest;
	mxDestroyArray(pMxSrc);
	mxDestroyArray(pMxDest);
}
void MatlabUtil::PlotGlvClip(CGlvClip& clipGlv)
{
	int iFrameNum = clipGlv.m_arFrame.size();
	if(iFrameNum == 0)
		return;
	int iKinSize = clipGlv.m_arFrame[0].m_arData.size();
	if(iKinSize == 0)
		return;
	//row: iKinSize; col: iFrameNum
	double** arClipAllData = new double*[iKinSize];
	for(int k = 0; k < iKinSize; ++k)
		arClipAllData[k] = new double[iFrameNum];

	//populate data
	for(int i = 0; i < iFrameNum; ++i)
	{
		CGlvFrame frmGlv = clipGlv.m_arFrame[i];
		for(int j = 0; j < iKinSize; ++j)
		{
			arClipAllData[j][i] = frmGlv.m_arData[j];
		}
	}
	//plot each sensor along timeline
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	char strCmd[200];
	sprintf(strCmd, "figure;ColorSet = varycolor(%d);set(gca, 'ColorOrder', ColorSet);hold all;", iKinSize);
	engEvalString(pMatlabEngine, strCmd);
	for(int k = 0; k < iKinSize; ++k)
	{
		mxArray* pMxOneData = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
		char dataName[20];
		sprintf(dataName, "data%d", k);
		mxSetClassName(pMxOneData, dataName);
		memcpy(mxGetPr(pMxOneData), (double*)arClipAllData[k], iFrameNum*sizeof(double));
		engPutVariable(pMatlabEngine, dataName, pMxOneData);

		char strCmd[200];
		sprintf(strCmd, "plot(%s);", dataName);	
		engEvalString(pMatlabEngine,strCmd);
		mxDestroyArray(pMxOneData);
	}
	engEvalString(pMatlabEngine, "hold off;");
	//release data
	for(int k = 0; k < iKinSize; ++k)
		delete arClipAllData[k];
	delete arClipAllData;

}
void MatlabUtil::PlotRawClip(CRawClip& clipRaw)
{
	int iFrameNum = clipRaw.m_arFrame.size();
	if(iFrameNum == 0)
		return;
	int iKinSize = clipRaw.m_arFrame[0].m_arData.size();
	if(iKinSize == 0)
		return;
	//row: iKinSize; col: iFrameNum
	double** arClipAllData = new double*[iKinSize];
	for(int k = 0; k < iKinSize; ++k)
		arClipAllData[k] = new double[iFrameNum];

	//populate data
	for(int i = 0; i < iFrameNum; ++i)
	{
		CRawFrame frmRaw = clipRaw.m_arFrame[i];
		for(int j = 0; j < iKinSize; ++j)
		{
			arClipAllData[j][i] = frmRaw.m_arData[j];
		}
	}
	//plot each sensor along timeline
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	char strCmd[200];
	sprintf(strCmd, "figure;ColorSet = varycolor(%d);set(gca, 'ColorOrder', ColorSet);hold all;", iKinSize);
	engEvalString(pMatlabEngine, strCmd);
	for(int k = 0; k < iKinSize; ++k)
	{
		mxArray* pMxOneData = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
		char dataName[20];
		sprintf(dataName, "data%d", k);
		mxSetClassName(pMxOneData, dataName);
		memcpy(mxGetPr(pMxOneData), (double*)arClipAllData[k], iFrameNum*sizeof(double));
		engPutVariable(pMatlabEngine, dataName, pMxOneData);

		char strCmd[200];
		sprintf(strCmd, "plot(%s);", dataName);	
		engEvalString(pMatlabEngine,strCmd);
		mxDestroyArray(pMxOneData);
	}
	engEvalString(pMatlabEngine, "hold off;");
	//release data
	for(int k = 0; k < iKinSize; ++k)
		delete arClipAllData[k];
	delete arClipAllData;
}
void MatlabUtil::PlotCrossAbd(CRawClip clipRaw,  char cMarkerType, char cMarkerColor, bool bNewFigure, bool bPlot3)
{
	int iFrameNum = clipRaw.m_arFrame.size();
	double* arLeftFlex = new double[iFrameNum];	
	double* arRightFlex = new double[iFrameNum];
	double* arAbdSensor = new double[iFrameNum];
	double* arAbdReal = new double[iFrameNum];
	for(int i = 0; i < iFrameNum; ++i)
	{
		CRawFrame frame = clipRaw.m_arFrame[i];
		arLeftFlex[i] = frame.m_arData[0];
		arRightFlex[i] = frame.m_arData[1];
		arAbdSensor[i] = frame.m_arData[2];
		arAbdReal[i] = frame.m_arData[3];
	}	
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	mxArray* pMxLeftFlex = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxLeftFlex, "leftFlex");
	memcpy(mxGetPr(pMxLeftFlex), (double*)arLeftFlex, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "leftFlex", pMxLeftFlex);
	
	mxArray* pMxRightFlex = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxRightFlex, "rightFlex");
	memcpy(mxGetPr(pMxRightFlex), (double*)arRightFlex, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "rightFlex", pMxRightFlex);
	
	mxArray* pMxAbdSensor = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdSensor, "abdSensor");
	memcpy(mxGetPr(pMxAbdSensor), (double*)arAbdSensor, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdSensor", pMxAbdSensor);

	string strMarker;
	strMarker.push_back(cMarkerColor);
	strMarker.push_back(cMarkerType);

	string strNewFigure = "";
	if(bNewFigure)
		strNewFigure = "figure;";
	
	char strCmd[200];
	if(bPlot3)
		sprintf(strCmd, "%splot3(leftFlex,rightFlex,abdSensor, '-%s');xlabel('leftFlexSensor');ylabel('rightFlexSensor');zlabel('abdSensor');hold on;", strNewFigure.c_str(), strMarker.c_str());
	else
		sprintf(strCmd, "%sscatter3(leftFlex,rightFlex,abdSensor, 50, '%s');xlabel('leftFlexSensor');ylabel('rightFlexSensor');zlabel('abdSensor');hold on;", strNewFigure.c_str(), strMarker.c_str());
	engEvalString(pMatlabEngine,strCmd);

	//release
    delete arLeftFlex;
	delete arRightFlex;
	delete arAbdSensor;
	delete arAbdReal;
	mxDestroyArray(pMxLeftFlex);
	mxDestroyArray(pMxRightFlex);
	mxDestroyArray(pMxAbdSensor);

}
void MatlabUtil::PlotCrossAbdByDifference(CRawClip clipRaw, double fAbdReal, char cMarkerType, char cMarkerColor, bool bNewFigure, bool bPlot3)
{
	int iFrameNum = clipRaw.m_arFrame.size();
	double* arFlexDifference = new double[iFrameNum];	
	double* arAbdSensor = new double[iFrameNum];	
	double* arAbdReal = new double[iFrameNum];
	for(int i = 0; i < iFrameNum; ++i)
	{
		CRawFrame frame = clipRaw.m_arFrame[i];
		arFlexDifference[i] = frame.m_arData[0] - frame.m_arData[1];
		arAbdSensor[i] = frame.m_arData[2];
		arAbdReal[i] = frame.m_arData[3];
	}	

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	mxArray* pMxFlexDifference = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxFlexDifference, "flexDifference");
	memcpy(mxGetPr(pMxFlexDifference), (double*)arFlexDifference, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "flexDifference", pMxFlexDifference);
	
	mxArray* pMxAbdSensor = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdSensor, "abdSensor");
	memcpy(mxGetPr(pMxAbdSensor), (double*)arAbdSensor, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdSensor", pMxAbdSensor);
	
	mxArray* pMxAbdReal = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdReal, "abdReal");
	memcpy(mxGetPr(pMxAbdReal), (double*)arAbdReal, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdReal", pMxAbdReal);

	string strMarker;
	strMarker.push_back(cMarkerColor);
	strMarker.push_back(cMarkerType);

	string strNewFigure = "";
	if(bNewFigure)
		strNewFigure = "figure;";

	//matlab calling		
	char strCmd[200];
	if(bPlot3)
		sprintf(strCmd, "%splot3(flexDifference,abdSensor, abdReal, '-%s');xlabel('flexDifference');ylabel('abdSensor');zlabel('abdReal');axis equal;hold on;", strNewFigure.c_str(), strMarker.c_str());
	else
		sprintf(strCmd, "%sscatter3(flexDifference,abdSensor, abdReal, 50, '%s');xlabel('flexDifference');ylabel('abdSensor');zlabel('abdReal');axis equal;hold on;", strNewFigure.c_str(), strMarker.c_str());
	engEvalString(pMatlabEngine,strCmd);

	//release
    delete arFlexDifference;
	delete arAbdSensor;
	delete arAbdReal;
	mxDestroyArray(pMxFlexDifference);
	mxDestroyArray(pMxAbdSensor);
	mxDestroyArray(pMxAbdReal);
}
//luoji bu da dui de
void MatlabUtil::GriddataCrossAbd(CRawClip clipRaw)
{
	int iFrameNum = clipRaw.m_arFrame.size();
	double* arLeftFlex = new double[iFrameNum];	
	double* arRightFlex = new double[iFrameNum];
	double* arAbdSensor = new double[iFrameNum];
	double* arAbdReal = new double[iFrameNum];
	for(int i = 0; i < iFrameNum; ++i)
	{
		CRawFrame frame = clipRaw.m_arFrame[i];
		arLeftFlex[i] = frame.m_arData[0];
		arRightFlex[i] = frame.m_arData[1];
		arAbdSensor[i] = frame.m_arData[2];
		arAbdReal[i] = frame.m_arData[3];
	}	
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	mxArray* pMxLeftFlex = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxLeftFlex, "leftFlex");
	memcpy(mxGetPr(pMxLeftFlex), (double*)arLeftFlex, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "leftFlex", pMxLeftFlex);
	
	mxArray* pMxRightFlex = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxRightFlex, "rightFlex");
	memcpy(mxGetPr(pMxRightFlex), (double*)arRightFlex, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "rightFlex", pMxRightFlex);
	
	mxArray* pMxAbdSensor = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdSensor, "abdSensor");
	memcpy(mxGetPr(pMxAbdSensor), (double*)arAbdSensor, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdSensor", pMxAbdSensor);

	/*string strMarker;
	strMarker.push_back(cMarkerColor);
	strMarker.push_back(cMarkerType);

	string strNewFigure = "";
	if(bNewFigure)
		strNewFigure = "figure;";*/

	//matlab calling	
	
	/*
	figure;
	xi=-110:3:10;
	yi=-110:3:10;
	[XI,YI]=meshgrid(xi,yi);
	ZI=griddata(leftFlex,rightFlex,abdSensor,XI,YI,'cubic');
	mesh(XI,YI,ZI);hold;
	plot3(x,y,z,'o');hold off;
	*/
	
	char strCmd[200];
	sprintf(strCmd, "figure;xi=-110:3:10;yi=-110:3:10;[XI,YI]=meshgrid(xi,yi);	ZI=griddata(leftFlex,rightFlex,abdSensor,XI,YI,'cubic');mesh(XI,YI,ZI);hold;plot3(leftFlex,rightFlex,abdSensor,'+');hold off;");
	engEvalString(pMatlabEngine,strCmd);

	//release
    delete arLeftFlex;
	delete arRightFlex;
	delete arAbdSensor;
	delete arAbdReal;
	mxDestroyArray(pMxLeftFlex);
	mxDestroyArray(pMxRightFlex);
	mxDestroyArray(pMxAbdSensor);
}
void MatlabUtil::GriddataCrossAbdByDifference(CRawClip clipRaw)
{	
	int iFrameNum = clipRaw.m_arFrame.size();
	double* arFlexDifference = new double[iFrameNum];	
	double* arAbdSensor = new double[iFrameNum];	
	double* arAbdReal = new double[iFrameNum];
	for(int i = 0; i < iFrameNum; ++i)
	{
		CRawFrame frame = clipRaw.m_arFrame[i];
		arFlexDifference[i] = frame.m_arData[0] - frame.m_arData[1];
		arAbdSensor[i] = frame.m_arData[2];
		arAbdReal[i] = frame.m_arData[3];
	}

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	mxArray* pMxFlexDifference = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxFlexDifference, "flexDifference");
	memcpy(mxGetPr(pMxFlexDifference), (double*)arFlexDifference, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "flexDifference", pMxFlexDifference);
	
	mxArray* pMxAbdSensor = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdSensor, "abdSensor");
	memcpy(mxGetPr(pMxAbdSensor), (double*)arAbdSensor, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdSensor", pMxAbdSensor);
	
	mxArray* pMxAbdReal = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdReal, "abdReal");
	memcpy(mxGetPr(pMxAbdReal), (double*)arAbdReal, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdReal", pMxAbdReal);

	/*string strMarker;
	strMarker.push_back(cMarkerColor);
	strMarker.push_back(cMarkerType);

	string strNewFigure = "";
	if(bNewFigure)
		strNewFigure = "figure;";*/

	//matlab calling	
	/*
	figure;
	xi=-60:3:70
	yi=-5:3:50;
	[XI,YI]=meshgrid(xi,yi);
	ZI=griddata(flexDifference,abdSensor,abdReal,XI,YI,'cubic');
	mesh(XI,YI,ZI);hold;
	plot3(x,y,z,'o');hold off;
	*/
	
	char strCmd[200];
	sprintf(strCmd, "figure;xi=-60:3:70;yi=-5:3:50;[XI,YI]=meshgrid(xi,yi);ZI=griddata(flexDifference,abdSensor,abdReal,XI,YI);mesh(XI,YI,ZI);hold;plot3(flexDifference,abdSensor,abdReal,'+');hold off;");	
	engEvalString(pMatlabEngine,strCmd);

	//release
    delete arFlexDifference;
	delete arAbdSensor;
	delete arAbdReal;
	mxDestroyArray(pMxFlexDifference);
	mxDestroyArray(pMxAbdSensor);
	mxDestroyArray(pMxAbdReal);
}
void MatlabUtil::DelaunayCrossAbd(CRawClip clipRaw)
{
	int iFrameNum = clipRaw.m_arFrame.size();
	double* arLeftFlex = new double[iFrameNum];	
	double* arRightFlex = new double[iFrameNum];
	double* arAbdSensor = new double[iFrameNum];
	double* arAbdReal = new double[iFrameNum];
	for(int i = 0; i < iFrameNum; ++i)
	{
		CRawFrame frame = clipRaw.m_arFrame[i];
		arLeftFlex[i] = frame.m_arData[0];
		arRightFlex[i] = frame.m_arData[1];
		arAbdSensor[i] = frame.m_arData[2];
		arAbdReal[i] = frame.m_arData[3];
	}
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	mxArray* pMxLeftFlex = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxLeftFlex, "leftFlex");
	memcpy(mxGetPr(pMxLeftFlex), (double*)arLeftFlex, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "leftFlex", pMxLeftFlex);
	
	mxArray* pMxRightFlex = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxRightFlex, "rightFlex");
	memcpy(mxGetPr(pMxRightFlex), (double*)arRightFlex, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "rightFlex", pMxRightFlex);
	
	mxArray* pMxAbdSensor = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdSensor, "abdSensor");
	memcpy(mxGetPr(pMxAbdSensor), (double*)arAbdSensor, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdSensor", pMxAbdSensor);

	/*string strMarker;
	strMarker.push_back(cMarkerColor);
	strMarker.push_back(cMarkerType);

	string strNewFigure = "";
	if(bNewFigure)
		strNewFigure = "figure;";*/

	//matlab calling		
	/*
	figure;
	Tes=delaunay3(leftFlex,rightFlex,abdSensor);
	X=[leftFlex(:),rightFlex(:),abdSensor(:)];
	tetramesh(Tes,X);
	*/
	
	char strCmd[200];
	sprintf(strCmd, "figure;Tes=delaunay3(leftFlex,rightFlex,abdSensor);X=[leftFlex(:),rightFlex(:),abdSensor(:)];tetramesh(Tes,X);grid on;");
	engEvalString(pMatlabEngine,strCmd);

	//release
    delete arLeftFlex;
	delete arRightFlex;
	delete arAbdSensor;
	delete arAbdReal;
	mxDestroyArray(pMxLeftFlex);
	mxDestroyArray(pMxRightFlex);
	mxDestroyArray(pMxAbdSensor);
}
void MatlabUtil::DelaunayCrossAbdByDifference(CRawClip clipRaw)
{
	int iFrameNum = clipRaw.m_arFrame.size();
	double* arFlexDifference = new double[iFrameNum];	
	double* arAbdSensor = new double[iFrameNum];	
	double* arAbdReal = new double[iFrameNum];
	for(int i = 0; i < iFrameNum; ++i)
	{
		CRawFrame frame = clipRaw.m_arFrame[i];
		arFlexDifference[i] = frame.m_arData[0] - frame.m_arData[1];
		arAbdSensor[i] = frame.m_arData[2];
		arAbdReal[i] = frame.m_arData[3];
	}	
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	mxArray* pMxFlexDifference = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxFlexDifference, "flexDifference");
	memcpy(mxGetPr(pMxFlexDifference), (double*)arFlexDifference, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "flexDifference", pMxFlexDifference);
	
	mxArray* pMxAbdSensor = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdSensor, "abdSensor");
	memcpy(mxGetPr(pMxAbdSensor), (double*)arAbdSensor, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdSensor", pMxAbdSensor);
	
	mxArray* pMxAbdReal = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdReal, "abdReal");
	memcpy(mxGetPr(pMxAbdReal), (double*)arAbdReal, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdReal", pMxAbdReal);

	/*string strMarker;
	strMarker.push_back(cMarkerColor);
	strMarker.push_back(cMarkerType);

	string strNewFigure = "";
	if(bNewFigure)
		strNewFigure = "figure;";*/

	//matlab calling	
	/*
	figure;
	Tes=delaunay(flexDifference,abdSensor);
	trimesh(Tes,flexDifference,abdSensor,abdReal);
	*/
	
	char strCmd[200];
	sprintf(strCmd, "figure;Tes=delaunay(flexDifference,abdSensor);trimesh(Tes,flexDifference,abdSensor,abdReal);");	
	engEvalString(pMatlabEngine,strCmd);

	//release
    delete arFlexDifference;
	delete arAbdSensor;
	delete arAbdReal;
	mxDestroyArray(pMxFlexDifference);
	mxDestroyArray(pMxAbdSensor);
	mxDestroyArray(pMxAbdReal);
}
double MatlabUtil::TDSearchCrossAbd(CRawClip clipRaw, CRawData dataTuple, std::vector<CRawData>& arSimplex, CRawData& barencentricCoord)
{
	int iFrameNum = clipRaw.m_arFrame.size();
	double* arLeftFlex = new double[iFrameNum];	
	double* arRightFlex = new double[iFrameNum];
	double* arAbdSensor = new double[iFrameNum];
	double* arAbdReal = new double[iFrameNum];
	double* arData = new double[3];
	for(int i = 0; i < iFrameNum; ++i)
	{
		CRawFrame frame = clipRaw.m_arFrame[i];
		arLeftFlex[i] = frame.m_arData[0];
		arRightFlex[i] = frame.m_arData[1];
		arAbdSensor[i] = frame.m_arData[2];
		arAbdReal[i] = frame.m_arData[3];
	}
	arData[0] = dataTuple.m_arData[0];
	arData[1] = dataTuple.m_arData[1];
	arData[2] = dataTuple.m_arData[2];
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	char outputBuffer[200];
	engOutputBuffer(pMatlabEngine, outputBuffer, 200);

	mxArray* pMxLeftFlex = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxLeftFlex, "leftFlex");
	memcpy(mxGetPr(pMxLeftFlex), (double*)arLeftFlex, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "leftFlex", pMxLeftFlex);
	
	mxArray* pMxRightFlex = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxRightFlex, "rightFlex");
	memcpy(mxGetPr(pMxRightFlex), (double*)arRightFlex, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "rightFlex", pMxRightFlex);
	
	mxArray* pMxAbdSensor = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdSensor, "abdSensor");
	memcpy(mxGetPr(pMxAbdSensor), (double*)arAbdSensor, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdSensor", pMxAbdSensor);

	mxArray* pMxAbdReal = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdReal, "abdReal");
	memcpy(mxGetPr(pMxAbdReal), (double*)arAbdReal, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdReal", pMxAbdReal);

	mxArray* pMxData = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxData, "tupleToSearch");
	memcpy(mxGetPr(pMxData), (double*)arData, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "tupleToSearch", pMxData);

	
	//matlab calling		
	char strCmd[700];
	sprintf(strCmd, "X=[leftFlex(:),rightFlex(:),abdSensor(:)];\
					Tes=delaunayn(X);\
					[t,bCoord]=tsearchn(X,Tes,tupleToSearch);\
					simplexIdx=zeros(1,4);\
					simplex=zeros(4,4);\
					abdRealSearched=0.5;\
					if isnan(t) \
					   bCoord=[0,0,0,0];\
					   k=dsearchn(X,Tes,tupleToSearch);\
					   simplex(1,:)=[X(k,:),abdReal(k)];\
					   abdRealSearched=abdReal(k);\
					else\
					   simplexIdx=Tes(t,:);\
					   simplex=[leftFlex(simplexIdx),rightFlex(simplexIdx),abdSensor(simplexIdx),abdReal(simplexIdx)];\
					   simplex=reshape(simplex,4,4);\
					   abdRealSearched=bCoord(1,1)*simplex(1,4)+bCoord(1,2)*simplex(2,4)+bCoord(1,3)*simplex(3,4)+bCoord(1,4)*simplex(4,4);\
					end");
	//sprintf(strCmd, "[abdRealSearched, bCoord, simplex]= TDSearchForRealAbd(leftFlex,rightFlex,abdSensor,abdReal,tupleToSearch);");
	engEvalString(pMatlabEngine,strCmd);

	double fResult;
	mxArray* pMxRealAbdSearched = engGetVariable(pMatlabEngine, "abdRealSearched");
	memcpy(&fResult, (char*)mxGetPr(pMxRealAbdSearched), 1*sizeof(double));

	double* arBCoord = new double[4];
	mxArray* pMxBCoord = engGetVariable(pMatlabEngine, "bCoord");
	memcpy((char*)arBCoord, (char*)mxGetPr(pMxBCoord), 4*sizeof(double));

	double* arSimplexVertice =  new double[4*4];
	mxArray* pMxSimplexVertice = engGetVariable(pMatlabEngine, "simplex");
	memcpy((char*)arSimplexVertice,(char*)mxGetPr(pMxSimplexVertice), 4*4*sizeof(double));	

	//populate
	arSimplex.clear();
	CRawData v1;
	v1.m_arData.push_back(arSimplexVertice[0*4]); v1.m_arData.push_back(arSimplexVertice[1*4]);
	v1.m_arData.push_back(arSimplexVertice[2*4]); v1.m_arData.push_back(arSimplexVertice[3*4]);
	arSimplex.push_back(v1);
	CRawData v2;
	v2.m_arData.push_back(arSimplexVertice[0*4+1]); v2.m_arData.push_back(arSimplexVertice[1*4+1]);
	v2.m_arData.push_back(arSimplexVertice[2*4+1]); v2.m_arData.push_back(arSimplexVertice[3*4+1]);
	arSimplex.push_back(v2);
	CRawData v3;
	v3.m_arData.push_back(arSimplexVertice[0*4+2]); v3.m_arData.push_back(arSimplexVertice[1*4+2]); 
	v3.m_arData.push_back(arSimplexVertice[2*4+2]); v3.m_arData.push_back(arSimplexVertice[3*4+2]);
	arSimplex.push_back(v3);
    CRawData v4;
	v4.m_arData.push_back(arSimplexVertice[0*4+3]); v4.m_arData.push_back(arSimplexVertice[1*4+3]); 
	v4.m_arData.push_back(arSimplexVertice[2*4+3]); v4.m_arData.push_back(arSimplexVertice[3*4+3]);
	arSimplex.push_back(v4);

	barencentricCoord.m_arData.clear();
	barencentricCoord.m_arData.push_back(arBCoord[0]);
	barencentricCoord.m_arData.push_back(arBCoord[1]);
	barencentricCoord.m_arData.push_back(arBCoord[2]);
	barencentricCoord.m_arData.push_back(arBCoord[3]);

	//release
    delete arLeftFlex;
	delete arRightFlex;
	delete arAbdSensor;
	delete arAbdReal;
	delete arData;
	delete arSimplexVertice;
	delete arBCoord;
	mxDestroyArray(pMxLeftFlex);
	mxDestroyArray(pMxRightFlex);
	mxDestroyArray(pMxAbdSensor);
	mxDestroyArray(pMxAbdReal);
	mxDestroyArray(pMxData);
	mxDestroyArray(pMxSimplexVertice);
	mxDestroyArray(pMxBCoord);
	mxDestroyArray(pMxRealAbdSearched);
	return fResult;
}
double MatlabUtil::TDSearchCrossAbdByDifference(CRawClip clipRaw, CRawData dataTuple, std::vector<CRawData>& arSimplex, CRawData& barencentricCoord)
{
	int iFrameNum = clipRaw.m_arFrame.size();
	double* arLeftFlex = new double[iFrameNum];	
	double* arRightFlex = new double[iFrameNum];
	double* arAbdSensor = new double[iFrameNum];
	double* arAbdReal = new double[iFrameNum];
	double* arData = new double[3];
	for(int i = 0; i < iFrameNum; ++i)
	{
		CRawFrame frame = clipRaw.m_arFrame[i];
		arLeftFlex[i] = frame.m_arData[0];
		arRightFlex[i] = frame.m_arData[1];
		arAbdSensor[i] = frame.m_arData[2];
		arAbdReal[i] = frame.m_arData[3];
	}
	arData[0] = dataTuple.m_arData[0];
	arData[1] = dataTuple.m_arData[1];
	arData[2] = dataTuple.m_arData[2];
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	mxArray* pMxLeftFlex = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxLeftFlex, "leftFlex");
	memcpy(mxGetPr(pMxLeftFlex), (double*)arLeftFlex, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "leftFlex", pMxLeftFlex);
	
	mxArray* pMxRightFlex = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxRightFlex, "rightFlex");
	memcpy(mxGetPr(pMxRightFlex), (double*)arRightFlex, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "rightFlex", pMxRightFlex);
	
	mxArray* pMxAbdSensor = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdSensor, "abdSensor");
	memcpy(mxGetPr(pMxAbdSensor), (double*)arAbdSensor, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdSensor", pMxAbdSensor);
	
	mxArray* pMxAbdReal = mxCreateDoubleMatrix(1, iFrameNum, mxREAL);
	mxSetClassName(pMxAbdReal, "abdReal");
	memcpy(mxGetPr(pMxAbdReal), (double*)arAbdReal, iFrameNum*sizeof(double));
	engPutVariable(pMatlabEngine, "abdReal", pMxAbdReal);

	mxArray* pMxData = mxCreateDoubleMatrix(1, 3, mxREAL);
	mxSetClassName(pMxData, "tupleToSearch");
	memcpy(mxGetPr(pMxData), (double*)arData, 3*sizeof(double));
	engPutVariable(pMatlabEngine, "tupleToSearch", pMxData);

	
	//matlab calling		
	char strCmd[750];
	/*sprintf(strCmd, "X=[leftFlex(:)-rightFlex(:),abdSensor(:)];\
					toSearch=[tupleToSearch(1)-tupleToSearch(2), tupleToSearch(3)];\
					Tes=delaunayn(X);\
					[t,bCoord]=tsearchn(X,Tes,toSearch);\
					simplexIdx=zeros(1,3);\
					simplex=zeros(3,4);\
					abdRealSearched=0.5;\
					if isnan(t) \
					   bCoord=[0,0,0];\
					   k=dsearchn(X,Tes,toSearch);\
					   simplex(1,:)=[leftFlex(k),rightFlex(k),abdSensor(k),abdReal(k)];\
					   abdRealSearched=abdReal(k);\
					else\
					   simplexIdx=Tes(t,:);\
					   simplex=[leftFlex(simplexIdx),rightFlex(simplexIdx),abdSensor(simplexIdx),abdReal(simplexIdx)];\
					   simplex=reshape(simplex,3,4);\
					   abdRealSearched=bCoord(1,1)*simplex(1,4)+bCoord(1,2)*simplex(2,4)+bCoord(1,3)*simplex(3,4);\
					end");*/
	sprintf(strCmd, "[abdRealSearched, bCoord, simplex]= TDSearchForRealAbdByDifference(leftFlex,rightFlex,abdSensor,abdReal,tupleToSearch);");
	engEvalString(pMatlabEngine,strCmd);

	double fResult;
	mxArray* pMxRealAbdSearched = engGetVariable(pMatlabEngine, "abdRealSearched");
	memcpy(&fResult, (char*)mxGetPr(pMxRealAbdSearched), 1*sizeof(double));

	double* arBCoord = new double[3];
	mxArray* pMxBCoord = engGetVariable(pMatlabEngine, "bCoord");
	memcpy((char*)arBCoord, (char*)mxGetPr(pMxBCoord), 3*sizeof(double));

	double* arSimplexVertice =  new double[3*4];
	mxArray* pMxSimplexVertice = engGetVariable(pMatlabEngine, "simplex");
	memcpy((char*)arSimplexVertice,(char*)mxGetPr(pMxSimplexVertice), 3*4*sizeof(double));	

	//populate
	arSimplex.clear();
	CRawData v1;
	v1.m_arData.push_back(arSimplexVertice[0*3]); v1.m_arData.push_back(arSimplexVertice[1*3]); 
	v1.m_arData.push_back(arSimplexVertice[2*3]); v1.m_arData.push_back(arSimplexVertice[3*3]); 
	arSimplex.push_back(v1);
	CRawData v2;
	v2.m_arData.push_back(arSimplexVertice[0*3+1]); v2.m_arData.push_back(arSimplexVertice[1*3+1]);	
	v2.m_arData.push_back(arSimplexVertice[2*3+1]); v2.m_arData.push_back(arSimplexVertice[3*3+1]); 
	arSimplex.push_back(v2);
	CRawData v3;
	v3.m_arData.push_back(arSimplexVertice[0*3+2]); v3.m_arData.push_back(arSimplexVertice[1*3+2]); 
	v3.m_arData.push_back(arSimplexVertice[2*3+2]); v3.m_arData.push_back(arSimplexVertice[3*3+2]);
	arSimplex.push_back(v3);

	barencentricCoord.m_arData.clear();
	barencentricCoord.m_arData.push_back(arBCoord[0]);
	barencentricCoord.m_arData.push_back(arBCoord[1]);
	barencentricCoord.m_arData.push_back(arBCoord[2]);

	//release
	delete arLeftFlex;
	delete arRightFlex;
	delete arAbdSensor;
	delete arAbdReal;
	delete arData;
	delete arSimplexVertice;
	delete arBCoord;
	mxDestroyArray(pMxLeftFlex);
	mxDestroyArray(pMxRightFlex);
	mxDestroyArray(pMxAbdSensor);
	mxDestroyArray(pMxAbdReal);
	mxDestroyArray(pMxData);
	mxDestroyArray(pMxSimplexVertice);
	mxDestroyArray(pMxBCoord);
	mxDestroyArray(pMxRealAbdSearched);
	return fResult;
}

void MatlabUtil::LoadPredictedMatFile(std::string strMatPath, std::vector<double>& arPredictedAbd)
{
	arPredictedAbd.clear();
	CString msg;   
	MATFile *pMatFile = matOpen(strMatPath.c_str(),"r");//open file
	mxArray *pMxPredictedTarget = matGetVariable(pMatFile,"predicted_target_m");//read in variable
	int iRow = mxGetM(pMxPredictedTarget);
	int iCol = mxGetN(pMxPredictedTarget);//read in size
	msg.Format(L"row:%d,col:%d",iRow,iCol);
	//AfxMessageBox(msg);
	
	double *dMatPredictedTarget = new double[iRow*iCol];
	memcpy((char*)dMatPredictedTarget, (char*)mxGetPr(pMxPredictedTarget), iRow*iCol*sizeof(double));	
	//dMatPredictedTarget = (double *)mxGetData(pMxPredictedTarget);//store in c++ array

	CString strTmp;
	msg = "";
	for(int i=0;i<iRow;i++)
	{
		 for(int j=0;j<iCol;j++)
		{
			strTmp.Format(L"%f",dMatPredictedTarget[j*iRow+i]);
			arPredictedAbd.push_back(dMatPredictedTarget[j*iRow+i]);
			msg = msg + strTmp;
			msg = msg + L" ";
		}
			msg = msg + L"\n";
	}
	AfxMessageBox(msg);
	
	delete dMatPredictedTarget;
	matClose(pMatFile);
	mxFree(pMatFile);	
	mxFree(pMxPredictedTarget);
}
void MatlabUtil::ReTrainAll()
{
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	//engEvalString(pMatlabEngine, "GPR_TrainHand_l;");
}
void MatlabUtil::LoadTrained()
{
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	//engEvalString(pMatlabEngine, "GPR_LoadTrainedHp_l;GPR_LoadTrainingset_l;");	
}
void MatlabUtil::Load_full(std::string strPath, bool bLeft)
{
	//tr + hp
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	if(strPath != "")
	{
		std::string strCmd = "WS_PATH=\'";
		strCmd.append(strPath);
		strCmd.append("\\trainingset\';");
		engEvalString(pMatlabEngine,  strCmd.c_str());
	}
	if(bLeft)
		engEvalString(pMatlabEngine, "data_fingerFLEX_full_l;data_fingerABD_full_l; data_thumb_full_l;\
									 model_fingerFLEX_full_l;model_fingerABD_full_l;model_thumb_full_l;\
									 hp_fingerFLEX_full_l;hp_fingerABD_full_l;hp_thumb_full_l;");
	else
		engEvalString(pMatlabEngine, "data_fingerFLEX_full_r;data_fingerABD_full_r; data_thumb_full_r;\
									 model_fingerFLEX_full_r;model_fingerABD_full_r;model_thumb_full_r;\
									 hp_fingerFLEX_full_r;hp_fingerABD_full_r;hp_thumb_full_r;");
}
void MatlabUtil::Load_fitc(std::string strPath, bool bLeft)
{
	//tr + hp
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	if(strPath != "")
	{
		std::string strCmd = "WS_PATH=\'";
		strCmd.append(strPath);		
		strCmd.append("\\trainingset\';");
		engEvalString(pMatlabEngine,  strCmd.c_str());
	}

	if(bLeft)
		engEvalString(pMatlabEngine, "data_fingerFLEX_fitc_l;data_fingerABD_fitc_l; data_thumb_fitc_l;\
									 model_fingerFLEX_fitc_l;model_fingerABD_fitc_l;model_thumb_fitc_l;\
									 hp_fingerFLEX_fitc_l;hp_fingerABD_fitc_l;hp_thumb_fitc_l;");
	else
		engEvalString(pMatlabEngine, "data_fingerFLEX_fitc_r;data_fingerABD_fitc_r; data_thumb_fitc_r;\
									 model_fingerFLEX_fitc_r;model_fingerABD_fitc_r;model_thumb_fitc_r;\
									 hp_fingerFLEX_fitc_r;hp_fingerABD_fitc_r;hp_thumb_fitc_r;");
}
void MatlabUtil::Load_FK_full(std::string strPath, bool bLeft)
{
	//tr + hp
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	if(strPath != "")
	{
		std::string strCmd = "WS_PATH=\'";
		strCmd.append(strPath);
		strCmd.append("\\trainingset\';");
		engEvalString(pMatlabEngine,  strCmd.c_str());
	}

	if(bLeft)
		engEvalString(pMatlabEngine, "load_TR_FK_full_l;load_MD_FK_full_l;load_HP_FK_full_l;");
	else
		engEvalString(pMatlabEngine, "load_TR_FK_full_r;load_MD_FK_full_r;load_HP_FK_full_r;");
}
void MatlabUtil::Load_FK_fitc(std::string strPath, bool bLeft)
{
	//tr + hp
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	if(strPath != "")
	{
		std::string strCmd = "WS_PATH=\'";
		strCmd.append(strPath);		
		strCmd.append("\\trainingset\';");
		engEvalString(pMatlabEngine,  strCmd.c_str());
	}

	if(bLeft)
		engEvalString(pMatlabEngine, "load_TR_FK_fitc_l;load_MD_FK_fitc_l;load_HP_FK_fitc_l;");
	else
		engEvalString(pMatlabEngine, "load_TR_FK_fitc_r;load_MD_FK_fitc_r;load_HP_FK_fitc_r;");
}
void MatlabUtil::Load_linear_go(std::string strPath, bool bLeft)
{
	//hp only, no tr
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	if(strPath != "")
	{
		std::string strCmd = "WS_PATH=\'";
		strCmd.append(strPath);		
		strCmd.append("\\trainingset\';");
		engEvalString(pMatlabEngine,  strCmd.c_str());
	}

	if(bLeft)
		engEvalString(pMatlabEngine, "load_go_l;");
	else
		engEvalString(pMatlabEngine, "load_go_r;");
}
void MatlabUtil::Load_Thumb_full(std::string strPath, bool bLeft)
{
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	if(strPath != "")
	{
		std::string strCmd = "WS_PATH=\'";
		strCmd.append(strPath);		
		strCmd.append("\\trainingset\';");
		engEvalString(pMatlabEngine,  strCmd.c_str());
	}

	if(bLeft)
		engEvalString(pMatlabEngine, "load_TR_thumb_full_l;load_MD_thumb_full_l;load_HP_thumb_full_l;");
	else
		engEvalString(pMatlabEngine, "load_TR_thumb_full_r;load_MD_thumb_full_r;load_HP_thumb_full_r;");
}
void MatlabUtil::Load_Thumb_bc(std::string strPath, bool bLeft)
{
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	if(strPath != "")
	{
		std::string strCmd = "WS_PATH=\'";
		strCmd.append(strPath);		
		strCmd.append("\\trainingset\';");
		engEvalString(pMatlabEngine,  strCmd.c_str());
	}

	if(bLeft)
		engEvalString(pMatlabEngine, "load_thumb_bc_l;");
	else
		engEvalString(pMatlabEngine, "load_thumb_bc_r;");
}
CRawFrame MatlabUtil::GPRCalibrate_Thumb_bc(CRawFrame& frmRaw, bool bLeft)
{
	CRawFrame frmCalibrated;
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	/////////////////////
	int iDataSize = frmRaw.m_arData.size();
	double* arRawData = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
	{
		arRawData[i] = frmRaw.m_arData[i];
	}	

	mxArray* pMxRawData = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRawData, "frmRaw");
	memcpy(mxGetPr(pMxRawData), (double*)arRawData, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "frmRaw", pMxRawData);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_thumb_bc_l(frmRaw);");
	else
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_thumb_bc_r(frmRaw);");


	double* arCalibratedData = new double[iDataSize];
	mxArray* pMxCalibratedData = engGetVariable(pMatlabEngine, "frmCalibrated");
	memcpy((char*)arCalibratedData, (char*)mxGetPr(pMxCalibratedData), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		frmCalibrated.m_arData.push_back(arCalibratedData[i]);
	}

	delete arRawData;
	delete arCalibratedData;
	mxDestroyArray(pMxRawData);
	mxDestroyArray(pMxCalibratedData);

	return frmCalibrated;
}

CRawFrame MatlabUtil::GPRCalibrate_Thumb_fitc(CRawFrame& frmRaw, bool bLeft)
{
	CRawFrame frmCalibrated;
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	/////////////////////
	int iDataSize = frmRaw.m_arData.size();
	double* arRawData = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
	{
		arRawData[i] = frmRaw.m_arData[i];
	}	

	mxArray* pMxRawData = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRawData, "frmRaw");
	memcpy(mxGetPr(pMxRawData), (double*)arRawData, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "frmRaw", pMxRawData);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_thumb_fitc_l(frmRaw);");
	else
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_thumb_fitc_r(frmRaw);");


	double* arCalibratedData = new double[iDataSize];
	mxArray* pMxCalibratedData = engGetVariable(pMatlabEngine, "frmCalibrated");
	memcpy((char*)arCalibratedData, (char*)mxGetPr(pMxCalibratedData), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		frmCalibrated.m_arData.push_back(arCalibratedData[i]);
	}

	delete arRawData;
	delete arCalibratedData;
	mxDestroyArray(pMxRawData);
	mxDestroyArray(pMxCalibratedData);

	return frmCalibrated;
}
CRawFrame MatlabUtil::GPRCalibrate_Thumb_full(CRawFrame& frmRaw, bool bLeft)
{
	CRawFrame frmCalibrated;
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	/////////////////////
	int iDataSize = frmRaw.m_arData.size();
	double* arRawData = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
	{
		arRawData[i] = frmRaw.m_arData[i];
	}	

	mxArray* pMxRawData = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRawData, "frmRaw");
	memcpy(mxGetPr(pMxRawData), (double*)arRawData, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "frmRaw", pMxRawData);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_thumb_full_l(frmRaw);");
	else
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_thumb_full_r(frmRaw);");


	double* arCalibratedData = new double[iDataSize];
	mxArray* pMxCalibratedData = engGetVariable(pMatlabEngine, "frmCalibrated");
	memcpy((char*)arCalibratedData, (char*)mxGetPr(pMxCalibratedData), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		frmCalibrated.m_arData.push_back(arCalibratedData[i]);
	}

	delete arRawData;
	delete arCalibratedData;
	mxDestroyArray(pMxRawData);
	mxDestroyArray(pMxCalibratedData);

	if(bLeft)
		frmCalibrated.SuppressOverbendSigmoid(bLeft, 1, 10, 100);

	return frmCalibrated;
}
CRawFrame MatlabUtil::GPRCalibrate_full(CRawFrame& frmRaw, bool bLeft)
{
	CRawFrame frmCalibrated;
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();

	/////////////////////
	int iDataSize = frmRaw.m_arData.size();
	double* arRawData = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
	{
		arRawData[i] = frmRaw.m_arData[i];
	}	

	mxArray* pMxRawData = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRawData, "frmRaw");
	memcpy(mxGetPr(pMxRawData), (double*)arRawData, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "frmRaw", pMxRawData);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_full_l(frmRaw);");
	else
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_full_r(frmRaw);");


	double* arCalibratedData = new double[iDataSize];
	mxArray* pMxCalibratedData = engGetVariable(pMatlabEngine, "frmCalibrated");
	memcpy((char*)arCalibratedData, (char*)mxGetPr(pMxCalibratedData), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		frmCalibrated.m_arData.push_back(arCalibratedData[i]);
	}

	delete arRawData;
	delete arCalibratedData;
	mxDestroyArray(pMxRawData);
	mxDestroyArray(pMxCalibratedData);

	if(bLeft)
		frmCalibrated.SuppressOverbendSigmoid(bLeft, 1, 10, 100);
	return frmCalibrated;
}
CRawFrame MatlabUtil::GPRCalibrate_fitc(CRawFrame& frmRaw, bool bLeft)
{
	CRawFrame frmCalibrated;
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[200];
	engOutputBuffer(pMatlabEngine, outputBuffer, 200);

	/////////////////////
	int iDataSize = frmRaw.m_arData.size();
	double* arRawData = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
	{
		arRawData[i] = frmRaw.m_arData[i];
	}	

	mxArray* pMxRawData = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRawData, "frmRaw");
	memcpy(mxGetPr(pMxRawData), (double*)arRawData, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "frmRaw", pMxRawData);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_fitc_l(frmRaw);");
	else
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_fitc_r(frmRaw);");


	double* arCalibratedData = new double[iDataSize];
	mxArray* pMxCalibratedData = engGetVariable(pMatlabEngine, "frmCalibrated");
	memcpy((char*)arCalibratedData, (char*)mxGetPr(pMxCalibratedData), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		frmCalibrated.m_arData.push_back(arCalibratedData[i]);
	}

	delete arRawData;
	delete arCalibratedData;
	mxDestroyArray(pMxRawData);
	mxDestroyArray(pMxCalibratedData);

	//frmCalibrated.RangeFilter(bLeft);
	return frmCalibrated;
}

CRawFrame MatlabUtil::GPRCalibrate_fingerFLEX_full(CRawFrame& frmRaw, bool bLeft)
{
	CRawFrame frmCalibrated;
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[200];
	engOutputBuffer(pMatlabEngine, outputBuffer, 200);

	/////////////////////
	int iDataSize = frmRaw.m_arData.size();
	double* arRawData = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
	{
		arRawData[i] = frmRaw.m_arData[i];
	}	

	mxArray* pMxRawData = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRawData, "frmRaw");
	memcpy(mxGetPr(pMxRawData), (double*)arRawData, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "frmRaw", pMxRawData);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_fingerFLEX_full_l(frmRaw);");
	else
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_fingerFLEX_full_r(frmRaw);");

	double* arCalibratedData = new double[iDataSize];
	mxArray* pMxCalibratedData = engGetVariable(pMatlabEngine, "frmCalibrated");
	memcpy((char*)arCalibratedData, (char*)mxGetPr(pMxCalibratedData), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		frmCalibrated.m_arData.push_back(arCalibratedData[i]);
	}

	delete arRawData;
	delete arCalibratedData;
	mxDestroyArray(pMxRawData);
	mxDestroyArray(pMxCalibratedData);

	return frmCalibrated;
}
CRawFrame MatlabUtil::GPRCalibrate_fingerABD_full(CRawFrame& frmRaw, bool bLeft)
{
	CRawFrame frmCalibrated;
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[200];
	engOutputBuffer(pMatlabEngine, outputBuffer, 200);

	/////////////////////
	int iDataSize = frmRaw.m_arData.size();
	double* arRawData = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
	{
		arRawData[i] = frmRaw.m_arData[i];
	}	

	mxArray* pMxRawData = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRawData, "frmRaw");
	memcpy(mxGetPr(pMxRawData), (double*)arRawData, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "frmRaw", pMxRawData);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_fingerABD_full_l(frmRaw);");
	else
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_fingerABD_full_r(frmRaw);");

	double* arCalibratedData = new double[iDataSize];
	mxArray* pMxCalibratedData = engGetVariable(pMatlabEngine, "frmCalibrated");
	memcpy((char*)arCalibratedData, (char*)mxGetPr(pMxCalibratedData), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		frmCalibrated.m_arData.push_back(arCalibratedData[i]);
	}

	delete arRawData;
	delete arCalibratedData;
	mxDestroyArray(pMxRawData);
	mxDestroyArray(pMxCalibratedData);

	return frmCalibrated;
}
CRawFrame MatlabUtil::GPRCalibrate_fingerFLEX_fitc(CRawFrame& frmRaw, bool bLeft)
{
	CRawFrame frmCalibrated;
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[200];
	engOutputBuffer(pMatlabEngine, outputBuffer, 200);

	/////////////////////
	int iDataSize = frmRaw.m_arData.size();
	double* arRawData = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
	{
		arRawData[i] = frmRaw.m_arData[i];
	}	

	mxArray* pMxRawData = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRawData, "frmRaw");
	memcpy(mxGetPr(pMxRawData), (double*)arRawData, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "frmRaw", pMxRawData);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_fingerFLEX_fitc_l(frmRaw);");
	else
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_fingerFLEX_fitc_r(frmRaw);");

	double* arCalibratedData = new double[iDataSize];
	mxArray* pMxCalibratedData = engGetVariable(pMatlabEngine, "frmCalibrated");
	memcpy((char*)arCalibratedData, (char*)mxGetPr(pMxCalibratedData), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		frmCalibrated.m_arData.push_back(arCalibratedData[i]);
	}

	delete arRawData;
	delete arCalibratedData;
	mxDestroyArray(pMxRawData);
	mxDestroyArray(pMxCalibratedData);

	return frmCalibrated;
}
CRawFrame MatlabUtil::GPRCalibrate_fingerABD_fitc(CRawFrame& frmRaw, bool bLeft)
{
	CRawFrame frmCalibrated;
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[200];
	engOutputBuffer(pMatlabEngine, outputBuffer, 200);

	/////////////////////
	int iDataSize = frmRaw.m_arData.size();
	double* arRawData = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
	{
		arRawData[i] = frmRaw.m_arData[i];
	}	

	mxArray* pMxRawData = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRawData, "frmRaw");
	memcpy(mxGetPr(pMxRawData), (double*)arRawData, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "frmRaw", pMxRawData);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_fingerABD_fitc_l(frmRaw);");
	else
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_fingerABD_fitc_r(frmRaw);");

	double* arCalibratedData = new double[iDataSize];
	mxArray* pMxCalibratedData = engGetVariable(pMatlabEngine, "frmCalibrated");
	memcpy((char*)arCalibratedData, (char*)mxGetPr(pMxCalibratedData), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		frmCalibrated.m_arData.push_back(arCalibratedData[i]);
	}

	delete arRawData;
	delete arCalibratedData;
	mxDestroyArray(pMxRawData);
	mxDestroyArray(pMxCalibratedData);

	return frmCalibrated;
}

CRawFrame MatlabUtil::GPRCalibrate_FK_full(CRawFrame& frmRaw, bool bLeft)
{
	CRawFrame frmCalibrated;
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[200];
	engOutputBuffer(pMatlabEngine, outputBuffer, 200);

	/////////////////////
	int iDataSize = frmRaw.m_arData.size();
	double* arRawData = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
	{
		arRawData[i] = frmRaw.m_arData[i];
	}	

	mxArray* pMxRawData = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRawData, "frmRaw");
	memcpy(mxGetPr(pMxRawData), (double*)arRawData, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "frmRaw", pMxRawData);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_FK_full_l(frmRaw);");
	else
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_FK_full_r(frmRaw);");

	double* arCalibratedData = new double[iDataSize];
	mxArray* pMxCalibratedData = engGetVariable(pMatlabEngine, "frmCalibrated");
	memcpy((char*)arCalibratedData, (char*)mxGetPr(pMxCalibratedData), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		frmCalibrated.m_arData.push_back(arCalibratedData[i]);
	}

	delete arRawData;
	delete arCalibratedData;
	mxDestroyArray(pMxRawData);
	mxDestroyArray(pMxCalibratedData);

	return frmCalibrated;
}
CRawFrame MatlabUtil::GPRCalibrate_FK_fitc(CRawFrame& frmRaw, bool bLeft)
{
	CRawFrame frmCalibrated;
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[200];
	engOutputBuffer(pMatlabEngine, outputBuffer, 200);

	/////////////////////
	int iDataSize = frmRaw.m_arData.size();
	double* arRawData = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
	{
		arRawData[i] = frmRaw.m_arData[i];
	}	

	mxArray* pMxRawData = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRawData, "frmRaw");
	memcpy(mxGetPr(pMxRawData), (double*)arRawData, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "frmRaw", pMxRawData);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_FK_fitc_l(frmRaw);");
	else
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_FK_fitc_r(frmRaw);");

	double* arCalibratedData = new double[iDataSize];
	mxArray* pMxCalibratedData = engGetVariable(pMatlabEngine, "frmCalibrated");
	memcpy((char*)arCalibratedData, (char*)mxGetPr(pMxCalibratedData), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		frmCalibrated.m_arData.push_back(arCalibratedData[i]);
	}

	delete arRawData;
	delete arCalibratedData;
	mxDestroyArray(pMxRawData);
	mxDestroyArray(pMxCalibratedData);

	return frmCalibrated;
}
CRawFrame MatlabUtil::GPRCalibrate_linear(CRawFrame& frmRaw, bool bLeft)
{
	CRawFrame frmCalibrated;
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[200];
	engOutputBuffer(pMatlabEngine, outputBuffer, 200);

	/////////////////////
	int iDataSize = frmRaw.m_arData.size();
	double* arRawData = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
	{
		arRawData[i] = frmRaw.m_arData[i];
	}	

	mxArray* pMxRawData = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRawData, "frmRaw");
	memcpy(mxGetPr(pMxRawData), (double*)arRawData, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "frmRaw", pMxRawData);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_go_l(frmRaw);");
	else
		engEvalString(pMatlabEngine, "frmCalibrated = calibrate_go_r(frmRaw);");

	double* arCalibratedData = new double[iDataSize];
	mxArray* pMxCalibratedData = engGetVariable(pMatlabEngine, "frmCalibrated");
	memcpy((char*)arCalibratedData, (char*)mxGetPr(pMxCalibratedData), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		frmCalibrated.m_arData.push_back(arCalibratedData[i]);
	}

	delete arRawData;
	delete arCalibratedData;
	mxDestroyArray(pMxRawData);
	mxDestroyArray(pMxCalibratedData);

	return frmCalibrated;
}
CGloveCalibration MatlabUtil::LinearRegressCalibrate(CGlvFrame frmGlvFlat, CGlvFrame frmGlvSpread, CGlvFrame frmGlvFist, CGlvFrame frmGlvExtBend,
		CGlvFrame frmRealFlat, CGlvFrame frmRealSpread, CGlvFrame frmRealFist, CGlvFrame frmRealExtBend, bool bLeft)
{
	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[200];
	engOutputBuffer(pMatlabEngine, outputBuffer, 200);

	//sensor ====================================================
	//flat
	int iDataSize = frmGlvFlat.m_arData.size();
	double* arGlvFlat = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
		arGlvFlat[i] = frmGlvFlat.m_arData[i];
	mxArray* pMxGlvFlat = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxGlvFlat, "flatGlv");
	memcpy(mxGetPr(pMxGlvFlat), (double*)arGlvFlat, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "flatGlv", pMxGlvFlat);

	//spread
	iDataSize = frmGlvSpread.m_arData.size();
	double* arGlvSpread = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
		arGlvSpread[i] = frmGlvSpread.m_arData[i];
	mxArray* pMxGlvSpread = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxGlvSpread, "spreadGlv");
	memcpy(mxGetPr(pMxGlvSpread), (double*)arGlvSpread, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "spreadGlv", pMxGlvSpread);

	//fist
	iDataSize = frmGlvFist.m_arData.size();
	double* arGlvFist = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
		arGlvFist[i] = frmGlvFist.m_arData[i];
	mxArray* pMxGlvFist = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxGlvFist, "fistGlv");
	memcpy(mxGetPr(pMxGlvFist), (double*)arGlvFist, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "fistGlv", pMxGlvFist);

	//extBend
	iDataSize = frmGlvExtBend.m_arData.size();
	double* arGlvExtBend = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
		arGlvExtBend[i] = frmGlvExtBend.m_arData[i];
	mxArray* pMxGlvExtBend = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxGlvExtBend, "extBendGlv");
	memcpy(mxGetPr(pMxGlvExtBend), (double*)arGlvExtBend, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "extBendGlv", pMxGlvExtBend);

	//real: degree to radian conversion is needed =====================================
	//flat
	iDataSize = frmRealFlat.m_arData.size();
	double* arRealFlat = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
		arRealFlat[i] = frmRealFlat.m_arData[i] * 3.1415926 / 180;
	mxArray* pMxRealFlat = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRealFlat, "flatReal");
	memcpy(mxGetPr(pMxRealFlat), (double*)arRealFlat, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "flatReal", pMxRealFlat);

	//spread
	iDataSize = frmRealSpread.m_arData.size();
	double* arRealSpread = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
		arRealSpread[i] = frmRealSpread.m_arData[i] * 3.1415926 / 180;
	mxArray* pMxRealSpread = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRealSpread, "spreadReal");
	memcpy(mxGetPr(pMxRealSpread), (double*)arRealSpread, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "spreadReal", pMxRealSpread);

	//fist
	iDataSize = frmRealFist.m_arData.size();
	double* arRealFist = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
		arRealFist[i] = frmRealFist.m_arData[i] * 3.1415926 / 180;
	mxArray* pMxRealFist = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRealFist, "fistReal");
	memcpy(mxGetPr(pMxRealFist), (double*)arRealFist, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "fistReal", pMxRealFist);

	//extBend
	iDataSize = frmRealExtBend.m_arData.size();
	double* arRealExtBend = new double[iDataSize];
	for(int i = 0; i < iDataSize; ++i)
		arRealExtBend[i] = frmRealExtBend.m_arData[i] * 3.1415926 / 180;
	mxArray* pMxRealExtBend = mxCreateDoubleMatrix(1, iDataSize, mxREAL);
	mxSetClassName(pMxRealExtBend, "extBendReal");
	memcpy(mxGetPr(pMxRealExtBend), (double*)arRealExtBend, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "extBendReal", pMxRealExtBend);
	
	if(bLeft)
		engEvalString(pMatlabEngine, "G_O = glv_linearRegress_l(flatGlv, spreadGlv, fistGlv, extBendGlv, flatReal, spreadReal, fistReal, extBendReal);");
	else
		engEvalString(pMatlabEngine, "G_O = glv_linearRegress_r(flatGlv, spreadGlv, fistGlv, extBendGlv, flatReal, spreadReal, fistReal, extBendReal);");


	CGloveCalibration glvCalibration;
	glvCalibration.m_arAdjustItem;
	double* arG_O = new double[2*iDataSize];
	mxArray* pMxG_O = engGetVariable(pMatlabEngine, "G_O");
	memcpy((char*)arG_O, (char*)mxGetPr(pMxG_O), 2*iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{		
		//j*iRow+i		
		glvCalibration.m_arAdjustItem[i].m_fGain = arG_O[i];
		glvCalibration.m_arAdjustItem[i].m_fOffset = arG_O[1*iDataSize+i];
	}

	delete arGlvFlat;
	delete arGlvSpread;
	delete arGlvFist;
	delete arGlvExtBend;
	delete arRealFlat;
	delete arRealSpread;
	delete arRealFist;
	delete arRealExtBend;
	delete arG_O;
	mxDestroyArray(pMxGlvFlat);
	mxDestroyArray(pMxGlvSpread);
	mxDestroyArray(pMxGlvFist);
	mxDestroyArray(pMxGlvExtBend);
	mxDestroyArray(pMxRealFlat);
	mxDestroyArray(pMxRealSpread);
	mxDestroyArray(pMxRealFist);
	mxDestroyArray(pMxRealExtBend);
	mxDestroyArray(pMxG_O);

	return glvCalibration;
}
CRawClip MatlabUtil::GPRCalibrate_Thumb_full(CRawClip& clipRaw, bool bLeft)
{
	CRawClip clipCalibrated;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_Thumb_full(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;
}

CRawClip MatlabUtil::GPRCalibrate_Thumb_fitc(CRawClip& clipRaw, bool bLeft)
{
	CRawClip clipCalibrated;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_Thumb_fitc(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;
}
CRawClip MatlabUtil::GPRCalibrate_Thumb_bc(CRawClip& clipRaw, bool bLeft)
{
	CRawClip clipCalibrated;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_Thumb_bc(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;
}
CRawClip MatlabUtil::GPRCalibrate_full(CRawClip& clipRaw, bool bLeft)
{
	CRawClip clipCalibrated;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_full(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;
}
CRawClip MatlabUtil::GPRCalibrate_fingerABD_full(CRawClip& clipRaw, bool bLeft)
{
	CRawClip clipCalibrated;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_fingerABD_full(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;
}
CRawClip MatlabUtil::GPRCalibrate_fingerFLEX_full(CRawClip& clipRaw, bool bLeft)
{
	CRawClip clipCalibrated;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_fingerFLEX_full(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;
}
CRawClip MatlabUtil::GPRCalibrate_fingerFLEX_fitc(CRawClip& clipRaw, bool bLeft)
{
	CRawClip clipCalibrated;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_fingerFLEX_fitc(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;
}
CRawClip MatlabUtil::GPRCalibrate_fingerABD_fitc(CRawClip& clipRaw, bool bLeft)
{
	CRawClip clipCalibrated;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_fingerABD_fitc(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;
}
CRawClip MatlabUtil::GPRCalibrate_fitc(CRawClip& clipRaw, bool bLeft)
{
	CRawClip clipCalibrated;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_fitc(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;
}
CRawClip MatlabUtil::GPRCalibrate_FK_full(CRawClip& clipRaw, bool bLeft)
{
	CRawClip clipCalibrated;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_FK_full(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;
}
CRawClip MatlabUtil::GPRCalibrate_FK_fitc(CRawClip& clipRaw, bool bLeft)
{
	CRawClip clipCalibrated;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_FK_fitc(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;
}
CRawClip MatlabUtil::GPRCalibrate_linear(CRawClip& clipRaw, bool bLeft)
{
	CRawClip clipCalibrated;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_linear(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;
}
CRawClip MatlabUtil::GPRCalibrate_FK_full(CRawClip& clipRaw, int iBegIdx, int iEndIdx, bool bLeft)
{
	if(iBegIdx>=iEndIdx)
	{
		iBegIdx = 0;
		iEndIdx = clipRaw.m_arFrame.size();
	}
	if(iBegIdx < 0) 
		iBegIdx = 0;
	if(iEndIdx > clipRaw.m_arFrame.size())
		iEndIdx = clipRaw.m_arFrame.size();

	CRawClip clipCalibrated;
	for(int i = iBegIdx; i < iEndIdx; ++i)
	{
		CRawFrame frmCalibrated = GPRCalibrate_FK_full(clipRaw.m_arFrame[i], bLeft);
		clipCalibrated.m_arFrame.push_back(frmCalibrated);
	}
	return clipCalibrated;

}
CRawClip MatlabUtil::MultilinearRegress(CRawClip clipTrainingTarget, CRawClip clipTrainingInput, CRawClip clipInput, int iDOFIndex)
{
	if(clipInput.m_arFrame.size() == 0)
		return clipInput;
	if(iDOFIndex < 0 || iDOFIndex >= clipInput.m_arFrame[0].m_arData.size())
		return clipInput;

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();	
	char outputBuffer[200];
	engOutputBuffer(pMatlabEngine, outputBuffer, 200);

	//training data preparation
	int iTrainingDataSize = clipTrainingTarget.m_arFrame.size();
	double* arTrainingTarget = new double [iTrainingDataSize];
	double* arTrainingInput = new double [iTrainingDataSize * 3];
	for(int i = 0; i < iTrainingDataSize; ++i)
	{
		arTrainingTarget[i] = clipTrainingTarget.m_arFrame[i].m_arData[0];
		arTrainingInput[0*iTrainingDataSize + i] = clipTrainingInput.m_arFrame[i].m_arData[0];
		arTrainingInput[1*iTrainingDataSize + i] = clipTrainingInput.m_arFrame[i].m_arData[1];
		arTrainingInput[2*iTrainingDataSize + i] = clipTrainingInput.m_arFrame[i].m_arData[2];
	}
	mxArray* pMxTrainingTarget = mxCreateDoubleMatrix(iTrainingDataSize, 1, mxREAL);
	mxSetClassName(pMxTrainingTarget, "trainingTarget");
	memcpy(mxGetPr(pMxTrainingTarget), (double*)arTrainingTarget, iTrainingDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "trainingTarget", pMxTrainingTarget);

	mxArray* pMxTrainingInput = mxCreateDoubleMatrix(iTrainingDataSize, 3, mxREAL);
	mxSetClassName(pMxTrainingInput, "trainingInput");
	memcpy(mxGetPr(pMxTrainingInput), (double*)arTrainingInput, 3*iTrainingDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "trainingInput", pMxTrainingInput);
	//input data preparation
	int iDataSize = clipInput.m_arFrame.size();
	double* arFlex1 = new double[iDataSize];
	double* arFlex2 = new double[iDataSize];
	double* arABD = new double[iDataSize];
	int iFlex1Index, iFlex2Index;
	switch(iDOFIndex)
	{
	case 7: iFlex1Index = 8; iFlex2Index = 14; break;
	case 19: iFlex1Index = 14; iFlex2Index = 20; break;
	case 25: iFlex1Index = 20; iFlex2Index = 26; break;
	default: return clipInput;
	}

	for(int i = 0; i < iDataSize; ++i)
	{
		arFlex1[i] = clipInput.m_arFrame[i].m_arData[iFlex1Index];
		arFlex2[i] = clipInput.m_arFrame[i].m_arData[iFlex2Index];
		arABD[i] = clipInput.m_arFrame[i].m_arData[iDOFIndex];
	}	

	mxArray* pMxFlex1 = mxCreateDoubleMatrix(iDataSize, 1, mxREAL);
	mxSetClassName(pMxFlex1, "flex1");
	memcpy(mxGetPr(pMxFlex1), (double*)arFlex1, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "flex1", pMxFlex1);

	mxArray* pMxFlex2 = mxCreateDoubleMatrix(iDataSize, 1, mxREAL);
	mxSetClassName(pMxFlex2, "flex2");
	memcpy(mxGetPr(pMxFlex2), (double*)arFlex2, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "flex2", pMxFlex2);

	mxArray* pMxABD = mxCreateDoubleMatrix(iDataSize, 1, mxREAL);
	mxSetClassName(pMxABD, "abd");
	memcpy(mxGetPr(pMxABD), (double*)arABD, iDataSize*sizeof(double));
	engPutVariable(pMatlabEngine, "abd", pMxABD);

	engEvalString(pMatlabEngine, "fABDMl = multilinear_reg(trainingTarget, trainingInput, flex1, flex2, abd);");

	double* arABDMl = new double[iDataSize];
	mxArray* pMxABDMl = engGetVariable(pMatlabEngine, "fABDMl");
	memcpy((char*)arABDMl, (char*)mxGetPr(pMxABDMl), iDataSize*sizeof(double));
	for(int i = 0; i < iDataSize; ++i)
	{
		clipInput.m_arFrame[i].m_arData[iDOFIndex] = arABDMl[i];
	}

	delete arFlex1;
	delete arFlex2;
	delete arABD;
	delete arABDMl;
	mxDestroyArray(pMxFlex1);
	mxDestroyArray(pMxFlex2);
	mxDestroyArray(pMxABD);
	mxDestroyArray(pMxABDMl);
	
	return clipInput;
}
