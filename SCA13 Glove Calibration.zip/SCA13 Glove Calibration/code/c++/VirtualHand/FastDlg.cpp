// FastDlg.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualHand.h"
#include "FastDlg.h"
#include "GloveUtil.h"


// CFastDlg dialog

IMPLEMENT_DYNAMIC(CFastDlg, CDialog)

CFastDlg::CFastDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFastDlg::IDD, pParent)
{

}

CFastDlg::~CFastDlg()
{
}

void CFastDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CFastDlg::OnInitDialog()
{
	CButton* pBut = (CButton*)GetDlgItem(IDC_CHECK_FAST_HD);
	pBut->SetCheck(1);

	pBut = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	pBut->SetCheck(1);

	return CDialog::OnInitDialog();
}
BEGIN_MESSAGE_MAP(CFastDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_BASE_PATH, &CFastDlg::OnBnClickedButtonBrowseBasePath)
	ON_BN_CLICKED(IDC_BUTTON_GENERATE_GROUND_TRUTH, &CFastDlg::OnBnClickedButtonGenerateGroundTruth)
	ON_BN_CLICKED(IDC_BUTTON_FAST_CALIBRATE, &CFastDlg::OnBnClickedButtonFastCalibrate)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_RAW_PATH, &CFastDlg::OnBnClickedButtonBrowseRawPath)
	ON_BN_CLICKED(IDC_BUTTON_FAST_BATCH_CALIBRATE, &CFastDlg::OnBnClickedButtonFastBatchCalibrate)
	ON_BN_CLICKED(IDC_BUTTON_FAST_BATCH_BVH, &CFastDlg::OnBnClickedButtonFastBatchBvh)
	ON_BN_CLICKED(IDC_BUTTON_FAST_GLV_TO_RAW, &CFastDlg::OnBnClickedButtonFastGlvToRaw)
	ON_BN_CLICKED(IDC_BUTTON_GENERATE_GROUND_TRUTH_IK, &CFastDlg::OnBnClickedButtonGenerateGroundTruthIk)
	ON_BN_CLICKED(IDC_BUTTON_EXTRACT_IK, &CFastDlg::OnBnClickedButtonExtractIk)
	ON_BN_CLICKED(IDC_BUTTON_FAST_TRAIN_IK, &CFastDlg::OnBnClickedButtonFastTrainIk)
	ON_BN_CLICKED(IDC_BUTTON_FAST_CHECK_IK_INPUT, &CFastDlg::OnBnClickedButtonFastCheckIkInput)
	ON_BN_CLICKED(IDC_BUTTON_GENERATE_GROUND_TRUTH_IK_FITC, &CFastDlg::OnBnClickedButtonGenerateGroundTruthIkFitc)
	ON_BN_CLICKED(IDC_BUTTON_EXTRACT_IK_FITC, &CFastDlg::OnBnClickedButtonExtractIkFitc)
	ON_BN_CLICKED(IDC_BUTTON_FAST_TRAIN_IK_FITC, &CFastDlg::OnBnClickedButtonFastTrainIkFitc)
	ON_BN_CLICKED(IDC_BUTTON_FAST_CHECK_IK_INPUT_FITC, &CFastDlg::OnBnClickedButtonFastCheckIkInputFitc)
	ON_BN_CLICKED(IDC_BUTTON_FAST_LOAD_HAND_SIZE, &CFastDlg::OnBnClickedButtonFastLoadHandSize)
	ON_BN_CLICKED(IDC_BUTTON_WRITE_GO, &CFastDlg::OnBnClickedButtonWriteGo)
	ON_BN_CLICKED(IDC_BUTTON_EXTRACT_FLEX_FULL, &CFastDlg::OnBnClickedButtonExtractFlexFull)
	ON_BN_CLICKED(IDC_BUTTON_EXTRACT_FLEX_FITC, &CFastDlg::OnBnClickedButtonExtractFlexFitc)
	ON_BN_CLICKED(IDC_BUTTON_FAST_TRAIN_FLEX_FULL, &CFastDlg::OnBnClickedButtonFastTrainFlexFull)
	ON_BN_CLICKED(IDC_BUTTON_FAST_TRAIN_FLEX_FITC, &CFastDlg::OnBnClickedButtonFastTrainFlexFitc)
	ON_BN_CLICKED(IDC_BUTTON_GENERATE_2FLEX_FITC, &CFastDlg::OnBnClickedButtonGenerate2flexFitc)
	ON_BN_CLICKED(IDC_BUTTON_GENERATE_2FLEX_FULL, &CFastDlg::OnBnClickedButtonGenerate2flexFull)
	ON_BN_CLICKED(IDC_BUTTON_EXTRACT_ABD_FULL, &CFastDlg::OnBnClickedButtonExtractAbdFull)
	ON_BN_CLICKED(IDC_BUTTON_EXTRACT_ABD_FITC, &CFastDlg::OnBnClickedButtonExtractAbdFitc)
	ON_BN_CLICKED(IDC_BUTTON_FAST_TRAIN_ABD_FULL, &CFastDlg::OnBnClickedButtonFastTrainAbdFull)
	ON_BN_CLICKED(IDC_BUTTON_FAST_TRAIN_ABD_FITC, &CFastDlg::OnBnClickedButtonFastTrainAbdFitc)
	ON_BN_CLICKED(IDC_BUTTON_GENERATE_3ABD_FULL, &CFastDlg::OnBnClickedButtonGenerate3abdFull)
	ON_BN_CLICKED(IDC_BUTTON_GENERATE_3ABD_FITC, &CFastDlg::OnBnClickedButtonGenerate3abdFitc)
	ON_BN_CLICKED(IDC_BUTTON_XFAST_CALIBRATE, &CFastDlg::OnBnClickedButtonXfastCalibrate)
	ON_BN_CLICKED(IDC_BUTTON_GENERATE_4IK_FULL, &CFastDlg::OnBnClickedButtonGenerate4ikFull)
	ON_BN_CLICKED(IDC_BUTTON_GENERATE_4IK_FITC, &CFastDlg::OnBnClickedButtonGenerate4ikFitc)
END_MESSAGE_MAP()


// CFastDlg message handlers

void CFastDlg::OnBnClickedButtonBrowseBasePath()
{
		CString strPath = GloveUtil::ShowFolderDlg(L"Base Path");
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FAST_BASE_PATH); 
		pEdit->SetWindowText(strPath);
		strPath = strPath.Trim();
		std::string strBasePath = GloveUtil::ToChar(strPath);
		m_fastCal.SetBasePath(strBasePath);
}
void CFastDlg::OnBnClickedButtonGenerateGroundTruth()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.generate_fk_groundtruth(pButLeft->GetCheck());
}

void CFastDlg::OnBnClickedButtonFastBatchCalibrate()
{
	m_fastCal.BatchCalibrate();
}
void CFastDlg::OnBnClickedButtonFastCalibrate()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FAST_RAW_PATH); 
	CString strPath;
	pEdit->GetWindowTextW(strPath);
	std::string strRawPath = GloveUtil::ToChar(strPath);
	CRawClip clipRaw, clipResult;
	clipRaw.LoadFromFile(strRawPath);
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.Calibrate(clipRaw, clipResult, pButLeft->GetCheck());
	clipResult.SaveToFile(m_fastCal.m_strBasePath + "_fast.raw");
}
void CFastDlg::OnBnClickedButtonBrowseRawPath()
{
	CFileDialog dlgFile(TRUE, L"Raw Kinematic File(*.raw)|*.raw", NULL, 4|2, L"Raw Kinematic File(*.raw)|*.raw||");
	if(IDOK == dlgFile.DoModal())
	{
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_FAST_RAW_PATH); 
		pEdit->SetWindowText(dlgFile.GetPathName());
	}	
}



void CFastDlg::OnBnClickedButtonFastBatchBvh()
{
	CString strBase(m_fastCal.m_strBasePath.c_str());

	::CreateDirectory(strBase + L"bvh/", NULL);
	::CreateDirectory(strBase + L"bvh/left/", NULL);
	::CreateDirectory(strBase + L"bvh/right/", NULL);

	CString strSrcLeft = strBase + L"raw/left/";
	CString strDestLeft = strBase + L"bvh/left/";
	GloveUtil::BatchToBvh(strSrcLeft, strDestLeft, true);

	CString strSrcRight = strBase + L"raw/right/";
	CString strDestRight = strBase + L"bvh/right/";
	GloveUtil::BatchToBvh(strSrcRight, strDestRight, false);
}

void CFastDlg::OnBnClickedButtonFastGlvToRaw()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	CString strBase(m_fastCal.m_strBasePath.c_str());
	//if(pButLeft->GetCheck())
	{
		CString strBaseGlv = strBase + L"glv/left/";
		CString strBaseRaw = strBase + L"raw/left/";
		GloveUtil::BatchGlvToRawUnder(strBaseGlv, strBaseRaw, true);
	}
	//else
	{
		CString strBaseGlv = strBase + L"glv/right/";
		CString strBaseRaw = strBase + L"raw/right/";
		GloveUtil::BatchGlvToRawUnder(strBaseGlv, strBaseRaw, false);
	}
}
void CFastDlg::OnBnClickedButtonGenerateGroundTruthIk()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.generate_ik_groundtruth(pButLeft->GetCheck(), /*bFull=*/true);
}
void CFastDlg::OnBnClickedButtonGenerateGroundTruthIkFitc()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.generate_ik_groundtruth(pButLeft->GetCheck(), /*bFull=*/false);
}
void CFastDlg::OnBnClickedButtonExtractIk()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.extract_thumb_tr(pButLeft->GetCheck(), /*bFull=*/true);
}
void CFastDlg::OnBnClickedButtonExtractIkFitc()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.extract_thumb_tr(pButLeft->GetCheck(), /*bFull=*/false);
}
void CFastDlg::OnBnClickedButtonFastTrainIk()
{
	CButton* pCheck = (CButton*)GetDlgItem(IDC_CHECK_FAST_HD);
	if(pCheck->GetCheck())
		m_fastCal.m_iHD = 1;
	else
		m_fastCal.m_iHD = -1;

	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.train_thumb(pButLeft->GetCheck(), /*bFull=*/true);
}
void CFastDlg::OnBnClickedButtonFastTrainIkFitc()
{	
	CButton* pCheck = (CButton*)GetDlgItem(IDC_CHECK_FAST_HD);
	if(pCheck->GetCheck())
		m_fastCal.m_iHD = 1;
	else
		m_fastCal.m_iHD = -1;

	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.train_thumb(pButLeft->GetCheck(), /*bFull=*/false);
}

void CFastDlg::OnBnClickedButtonFastCheckIkInput()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.check_ik_quality(pButLeft->GetCheck(), /*bFull=*/true);
}
void CFastDlg::OnBnClickedButtonFastCheckIkInputFitc()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.check_ik_quality(pButLeft->GetCheck(), /*bFull=*/false);
}

void CFastDlg::OnBnClickedButtonFastLoadHandSize()
{
	CFileDialog dlgFile(TRUE, L"Glove Handsize File(*.gsz)|*.gsz", NULL, 4|2, L"Glove Handsize File(*.gsz)|*.gsz||");
	if(IDOK == dlgFile.DoModal())
		m_fastCal.load_hand_size(dlgFile.GetPathName());
}

void CFastDlg::OnBnClickedButtonWriteGo()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.extract_linear_go(pButLeft->GetCheck());
}

void CFastDlg::OnBnClickedButtonExtractFlexFull()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.extract_finger_flex_tr(pButLeft->GetCheck(), true);
}

void CFastDlg::OnBnClickedButtonExtractFlexFitc()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.extract_finger_flex_tr(pButLeft->GetCheck(), false);
}

void CFastDlg::OnBnClickedButtonFastTrainFlexFull()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.train_finger_flex(pButLeft->GetCheck(), true);
}

void CFastDlg::OnBnClickedButtonFastTrainFlexFitc()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.train_finger_flex(pButLeft->GetCheck(), false);
}

void CFastDlg::OnBnClickedButtonGenerate2flexFitc()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.generate_finger_2flex(pButLeft->GetCheck(), false);
}

void CFastDlg::OnBnClickedButtonGenerate2flexFull()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.generate_finger_2flex(pButLeft->GetCheck(), true);
}

void CFastDlg::OnBnClickedButtonExtractAbdFull()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.extract_finger_abd_tr(pButLeft->GetCheck(), true);
}

void CFastDlg::OnBnClickedButtonExtractAbdFitc()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.extract_finger_abd_tr(pButLeft->GetCheck(), false);
}

void CFastDlg::OnBnClickedButtonFastTrainAbdFull()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.train_finger_abd(pButLeft->GetCheck(), true);
}

void CFastDlg::OnBnClickedButtonFastTrainAbdFitc()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.train_finger_abd(pButLeft->GetCheck() , false);
}

void CFastDlg::OnBnClickedButtonGenerate3abdFull()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.generate_finger_3abd(pButLeft->GetCheck(), true);
}

void CFastDlg::OnBnClickedButtonGenerate3abdFitc()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.generate_finger_3abd(pButLeft->GetCheck(), false);
}
void CFastDlg::OnBnClickedButtonGenerate4ikFull()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.generate_thumb_4ik(pButLeft->GetCheck(), true);
}

void CFastDlg::OnBnClickedButtonGenerate4ikFitc()
{
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	m_fastCal.generate_thumb_4ik(pButLeft->GetCheck(), false);
}


void CFastDlg::OnBnClickedButtonXfastCalibrate()
{
	CString strPath(m_fastCal.m_strBasePath.c_str());
	CString strResultPath(m_fastCal.m_strBasePath.c_str());
	CButton* pButLeft = (CButton*)GetDlgItem(IDC_CHECK_FAST_LEFT);
	bool bLeft = pButLeft->GetCheck();

	if(bLeft)
	{		
		strResultPath = strResultPath + L"raw/left/sp/xfast/";
		strPath = strPath + L"raw/left/sp/1base/*.raw";
	}
	else
	{
		strResultPath = strResultPath + L"raw/right/sp/xfast/";
		strPath = strPath + L"raw/right/sp/1base/*.raw";
	}
	::CreateDirectory(strResultPath, NULL);

	m_fastCal.generate_fk_groundtruth(bLeft);
	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(strPath);
	int iErrCode = 0;
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		CString strFileName = finder.GetFilePath();
		CRawClip clipInput;
		clipInput.LoadFromFile(GloveUtil::ToChar(strFileName));
		CRawClip clipResult = m_fastCal.xfast_calibrate(clipInput, bLeft, GloveUtil::ToChar(finder.GetFileName()));
		clipResult.SaveToFile(GloveUtil::ToChar(strResultPath + finder.GetFileName()));
	}
}

