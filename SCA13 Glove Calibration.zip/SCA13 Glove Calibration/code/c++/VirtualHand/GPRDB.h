#pragma once
#include <vector>
#include <string>
#include "RawAnimation.h"

class CGPRDBItem
{
public:
	CGPRDBItem();
	CGPRDBItem(CRawFrame frmSensor, CRawFrame frmSln);
	CRawFrame m_frmSensor;
	CRawFrame m_frmSln;
};


class CGPRDB
{
public:
	static CGPRDB* GetIKDB();
private:
	static CGPRDB* m_pIKDB;

public:
	std::vector<CGPRDBItem> m_arDBItem;

	void SaveToFile(std::string strPath);
	void LoadFromFile(std::string strPath);
	CRawClip GetClipSensor();
	CRawClip GetClipSln();

	std::vector<int> GetKNearestThumbSensor(CRawFrame frmTarget, int iK = 1, bool bHD = true);
	CRawFrame GetSlnGuessed(CRawFrame frmSensor, std::vector<int> arIdx);
	bool CheckQuality(CGPRDBItem item);
};

