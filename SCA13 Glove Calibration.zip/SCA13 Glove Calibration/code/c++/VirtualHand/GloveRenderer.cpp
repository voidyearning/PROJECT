#include "stdafx.h"
#include "GloveRenderer.h"
#include "RGBColor.h"


//=========================================================================
COpenGLHandRendererKin::COpenGLHandRendererKin()
{
	m_bShowDOF = true;
	m_bWireframe = false;	
	m_fJointSize = 0.5;
	
	m_bShowProb = false;
	m_bHighlightActive = false;
	m_bShowHand = true;
}
COpenGLHandRendererKin::COpenGLHandRendererKin(CHandSkeletonKin* pHand)
{
	m_pHand = pHand;
	m_bShowDOF = true;
	m_bWireframe = false;
	m_fJointSize = 0.5;
	
	m_bShowProb = false;
	m_bHighlightActive = false;
	m_bShowHand = true;

	m_probRenderer = CProbFrameRenderer(pHand);
}
COpenGLHandRendererKin::~COpenGLHandRendererKin()
{

}

void COpenGLHandRendererKin::SetHand(CHandSkeletonKin* pHand)
{
	m_pHand = pHand;
}
void COpenGLHandRendererKin::SetWireframe(bool bWireframe)
{
	m_bWireframe = bWireframe;
}
void COpenGLHandRendererKin::RenderProbability3DSpace()
{
	if(!m_bShowProb)
		return;

	if(m_probRenderer.m_probFrame.m_arProbData.size() == 0)
	{
		glPushMatrix();
		glRotated(m_pHand->m_fWristAbd, 0.0, 1.0, 0.0);
		glRotated(m_pHand->m_fWristFlex, 0.0, 0.0, 1.0);
		m_probRenderer.RenderBoundary();
		glPopMatrix();
	}

	m_probRenderer.Render();
}


void TestColor()
{
	COLORREF iFullRGB = RGB(255, 255, 255);
	//int iFullRGB = 768;
	for(int i = 0; i <= iFullRGB; i = i + 1000)
	{
		//double dProb = (x + PROB_SPACE_SIZE) / (double) (2 * PROB_SPACE_SIZE);
		//COLORREF iColor = iFullRGB * dProb;
		int iRValue = 0; 
		int iGValue = 0;
		int iBValue = 0; 

		CKinematicPoint color = CProbFrameRenderer::Scalar2RGB(i, 0, iFullRGB);
		glColor3f(color.m_fX, color.m_fY, color.m_fZ);

		glPushMatrix();
		glTranslatef(i/(double)(iFullRGB/4), 0, 0);
		glutSolidCube(0.5);
		glPopMatrix();
	}
	glEnd();
}
void COpenGLHandRendererKin::Render()
{
	if(m_pHand == NULL)
		return;

	//show probability in space
	if(m_bShowProb)
		//TestColor();
		RenderProbability3DSpace();

	if(!m_bShowHand)
		return;

	//kinematic hand
	glPushMatrix();
	glColor3ub(RGB_FOREARM);
	RENDER_FOREARM(m_fJointSize, 20);		
	glRotated(m_pHand->m_fWristAbd, 0.0, 1.0, 0.0);
	glRotated(m_pHand->m_fWristFlex, 0.0, 0.0, 1.0);
	CKinematicHand* pHandKin = m_pHand->m_pHand;
	for(int ic = 0; ic < pHandKin->m_arChain.size(); ++ic)
	{
		glPushMatrix();
		CKinematicChain* pChain = pHandKin->m_arChain[ic];		
		switch(ic)
		{
		case 0: glColor3ub(m_clrThumb.m_fX, m_clrThumb.m_fY, m_clrThumb.m_fZ); break;
		case 1: glColor3ub(m_clrIndex.m_fX, m_clrIndex.m_fY, m_clrIndex.m_fZ); break;
		case 2: glColor3ub(m_clrMid.m_fX, m_clrMid.m_fY, m_clrMid.m_fZ); break;
		case 3: glColor3ub(m_clrRing.m_fX, m_clrRing.m_fY, m_clrRing.m_fZ); break;
		case 4: glColor3ub(m_clrPinky.m_fX, m_clrPinky.m_fY, m_clrPinky.m_fZ); break;
		}
		glTranslatef(pChain->m_posRoot.m_fX, pChain->m_posRoot.m_fY, pChain->m_posRoot.m_fZ);
		GLUquadricObj *pobj = gluNewQuadric();
	
		for(int i = 0; i < pChain->m_arJoint.size(); ++i)
		{					
			RENDER_JOINT(m_fJointSize);//at previous joint i-1 position, draw here
			CKinematicJoint* pJoint = pChain->m_arJoint[i];//current joint i	
			RENDER_ORTHO_BONE_TO(m_fJointSize, pJoint->m_posLocalCoord.m_fX, pJoint->m_posLocalCoord.m_fY,pJoint->m_posLocalCoord.m_fZ);//draw link from joint i-1 to joint i
			glTranslatef(pJoint->m_posLocalCoord.m_fX, pJoint->m_posLocalCoord.m_fY,pJoint->m_posLocalCoord.m_fZ);//translate from previous joint i-1 to current joint i
			for(int j = 0; j < pJoint->m_arDOF.size(); ++j)
			{
				CKinematicDOF* pDOF = pJoint->m_arDOF[j];
				glRotated(pDOF->m_dLocalRotationAngle, pDOF->m_vecLocalAxis.m_fX, pDOF->m_vecLocalAxis.m_fY, pDOF->m_vecLocalAxis.m_fZ);

				if(pDOF->m_vecLocalAxis.m_fX==1)
					glRotated(90, 0, 1, 0);
				if(pDOF->m_vecLocalAxis.m_fY == 1)
					glRotated(-90, 1, 0, 0);
			
				//if(m_bShowDOF)
				//	gluCylinder (pobj, 0.2, 0.2, 1.0, 4, 4);
			
				if(pDOF->m_vecLocalAxis.m_fX==1)
					glRotated(-90, 0, 1, 0);
				if(pDOF->m_vecLocalAxis.m_fY==1)
					glRotated(90, 1, 0, 0);			
			}
		}
		RENDER_JOINT(m_fJointSize);
		RENDER_NAIL(m_fJointSize, 0.5);
		glPopMatrix();
	}
	glPopMatrix();
}
