#pragma once
#include "RawAnimation.h"

// CKinematicRotationCtrl dialog

class CKinematicRotationCtrl : public CDialog
{
	DECLARE_DYNAMIC(CKinematicRotationCtrl)

public:
	CKinematicRotationCtrl(bool bLeft = true, CWnd* pParent = NULL);   // standard constructor
	virtual ~CKinematicRotationCtrl();
	virtual BOOL OnInitDialog();
	bool m_bLeft;
	CRawFrame* m_pFrmRaw;
	bool m_bRealtimeMocap;
	void SetReadOnly(bool bReadOnly = true);
	void UpdateFrameToUI();
	void UpdateUIToFrame();
	void SetRealtimeMocap(bool bRealtimeMocap = true);
	void TouchFrame(CRawFrame& frmRaw);
	void TouchClip(CRawClip& clipRaw);
	void SynchronizePlayback(int iIdx = -1, float fVal = 0);

// Dialog Data
	enum { IDD = IDD_CTRL_KINEMATIC_ROTATION };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeEditThumbRollRotation0();
	afx_msg void OnEnChangeEditThumbAbdRotation1();
	afx_msg void OnEnChangeEditThumbVirtualRotation2();
	afx_msg void OnEnChangeEditThumbFlexProxRotation3();
	afx_msg void OnEnChangeEditThumbDistRotation4();
	afx_msg void OnEnChangeEditIndexAbdPalmRotation5();
	afx_msg void OnEnChangeEditIndexFlexPalmRotation6();
	afx_msg void OnEnChangeEditIndexAbdRotation7();
	afx_msg void OnEnChangeEditIndexFlexProxRotation8();
	afx_msg void OnEnChangeEditIndexFlexMidRotation9();
	afx_msg void OnEnChangeEditIndexFlexDistRotation10();
	afx_msg void OnEnChangeEditMiddleAbdPalmRotation11();
	afx_msg void OnEnChangeEditMiddleFlexPalmRotation12();
	afx_msg void OnEnChangeEditMiddleAbdRotation13();
	afx_msg void OnEnChangeEditMiddleFlexProxRotation14();
	afx_msg void OnEnChangeEditMiddleFlexMidRotation15();
	afx_msg void OnEnChangeEditMiddleFlexDistRotation16();
	afx_msg void OnEnChangeEditRingAbdPalmRotation17();
	afx_msg void OnEnChangeEditRingFlexPalmRotation18();
	afx_msg void OnEnChangeEditRingAbdRotation19();
	afx_msg void OnEnChangeEditRingFlexProxRotation20();
	afx_msg void OnEnChangeEditRingFlexMidRotation21();
	afx_msg void OnEnChangeEditRingFlexDistRotation22();
	afx_msg void OnEnChangeEditPinkyAbdPalmRotation23();
	afx_msg void OnEnChangeEditPinkyFlexPalmRotation24();
	afx_msg void OnEnChangeEditPinkyAbdRotation25();
	afx_msg void OnEnChangeEditPinkyFlexProxRotation26();
	afx_msg void OnEnChangeEditPinkyFlexMidRotation27();
	afx_msg void OnEnChangeEditPinkyFlexDistRotation28();
	afx_msg void OnEnChangeEditWristFlexRotation29();
	afx_msg void OnEnChangeEditWristAbdRotation30();
	afx_msg void OnBnClickedButtonIkActiveTouch();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedButtonIkAdvanced();
};
