#include "GloveUtil.h"
#include "GloveSkeleton.h"
#include <fstream>

float GloveUtil::linearAdjust(float x, float x1, float x2, float y1, float y2)
{
	float y = y1 + (y2 - y1) * (x - x1) / (x2 - x1);
	if(abs(x2-x1) <= 0.5)
		return 0.2 * y1 + 0.8 * y2;
	return y;
}
int GloveUtil::GlvIdx2RawIdx(int iGlvIdx)
{
	switch(iGlvIdx)
	{
	case CGlvStructre::glv_thumbTMJ: return HAND_SKEL_DOF_THUMB_ROLL;
	case CGlvStructre::glv_thumbMPJ: return HAND_SKEL_DOF_THUMB_FLEX_PROX;
	case CGlvStructre::glv_thumbIJ: return HAND_SKEL_DOF_THUMB_FLEX_DIST; 
	case CGlvStructre::glv_thumbAbduction: return HAND_SKEL_DOF_THUMB_ABD;

	case CGlvStructre::glv_indexMPJ: return HAND_SKEL_DOF_INDEX_FLEX_PROX;
	case  CGlvStructre::glv_indexPIJ: return HAND_SKEL_DOF_INDEX_FLEX_MID;
	case CGlvStructre::glv_indexDIJ: return HAND_SKEL_DOF_INDEX_FLEX_DIST;
	case CGlvStructre::glv_indexAbduction: return HAND_SKEL_DOF_INDEX_ABD;

	case CGlvStructre::glv_middleMPJ: return HAND_SKEL_DOF_MID_FLEX_PROX;
	case CGlvStructre::glv_middlePIJ: return HAND_SKEL_DOF_MID_FLEX_MID;
	case CGlvStructre::glv_middleDIJ: return HAND_SKEL_DOF_MID_FLEX_DIST;
	case CGlvStructre::glv_middleAbudction: return HAND_SKEL_DOF_MID_ABD;

	case CGlvStructre::glv_ringMPJ: return HAND_SKEL_DOF_RING_FLEX_PROX;
	case CGlvStructre::glv_ringPIJ: return HAND_SKEL_DOF_RING_FLEX_MID;
	case CGlvStructre::glv_ringDIJ: return HAND_SKEL_DOF_RING_FLEX_DIST;
	case CGlvStructre::glv_ringAbduction: return HAND_SKEL_DOF_RING_ABD;

	case CGlvStructre::glv_pinkieMPJ: return HAND_SKEL_DOF_PINKY_FLEX_PROX;
	case CGlvStructre::glv_pinkiePIJ: return HAND_SKEL_DOF_PINKY_FLEX_MID;
	case CGlvStructre::glv_pinkieDIJ: return HAND_SKEL_DOF_PINKY_FLEX_DIST;
	case CGlvStructre::glv_pinkieAbduction: return HAND_SKEL_DOF_PINKY_ABD;

	case CGlvStructre::glv_palmArch: return -1;//TODO: implementation
	case CGlvStructre::glv_wristPitch: return HAND_SKEL_DOF_WRIST_FLEX;
	case CGlvStructre::glv_wristYaw: return HAND_SKEL_DOF_WRIST_ABD;
	}
	return -1;
}
int GloveUtil::RawIdx2GlvIdx(int iRawIdx)
{
	//TODO: static const int glv_palmArch = 20;
	switch(iRawIdx)
	{
	case HAND_SKEL_DOF_THUMB_ROLL: return CGlvStructre::glv_thumbTMJ;
	case HAND_SKEL_DOF_THUMB_ABD: return CGlvStructre::glv_thumbAbduction;
	case HAND_SKEL_DOF_THUMB_VIRTUAL: return -1;
	case HAND_SKEL_DOF_THUMB_FLEX_PROX: return CGlvStructre::glv_thumbMPJ;
	case HAND_SKEL_DOF_THUMB_FLEX_DIST: return CGlvStructre::glv_thumbIJ;
		
	case HAND_SKEL_DOF_INDEX_ABD_PALM: return -1; 
	case HAND_SKEL_DOF_INDEX_FLEX_PALM: return -1;
	case HAND_SKEL_DOF_INDEX_ABD: return CGlvStructre::glv_indexAbduction;
	case HAND_SKEL_DOF_INDEX_FLEX_PROX: return CGlvStructre::glv_indexMPJ;
	case HAND_SKEL_DOF_INDEX_FLEX_MID: return CGlvStructre::glv_indexPIJ;
	case HAND_SKEL_DOF_INDEX_FLEX_DIST: return CGlvStructre::glv_indexDIJ;
		
	case HAND_SKEL_DOF_MID_ABD_PALM: return -1;
	case HAND_SKEL_DOF_MID_FLEX_PALM: return -1;
	case HAND_SKEL_DOF_MID_ABD: return CGlvStructre::glv_middleAbudction;
	case HAND_SKEL_DOF_MID_FLEX_PROX: return CGlvStructre::glv_middleMPJ;
	case HAND_SKEL_DOF_MID_FLEX_MID: return CGlvStructre::glv_middlePIJ;
	case HAND_SKEL_DOF_MID_FLEX_DIST: return CGlvStructre::glv_middleDIJ;
		
	case HAND_SKEL_DOF_RING_ABD_PALM: return -1;
	case HAND_SKEL_DOF_RING_FLEX_PALM: return -1;
	case HAND_SKEL_DOF_RING_ABD: return CGlvStructre::glv_ringAbduction;
	case HAND_SKEL_DOF_RING_FLEX_PROX: return CGlvStructre::glv_ringMPJ;
	case HAND_SKEL_DOF_RING_FLEX_MID: return CGlvStructre::glv_ringPIJ;
	case HAND_SKEL_DOF_RING_FLEX_DIST: return CGlvStructre::glv_ringDIJ;
		
	case HAND_SKEL_DOF_PINKY_ABD_PALM: return -1;
	case HAND_SKEL_DOF_PINKY_FLEX_PALM: return -1;
	case HAND_SKEL_DOF_PINKY_ABD: return CGlvStructre::glv_pinkieAbduction;
	case HAND_SKEL_DOF_PINKY_FLEX_PROX: return CGlvStructre::glv_pinkieMPJ;
	case HAND_SKEL_DOF_PINKY_FLEX_MID: return CGlvStructre::glv_pinkiePIJ;
	case HAND_SKEL_DOF_PINKY_FLEX_DIST: return CGlvStructre::glv_pinkieDIJ;
		
	case HAND_SKEL_DOF_WRIST_FLEX: return CGlvStructre::glv_wristPitch;
	case HAND_SKEL_DOF_WRIST_ABD: return CGlvStructre::glv_wristYaw;
	}
	return -1;
}
//adjust to  (-180, 180]
float GloveUtil::NormalizeDegree(float fDegree)
{
	while(fDegree <= -180)
		fDegree = fDegree + 360;

	while(fDegree > 180)
		fDegree = fDegree - 360;

	ASSERT(fDegree<=180 && fDegree > -180);
	return fDegree;
}
CGlvFrame GloveUtil::GloveDataToFrame(std::vector<float> arData)
{
	CGlvFrame frame;
	if(arData.size() == 0)
		return frame;

	frame.m_fTime = arData[0];
	for(int i = 1; i < arData.size(); ++i)
		frame.m_arData.push_back(arData[i]);

	return frame;
}
CString GloveUtil::GloveDataToStringRadian(std::vector<float> arData)
{
	CString strFrame = L"";
	if(arData.size() == 0)
		return strFrame;

	CString strData = L"";
	strData.Format(L"time: %f\r\n", arData[0]);
	//strFrame += strData;

	strData = L"";
	strData.Format(L"0-thumbTMJ: %f\t", arData[1]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"1-thumbMPJ: %f\t", arData[2]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"2-thumbIJ: %f\t", arData[3]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"3-thumbAbduction: %f\r\n", arData[4]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"4-indexMPJ: %f\t", arData[5]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"5-indexPIJ: %f\t", arData[6]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"6-indexDIJ: %f\t", arData[7]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"7-indexAbduction: %f\r\n", arData[8]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"8-middleMPJ: %f\t", arData[9]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"9-middlePIJ: %f\t", arData[10]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"10-middleDIJ: %f\t", arData[11]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"11-middleAbudction: %f\r\n", arData[12]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"12-ringMPJ: %f\t", arData[13]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"13-ringPIJ: %f\t", arData[14]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"14-ringDIJ: %f\t", arData[15]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"15-ringAbduction: %f\r\n", arData[16]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"16-pinkieMPJ: %f\t", arData[17]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"17-pinkiePIJ: %f\t", arData[18]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"18-pinkieDIJ: %f\t", arData[19]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"19-pinkieAbduction: %f\r\n", arData[20]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"20-palmarch: %f\t", arData[21]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"21-palmflex: %f\t", arData[22]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"22-palmAbduc: %f\r\n", arData[23]);
	strFrame += strData;

	return strFrame;

}
CString GloveUtil::GloveDataToStringDegree(std::vector<float> arData)
{
	CString strFrame = L"";
	if(arData.size() == 0)
		return strFrame;

	CString strData = L"";
	strData.Format(L"time: %f\r\n", arData[0]);
	//strFrame += strData;

	strData = L"";
	strData.Format(L"0-thumbTMJ: %f\t", RadianToDegree(arData[1]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"1-thumbMPJ: %f\t", RadianToDegree(arData[2]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"2-thumbIJ: %f\t", RadianToDegree(arData[3]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"3-thumbAbduction: %f\r\n", RadianToDegree(arData[4]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"4-indexMPJ: %f\t", RadianToDegree(arData[5]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"5-indexPIJ: %f\t", RadianToDegree(arData[6]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"6-indexDIJ: %f\t", RadianToDegree(arData[7]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"7-indexAbduction: %f\r\n", RadianToDegree(arData[8]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"8-middleMPJ: %f\t", RadianToDegree(arData[9]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"9-middlePIJ: %f\t", RadianToDegree(arData[10]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"10-middleDIJ: %f\t", RadianToDegree(arData[11]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"11-middleAbudction: %f\r\n", RadianToDegree(arData[12]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"12-ringMPJ: %f\t", RadianToDegree(arData[13]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"13-ringPIJ: %f\t", RadianToDegree(arData[14]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"14-ringDIJ: %f\t", RadianToDegree(arData[15]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"15-ringAbduction: %f\r\n", RadianToDegree(arData[16]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"16-pinkieMPJ: %f\t", RadianToDegree(arData[17]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"17-pinkiePIJ: %f\t", RadianToDegree(arData[18]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"18-pinkieDIJ: %f\t", RadianToDegree(arData[19]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"19-pinkieAbduction: %f\r\n", RadianToDegree(arData[20]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"20-palmarch: %f\t", RadianToDegree(arData[21]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"21-palmflex: %f\t", RadianToDegree(arData[22]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"22-palmAbduc: %f\r\n", RadianToDegree(arData[23]));
	strFrame += strData;

	return strFrame;
}
CString GloveUtil::GloveDataToString(std::vector<float> arData, std::vector<float> arSensor)
{
	CString strFrame = L"";
	if(arData.size() == 0)
		return strFrame;

	CString strData = L"";
	strData.Format(L"time: %.1f\r\n", arData[0]);
	//strFrame += strData;

	strData = L"";
	strData.Format(L"0-thumbTMJ: %.1f-%.1f\t", RadianToDegree(arData[1]), arSensor[0]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"1-thumbMPJ: %.1f-%.1f\t", RadianToDegree(arData[2]), arSensor[1]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"2-thumbIJ: %.1f-%.1f\t", RadianToDegree(arData[3]), arSensor[2]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"3-thumbAbduction: %.1f-%.1f\r\n", RadianToDegree(arData[4]), arSensor[3]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"4-indexMPJ: %.1f-%.1f\t", RadianToDegree(arData[5]), arSensor[4]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"5-indexPIJ: %.1f-%.1f\t", RadianToDegree(arData[6]), arSensor[5]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"6-indexDIJ: %.1f-%.1f\t", RadianToDegree(arData[7]), arSensor[6]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"7-indexAbduction: %.1f-%.1f\r\n", RadianToDegree(arData[8]), arSensor[7]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"8-middleMPJ: %.1f-%.1f\t", RadianToDegree(arData[9]), arSensor[8]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"9-middlePIJ: %.1f-%.1f\t", RadianToDegree(arData[10]), arSensor[9]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"10-middleDIJ: %.1f-%.1f\t", RadianToDegree(arData[11]), arSensor[10]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"11-middleAbudction: %.1f-%.1f\r\n", RadianToDegree(arData[12]), arSensor[11]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"12-ringMPJ: %.1f-%.1f\t", RadianToDegree(arData[13]), arSensor[12]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"13-ringPIJ: %.1f-%.1f\t", RadianToDegree(arData[14]), arSensor[13]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"14-ringDIJ: %.1f-%.1f\t", RadianToDegree(arData[15]), arSensor[14]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"15-ringAbduction: %.1f-%.1f\r\n", RadianToDegree(arData[16]), arSensor[15]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"16-pinkieMPJ: %.1f-%.1f\t", RadianToDegree(arData[17]), arSensor[16]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"17-pinkiePIJ: %.1f-%.1f\t", RadianToDegree(arData[18]), arSensor[17]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"18-pinkieDIJ: %.1f-%.1f\t", RadianToDegree(arData[19]), arSensor[18]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"19-pinkieAbduction: %.1f-%.1f\r\n", RadianToDegree(arData[20]), arSensor[19]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"20-palmarch: %.1f-%.1f\t", RadianToDegree(arData[21]), arSensor[20]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"21-palmflex: %.1f-%.1f\t", RadianToDegree(arData[22]), arSensor[21]);
	strFrame += strData;

	strData = L"";
	strData.Format(L"22-palmAbduc: %.1f-%.1f\r\n", RadianToDegree(arData[23]), arSensor[22]);
	strFrame += strData;

	return strFrame;
}
CString GloveUtil::FrameToString(CGlvFrame frame)
{
	CString strFrame = L"";
	if(frame.m_arData.size() == 0)
		return strFrame;

	CString strData = L"";
	strData.Format(L"time: %f\r\n", frame.m_fTime);
	strFrame += strData;

	strData = L"";
	strData.Format(L"0-thumbTMJ: %f\t", RadianToDegree(frame.m_arData[0]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"1-thumbMPJ: %f\t", RadianToDegree(frame.m_arData[1]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"2-thumbIJ: %f\t", RadianToDegree(frame.m_arData[2]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"3-thumbAbduction: %f\r\n", RadianToDegree(frame.m_arData[3]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"4-indexMPJ: %f\t", RadianToDegree(frame.m_arData[4]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"5-indexPIJ: %f\t", RadianToDegree(frame.m_arData[5]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"6-indexDIJ: %f\t", RadianToDegree(frame.m_arData[6]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"7-indexAbduction: %f\r\n", RadianToDegree(frame.m_arData[7]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"8-middleMPJ: %f\t", RadianToDegree(frame.m_arData[8]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"9-middlePIJ: %f\t", RadianToDegree(frame.m_arData[9]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"10-middleDIJ: %f\t", RadianToDegree(frame.m_arData[10]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"11-middleAbudction: %f\r\n", RadianToDegree(frame.m_arData[11]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"12-ringMPJ: %f\t", RadianToDegree(frame.m_arData[12]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"13-ringPIJ: %f\t", RadianToDegree(frame.m_arData[13]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"14-ringDIJ: %f\t", RadianToDegree(frame.m_arData[14]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"15-ringAbduction: %f\r\n", RadianToDegree(frame.m_arData[15]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"16-pinkieMPJ: %f\t", RadianToDegree(frame.m_arData[16]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"17-pinkiePIJ: %f\t", RadianToDegree(frame.m_arData[17]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"18-pinkieDIJ: %f\t", RadianToDegree(frame.m_arData[18]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"19-pinkieAbduction: %f\r\n", RadianToDegree(frame.m_arData[19]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"20-palmarch: %f\t", RadianToDegree(frame.m_arData[20]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"21-palmflex: %f\t", RadianToDegree(frame.m_arData[21]));
	strFrame += strData;

	strData = L"";
	strData.Format(L"22-palmAbduc: %f\r\n", RadianToDegree(frame.m_arData[22]));
	strFrame += strData;

	return strFrame;

}
float GloveUtil::RadianToDegree(float fRadian)
{
	return fRadian * 180 / 3.1415926;
}
float GloveUtil::DegreeToRadian(float fDegree)
{
	return fDegree * 3.1415926 / 180;
}
//needs to delete by caller
char* GloveUtil::ToChar(CString strWide)
{
	wchar_t* wText_l = strWide.GetBuffer(0);
	DWORD dwNum_l = WideCharToMultiByte(CP_OEMCP,NULL,wText_l,-1,NULL,0,NULL,FALSE);
	char *psText_l;
	psText_l = new char[dwNum_l];
	WideCharToMultiByte(CP_OEMCP,NULL,wText_l,-1,psText_l,dwNum_l,NULL,FALSE);
	return psText_l;
}

#include   <shlobj.h>
CString GloveUtil::ShowFolderDlg(CString strTitle)
{
	CString strFilePath; 
	TCHAR pszBuffer[_MAX_PATH]; 
	BROWSEINFO bi;   
	LPITEMIDLIST pidl; 
	bi.hwndOwner = NULL; 
	bi.pidlRoot = NULL; 
	bi.pszDisplayName = pszBuffer; 
	bi.lpszTitle = strTitle;
	bi.ulFlags = BIF_RETURNFSANCESTORS | BIF_RETURNONLYFSDIRS; 
	bi.lpfn = NULL;
	bi.lParam = 0;
	if((pidl = SHBrowseForFolder(&bi)) != NULL) 
	{ 
		if(SHGetPathFromIDList(pidl, pszBuffer)) 
		{
			strFilePath = CString(pszBuffer);
			if(strFilePath.GetLength() > 0 && strFilePath.Right(1) != _T( "\\ "))   
				strFilePath   +=   _T( "\\ "); 
		} 
	}
	return strFilePath;
}

#include <math.h>
#define CLOSE_EPS 0.1
//under current gain-g and offset-o, the captured value and real value, calculate the apporipriate g' and o'
//NOTE that the annotation in glove sdk is wrong by saying a = g * (s - o)
//joint angle in radian a = g*(s + o)
//(a1 - a2) = g(s1 - s2), g, a1, a2 are known,
//(r1 - r2) = g'(s1 - s2), r1, r2 are known, then g' can be calculated
//g' = g * (r1 - r2)/(a1 - a2), when a1 != a2, 
CGloveCalibration GloveUtil::AutoCalibrate(CGloveCalibration curCalibration, CGlvFrame frmCap1, CGlvFrame frmReal1, CGlvFrame frmCap2, CGlvFrame frmReal2)
{
	CGloveCalibration newCalibration;
	for(int i = 0; i < frmCap1.m_arData.size(); ++i)
	{
		float a1 = frmCap1.m_arData[i];
		float a2 = frmCap2.m_arData[i];
		float r1 = frmReal1.m_arData[i];
		float r2 = frmReal2.m_arData[i];
		CGloveCalibrationItem curCal = curCalibration.m_arAdjustItem[i];

		//do not touch gain and offset of un-involved DOF
		if(fabs(a1 - a2) <= CLOSE_EPS || 
			fabs(r1 - r2) <= CLOSE_EPS)
		{
			newCalibration.m_arAdjustItem[i]=curCal;
			continue;
		}

		float g_ = (r1 - r2) * curCal.m_fGain / (a1 - a2);
		float s1 = a1/curCal.m_fGain - curCal.m_fOffset;
		float s2 = a2/curCal.m_fGain - curCal.m_fOffset;		
		float o_1 = (r1/g_ - s1);
		float o_2 = (r2/g_ - s2);
		if(fabs(o_1 - o_2) > 1)
			ASSERT(false);

		newCalibration.m_arAdjustItem[i] = (CGloveCalibrationItem(g_, o_1));
	}
	return newCalibration;
}

CGloveCalibrationItem GloveUtil::LinearCalibrate(float fs1, float fs2, float fr1, float fr2)
{
	CGloveCalibrationItem calItem;
	if(fs1 == fs2)
		calItem;

	calItem.m_fGain = (fr1-fr2) / (fs1 - fs2);
	if(calItem.m_fGain != 0)
		calItem.m_fOffset = (fr1 - calItem.m_fGain*fs1) / calItem.m_fGain;
	return calItem;
}
CGloveCalibration GloveUtil::LinearCalibrate(CGlvFrame frmFlat_s, CGlvFrame frmSpread_s, CGlvFrame frmFist_s, CGlvFrame frmExtBend_s,
		CGlvFrame frmFlat_r, CGlvFrame frmSpread_r, CGlvFrame frmFist_r, CGlvFrame frmExtBend_r)
{
	CGloveCalibration newCalibration;

	//abd: flat, spread
	newCalibration.m_arAdjustItem[CGlvStructre::glv_indexAbduction] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_indexAbduction], frmSpread_s.m_arData[CGlvStructre::glv_indexAbduction], 
		frmFlat_r.m_arData[CGlvStructre::glv_indexAbduction], frmSpread_r.m_arData[CGlvStructre::glv_indexAbduction]);

	newCalibration.m_arAdjustItem[CGlvStructre::glv_middleAbudction].m_fGain = 0;
	newCalibration.m_arAdjustItem[CGlvStructre::glv_middleAbudction].m_fOffset = 0;

	newCalibration.m_arAdjustItem[CGlvStructre::glv_ringAbduction] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_ringAbduction], frmSpread_s.m_arData[CGlvStructre::glv_ringAbduction],
		frmFlat_r.m_arData[CGlvStructre::glv_ringAbduction], frmSpread_r.m_arData[CGlvStructre::glv_ringAbduction]);

	newCalibration.m_arAdjustItem[CGlvStructre::glv_pinkieAbduction] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_pinkieAbduction], frmSpread_s.m_arData[CGlvStructre::glv_pinkieAbduction],
		frmFlat_r.m_arData[CGlvStructre::glv_pinkieAbduction], frmSpread_r.m_arData[CGlvStructre::glv_pinkieAbduction]);

	//flex: flat, fist
	newCalibration.m_arAdjustItem[CGlvStructre::glv_indexMPJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_indexMPJ], frmFist_s.m_arData[CGlvStructre::glv_indexMPJ],
		frmFlat_r.m_arData[CGlvStructre::glv_indexMPJ], frmFist_r.m_arData[CGlvStructre::glv_indexMPJ]);	
	newCalibration.m_arAdjustItem[CGlvStructre::glv_indexPIJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_indexPIJ], frmFist_s.m_arData[CGlvStructre::glv_indexPIJ],
		frmFlat_r.m_arData[CGlvStructre::glv_indexPIJ], frmFist_r.m_arData[CGlvStructre::glv_indexPIJ]);
	newCalibration.m_arAdjustItem[CGlvStructre::glv_indexDIJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_indexDIJ], frmFist_s.m_arData[CGlvStructre::glv_indexDIJ],
		frmFlat_r.m_arData[CGlvStructre::glv_indexDIJ], frmFist_r.m_arData[CGlvStructre::glv_indexDIJ]);
	//middle
	newCalibration.m_arAdjustItem[CGlvStructre::glv_middleMPJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_middleMPJ], frmFist_s.m_arData[CGlvStructre::glv_middleMPJ],
		frmFlat_r.m_arData[CGlvStructre::glv_middleMPJ], frmFist_r.m_arData[CGlvStructre::glv_middleMPJ]);	
	newCalibration.m_arAdjustItem[CGlvStructre::glv_middlePIJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_middlePIJ], frmFist_s.m_arData[CGlvStructre::glv_middlePIJ],
		frmFlat_r.m_arData[CGlvStructre::glv_middlePIJ], frmFist_r.m_arData[CGlvStructre::glv_middlePIJ]);	
	newCalibration.m_arAdjustItem[CGlvStructre::glv_middleDIJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_middleDIJ], frmFist_s.m_arData[CGlvStructre::glv_middleDIJ],
		frmFlat_r.m_arData[CGlvStructre::glv_middleDIJ], frmFist_r.m_arData[CGlvStructre::glv_middleDIJ]);
	//ring	
	newCalibration.m_arAdjustItem[CGlvStructre::glv_ringMPJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_ringMPJ], frmFist_s.m_arData[CGlvStructre::glv_ringMPJ],
		frmFlat_r.m_arData[CGlvStructre::glv_ringMPJ], frmFist_r.m_arData[CGlvStructre::glv_ringMPJ]);	
	newCalibration.m_arAdjustItem[CGlvStructre::glv_ringPIJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_ringPIJ], frmFist_s.m_arData[CGlvStructre::glv_ringPIJ],
		frmFlat_r.m_arData[CGlvStructre::glv_ringPIJ], frmFist_r.m_arData[CGlvStructre::glv_ringPIJ]);	
	newCalibration.m_arAdjustItem[CGlvStructre::glv_ringDIJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_ringDIJ], frmFist_s.m_arData[CGlvStructre::glv_ringDIJ],
		frmFlat_r.m_arData[CGlvStructre::glv_ringDIJ], frmFist_r.m_arData[CGlvStructre::glv_ringDIJ]);
	//pinky	
	newCalibration.m_arAdjustItem[CGlvStructre::glv_pinkieMPJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_pinkieMPJ], frmFist_s.m_arData[CGlvStructre::glv_pinkieMPJ],
		frmFlat_r.m_arData[CGlvStructre::glv_pinkieMPJ], frmFist_r.m_arData[CGlvStructre::glv_pinkieMPJ]);	
	newCalibration.m_arAdjustItem[CGlvStructre::glv_pinkiePIJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_pinkiePIJ], frmFist_s.m_arData[CGlvStructre::glv_pinkiePIJ],
		frmFlat_r.m_arData[CGlvStructre::glv_pinkiePIJ], frmFist_r.m_arData[CGlvStructre::glv_pinkiePIJ]);	
	newCalibration.m_arAdjustItem[CGlvStructre::glv_pinkieDIJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_pinkieDIJ], frmFist_s.m_arData[CGlvStructre::glv_pinkieDIJ],
		frmFlat_r.m_arData[CGlvStructre::glv_pinkieDIJ], frmFist_r.m_arData[CGlvStructre::glv_pinkieDIJ]);
	//thumb: flat fist
	newCalibration.m_arAdjustItem[CGlvStructre::glv_thumbTMJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_thumbTMJ], frmFist_s.m_arData[CGlvStructre::glv_thumbTMJ],
		frmFlat_r.m_arData[CGlvStructre::glv_thumbTMJ], frmFist_r.m_arData[CGlvStructre::glv_thumbTMJ]);	
	newCalibration.m_arAdjustItem[CGlvStructre::glv_thumbMPJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_thumbMPJ], frmFist_s.m_arData[CGlvStructre::glv_thumbMPJ],
		frmFlat_r.m_arData[CGlvStructre::glv_thumbMPJ], frmFist_r.m_arData[CGlvStructre::glv_thumbMPJ]);	
	newCalibration.m_arAdjustItem[CGlvStructre::glv_thumbIJ] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_thumbIJ], frmFist_s.m_arData[CGlvStructre::glv_thumbIJ],
		frmFlat_r.m_arData[CGlvStructre::glv_thumbIJ], frmFist_r.m_arData[CGlvStructre::glv_thumbIJ]);	
	newCalibration.m_arAdjustItem[CGlvStructre::glv_thumbAbduction] = LinearCalibrate(
		frmFlat_s.m_arData[CGlvStructre::glv_thumbAbduction], frmFist_s.m_arData[CGlvStructre::glv_thumbAbduction],
		frmFlat_r.m_arData[CGlvStructre::glv_thumbAbduction], frmFist_r.m_arData[CGlvStructre::glv_thumbAbduction]);
	return newCalibration;
}
/*
Finger 0:
   0   142.8   0.0241471   0
   1   28.05   0.0194656   0
   2   130.05   0.0246399   0
   3   94.35   0.00640639   0
Finger 1:
   0   99.45   0.0192192   0
   1   61.2   0.0179872   0
   2   5.69969e-006   0.0246399   0
   3   127.5   0.0162624   0
Finger 2:
   0   94.35   0.0137984   0
   1   71.4   0.0219295   0
   2   5.69969e-006   0.0246399   0
   3   165.75   0.17248   0
Finger 3:
   0   112.2   0.0174944   0
   1   68.85   0.0226687   0
   2   5.69969e-006   0.0246399   0
   3   130.05   0.00394239   0
Finger 4:
   0   94.35   0.0150304   0
   1   66.3   0.01848   0
   2   5.69969e-006   0.0246399   0
   3   112.2   0.00468159   0
Finger 5:
   0   173.4   0.0246399   0
   1   112.2   0.0246399   0
   2   255   0.0167552   0
   3   60.0   0.00781   0
*/
CRawFrame GloveUtil::GlvToRaw(CGlvFrame frmGlv, bool bLeft)
{
	std::vector<float> arSensorDegreeData;
	for(int i = 0; i < frmGlv.m_arData.size(); ++i)
		arSensorDegreeData.push_back(RadianToDegree(frmGlv.m_arData[i]));

	CRawFrame frmRaw = CRawFrame::GetEmptyFrame();
	if(bLeft)
	{	
		frmRaw.m_arData[HAND_SKEL_DOF_THUMB_ROLL] = arSensorDegreeData[CGlvStructre::glv_thumbTMJ];
		frmRaw.m_arData[HAND_SKEL_DOF_INDEX_ABD_PALM] = 15;
		frmRaw.m_arData[HAND_SKEL_DOF_RING_ABD_PALM] = -15;
		frmRaw.m_arData[HAND_SKEL_DOF_PINKY_ABD_PALM] = -30;
	}
	if(bLeft == false)
	{
		frmRaw.m_arData[HAND_SKEL_DOF_THUMB_ROLL] = - arSensorDegreeData[CGlvStructre::glv_thumbTMJ];
		frmRaw.m_arData[HAND_SKEL_DOF_INDEX_ABD_PALM] = -15;
		frmRaw.m_arData[HAND_SKEL_DOF_RING_ABD_PALM] = 15;
		frmRaw.m_arData[HAND_SKEL_DOF_PINKY_ABD_PALM] = 30;
	}
	frmRaw.m_arData[HAND_SKEL_DOF_THUMB_ABD] =  arSensorDegreeData[CGlvStructre::glv_thumbAbduction];
	frmRaw.m_arData[HAND_SKEL_DOF_THUMB_VIRTUAL] = 0.25*frmRaw.m_arData[HAND_SKEL_DOF_THUMB_ROLL]-0.375*frmRaw.m_arData[HAND_SKEL_DOF_THUMB_ABD];
	frmRaw.m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX] = arSensorDegreeData[CGlvStructre::glv_thumbMPJ];
	frmRaw.m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST] = arSensorDegreeData[CGlvStructre::glv_thumbIJ];

	frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_PALM] = 0;
	frmRaw.m_arData[HAND_SKEL_DOF_INDEX_ABD] = arSensorDegreeData[CGlvStructre::glv_indexAbduction] - frmRaw.m_arData[HAND_SKEL_DOF_INDEX_ABD_PALM];
	frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX] = arSensorDegreeData[CGlvStructre::glv_indexMPJ];
	frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID] = arSensorDegreeData[CGlvStructre::glv_indexPIJ];
	frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST] = arSensorDegreeData[CGlvStructre::glv_indexDIJ];

	frmRaw.m_arData[HAND_SKEL_DOF_MID_ABD_PALM] = 0;
	frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_PALM] = 0;
	frmRaw.m_arData[HAND_SKEL_DOF_MID_ABD] = 0;
	frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_PROX] = arSensorDegreeData[CGlvStructre::glv_middleMPJ];
	frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_MID] = arSensorDegreeData[CGlvStructre::glv_middlePIJ];
	frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_DIST] = arSensorDegreeData[CGlvStructre::glv_middleDIJ];

	frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_PALM] = 0;
	frmRaw.m_arData[HAND_SKEL_DOF_RING_ABD] = arSensorDegreeData[CGlvStructre::glv_ringAbduction] - frmRaw.m_arData[HAND_SKEL_DOF_RING_ABD_PALM];
	frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_PROX] = arSensorDegreeData[CGlvStructre::glv_ringMPJ];
	frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_MID] = arSensorDegreeData[CGlvStructre::glv_ringPIJ];
	frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_DIST] = arSensorDegreeData[CGlvStructre::glv_ringDIJ];

	frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_PALM] = 0;
	frmRaw.m_arData[HAND_SKEL_DOF_PINKY_ABD] = arSensorDegreeData[CGlvStructre::glv_pinkieAbduction] - frmRaw.m_arData[HAND_SKEL_DOF_PINKY_ABD_PALM];
	frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX] = arSensorDegreeData[CGlvStructre::glv_pinkieMPJ];
	frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID] = arSensorDegreeData[CGlvStructre::glv_pinkiePIJ];
	frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST] = arSensorDegreeData[CGlvStructre::glv_pinkieDIJ];

	//wrist
	frmRaw.m_arData[HAND_SKEL_DOF_WRIST_FLEX] = arSensorDegreeData[CGlvStructre::glv_wristPitch];
	frmRaw.m_arData[HAND_SKEL_DOF_WRIST_ABD] = arSensorDegreeData[CGlvStructre::glv_wristYaw];
	return frmRaw;
}
CGlvFrame GloveUtil::RawToGlv(CRawFrame frmRaw, bool bLeft)
{	
	CGlvFrame frmGlv = CGlvFrame::GetEmptyFrame();
	frmGlv.m_arData[CGlvStructre::glv_thumbAbduction] =  frmRaw.m_arData[HAND_SKEL_DOF_THUMB_ABD];
	frmGlv.m_arData[CGlvStructre::glv_thumbMPJ] = frmRaw.m_arData[HAND_SKEL_DOF_THUMB_FLEX_PROX];
	frmGlv.m_arData[CGlvStructre::glv_thumbIJ] = frmRaw.m_arData[HAND_SKEL_DOF_THUMB_FLEX_DIST];

	frmGlv.m_arData[CGlvStructre::glv_indexAbduction] = frmRaw.m_arData[HAND_SKEL_DOF_INDEX_ABD] + frmRaw.m_arData[HAND_SKEL_DOF_INDEX_ABD_PALM];
	frmGlv.m_arData[CGlvStructre::glv_indexMPJ] = frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_PROX];
	frmGlv.m_arData[CGlvStructre::glv_indexPIJ] = frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_MID];
	frmGlv.m_arData[CGlvStructre::glv_indexDIJ] = frmRaw.m_arData[HAND_SKEL_DOF_INDEX_FLEX_DIST];

	frmGlv.m_arData[CGlvStructre::glv_middleMPJ] = frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_PROX];
	frmGlv.m_arData[CGlvStructre::glv_middlePIJ] = frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_MID];
	frmGlv.m_arData[CGlvStructre::glv_middleDIJ] = frmRaw.m_arData[HAND_SKEL_DOF_MID_FLEX_DIST];

	frmGlv.m_arData[CGlvStructre::glv_ringAbduction] = frmRaw.m_arData[HAND_SKEL_DOF_RING_ABD] + frmRaw.m_arData[HAND_SKEL_DOF_RING_ABD_PALM];
	frmGlv.m_arData[CGlvStructre::glv_ringMPJ] = frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_PROX];
	frmGlv.m_arData[CGlvStructre::glv_ringPIJ] = frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_MID];
	frmGlv.m_arData[CGlvStructre::glv_ringDIJ] = frmRaw.m_arData[HAND_SKEL_DOF_RING_FLEX_DIST];

	frmGlv.m_arData[CGlvStructre::glv_pinkieAbduction] = frmRaw.m_arData[HAND_SKEL_DOF_PINKY_ABD] + frmRaw.m_arData[HAND_SKEL_DOF_PINKY_ABD_PALM];
	frmGlv.m_arData[CGlvStructre::glv_pinkieMPJ] = frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_PROX];
	frmGlv.m_arData[CGlvStructre::glv_pinkiePIJ] = frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_MID];
	frmGlv.m_arData[CGlvStructre::glv_pinkieDIJ] = frmRaw.m_arData[HAND_SKEL_DOF_PINKY_FLEX_DIST];

	frmGlv.m_arData[CGlvStructre::glv_wristPitch] = frmRaw.m_arData[HAND_SKEL_DOF_WRIST_FLEX];
	frmGlv.m_arData[CGlvStructre::glv_wristYaw] = frmRaw.m_arData[HAND_SKEL_DOF_WRIST_ABD];

	if(bLeft)
		frmGlv.m_arData[CGlvStructre::glv_thumbTMJ] = frmRaw.m_arData[HAND_SKEL_DOF_THUMB_ROLL]; 
	else
		frmGlv.m_arData[CGlvStructre::glv_thumbTMJ] = - frmRaw.m_arData[HAND_SKEL_DOF_THUMB_ROLL];

	for(int i = 0; i < frmGlv.m_arData.size(); ++i)
		frmGlv.m_arData[i] = DegreeToRadian(frmGlv.m_arData[i]);
	return frmGlv;
}
CRawClip GloveUtil::GlvToRaw(CGlvClip clipGlv, bool bLeft)
{
	CRawClip clipRaw;
	for(int i = 0; i < clipGlv.m_arFrame.size(); ++i)
	{
		CGlvFrame frmGlv = clipGlv.m_arFrame[i];
		CRawFrame frmRaw = GlvToRaw(frmGlv, bLeft);
		clipRaw.m_arFrame.push_back(frmRaw);
	}
	return clipRaw;
}

CRawTimeClip GloveUtil::GlvToRawTime(CGlvClip clipGlv, bool bLeft)
{
	CRawTimeClip clipRawTime;
	for(int i = 0; i < clipGlv.m_arFrame.size(); ++i)
	{
		CGlvFrame frmGlv = clipGlv.m_arFrame[i];
		CRawFrame frmRaw = GlvToRaw(frmGlv, bLeft);
		clipRawTime.m_arFrame.push_back(frmRaw);
		clipRawTime.m_arTime.push_back(frmGlv.m_fTime);
	}
	return clipRawTime;
}
CRawClip GloveUtil::RawTimeToRaw(CRawTimeClip clipRawTime)
{
	CRawClip clipResult;
	clipResult.m_arFrame = clipRawTime.m_arFrame;
	return clipResult;
}
CRawTimeClip GloveUtil::RawToRawTime(CRawClip clipRaw, CGlvClip clipGlvTimeRef)
{
	CRawTimeClip clipRawTime(clipRaw, clipGlvTimeRef);
	return clipRawTime;
}
CMarkersClip GloveUtil::RawToMarkers(CRawClip clipRaw, bool bLeft)
{
	CHandSkeletonKin* pHand = new CHandSkeletonKin(!bLeft); 

	CMarkersClip clipMarkers;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = clipRaw.m_arFrame[i];
		pHand->UpdateFromKinematicData(frmRaw.m_arData);
		pHand->m_pHand->PopulateGlobalPosAndAxis();

		CMarkersFrame frmMarkers;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(0,0,0));//0-root
		CKinematicPos posThumbTip = pHand->m_pHand->m_arChain[0]->GetGlobalEndEffectorPos();
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posThumbTip.m_fX,posThumbTip.m_fY, posThumbTip.m_fZ));//1-thumb tip

		CKinematicChain* pChainIndex = pHand->m_pHand->m_arChain[1];
		CKinematicPos posIndexBase = pChainIndex->m_arJoint[1]->m_posGlobalCoord;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posIndexBase.m_fX, posIndexBase.m_fY, posIndexBase.m_fZ));//2-index base
		CKinematicPos posIndexPIP = pChainIndex->m_arJoint[3]->m_posGlobalCoord;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posIndexPIP.m_fX,posIndexPIP.m_fY,posIndexPIP.m_fZ));//3-index PIP

		CKinematicChain* pChainMid = pHand->m_pHand->m_arChain[2];
		CKinematicPos posMidPIP = pChainMid->m_arJoint[3]->m_posGlobalCoord;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posMidPIP.m_fX,posMidPIP.m_fY, posMidPIP.m_fZ));//4-mid PIP

		CKinematicChain* pChainRing = pHand->m_pHand->m_arChain[3];
		CKinematicPos posRingPIP = pChainRing->m_arJoint[3]->m_posGlobalCoord;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posRingPIP.m_fX,posRingPIP.m_fY, posRingPIP.m_fZ));//5-ring PIP

		CKinematicChain* pChainPinky = pHand->m_pHand->m_arChain[4];
		CKinematicPos posPinkyBase = pChainPinky->m_arJoint[1]->m_posGlobalCoord;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posPinkyBase.m_fX, posPinkyBase.m_fY, posPinkyBase.m_fZ));//6-pinky base
		CKinematicPos posPinkyPIP = pChainPinky->m_arJoint[3]->m_posGlobalCoord;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posPinkyPIP.m_fX, posPinkyPIP.m_fY, posPinkyPIP.m_fZ));//7-pinky PIP
		clipMarkers.m_arFrame.push_back(frmMarkers);
	}
	return clipMarkers;
}

CMarkersClip GloveUtil::RawTimeToMarkers(CRawTimeClip clipRawTime, bool bLeft)
{
	CHandSkeletonKin* pHand = new CHandSkeletonKin(!bLeft); 

	CMarkersClip clipMarkers;
	for(int i = 0; i < clipRawTime.m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = clipRawTime.m_arFrame[i];
		pHand->UpdateFromKinematicData(frmRaw.m_arData);
		pHand->m_pHand->PopulateGlobalPosAndAxis();

		CMarkersFrame frmMarkers;
		frmMarkers.m_fTime = clipRawTime.m_arTime[i];

		frmMarkers.m_arMarkers.push_back(CMarkerPosition(0,0,0));//0-root
		CKinematicPos posThumbTip = pHand->m_pHand->m_arChain[0]->GetGlobalEndEffectorPos();
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posThumbTip.m_fX,posThumbTip.m_fY, posThumbTip.m_fZ));//1-thumb tip

		CKinematicChain* pChainIndex = pHand->m_pHand->m_arChain[1];
		CKinematicPos posIndexBase = pChainIndex->m_arJoint[1]->m_posGlobalCoord;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posIndexBase.m_fX, posIndexBase.m_fY, posIndexBase.m_fZ));//2-index base
		CKinematicPos posIndexPIP = pChainIndex->m_arJoint[3]->m_posGlobalCoord;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posIndexPIP.m_fX,posIndexPIP.m_fY,posIndexPIP.m_fZ));//3-index PIP

		CKinematicChain* pChainMid = pHand->m_pHand->m_arChain[2];
		CKinematicPos posMidPIP = pChainMid->m_arJoint[3]->m_posGlobalCoord;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posMidPIP.m_fX,posMidPIP.m_fY, posMidPIP.m_fZ));//4-mid PIP

		CKinematicChain* pChainRing = pHand->m_pHand->m_arChain[3];
		CKinematicPos posRingPIP = pChainRing->m_arJoint[3]->m_posGlobalCoord;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posRingPIP.m_fX,posRingPIP.m_fY, posRingPIP.m_fZ));//5-ring PIP

		CKinematicChain* pChainPinky = pHand->m_pHand->m_arChain[4];
		CKinematicPos posPinkyBase = pChainPinky->m_arJoint[1]->m_posGlobalCoord;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posPinkyBase.m_fX, posPinkyBase.m_fY, posPinkyBase.m_fZ));//6-pinky base
		CKinematicPos posPinkyPIP = pChainPinky->m_arJoint[3]->m_posGlobalCoord;
		frmMarkers.m_arMarkers.push_back(CMarkerPosition(posPinkyPIP.m_fX, posPinkyPIP.m_fY, posPinkyPIP.m_fZ));//7-pinky PIP
		clipMarkers.m_arFrame.push_back(frmMarkers);
	}
	return clipMarkers;
}
CGlvClip GloveUtil::RawToGlv(CRawClip clipRaw, bool bLeft)
{
	CGlvClip clipGlv;
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = clipRaw.m_arFrame[i];
		CGlvFrame frmGlv = RawToGlv(frmRaw, bLeft);
		clipGlv.m_arFrame.push_back(frmGlv);
	}
	return clipGlv;
}
CGlvFrame GloveUtil::LinearCalibrateGlvToGlv(CGlvFrame frmUncalib, CGloveCalibration calib)
{	
	CGlvFrame frmCalib;
	for(int i = 0; i < frmUncalib.m_arData.size(); ++i)
	{
		CGloveCalibrationItem item = calib.m_arAdjustItem[i];
		float fDataCalibrated = item.m_fGain * (frmUncalib.m_arData[i] + item.m_fOffset);
		frmCalib.m_arData.push_back(fDataCalibrated);
	}
	return frmCalib;
}

CGlvFrame GloveUtil::LinearUnCalibrateGlvToGlv(CGlvFrame frmCalib, CGloveCalibration calib)
{
	CGlvFrame frmUnCalib;
	for(int i = 0; i < frmCalib.m_arData.size(); ++i)
	{
		CGloveCalibrationItem item = calib.m_arAdjustItem[i];
		float fDataUnCalibrated = (frmCalib.m_arData[i] / item.m_fGain) - item.m_fOffset;//item.m_fGain * (frmUncalib.m_arData[i] + item.m_fOffset);
		frmUnCalib.m_arData.push_back(fDataUnCalibrated);
	}
	return frmUnCalib;
}

CGlvClip GloveUtil::LinearCalibrateGlvToGlv(CGlvClip clipUncalib, CGloveCalibration calib)
{
	CGlvClip clipCalib;
	clipCalib.m_fBaseTime = clipUncalib.m_fBaseTime;
	clipCalib.m_fIntervalTime = clipUncalib.m_fIntervalTime;
	//calib frm by frm
	for(int i = 0; i < clipUncalib.GetFrameCount(); ++i)
	{
		CGlvFrame frmUncalib = clipUncalib.m_arFrame[i];
		CGlvFrame frmCalib = LinearCalibrateGlvToGlv(frmUncalib, calib);
		frmCalib.m_fTime = frmUncalib.m_fTime;
		clipCalib.m_arFrame.push_back(frmCalib);
	}
	return clipCalib;
}

CRawFrame GloveUtil::LinearCalibrateGlvToRaw(CGlvFrame frmUncalib, CGloveCalibration calib, bool bLeft)
{
	CRawFrame frmCalib;
	CGlvFrame frmCalibGlv = LinearCalibrateGlvToGlv(frmUncalib, calib);
	frmCalib = GlvToRaw(frmCalibGlv, bLeft);
	return frmCalib;
}

CRawClip GloveUtil::LinearCalibrateGlvToRaw(CGlvClip clipUncalib, CGloveCalibration calib, bool bLeft)
{
	CRawClip clipCalib;
	for(int i = 0; i < clipUncalib.GetFrameCount(); ++i)
	{
		CGlvFrame frmUncalib = clipUncalib.m_arFrame[i];		
		CRawFrame frmCalib = LinearCalibrateGlvToRaw(frmUncalib, calib, bLeft);
		clipCalib.m_arFrame.push_back(frmCalib);
	}
	return clipCalib;
}

CRawFrame GloveUtil::LinearCalibrateRawToRaw(CRawFrame frmUncalib, CGloveCalibration calib, bool bLeft)
{
	CGlvFrame frmUncalibGlv = RawToGlv(frmUncalib, bLeft);
	CGlvFrame frmCalibGlv = LinearCalibrateGlvToGlv(frmUncalibGlv, calib);
	CRawFrame frmCalib = GlvToRaw(frmCalibGlv, bLeft);
	return frmCalib;
}
CRawClip GloveUtil::LinearCalibrateRawToRaw(CRawClip clipUncalib, CGloveCalibration calib, bool bLeft)
{
	CRawClip clipCalib;
	for(int i = 0; i < clipUncalib.GetFrameCount(); ++i)	
	{
		CRawFrame frmUncalib = clipUncalib.m_arFrame[i];
		CRawFrame frmCalib = LinearCalibrateRawToRaw(frmUncalib, calib, bLeft);
		clipCalib.m_arFrame.push_back(frmCalib);
	}
	return clipCalib;
}

CRawClip GloveUtil::LinearUnCalibrateRawToRaw(CRawClip clipRaw, CGloveCalibration calib, bool bLeft)
{
	CRawClip clipUnCalib;
	for(int i = 0; i < clipRaw.GetFrameCount(); ++i)	
	{
		CRawFrame frmCalib = clipRaw.m_arFrame[i];
		CRawFrame frmUnCalib = LinearUnCalibrateRawToRaw(frmCalib, calib, bLeft);
		clipUnCalib.m_arFrame.push_back(frmUnCalib);
	}
	return clipUnCalib;
}
CRawFrame GloveUtil::LinearUnCalibrateRawToRaw(CRawFrame frmRaw, CGloveCalibration calib, bool bLeft)
{
	CGlvFrame frmCalibGlv = RawToGlv(frmRaw, bLeft);
	CGlvFrame frmUnCalibGlv = LinearUnCalibrateGlvToGlv(frmCalibGlv, calib);
	CRawFrame frmUnCalib = GlvToRaw(frmUnCalibGlv, bLeft);
	return frmUnCalib;
}
void GloveUtil::AdjustWrist(CRawClip* pClipRaw)
{
	int iSize = 31;
	for(int i = 0; i < pClipRaw->m_arFrame.size(); ++i)
	{
		pClipRaw->m_arFrame[i].m_arData[iSize-2] = pClipRaw->m_arFrame[i].m_arData[iSize-2] - 135;
		pClipRaw->m_arFrame[i].m_arData[iSize-1] = - 0.3 * pClipRaw->m_arFrame[i].m_arData[iSize-1] - 50;
	}
}

void GloveUtil::CopyThumb(CRawClip* pClipFrom, CRawClip* pClipTo)
{
	for(int i = 0; i < pClipTo->m_arFrame.size(); ++i)
	{
		pClipTo->m_arFrame[i].m_arData[0] = pClipFrom->m_arFrame[i].m_arData[0];
		pClipTo->m_arFrame[i].m_arData[1] = pClipFrom->m_arFrame[i].m_arData[1];
		pClipTo->m_arFrame[i].m_arData[2] = pClipFrom->m_arFrame[i].m_arData[2];
		pClipTo->m_arFrame[i].m_arData[3] = pClipFrom->m_arFrame[i].m_arData[3];
		pClipTo->m_arFrame[i].m_arData[4] = pClipFrom->m_arFrame[i].m_arData[4];
	}
}
void GloveUtil::BatchGlvToRawUnder(CString strGlvPath, CString strRawPath, bool bLeft)
{
	CreateDirectory(strRawPath, NULL);

	CString strGlvPath_tofind = strGlvPath + L"\\*.*";
	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(strGlvPath_tofind);
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		CString strTitle = finder.GetFileTitle();
		if(finder.IsDirectory())
		{
			if(strTitle == L"." || strTitle == L".." || strTitle.IsEmpty())
				continue;
			BatchGlvToRawUnder(strGlvPath + L"\\" + strTitle, strRawPath + L"\\" + strTitle, bLeft);
		}
		else
		{
			CString strFileName = finder.GetFileName();
			if(strFileName.Find(L".glv") == -1)
				continue;
			CGlvClip clipGlv;
			clipGlv.LoadFromFile(GloveUtil::ToChar(finder.GetFilePath()));
			CRawClip clipRaw = GloveUtil::GlvToRaw(clipGlv, bLeft);
			CString strRawName = strTitle + L".raw";
			clipRaw.SaveToFile(GloveUtil::ToChar(strRawPath+L"\\"+strRawName));
		}
	}
}

void GloveUtil::BatchRecalibUnder(CString strSrcPath, CString strDestPath, CGloveCalibration calib, bool bLeft)
{
	CreateDirectory(strDestPath, NULL);

	CString strSrcPath_tofind = strSrcPath + L"\\*.*";
	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(strSrcPath_tofind);
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		CString strTitle = finder.GetFileTitle();
		if(finder.IsDirectory())
		{
			if(strTitle == L"." || strTitle == L".." || strTitle.IsEmpty())
				continue;
			BatchRecalibUnder(strSrcPath + L"\\" + strTitle, strDestPath + L"\\" + strTitle, calib, bLeft);
		}
		else
		{
			CString strFileName = finder.GetFileName();
			if(strFileName.Find(L".raw") == -1)
				continue;
			CRawClip clipUncalibRaw;
			clipUncalibRaw.LoadFromFile(GloveUtil::ToChar(finder.GetFilePath()));
			CRawClip clipCalibRaw = GloveUtil::LinearCalibrateRawToRaw(clipUncalibRaw, calib, bLeft);
			CString strDestName = strTitle + L"_recalib.raw";
			clipCalibRaw.SaveToFile(GloveUtil::ToChar(strDestPath+L"\\"+strDestName));
		}
	}
}
void GloveUtil::BatchUncalibUnder(CString strSrcPath, CString strDestPath, CGloveCalibration calib, bool bLeft)
{
	CreateDirectory(strDestPath, NULL);

	CString strSrcPath_tofind = strSrcPath + L"\\*.*";
	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(strSrcPath_tofind);
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		CString strTitle = finder.GetFileTitle();
		if(finder.IsDirectory())
		{
			if(strTitle == L"." || strTitle == L".." || strTitle.IsEmpty())
				continue;
			BatchUncalibUnder(strSrcPath + L"\\" + strTitle, strDestPath + L"\\" + strTitle, calib, bLeft);
		}
		else
		{
			CString strFileName = finder.GetFileName();
			if(strFileName.Find(L".raw") == -1)
				continue;
			CRawClip clipUncalibRaw;
			clipUncalibRaw.LoadFromFile(GloveUtil::ToChar(finder.GetFilePath()));
			CRawClip clipCalibRaw = GloveUtil::LinearUnCalibrateRawToRaw(clipUncalibRaw, calib, bLeft);
			CString strDestName = strTitle + L"_uncalib.raw";
			clipCalibRaw.SaveToFile(GloveUtil::ToChar(strDestPath+L"\\"+strDestName));
		}
	}
}
void GloveUtil::BatchGPRfullUnder(CString strSrcPath, CString strDestPath, bool bLeft)
{
	CreateDirectory(strDestPath, NULL);

	CString strSrcPath_tofind = strSrcPath + L"\\*.*";
	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(strSrcPath_tofind);
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		CString strTitle = finder.GetFileTitle();
		if(finder.IsDirectory())
		{
			if(strTitle == L"." || strTitle == L".." || strTitle.IsEmpty())
				continue;
			BatchGPRfullUnder(strSrcPath + L"\\" + strTitle, strDestPath + L"\\" + strTitle, bLeft);
		}
		else
		{
			CString strFileName = finder.GetFileName();
			if(strFileName.Find(L".raw") == -1)
				continue;
			CRawClip clipUncalibRaw;
			clipUncalibRaw.LoadFromFile(GloveUtil::ToChar(finder.GetFilePath()));
			CRawClip clipCalibRaw = MatlabUtil::GPRCalibrate_full(clipUncalibRaw, bLeft);
			CString strDestName = strTitle + L"_gprfull.raw";
			clipCalibRaw.SaveToFile(GloveUtil::ToChar(strDestPath+L"\\"+strDestName));
		}
	}
}
void GloveUtil::BatchGPRfitcUnder(CString strSrcPath, CString strDestPath, bool bLeft)
{
	CreateDirectory(strDestPath, NULL);

	CString strSrcPath_tofind = strSrcPath + L"\\*.*";
	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(strSrcPath_tofind);
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		CString strTitle = finder.GetFileTitle();
		if(finder.IsDirectory())
		{
			if(strTitle == L"." || strTitle == L".." || strTitle.IsEmpty())
				continue;
			BatchGPRfitcUnder(strSrcPath + L"\\" + strTitle, strDestPath + L"\\" + strTitle, bLeft);
		}
		else
		{
			CString strFileName = finder.GetFileName();
			if(strFileName.Find(L".raw") == -1)
				continue;
			CRawClip clipUncalibRaw;
			clipUncalibRaw.LoadFromFile(GloveUtil::ToChar(finder.GetFilePath()));
			CRawClip clipCalibRaw = MatlabUtil::GPRCalibrate_fitc(clipUncalibRaw, bLeft);
			CString strDestName = strTitle + L"_gprfitc.raw";
			clipCalibRaw.SaveToFile(GloveUtil::ToChar(strDestPath+L"\\"+strDestName));
		}
	}
}
void GloveUtil::BatchWristUnder(CString strSrcPath, CString strDestPath, bool bLeft)
{
	CreateDirectory(strDestPath, NULL);

	CString strSrcPath_tofind = strSrcPath + L"\\*.*";
	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(strSrcPath_tofind);
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		CString strTitle = finder.GetFileTitle();
		if(finder.IsDirectory())
		{
			if(strTitle == L"." || strTitle == L".." || strTitle.IsEmpty())
				continue;
			BatchWristUnder(strSrcPath + L"\\" + strTitle, strDestPath + L"\\" + strTitle, bLeft);
		}
		else
		{
			CString strFileName = finder.GetFileName();
			if(strFileName.Find(L".raw") == -1)
				continue;
			CRawClip clip;
			clip.LoadFromFile(GloveUtil::ToChar(finder.GetFilePath()));
			//GloveUtil::AdjustWrist(&clip);
			clip.ZeroWristRotations();
			clip.SuppressOverbend(bLeft);
			CString strDestName = strTitle + L"_wa.raw";
			clip.SaveToFile(GloveUtil::ToChar(strDestPath+L"\\"+strDestName));
		}
	}
}

#include "GloveSkeleton.h"
void GloveUtil::BatchToBvh(CString strSrcPath, CString strDestPath, bool bLeft)
{
	CreateDirectory(strDestPath, NULL);

	CString strSrcPath_tofind = strSrcPath + L"\\*.*";
	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(strSrcPath_tofind);
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		CString strTitle = finder.GetFileTitle();
		if(finder.IsDirectory())
		{
			if(strTitle == L"." || strTitle == L".." || strTitle.IsEmpty())
				continue;
			BatchToBvh(strSrcPath + L"\\" + strTitle, strDestPath + L"\\" + strTitle, bLeft);
		}
		else
		{
			CString strFileName = finder.GetFileName();
			if(strFileName.Find(L".raw") == -1)
				continue;
			CRawClip clipRaw;
			clipRaw.LoadFromFile(GloveUtil::ToChar(finder.GetFilePath()));
			CHandSkeletonKin hand(!bLeft);
			std::string strHeader = hand.GetBvhHeader();
			CString strDestName = strTitle + L".bvh";
			clipRaw.SaveToBvh(GloveUtil::ToChar(strDestPath+L"\\"+strDestName), strHeader);
		}
	}
}
void GloveUtil::CreateTrUnder(CString strTr)
{
	CreateDirectory(strTr, NULL);
	//thumb
	CreateDirectory(strTr + L"\\0_HAND_SKEL_DOF_THUMB_ROLL", NULL);
	CreateDirectory(strTr + L"\\1_HAND_SKEL_DOF_THUMB_ABD", NULL);
	CreateDirectory(strTr + L"\\2_HAND_SKEL_DOF_THUMB_VIRTUAL", NULL);
	CreateDirectory(strTr + L"\\3_HAND_SKEL_DOF_THUMB_FLEX_PROX", NULL);
	CreateDirectory(strTr + L"\\4_HAND_SKEL_DOF_THUMB_FLEX_DIST", NULL);
	//index
	CreateDirectory(strTr + L"\\5_HAND_SKEL_DOF_INDEX_ABD_PALM", NULL);
	CreateDirectory(strTr + L"\\6_HAND_SKEL_DOF_INDEX_FLEX_PALM", NULL);
	CreateDirectory(strTr + L"\\7_HAND_SKEL_DOF_INDEX_ABD", NULL);
	CreateDirectory(strTr + L"\\8_HAND_SKEL_DOF_INDEX_FLEX_PROX", NULL);
	CreateDirectory(strTr + L"\\9_HAND_SKEL_DOF_INDEX_FLEX_MID", NULL);
	CreateDirectory(strTr + L"\\10_HAND_SKEL_DOF_INDEX_FLEX_DIST", NULL);
	//middle
	CreateDirectory(strTr + L"\\11_HAND_SKEL_DOF_MID_ABD_PALM", NULL);
	CreateDirectory(strTr + L"\\12_HAND_SKEL_DOF_MID_FLEX_PALM", NULL);
	CreateDirectory(strTr + L"\\13_HAND_SKEL_DOF_MID_ABD", NULL);
	CreateDirectory(strTr + L"\\14_HAND_SKEL_DOF_MID_FLEX_PROX", NULL);
	CreateDirectory(strTr + L"\\15_HAND_SKEL_DOF_MID_FLEX_MID", NULL);
	CreateDirectory(strTr + L"\\16_HAND_SKEL_DOF_MID_FLEX_DIST", NULL);
	//ring
	CreateDirectory(strTr + L"\\17_HAND_SKEL_DOF_RING_ABD_PALM", NULL);
	CreateDirectory(strTr + L"\\18_HAND_SKEL_DOF_RING_FLEX_PALM", NULL);
	CreateDirectory(strTr + L"\\19_HAND_SKEL_DOF_RING_ABD", NULL);
	CreateDirectory(strTr + L"\\20_HAND_SKEL_DOF_RING_FLEX_PROX", NULL);
	CreateDirectory(strTr + L"\\21_HAND_SKEL_DOF_RING_FLEX_MID", NULL);
	CreateDirectory(strTr + L"\\22_HAND_SKEL_DOF_RING_FLEX_DIST", NULL);
	//pinky
	CreateDirectory(strTr + L"\\23_HAND_SKEL_DOF_PINKY_ABD_PALM", NULL);
	CreateDirectory(strTr + L"\\24_HAND_SKEL_DOF_PINKY_FLEX_PALM", NULL);
	CreateDirectory(strTr + L"\\25_HAND_SKEL_DOF_PINKY_ABD", NULL);
	CreateDirectory(strTr + L"\\26_HAND_SKEL_DOF_PINKY_FLEX_PROX", NULL);
	CreateDirectory(strTr + L"\\27_HAND_SKEL_DOF_PINKY_FLEX_MID", NULL);
	CreateDirectory(strTr + L"\\28_HAND_SKEL_DOF_PINKY_FLEX_DIST", NULL);
	//wrist
	CreateDirectory(strTr + L"\\29_HAND_SKEL_DOF_WRIST_FLEX", NULL);
	CreateDirectory(strTr + L"\\30_HAND_SKEL_DOF_WRIST_ABD", NULL);
}


void GloveUtil::CalculateFKError()
{
	std::string strBasePath = "C:/wangyi/research/glove/text/To Siggraph Aisa 2012/results/FK Accuracy Evaluation/quantify1/";
	std::string strResultPath = "C:/wangyi/research/glove/text/To Siggraph Aisa 2012/results/FK Accuracy Evaluation/quantify1/groundTruth/FK Evaluation Report.txt";
	std::ofstream fout(strResultPath.c_str());

	fout << "sensor===========================================\r\n";
	CalculateFKError(strBasePath + "sensor/", "_snr_l.raw", fout);
	fout << "linear===========================================\r\n";
	CalculateFKError(strBasePath + "linear/", "_snr_l_calib.raw", fout);
	fout << "gprfull===========================================\r\n";
	CalculateFKError(strBasePath + "gpr full/", "_snr_l_gprfull.raw", fout);
	fout << "gprfitc 1000===========================================\r\n";
	CalculateFKError(strBasePath + "gpr fitc 1000/", "_snr_l_gprfitc.raw", fout);
	fout << "gprfitc 500===========================================\r\n";
	CalculateFKError(strBasePath + "gpr fitc 500/", "_snr_l_gprfitc.raw", fout);
	fout << "gprfitc 300===========================================\r\n";
	CalculateFKError(strBasePath + "gpr fitc 300/", "_snr_l_gprfitc.raw", fout);
	fout << "gprfitc 100===========================================\r\n";
	CalculateFKError(strBasePath + "gpr fitc 100/", "_snr_l_gprfitc.raw", fout);
	fout << "gprfitc 50===========================================\r\n";
	CalculateFKError(strBasePath + "gpr fitc 50/", "_snr_l_gprfitc.raw", fout);
	fout << "gprfitc 20===========================================\r\n";
	CalculateFKError(strBasePath + "gpr fitc 20/", "_snr_l_gprfitc.raw", fout);

	fout.flush();
	fout.close();
}
void GloveUtil::CalculateFKError(std::string strPath, std::string strSuffix, std::ofstream& fout)
{
	CRawClip clipFlat, clipFist, clipSpread, clipOverbend, clipThumbUp, clipPointing, clipPinkyUp, clipRest, clipOk;

	//load clip ====================================================================================
	clipFlat.LoadFromFile(strPath + "flat" + strSuffix);
	clipFist.LoadFromFile(strPath + "fist" + strSuffix);
	clipSpread.LoadFromFile(strPath + "spread" + strSuffix);
	clipOverbend.LoadFromFile(strPath + "overbend" + strSuffix);
	clipThumbUp.LoadFromFile(strPath + "thumbUp" + strSuffix);
	clipPointing.LoadFromFile(strPath + "pointing" + strSuffix);
	clipPinkyUp.LoadFromFile(strPath + "pinkyUp" + strSuffix);
	clipRest.LoadFromFile(strPath + "other_flex_motion" + strSuffix);
	clipOk.LoadFromFile(strPath + "ok" + strSuffix);

	//load ground truth
	std::string strTruthPath = "C:/wangyi/research/glove/text/To Siggraph Aisa 2012/results/FK Accuracy Evaluation/quantify1/groundTruth/";
	//frame in degree, to radian
	CGlvClip clipGlvFlat, clipGlvSpread, clipGlvFist, clipGlvOverbend, clipGlvThumbUp, clipGlvPointing, clipGlvRest, clipGlvPinkyUp, clipGlvOk/*FK*/;
	clipGlvFlat.LoadFromFile(strTruthPath + "flat.glv"); clipGlvFlat.ToRadian();
	clipGlvSpread.LoadFromFile(strTruthPath + "spread.glv"); clipGlvSpread.ToRadian();
	clipGlvFist.LoadFromFile(strTruthPath + "fist.glv"); clipGlvFist.ToRadian();
	clipGlvOverbend.LoadFromFile(strTruthPath + "overbend.glv"); clipGlvOverbend.ToRadian();
	clipGlvThumbUp.LoadFromFile(strTruthPath + "thumbUp.glv"); clipGlvThumbUp.ToRadian();
	clipGlvPointing.LoadFromFile(strTruthPath + "pointing.glv"); clipGlvPointing.ToRadian();
	clipGlvRest.LoadFromFile(strTruthPath + "rest.glv"); clipGlvRest.ToRadian();
	clipGlvPinkyUp.LoadFromFile(strTruthPath + "pinkyUp.glv"); clipGlvPinkyUp.ToRadian();
	clipGlvOk.LoadFromFile(strTruthPath + "ok.glv"); clipGlvOk.ToRadian();
	
	//to raw gound truth
	CRawClip clipFlat_gt = GloveUtil::GlvToRaw(clipGlvFlat, true);
	CRawClip clipSpread_gt = GloveUtil::GlvToRaw(clipGlvSpread, true);
	CRawClip clipFist_gt = GloveUtil::GlvToRaw(clipGlvFist, true);
	CRawClip clipOverbend_gt = GloveUtil::GlvToRaw(clipGlvOverbend, true);
	CRawClip clipThumbUp_gt = GloveUtil::GlvToRaw(clipGlvThumbUp, true);
	CRawClip clipPointing_gt = GloveUtil::GlvToRaw(clipGlvPointing, true);
	CRawClip clipRest_gt = GloveUtil::GlvToRaw(clipGlvRest, true);
	CRawClip clipPinkyUp_gt = GloveUtil::GlvToRaw(clipGlvPinkyUp, true);
	CRawClip clipOk_gt = GloveUtil::GlvToRaw(clipGlvOk, true);

	//Calculate Error =========================================================================
	//flat
	int iSampleIdx = 0; 
	float fMaxErr, fMeanErr, fStdErr;
	int iMaxIdx;
	CRawFrame::CalError(clipFlat.m_arFrame[iSampleIdx], clipFlat_gt.m_arFrame[0], fMaxErr, iMaxIdx, fMeanErr, fStdErr);
	fout << "flat error: (" << fMaxErr << "," << iMaxIdx << "), (" << fMeanErr << ", " << fStdErr << ")\r\n"; 
	
	iSampleIdx = 0;
	CRawFrame::CalError(clipFist.m_arFrame[iSampleIdx], clipFist_gt.m_arFrame[0], fMaxErr, iMaxIdx, fMeanErr, fStdErr);
	fout << "fist error: (" << fMaxErr << "," << iMaxIdx << "), (" << fMeanErr << ", " << fStdErr << ")\r\n"; 

	CRawFrame::CalError(clipSpread.m_arFrame[iSampleIdx], clipSpread_gt.m_arFrame[0], fMaxErr, iMaxIdx, fMeanErr, fStdErr);
	fout << "spread error: (" << fMaxErr << "," << iMaxIdx << "), (" << fMeanErr << ", " << fStdErr << ")\r\n"; 

	CRawFrame::CalError(clipOverbend.m_arFrame[iSampleIdx], clipOverbend_gt.m_arFrame[0], fMaxErr, iMaxIdx, fMeanErr, fStdErr);
	fout << "overbend error: (" << fMaxErr << "," << iMaxIdx << "), (" << fMeanErr << ", " << fStdErr << ")\r\n"; 

	CRawFrame::CalError(clipThumbUp.m_arFrame[iSampleIdx], clipThumbUp_gt.m_arFrame[0], fMaxErr, iMaxIdx, fMeanErr, fStdErr);
	fout << "thumbUp error: (" << fMaxErr << "," << iMaxIdx << "), (" << fMeanErr << ", " << fStdErr << ")\r\n"; 

	CRawFrame::CalError(clipPointing.m_arFrame[iSampleIdx], clipPointing_gt.m_arFrame[0], fMaxErr, iMaxIdx, fMeanErr, fStdErr);
	fout << "pointing error: (" << fMaxErr << "," << iMaxIdx << "), (" << fMeanErr << ", " << fStdErr << ")\r\n"; 

	iSampleIdx = 100;
	CRawFrame::CalError(clipRest.m_arFrame[iSampleIdx], clipRest_gt.m_arFrame[0], fMaxErr, iMaxIdx, fMeanErr, fStdErr);
	fout << "rest error: (" << fMaxErr << "," << iMaxIdx << "), (" << fMeanErr << ", " << fStdErr << ")\r\n"; 

	iSampleIdx = 0;
	CRawFrame::CalError(clipPinkyUp.m_arFrame[iSampleIdx], clipPinkyUp_gt.m_arFrame[0], fMaxErr, iMaxIdx, fMeanErr, fStdErr);
	fout << "pinkyUp error: (" << fMaxErr << "," << iMaxIdx << "), (" << fMeanErr << ", " << fStdErr << ")\r\n"; 

	CRawFrame::CalError(clipOk.m_arFrame[iSampleIdx], clipOk_gt.m_arFrame[0], fMaxErr, iMaxIdx, fMeanErr, fStdErr);
	fout << "ok error: (" << fMaxErr << "," << iMaxIdx << "), (" << fMeanErr << ", " << fStdErr << ")\r\n";
}


void GloveUtil::ExportMarkers(CRawClip clipRaw, std::string strPath, bool bLeft)
{
	CMarkersClip clipMarkers = GloveUtil::RawToMarkers(clipRaw, bLeft);
	clipMarkers.SaveToFile(strPath);
}

void GloveUtil::ExportMarkers(CRawTimeClip clipRawTime, std::string strPath, bool bLeft)
{

}

#include "GPRDB.h"
CRawClip GloveUtil::IKSampling(CRawClip& clipRawSensor, int iTouchingType, bool bLeft)
{
	CRawClip clipSampled; //this is the result for returnning
	//CRawClip clipDBSensor, clipDBSln;
	CGPRDB* pDBGPR = CGPRDB::GetIKDB();
	CHandSkeletonKin* pHand = new CHandSkeletonKin(!bLeft);
	for(int i = 0; i < clipRawSensor.m_arFrame.size(); ++i)
	{
		CRawFrame frmCurSensor = clipRawSensor.m_arFrame[i];
		CRawFrame frmCurSlnGuess = frmCurSensor;
		std::vector<float> arWeight;
		if(pDBGPR->m_arDBItem.size() > 0)
		{
			std::vector<int> arKNNIdx = pDBGPR->GetKNearestThumbSensor(frmCurSensor, 1, false);
			CRawClip clipKNNSensor, clipKNNSln;
			for(int knn = 0; knn < arKNNIdx.size(); ++knn)
			{
				int iKNNIdx = arKNNIdx[knn];
				CRawFrame frmKNNSensor = pDBGPR->m_arDBItem[iKNNIdx].m_frmSensor;
				CRawFrame frmKNNSln = pDBGPR->m_arDBItem[iKNNIdx].m_frmSln;
				clipKNNSensor.m_arFrame.push_back(frmKNNSensor);
				clipKNNSln.m_arFrame.push_back(frmKNNSln);
			}
			//average pose			
			CRawFrame frmNearestSensor = clipKNNSensor.GetAveragePose();
			CRawFrame frmNearestSln = clipKNNSln.GetAveragePose();
			//TODO: let's try later, then we set weight according to difference

			frmCurSlnGuess = frmNearestSln;
		}
		pHand->m_pHand->UpdateFromKinematicData(frmCurSensor.m_arData);
		pHand->m_pHand->PopulateGlobalPosAndAxis();
		CKinematicPos posGoal = pHand->m_pHand->m_arChain[iTouchingType]->GetGlobalEndEffectorPos();
		//call matlab solver==========================================================================================
		if(i>0)
			pHand->m_pHand->UpdateFingerFromKinematicData(CKinematicHand::HAND_CHAIN_ID::E_CHAIN_THUMB, frmCurSlnGuess.m_arData);		
		pHand->m_pHand->PopulateGlobalPosAndAxis();
		CKinematicPos posEnd = pHand->m_pHand->m_arChain[0]->GetGlobalEndEffectorPos();
		frmCurSlnGuess.m_arData.clear();
		pHand->UpdateToKinematicData(frmCurSlnGuess.m_arData);
		pHand->m_pHand->ik_thumb_reach(posGoal, -1, arWeight);
		posEnd = pHand->m_pHand->m_arChain[0]->GetGlobalEndEffectorPos();
		float fDistance = posEnd.DistanceTo(posGoal);

		CRawFrame frmCurSln;
		pHand->UpdateToKinematicData(frmCurSln.m_arData);
		clipSampled.m_arFrame.push_back(frmCurSln);

		//update DB ==============================================================================================
		CGPRDBItem dbItem(frmCurSensor, frmCurSln);
		if(pDBGPR->CheckQuality(dbItem))
			pDBGPR->m_arDBItem.push_back(dbItem);
	}
	delete pHand;
	return clipSampled;
}

void GloveUtil::constructStaticPoseForPerception(CString strPoseInputFile, CString strPoseOutputFile)
{
	CRawClip clipPoseInput;
	clipPoseInput.LoadFromFile(GloveUtil::ToChar(strPoseInputFile));

	CRawFrame frmPose = clipPoseInput.GetAveragePose();
	frmPose.m_arData[29] = 0;
	frmPose.m_arData[30] = 0;
	
	//let's generate 300 frame clip
	int iLength = 300;
	CRawClip clipPoseOutput;
	for(int i = 0; i < iLength; ++i)
	{
		//1. copy the hand pose
		clipPoseOutput.m_arFrame.push_back(frmPose);

		//2. move the wrist along time
		float fAbd = 0;

		//100 - 125
		if(i >= 100 && i <= 115)
		{
			float iPhase = 3.1415926 * (i - 100.0) /15.0; 
			fAbd = - sin(iPhase) * 25;
		}

		//200 - 225
		if(i >= 200 && i <= 215)
		{
			float iPhase = 3.1415926 * (i - 200.0) / 15.0; 
			fAbd = - sin(iPhase) *25;
		}

		clipPoseOutput.m_arFrame[clipPoseOutput.m_arFrame.size()-1].m_arData[30] = fAbd;

	}
	clipPoseOutput.SaveToFile(GloveUtil::ToChar(strPoseOutputFile));
}
void GloveUtil::UseHandPose(CString strPoseFile, CString strWristFile, CString strOutput)
{
	CRawClip clipPoseInput;
	clipPoseInput.LoadFromFile(GloveUtil::ToChar(strPoseFile));

	CRawFrame frmPose = clipPoseInput.GetAveragePose();
	frmPose.m_arData[29] = 0;
	frmPose.m_arData[30] = 0;

	CRawClip clipWristInput;
	clipWristInput.LoadFromFile(GloveUtil::ToChar(strWristFile));

	CRawClip clipOutput;
	for(int i = 81; i < clipWristInput.m_arFrame.size()+81; ++i)
	{
		CRawFrame frmWrist=clipWristInput.m_arFrame[i%clipWristInput.m_arFrame.size()];
		clipOutput.m_arFrame.push_back(frmPose);
		clipOutput.m_arFrame[clipOutput.m_arFrame.size()-1].m_arData[30] = frmWrist.m_arData[30];
		clipOutput.m_arFrame[clipOutput.m_arFrame.size()-1].m_arData[29]=frmWrist.m_arData[29];
	}
	clipOutput.SaveToFile(GloveUtil::ToChar(strOutput));
}

