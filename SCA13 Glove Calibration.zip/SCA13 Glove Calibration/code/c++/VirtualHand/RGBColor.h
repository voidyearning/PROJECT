#define RGB_WHITE				255, 255, 255
#define RGB_RED					255, 0, 0
#define RGB_GREEN				0, 128, 0
#define RGB_BLUE				0, 0, 255
#define RGB_BLACK				0, 0, 0
#define RGB_YELLOW				255, 255, 0
#define RGB_GOLD				255, 215, 0
#define RGB_IVORY				255, 255, 240
#define RGB_AQUA				0, 255, 255


#define RGB_LIGHTPINK			255, 182, 193
#define RGB_PINK				255, 192, 203
#define RGB_CRIMSON				220, 20, 60
#define RGB_LAVENDERBLUSH		255, 240, 245
#define RGB_PALEVIOLETRED		219, 112, 214
#define RGB_HOTPINK				255, 105, 180
#define RGB_DEEPPINK			255, 20, 147
#define RGB_MEDIUMVIOLETRED		199, 21, 133
#define RGB_ORCHID				218, 112, 214
#define RGB_THISTLE				216, 191, 216
#define RGB_PLUM				221, 160, 221
#define RGB_VIOLET				238, 130, 238
#define RGB_MAGENTA				255, 0, 255
#define RGB_FUCHSIA				255, 0, 255
#define RGB_DARKMAGENTA			139, 0, 139
#define RGB_PURPLE				128, 0, 128
#define RGB_MEDIUMORCHID		186, 85, 211
#define RGB_DARKVIOLET			148, 0, 211
#define RGB_DARKORCHID			153, 50, 204
#define RGB_INDIGO				75, 0, 130
#define RGB_BLUEVIOLET			138, 43, 226
#define RGB_MEDIUMPURPLE		147, 112, 219
#define RGB_MEDIUMSLATEBLUE		123, 104, 238
#define RGB_SLATEBLUE			106, 90, 205
#define RGB_DARKSLATEBLUE		72, 61, 139


#define RGB_PALM				RGB_PINK
#define RGB_THUMB				85, 0,155
#define RGB_INDEX				 255, 12, 128//255, 5, 150
#define RGB_MIDDLE			255, 255, 0
#define RGB_RING				47, 240, 47
#define RGB_PINKY				0,255,255
#define RGB_FOREARM				RGB_PALM
#define RGB_NAIL				RGB_PALM
#define RGB_BACKGD				212, 208, 200

