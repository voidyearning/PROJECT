#pragma once
#include <vector>
#include <string>
#include "BaseAnimation.h"
#include "CKinematic\CKinematicChain.h"
#include "GloveSkeleton.h"


class CProbData
{
public:
	CKinematicPoint m_ptPos;
	double m_dProb;
	
	CProbData();	
	CProbData(double x, double y, double z, double dProb);
	CProbData(std::string strProbData);
	std::string ToString();
};

class CProbFrame : public CBaseFrame
{
public:
	CProbFrame();
	void PopulateProbData_byRange();
	void PopulateProbData_byRange(CKinematicPoint ptRangeMin, CKinematicPoint ptRangeMax, CKinematicPoint ptRangeStep);
	void PopulateProbData_linear();

	double GetRoughProbAt(CKinematicPoint ptPos);
	double GetExactProbAt(CKinematicPoint ptPos);

	int GetIndexFromPos(CKinematicPoint pt);

	CKinematicPoint m_ptRangeMin;
	CKinematicPoint m_ptRangeMax;	
	CKinematicPoint m_ptRangeStep;

	//this is something stupid
	float m_fWristAbd;
	float m_fWristFlex;

	CProbData m_maxProbData;
	std::vector<CProbData> m_arProbData;
	CHandSkeletonKin* m_pHand;
	void SaveToFile(std::string strPath);
	void LoadFromFile(std::string strPath);	
	std::string ToString();
	void LoadFromString(std::string strProbFrame);
};
class CProbClip : public CBaseClip
{
public:
	std::vector<CProbFrame> m_arFrame;
	void SaveToFile(std::string strPath);
	void LoadFromFile(std::string strPath);
	int GetFrameCount();
	CBaseFrame* GetFrameAt(int iFrmIdx);	
	virtual void SetFrameAt(int iFrmIdx, CBaseFrame*);
};