#pragma once
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glaux.h>
#include <gl/glut.h>
#include "CRenderer.h"
#include "GloveSkeleton.h"
#include <math.h>
#include "ProbRenderer.h"

#define RENDER_NAIL(r, l) glPushMatrix();\
	glColor3ub(RGB_NAIL);\
	glTranslatef(0.0, -r, 0.0);\
	if(m_bWireframe)\
	glutWireCube(l);\
	else\
	glutSolidCube(l);\
	glPopMatrix();

#define RENDER_JOINT(r)	if(m_bWireframe)\
	glutWireSphere(r, 9, 9);\
	else\
	glutSolidSphere(r, 9, 9);

#define RENDER_BONE(r, l) glPushMatrix();\
	glRotated(-90, 0.0, 1.0, 0.0);\
	if(m_bWireframe)\
	glutWireCone(r, l, 9, 9);\
	else\
	glutSolidCone(r, l, 9, 9);\
	glPopMatrix();

#define RENDER_FOREARM(r, l) glPushMatrix();\
	glTranslatef(l, 0.0, 0.0);\
	glRotated(-90, 0.0, 1.0, 0.0);\
	if(m_bWireframe)\
	glutWireCone(r, l, 9, 9);\
	else\
	glutSolidCone(r, l, 9, 9);\
	glPopMatrix();

#define RENDER_ORTHO_BONE_TO(r, x, y, z) glPushMatrix();\
	if(y==0 && z==0) {\
		if(x>0) glRotated(90, 0.0, 1.0, 0.0);\
		else glRotated(-90,0.0,1.0,0.0);}\
	if(x==0 && z==0) {\
		if(y>0) glRotated(-90, 0.0, 0.0, 1.0);\
		else glRotated(90, 0.0, 0.0, 1.0);}\
	if(x==0 && y==0 && z<0) glRotated(180, 1.0, 0.0, 0.0);\
	float l=sqrt(x*x+y*y+z*z);\
	if(m_bWireframe)\
	glutWireCone(r, l, 9, 9);\
	else\
	glutSolidCone(r, l, 9, 9);\
	glPopMatrix();





#include "CKinematic\CRenderer.h"
class COpenGLHandRendererKin : public CKinematicHandRenderer
{
public:
	COpenGLHandRendererKin();
	COpenGLHandRendererKin(CHandSkeletonKin* pHand);
	virtual ~COpenGLHandRendererKin();

	void SetHand(CHandSkeletonKin* pHand);
	
	void SetWireframe(bool bWireframe);
	virtual void Render();
	void RenderProbability3DSpace();

	CHandSkeletonKin* m_pHand;
	float m_fJointSize;
	bool m_bWireframe;
	bool m_bShowDOF;
	bool m_bShowHand;



	CProbFrameRenderer m_probRenderer;
};
