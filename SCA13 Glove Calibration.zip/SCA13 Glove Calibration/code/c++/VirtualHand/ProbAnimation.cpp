#include "stdafx.h"
#include "ProbAnimation.h"
#include <fstream>
#include "math.h"

//================================================================================
CProbData::CProbData()
{
}
CProbData::CProbData(double x, double y, double z, double dProb)
{
	m_ptPos.m_fX = x;
	m_ptPos.m_fY = y;
	m_ptPos.m_fZ = z;
	m_dProb = dProb;
}
CProbData::CProbData(std::string strProbData)
{
	int iBL = strProbData.find_first_of("(");
	int iBR = strProbData.find_last_of(")");
	std::string strPos = strProbData.substr(iBL, iBR-iBL+1);
	std::string strProb = strProbData.substr(iBR+1);
	m_ptPos = CKinematicPoint((char*)strPos.c_str());
	m_dProb = atof(strProb.c_str());
}
std::string CProbData::ToString()
{
	char buf[500];
	sprintf(buf, "(%f,%f,%f)%f", m_ptPos.m_fX, m_ptPos.m_fY, m_ptPos.m_fZ, m_dProb);
	std::string strProbData;
	strProbData.assign(buf);
	return strProbData;
}
//================================================================================
CProbFrame::CProbFrame()
{
	m_ptRangeMin = CKinematicPoint(-20, -10, -8);
	m_ptRangeMax = CKinematicPoint(-10, 15, 10);
	m_ptRangeStep = CKinematicPoint(1, 1, 1);
	
	m_maxProbData = CProbData(m_ptRangeMax.m_fX + 1, m_ptRangeMax.m_fY, m_ptRangeMax.m_fZ, 100000000);
	m_arProbData.clear();
	m_pHand = NULL;

	m_fWristAbd = 0;
	m_fWristFlex = 0;
}
void CProbFrame::PopulateProbData_byRange()
{
	m_maxProbData = CProbData(m_ptRangeMax.m_fX + 1, m_ptRangeMax.m_fY, m_ptRangeMax.m_fZ, 100000000);
	m_arProbData.clear();
	/*int iXRange = m_ptRangeMax.m_fX - m_ptRangeMin.m_fX + 1;
	int iYRange = m_ptRangeMax.m_fY - m_ptRangeMin.m_fY + 1;
	int iZRange = m_ptRangeMax.m_fZ - m_ptRangeMin.m_fZ + 1;
	int iTotal = iXRange * iYRange * iZRange;
	m_arProbData.reserve(iTotal);*/

	//force calculation step to be 1
	for(double x = m_ptRangeMin.m_fX; x <= m_ptRangeMax.m_fX; ++x)//x = x + m_ptRangeStep.m_fX)
	{
		for(double y = m_ptRangeMin.m_fY; y <= m_ptRangeMax.m_fY; ++y)//y = y + m_ptRangeStep.m_fY)
		{
			for(double z = m_ptRangeMin.m_fZ; z <= m_ptRangeMax.m_fZ; ++z)//z = z + m_ptRangeStep.m_fZ)
			{
				CKinematicPos posEnd(x, y, z);
				double dProb = m_pHand->GetActiveProbability(posEnd);
				CProbData probData(posEnd.m_fX, posEnd.m_fY, posEnd.m_fZ, dProb);
				m_arProbData.push_back(probData);
				if(m_maxProbData.m_dProb > dProb)
					m_maxProbData = probData;
			}
		}
	}

	m_fWristAbd = m_pHand->m_fWristAbd;
	m_fWristFlex = m_pHand->m_fWristFlex;

	int iXRange = ((m_ptRangeMax.m_fX - m_ptRangeMin.m_fX) / m_ptRangeStep.m_fX) + 1;	
	int iYRange = ((m_ptRangeMax.m_fY - m_ptRangeMin.m_fY) / m_ptRangeStep.m_fY) + 1;	
	int iZRange = ((m_ptRangeMax.m_fZ - m_ptRangeMin.m_fZ) / m_ptRangeStep.m_fZ) + 1;

	int iSize = iXRange * iYRange * iZRange;
	assert(iSize == m_arProbData.size());

}
void CProbFrame::PopulateProbData_byRange(CKinematicPoint ptRangeMin, CKinematicPoint ptRangeMax, CKinematicPoint ptRangeStep)
{
	if(m_pHand == NULL)
		return;

	m_ptRangeMin = ptRangeMin;
	m_ptRangeMax = ptRangeMax;
	m_ptRangeStep = ptRangeStep;

	PopulateProbData_byRange();	
}
void CProbFrame::PopulateProbData_linear()
{
	m_maxProbData = CProbData(m_ptRangeMax.m_fX + 1, m_ptRangeMax.m_fY, m_ptRangeMax.m_fZ, 100000000);
	m_arProbData.clear();
	
	std::vector<CKinematicChain*> arActiveChain;
	m_pHand->m_pHand->GetActiveChain(arActiveChain);
	if(arActiveChain.size() != 2)
		return;

	m_pHand->m_pHand->PopulateGlobalPosAndAxis();
	CKinematicPoint ptStart = arActiveChain[0]->GetGlobalEndEffectorPos();
	CKinematicPoint ptEnd = arActiveChain[1]->GetGlobalEndEffectorPos();
	CKinematicPoint ptStep(ptEnd.m_fX - ptStart.m_fX, ptEnd.m_fY - ptStart.m_fY, ptEnd.m_fZ-ptStart.m_fZ);
	ptStep.Normalize();
	ptStep *= 0.1;//resolution to be 1mm
	
	CKinematicPoint ptCursor = ptStart;
	while(ptCursor.m_fX < ptEnd.m_fX &&
		ptCursor.m_fY < ptEnd.m_fY &&
		ptCursor.m_fZ < ptEnd.m_fZ)
	{
		float fProb = m_pHand->GetActiveProbability(ptCursor);
		if(fProb < m_maxProbData.m_dProb)
		{
			m_maxProbData.m_ptPos = ptCursor;
			m_maxProbData.m_dProb = fProb;
		}
		m_arProbData.push_back(CProbData(ptCursor.m_fX, ptCursor.m_fY, ptCursor.m_fZ, fProb));
		ptCursor += ptStep;
	}
	float fProbEnd = m_pHand->GetActiveProbability(ptEnd);
	if(fProbEnd < m_maxProbData.m_dProb)
	{
		m_maxProbData.m_ptPos = ptEnd;
		m_maxProbData.m_dProb = fProbEnd;
	}
	
	m_fWristAbd = m_pHand->m_fWristAbd;
	m_fWristFlex = m_pHand->m_fWristFlex;
}

//assume that the calculation step is 1
int CProbFrame::GetIndexFromPos(CKinematicPoint pt)
{
	/*float minDist = 100000;
	int iMinDistIdx = -1;
	for(int i = 0; i < m_arProbData.size(); ++i)
	{
		CProbData pd = m_arProbData[i];
		CKinematicPoint vecDist(pd.m_ptPos.m_fX-pt.m_fX, pd.m_ptPos.m_fY-pt.m_fY, pd.m_ptPos.m_fZ-pt.m_fZ);
		float fDist = vecDist.GetEuclideanLength();
		if(fDist < minDist)
		{
			minDist = fDist;
			iMinDistIdx = i;
		}
	}
	return iMinDistIdx;*/
	int z = (pt.m_fZ - m_ptRangeMin.m_fZ); int zRange = m_ptRangeMax.m_fZ - m_ptRangeMin.m_fZ + 1;
	int y = (pt.m_fY - m_ptRangeMin.m_fY); int yRange = m_ptRangeMax.m_fY - m_ptRangeMin.m_fY + 1;
	int x = (pt.m_fX - m_ptRangeMin.m_fX); int xRange = m_ptRangeMax.m_fX - m_ptRangeMin.m_fX + 1;
	int iIdx = x*(yRange)*(zRange) + y*(zRange) + z;
	return iIdx;
}

double CProbFrame::GetRoughProbAt(CKinematicPoint ptPos)
{
	if(m_arProbData.size() == 0)
		return 0;

	int idx = GetIndexFromPos(ptPos);
	/*if(ptPos.m_fX >= m_ptRangeMin.m_fX && ptPos.m_fX <= m_ptRangeMax.m_fX &&
		ptPos.m_fY >= m_ptRangeMin.m_fY && ptPos.m_fY <= m_ptRangeMax.m_fY &&
		ptPos.m_fZ >= m_ptRangeMin.m_fZ && ptPos.m_fZ <= m_ptRangeMax.m_fZ)
	{
		assert(abs(ptPos.m_fX - m_arProbData[idx].m_ptPos.m_fX) < m_ptRangeStep.m_fX);
		assert(abs(ptPos.m_fY - m_arProbData[idx].m_ptPos.m_fY) < m_ptRangeStep.m_fY);
		assert(abs(ptPos.m_fZ - m_arProbData[idx].m_ptPos.m_fZ) < m_ptRangeStep.m_fZ);
	}*/
	if(idx < m_arProbData.size())
		return m_arProbData[idx].m_dProb;
	return 0;
}

double CProbFrame::GetExactProbAt(CKinematicPoint ptPos)
{
	double dProb = m_pHand->GetActiveProbability(ptPos);
	return dProb;
}
std::string CProbFrame::ToString()
{	
	std::string strProbFrame = "";
	char bufAbd[50] = {0};
	sprintf(bufAbd, "%f\r\n", m_fWristAbd);
	strProbFrame.append(bufAbd);
	char bufFlex[50] = {0};
	sprintf(bufFlex, "%f\r\n", m_fWristFlex);
	strProbFrame.append(bufFlex);

	strProbFrame.append(m_ptRangeMin.ToString());
	strProbFrame.append("\r\n");
	strProbFrame.append(m_ptRangeMax.ToString());
	strProbFrame.append("\r\n");
	strProbFrame.append(m_ptRangeStep.ToString());
	strProbFrame.append("\r\n");
	strProbFrame.append(m_maxProbData.ToString());
	strProbFrame.append("\r\n");

	for(int j = 0; j < m_arProbData.size(); ++j)
	{
		CProbData pd = m_arProbData[j];
		strProbFrame.append(pd.ToString());
		strProbFrame.append("\r\n");
	}
	return strProbFrame;
}
void CProbFrame::LoadFromString(std::string strProbFrame)
{
	m_arProbData.clear();
	
	int iLineBeg = 0;
	int iLineEnd = strProbFrame.find_first_of("\r\n");

	//something before all the prob matrix
	//wrist abd
	std::string strWristAbd = strProbFrame.substr(iLineBeg, iLineEnd - iLineBeg +1);
	m_fWristAbd = atof(strWristAbd.c_str());

	//wrist flex
	iLineBeg = iLineEnd + 2;
	iLineEnd = strProbFrame.find("\r\n", iLineBeg);
	std::string strWristFlex = strProbFrame.substr(iLineBeg, iLineEnd - iLineBeg + 1);
	m_fWristFlex = atof(strWristFlex.c_str());

	//range min
	iLineBeg = iLineEnd + 2;
	iLineEnd = strProbFrame.find("\r\n", iLineBeg);
	std::string strRangeMin = strProbFrame.substr(iLineBeg, iLineEnd - iLineBeg + 1);
	m_ptRangeMin = CKinematicPoint((char*)strRangeMin.c_str());

	//range max
	iLineBeg = iLineEnd + 2;
	iLineEnd = strProbFrame.find("\r\n", iLineBeg);
	std::string strRangeMax = strProbFrame.substr(iLineBeg, iLineEnd - iLineBeg + 1);
	m_ptRangeMax = CKinematicPoint((char*)strRangeMax.c_str());

	//range step
	iLineBeg = iLineEnd + 2;
	iLineEnd = strProbFrame.find("\r\n", iLineBeg);
	std::string strRangeStep = strProbFrame.substr(iLineBeg, iLineEnd - iLineBeg + 1);
	m_ptRangeStep = CKinematicPoint((char*)strRangeStep.c_str());

	//max prob data
	iLineBeg = iLineEnd + 2;
	iLineEnd = strProbFrame.find("\r\n", iLineBeg);
	std::string strMaxProbData = strProbFrame.substr(iLineBeg, iLineEnd - iLineBeg + 1);
	m_maxProbData = CProbData(strMaxProbData);

	iLineBeg = iLineEnd + 2;
	while(iLineBeg < strProbFrame.length())
	{
		//each line is one piece of probData
		iLineEnd = strProbFrame.find("\r\n", iLineBeg);
		std::string strProbData = strProbFrame.substr(iLineBeg, iLineEnd - iLineBeg + 1);
		CProbData pd(strProbData);
		m_arProbData.push_back(pd);
		iLineBeg = iLineEnd + 2;
	};
}

void CProbFrame::SaveToFile(std::string strPath)
{
	std::ofstream fout(strPath.c_str());

	fout << m_fWristAbd << std::endl;
	fout << m_fWristFlex << std::endl;
	fout << "(" << m_ptRangeMin.m_fX << "," << m_ptRangeMin.m_fY << "," << m_ptRangeMin.m_fZ << ")" << std::endl;
	fout << "(" << m_ptRangeMax.m_fX << "," << m_ptRangeMax.m_fY << "," << m_ptRangeMax.m_fZ << ")" << std::endl;
	fout << "(" << m_ptRangeStep.m_fX << "," << m_ptRangeStep.m_fY << "," << m_ptRangeStep.m_fZ << ")" << std::endl;
	fout << "(" << m_maxProbData.m_ptPos.m_fX << "," << m_maxProbData.m_ptPos.m_fY << "," 
		<< m_maxProbData.m_ptPos.m_fZ << ")" << m_maxProbData.m_dProb << std::endl;
	
	for(int j = 0; j < m_arProbData.size(); ++j)
	{
		CProbData pd = m_arProbData[j];
		fout << pd.ToString() << std::endl;
	}		
	fout.flush();
	fout.close();
}
void CProbFrame::LoadFromFile(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	m_arProbData.clear();

	//something before all the prob matrix
	//wrist abd
	char bufWristAbd[50] = {0};
	fin.getline(bufWristAbd, sizeof(bufWristAbd));
	m_fWristAbd = atof(bufWristAbd);

	//wrist flex
	char bufWristFlex[50] = {0};
	fin.getline(bufWristFlex, sizeof(bufWristFlex));
	m_fWristFlex = atof(bufWristFlex);

	//range min
	char bufMin[500] = {0};
	fin.getline(bufMin, sizeof(bufMin));
	m_ptRangeMin = CKinematicPoint(bufMin);

	//range max
	char bufMax[500] = {0};
	fin.getline(bufMax, sizeof(bufMax));
	m_ptRangeMax = CKinematicPoint(bufMax);

	//range step
	char bufStep[500] = {0};
	fin.getline(bufStep, sizeof(bufStep));
	m_ptRangeStep = CKinematicPoint(bufStep);

	//max prob data
	char bufMaxProbData[500] = {0};
	fin.getline(bufMaxProbData, sizeof(bufMaxProbData));
	m_maxProbData = CProbData(bufMaxProbData);

	while(fin.good())
	{
		//each line is one piece of probData
		char buf[500] = {0};
		fin.getline(buf, sizeof(buf));
		std::string strProbData(buf);
		CProbData pd(strProbData);
		m_arProbData.push_back(pd);
	}
}
//================================================================================
void CProbClip::SaveToFile(std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CProbFrame frm = m_arFrame[i];
		fout << "Frame:" << i << std::endl;
		fout << frm.ToString();
		fout<<std::endl;
	}
	fout.flush();
	fout.close();	
}
void CProbClip::LoadFromFile(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	m_arFrame.clear();
	char* buf = new char[1000000];
	fin.get(buf, sizeof(buf));
	std::string strProbClip(buf);
	int iFrameBeg = strProbClip.find("Frame:");
	int iFrameEnd = strProbClip.find("Frame:", iFrameBeg + 1);

	while(iFrameBeg < strPath.length())
	{
		std::string strFrame = strProbClip.substr(iFrameBeg, iFrameEnd - iFrameBeg + 1);
		CProbFrame frm;
		frm.LoadFromString(strFrame);
		m_arFrame.push_back(frm);
		iFrameBeg += iFrameEnd + 6;
		iFrameEnd = strProbClip.find("Frame:", iFrameBeg);
		if(iFrameEnd == std::string::npos)
			iFrameEnd = strProbClip.length() -1;
	};
}
int CProbClip::GetFrameCount()
{
	return m_arFrame.size();
}
CBaseFrame* CProbClip::GetFrameAt(int iFrmIdx)
{
	return (CBaseFrame*)(&m_arFrame[iFrmIdx]);
}
void CProbClip::SetFrameAt(int iFrmIdx, CBaseFrame* pFrame)
{
	m_arFrame[iFrmIdx] = *(CProbFrame*)pFrame;
}