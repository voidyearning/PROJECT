#include "stdafx.h"
#include "PtTrajAnimation.h"
#include "ProbAnimation.h"
#include <fstream>
#include "math.h"


CPtTrajFrame::CPtTrajFrame()
{	
	m_fWristAbd = 0;
	m_fWristFlex = 0;
}
CPtTrajFrame::CPtTrajFrame(CKinematicPoint pos)
{
	m_fWristAbd = 0;
	m_fWristFlex = 0;
	m_pos = pos;
}
CPtTrajFrame::CPtTrajFrame(const CPtTrajFrame& frame)
{
	m_pos = frame.m_pos;
	m_fWristAbd = frame.m_fWristAbd;
	m_fWristFlex = frame.m_fWristFlex;
}

CPtTrajClip::CPtTrajClip()
{
	m_pHand = NULL;	
	m_iBegIdx = m_iEndIdx = -1;
}
CPtTrajClip::CPtTrajClip(CHandSkeletonKin* pHand)
{
	m_pHand = pHand;
	m_iBegIdx = m_iEndIdx = -1;
}

CPtTrajClip::CPtTrajClip(const CPtTrajClip& clip)
{
	m_pHand = clip.m_pHand;
	m_iBegIdx = clip.m_iBegIdx;
	m_iEndIdx = clip.m_iEndIdx;
	for(int i = 0; i < clip.m_arFrame.size(); ++i)
	{
		CPtTrajFrame frm = clip.m_arFrame[i];
		m_arFrame.push_back(frm);
	}

}
void CPtTrajClip::SaveToFile(std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	fout << m_iBegIdx << endl;
	fout << m_iEndIdx << endl;
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CPtTrajFrame frm = m_arFrame[i];
		fout << frm.m_pos.ToString() << frm.m_fWristAbd << "," << frm.m_fWristFlex <<  std::endl;
	}
	fout.flush();
	fout.close();	
}
void CPtTrajClip::LoadFromFile(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	char bufBegIdx[15] = {0};
	fin.getline(bufBegIdx, sizeof(bufBegIdx));
	m_iBegIdx = atoi(bufBegIdx);
	char bufEndIdx[15] = {0};
	fin.getline(bufEndIdx, sizeof(bufEndIdx));
	m_iEndIdx = atoi(bufEndIdx);

	m_arFrame.clear();
	while(fin.good())
	{
		char buf[1024] = {0};
		fin.getline(buf, sizeof(buf));
		std::string strLine(buf);
		int iBR = strLine.find(")");
		std::string strPos = strLine.substr(0, iBR+1);		
		CKinematicPoint pt((char*)strPos.c_str());

		std::string strWrist = strLine.substr(iBR+1);
		int iComa = strWrist.find(",");
		std::string strWristAbd = strLine.substr(0, iComa);
		std::string strWristFlex = strLine.substr(iComa+1);

		CPtTrajFrame frm;
		frm.m_pos = pt;
		frm.m_fWristAbd = atof(strWristAbd.c_str());
		frm.m_fWristFlex = atof(strWristAbd.c_str());

		if(frm.m_arData.size() != 0)
			m_arFrame.push_back(frm);
	};
}
int CPtTrajClip::GetFrameCount()
{
	return m_arFrame.size();
}
CBaseFrame* CPtTrajClip::GetFrameAt(int iFrmIdx)
{
	return (CBaseFrame*)(&m_arFrame[iFrmIdx]);
}
void CPtTrajClip::SetFrameAt(int iFrmIdx, CBaseFrame* pFrame)
{
	m_arFrame[iFrmIdx] = *(CPtTrajFrame*)pFrame;
}

void CPtTrajClip::PopulateEndEffectorTrajClip(int iChainIdx,  CBaseClip* pMotionClip, int iBegIdx, int iEndIdx)
{
	m_arFrame.clear();
	if(m_pHand==NULL || pMotionClip == NULL)
		return;

	if(iBegIdx < 0)
		iBegIdx = 0;
	if(iEndIdx >= pMotionClip->GetFrameCount())
		iEndIdx = pMotionClip->GetFrameCount() - 1;
	
	m_iBegIdx = iBegIdx;
	m_iEndIdx = iEndIdx;
	for(int i = iBegIdx; i <= iEndIdx; ++ i)
	{
		CBaseFrame* pFrm = pMotionClip->GetFrameAt(i);
		m_pHand->UpdateFromFrame(pFrm);
		m_pHand->m_pHand->PopulateGlobalPosAndAxis();
		CPtTrajFrame frmTraj(m_pHand->m_pHand->m_arChain[iChainIdx]->GetGlobalEndEffectorPos());
		frmTraj.m_fWristAbd = m_pHand->m_fWristAbd;
		frmTraj.m_fWristFlex = m_pHand->m_fWristFlex;
		m_arFrame.push_back(frmTraj);
	}
}
void CPtTrajClip::PopulateActiveCOMTrajClip(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx)
{
	m_arFrame.clear();
	if(m_pHand==NULL || pMotionClip == NULL)
		return;

	if(iBegIdx < 0)
		iBegIdx = 0;
	if(iEndIdx >= pMotionClip->GetFrameCount())
		iEndIdx = pMotionClip->GetFrameCount() - 1;
	
	m_iBegIdx = iBegIdx;
	m_iEndIdx = iEndIdx;

	std::vector<CKinematicChain*> arActiveChain;
	m_pHand->m_pHand->GetActiveChain(arActiveChain);
	if(arActiveChain.size() == 0)
		return;

	for(int i = iBegIdx; i <= iEndIdx; ++ i)
	{
		CBaseFrame* pFrm = pMotionClip->GetFrameAt(i);
		m_pHand->UpdateFromFrame(pFrm);
		m_pHand->m_pHand->PopulateGlobalPosAndAxis();
		CKinematicPoint ptCOM(0, 0, 0);
		for(int c = 0; c < arActiveChain.size(); ++c)
		{
			CKinematicPoint ptEnd = arActiveChain[c]->GetGlobalEndEffectorPos();
			ptCOM += ptEnd;
		}
		ptCOM /= arActiveChain.size();
		CPtTrajFrame frmTraj(ptCOM);
		frmTraj.m_fWristAbd = m_pHand->m_fWristAbd;
		frmTraj.m_fWristFlex = m_pHand->m_fWristFlex;
		m_arFrame.push_back(frmTraj);
	}
}
void CPtTrajClip::PopulateActiveMaxProbTrajClip_traverse(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx)
{
	m_arFrame.clear();
	if(m_pHand == NULL || pMotionClip == NULL)
		return;

	if(iBegIdx < 0)
		iBegIdx = 0;
	if(iEndIdx >= pMotionClip->GetFrameCount())
		iEndIdx = pMotionClip->GetFrameCount() - 1;
	m_iBegIdx = iBegIdx;
	m_iEndIdx = iEndIdx;

	CProbFrame frmProb;
	frmProb.m_pHand = m_pHand;	
	for(int i = iBegIdx; i <= iEndIdx; ++ i)
	{
		CBaseFrame* pFrm = pMotionClip->GetFrameAt(i);
		m_pHand->UpdateFromFrame(pFrm);
		m_pHand->m_pHand->PopulateGlobalPosAndAxis();
		CKinematicPoint ptRangeMin(1000, 1000, 1000);
		CKinematicPoint ptRangeMax(-1000, -1000, -1000);
		CKinematicPoint ptRangeStep = CKinematicPoint(1, 1, 1);
		m_pHand->m_pHand->GetActiveEndEffectorRange(ptRangeMin, ptRangeMax);
		frmProb.PopulateProbData_byRange(ptRangeMin, ptRangeMax, ptRangeStep);

		CKinematicPoint maxPos = frmProb.m_maxProbData.m_ptPos;		
		//x range - next step	============================================================
		float fProbX_p = frmProb.GetRoughProbAt(CKinematicPoint(maxPos.m_fX-1, maxPos.m_fY,maxPos.m_fZ));
		float fProbX_n = frmProb.GetRoughProbAt(CKinematicPoint(maxPos.m_fX+1, maxPos.m_fY, maxPos.m_fZ));
		if(fProbX_p > fProbX_n)
		{
			ptRangeMin.m_fX = maxPos.m_fX-1;
			ptRangeMax.m_fX = maxPos.m_fX;
		}
		else if(fProbX_n > fProbX_p)
		{
			ptRangeMin.m_fX = maxPos.m_fX;
			ptRangeMax.m_fX = maxPos.m_fX + 1;
		}
		else
		{
			ptRangeMin.m_fX = ptRangeMax.m_fX = maxPos.m_fX;
		}

		//y range - next step =============================================================
		float fProbY_p = frmProb.GetRoughProbAt(CKinematicPoint(maxPos.m_fX, maxPos.m_fY-1, maxPos.m_fZ));
		float fProbY_n = frmProb.GetRoughProbAt(CKinematicPoint(maxPos.m_fX, maxPos.m_fY+1, maxPos.m_fZ));
		if(fProbY_p > fProbY_n)
		{
			ptRangeMin.m_fY = maxPos.m_fY -1;
			ptRangeMax.m_fY = maxPos.m_fY;
		}
		else if(fProbY_n > fProbY_p)
		{
			ptRangeMin.m_fY = maxPos.m_fY;
			ptRangeMax.m_fY = maxPos.m_fY + 1;
		}
		else
		{
			ptRangeMin.m_fY = ptRangeMax.m_fY = maxPos.m_fY;
		}
		//z range - next step ================================================================
		float fProbZ_p = frmProb.GetRoughProbAt(CKinematicPoint(maxPos.m_fX, maxPos.m_fY, maxPos.m_fZ-1));
		float fProbZ_n = frmProb.GetRoughProbAt(CKinematicPoint(maxPos.m_fX, maxPos.m_fY, maxPos.m_fZ+1));
		if(fProbZ_p > fProbZ_n)
		{
			ptRangeMin.m_fZ = maxPos.m_fZ-1;
			ptRangeMax.m_fZ = maxPos.m_fZ;
		}
		else if(fProbZ_n > fProbZ_p)
		{
			ptRangeMin.m_fZ = maxPos.m_fZ;
			ptRangeMax.m_fZ = maxPos.m_fZ + 1;
		}
		else
		{
			ptRangeMin.m_fZ = ptRangeMax.m_fZ = maxPos.m_fZ;
		}
		//new step
		ptRangeStep = CKinematicPoint(0.1, 0.1, 0.1);
		frmProb.PopulateProbData_byRange(ptRangeMin, ptRangeMax, ptRangeStep);
		CPtTrajFrame frmTraj(frmProb.m_maxProbData.m_ptPos);
		frmTraj.m_fWristAbd = m_pHand->m_fWristAbd;
		frmTraj.m_fWristFlex = m_pHand->m_fWristFlex;
		m_arFrame.push_back(frmTraj);
	}
}
//especially for 2-finger touching
void CPtTrajClip::PopulateActiveMaxProbTrajClip_approx(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx)
{	
	m_arFrame.clear();
	if(m_pHand == NULL || pMotionClip == NULL)
		return;

	if(iBegIdx < 0)
		iBegIdx = 0;
	if(iEndIdx >= pMotionClip->GetFrameCount())
		iEndIdx = pMotionClip->GetFrameCount() - 1;

	m_iBegIdx = iBegIdx;
	m_iEndIdx = iEndIdx;
	
	std::vector<CKinematicChain*> arActiveChain;
	m_pHand->m_pHand->GetActiveChain(arActiveChain);
	if(arActiveChain.size() != 2)
		return;

	for(int i = iBegIdx; i <= iEndIdx; ++ i)
	{
		CBaseFrame* pFrm = pMotionClip->GetFrameAt(i);
		m_pHand->UpdateFromFrame(pFrm);
		CProbFrame frmProb;
		frmProb.m_pHand = m_pHand;
		frmProb.PopulateProbData_linear();
		CPtTrajFrame frmTraj(frmProb.m_maxProbData.m_ptPos);		
		frmTraj.m_fWristAbd = m_pHand->m_fWristAbd;
		frmTraj.m_fWristFlex = m_pHand->m_fWristFlex;
		m_arFrame.push_back(frmTraj);
	}
}
std::vector<CPtTrajClip> CPtTrajClip::GetActiveEndEffectorTrajClip(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx)
{
	std::vector<CPtTrajClip> arResult;
	if(m_pHand == NULL || pMotionClip == NULL)
		return arResult;

	if(iBegIdx < 0)
		iBegIdx = 0;
	if(iEndIdx >= pMotionClip->GetFrameCount())
		iEndIdx = pMotionClip->GetFrameCount() - 1;

	m_iBegIdx = iBegIdx;
	m_iEndIdx = iEndIdx;

	std::vector<CKinematicChain*> arChain;
	if(m_pHand->IsFingerActive(FLAG_ACTIVE_THUMB))
	{
		arChain.push_back(m_pHand->m_pHand->m_arChain[0]);
		CPtTrajClip clip(m_pHand);
		clip.m_iBegIdx = m_iBegIdx;
		clip.m_iEndIdx = m_iEndIdx;
		arResult.push_back(clip);
	}
	if(m_pHand->IsFingerActive(FLAG_ACTIVE_INDEX))
	{
		arChain.push_back(m_pHand->m_pHand->m_arChain[1]);
		CPtTrajClip clip(m_pHand);
		clip.m_iBegIdx = m_iBegIdx;
		clip.m_iEndIdx = m_iEndIdx;
		arResult.push_back(clip);
	}
	if(m_pHand->IsFingerActive(FLAG_ACTIVE_MID))
	{
		arChain.push_back(m_pHand->m_pHand->m_arChain[2]);	
		CPtTrajClip clip(m_pHand);
		clip.m_iBegIdx = m_iBegIdx;
		clip.m_iEndIdx = m_iEndIdx;
		arResult.push_back(clip);
	}
	if(m_pHand->IsFingerActive(FLAG_ACTIVE_RING))
	{
		arChain.push_back(m_pHand->m_pHand->m_arChain[3]);
		CPtTrajClip clip(m_pHand);
		clip.m_iBegIdx = m_iBegIdx;
		clip.m_iEndIdx = m_iEndIdx;
		arResult.push_back(clip);
	}
	if(m_pHand->IsFingerActive(FLAG_ACTIVE_PINKY))
	{
		arChain.push_back(m_pHand->m_pHand->m_arChain[4]);	
		CPtTrajClip clip(m_pHand);
		clip.m_iBegIdx = m_iBegIdx;
		clip.m_iEndIdx = m_iEndIdx;
		arResult.push_back(clip);
	}

	for(int i = iBegIdx; i <= iEndIdx; ++ i)
	{
		CBaseFrame* pFrm = pMotionClip->GetFrameAt(i);
		m_pHand->UpdateFromFrame(pFrm);
		m_pHand->m_pHand->PopulateGlobalPosAndAxis();

		for(int j = 0; j < arChain.size(); ++j)
		{
			CKinematicChain* pChain = arChain[j];
			CPtTrajClip clip = arResult[j];
			CPtTrajFrame frame(pChain->GetGlobalEndEffectorPos());			
			frame.m_fWristAbd = m_pHand->m_fWristAbd;
			frame.m_fWristFlex = m_pHand->m_fWristFlex;
			clip.m_arFrame.push_back(frame);
			arResult[j] = clip;
		}
	}
	return arResult;
}

CPtTrajClip CPtTrajClip::GetActiveMaxProbTrajClip_traverse(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx)
{
	PopulateActiveMaxProbTrajClip_traverse(pMotionClip, iBegIdx, iEndIdx);
	return *this;
}
CPtTrajClip CPtTrajClip::GetActiveMaxProbTrajClip_approx(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx)
{
	PopulateActiveMaxProbTrajClip_approx(pMotionClip, iBegIdx, iEndIdx);
	return *this;
}
CPtTrajClip CPtTrajClip::GetActiveCOMTrajClip(CBaseClip* pMotionClip, int iBegIdx, int iEndIdx)
{
	PopulateActiveCOMTrajClip(pMotionClip, iBegIdx, iEndIdx);
	return *this;
}