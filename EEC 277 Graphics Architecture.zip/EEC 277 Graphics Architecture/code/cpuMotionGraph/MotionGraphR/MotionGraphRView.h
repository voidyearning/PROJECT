// MotionGraphRView.h : interface of the CMotionGraphRView class
//


#pragma once


class CMotionGraphRView : public CView
{
protected: // create from serialization only
	CMotionGraphRView();
	DECLARE_DYNCREATE(CMotionGraphRView)

// Attributes
public:
	CMotionGraphRDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CMotionGraphRView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MotionGraphRView.cpp
inline CMotionGraphRDoc* CMotionGraphRView::GetDocument() const
   { return reinterpret_cast<CMotionGraphRDoc*>(m_pDocument); }
#endif

