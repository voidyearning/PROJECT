#pragma once
#include <vector>
#include <string>
#include "MotionDB.h"

#define WINDOW_K	10
#define DISTANCE_THRESHOLD 10
#define LOCAL_MINIMA_REGION 5
#define TRANSITION_EDGE_LENGTH 50

#define MAX_WEIGHT	65532

class CMotionGraphR
{
public:
	static void test();

	CMotionGraphR(CMotionDB* pDB);

	void Initialize();
	void ClearGraph();


	void ConstructMotionGraph();
	void ConstructBaseGraphFromDB();
	void CalculateDistanceMatrix(int iWindowK);
	void CalculateTransitionMatrix(float fThreshold);
	void CreateTransitionEdge(int iEdgeLength);
	CRawClip* GenerateRandomWalk(int iStartIdx=0, int iMinNode=-1, int iMinFrames=-1);

	CMotionDB* m_pMotionDB;
	float** m_arDistanceMatrix;
	bool** m_arTransitionMatrix;
	CRawClip*** m_arTransitionEdgeMatrix;
	
	CRawClip* m_pClipBase1;
	CRawClip* m_pClipBase2;

	void SaveTo(std::string strPath);
	void LoadFrom(std::string strPath);

	//all pairs shortest path search
	float** m_arInitialWeightMatrix;
	float** m_arInitialPredMatrix;
	float** m_arShortestPathPredMatrix;
	float** m_arShortestPathWeightMatrix;
	
	void ClearWeightAndPredMatrix();
	void InitializeWeightAndPredMatrix();
	void FloydWarshallSearch();
	CRawClip GetShortestPathClip(int iNodeI = -1, int iNodeJ = -1);
	void SaveWeightAndPredMatrix(std::string strPath);

	

private:
	void constructBaseClipsFromDB();
	float distanceInWindow(int iIndexI, int iIndexJ, int iWindowK);
	bool transitionInWindow(int iIndexI, int iIndexJ, int iWindowK, float fThreshold);
	void saveD(std::string strPath);
	void saveT(std::string strPath);
	void saveTEdges(std::string strPath, bool bRaw = true);
	CRawClip* isFromSameClip(int iIndexI, int iIndexJ, int& iClipStartIndex);
	CRawClip* getClip(int iFrameIndex, int& iClipStartIndex);
	CRawClip getRandomEdge(int iOutwardIdx, int& iDestIdx);
};


