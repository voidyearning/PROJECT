// MotionGraphRDoc.cpp : implementation of the CMotionGraphRDoc class
//

#include "stdafx.h"
#include "MotionGraphR.h"

#include "MotionGraphRDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMotionGraphRDoc

IMPLEMENT_DYNCREATE(CMotionGraphRDoc, CDocument)

BEGIN_MESSAGE_MAP(CMotionGraphRDoc, CDocument)
	ON_COMMAND(ID_FILE_OPEN, &CMotionGraphRDoc::OnFileOpen)
	ON_COMMAND(ID_VIEW_MOTIONIMAGE, &CMotionGraphRDoc::OnViewMotionimage)
	ON_COMMAND(ID_MOTIONGRAPH_LOADMOTIONDB, &CMotionGraphRDoc::OnMotiongraphLoadmotiondb)
	ON_COMMAND(ID_MOTIONGRAPH_CONSTRUCTMOTIONGRAPH, &CMotionGraphRDoc::OnMotiongraphConstructmotiongraph)
	ON_COMMAND(ID_MOTIONGRAPH_SAVEMOTIONGRAPH, &CMotionGraphRDoc::OnMotiongraphSavemotiongraph)
	ON_COMMAND(ID_MOTIONGRAPH_LOADMOTIONDBORDERED, &CMotionGraphRDoc::OnMotiongraphLoadmotiondbordered)
	ON_COMMAND(ID_MOTIONGRAPH_SAVEMOTIONDB, &CMotionGraphRDoc::OnMotiongraphSavemotiondb)
	ON_COMMAND(ID_MOTIONGRAPH_LOADMOTIONGRAPH, &CMotionGraphRDoc::OnMotiongraphLoadmotiongraph)
	ON_COMMAND(ID_MOTIONGRAPH_GENERATERANDOMWALK, &CMotionGraphRDoc::OnMotiongraphGeneraterandomwalk)
	ON_COMMAND(ID_CONSTRUCTMOTIONGRAPH_CALCULATEDISTANCEMATRIX, &CMotionGraphRDoc::OnConstructmotiongraphCalculatedistancematrix)
	ON_COMMAND(ID_CONSTRUCTMOTIONGRAPH_CALCULATETRANSITIONMATRIX, &CMotionGraphRDoc::OnConstructmotiongraphCalculatetransitionmatrix)
	ON_COMMAND(ID_CONSTRUCTMOTIONGRAPH_INTERPOLATETRANSITIONEDGES, &CMotionGraphRDoc::OnConstructmotiongraphInterpolatetransitionedges)
	ON_COMMAND(ID_CONSTRUCTMOTIONGRAPH_CONSTRUCTMOTIONGRAPH, &CMotionGraphRDoc::OnConstructmotiongraphConstructmotiongraph)
	ON_COMMAND(ID_MOTIONGRAPH_FLOYDWARSHALLSHORTESTPATHSEARCH, &CMotionGraphRDoc::OnMotiongraphFloydwarshallshortestpathsearch)
	ON_COMMAND(ID_MOTIONGRAPH_GENERATESHORTESTPATHCLIP, &CMotionGraphRDoc::OnMotiongraphGenerateshortestpathclip)
END_MESSAGE_MAP()


// CMotionGraphRDoc construction/destruction

CMotionGraphRDoc::CMotionGraphRDoc()
{
	m_pMotionGraph = NULL;
	m_pMotionDB = NULL;
}

CMotionGraphRDoc::~CMotionGraphRDoc()
{
}

BOOL CMotionGraphRDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CMotionGraphRDoc serialization

void CMotionGraphRDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CMotionGraphRDoc diagnostics

#ifdef _DEBUG
void CMotionGraphRDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMotionGraphRDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CMotionGraphRDoc commands

char* CMotionGraphRDoc::wToChar(CString strWide)
{
	wchar_t* wText_l = strWide.GetBuffer(0);
	DWORD dwNum_l = WideCharToMultiByte(CP_OEMCP,NULL,wText_l,-1,NULL,0,NULL,FALSE);
	char *psText_l;
	psText_l = new char[dwNum_l];
	WideCharToMultiByte(CP_OEMCP,NULL,wText_l,-1,psText_l,dwNum_l,NULL,FALSE);
	return psText_l;
}
#include "AMCAnimation.h"
void CMotionGraphRDoc::OnFileOpen()
{
	CWinApp* pWinApp;
	pWinApp = (CWinApp*) AfxGetApp( );
	CFileDialog dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, L"amc(*.amc)|*.amc||");
	if(dlg.DoModal()==IDOK)
	{
		pWinApp->OpenDocumentFile(dlg.GetPathName());
		CAMCClip clipAMC;
		clipAMC.LoadFromFile(wToChar(dlg.GetPathName()));
		CRawClip clipRaw;
		clipAMC.SaveToRaw(clipRaw);
		clipRaw.SaveToFile("c:\\wangyi\\running.raw");
		//clipAMC.SaveToFile("c:\\wangyi\\test.amc");
	}
}
void CMotionGraphRDoc::OnViewMotionimage()
{
}





void CMotionGraphRDoc::OnMotiongraphSavemotiondb()
{
	CFileDialog dlgFile(FALSE, L"raw data(*.raw)|*.raw|AMC(*.amc)|*.amc", NULL, 4|2, L"raw data(*.raw)|*.raw|AMC(*.amc)|*.amc||");
	if(dlgFile.DoModal()==IDOK)
	{
		m_pMotionDB = new CMotionDB();
		CString strFileName = dlgFile.GetPathName();
		int iSep = strFileName.ReverseFind('\\');
		CString strPath = strFileName.Mid(0, iSep);
		if(strFileName.Find(L".raw") > strFileName.Find(L".amc"))		
			m_pMotionDB->LoadFromRawInOrder(wToChar(strPath));
	}
}
void CMotionGraphRDoc::OnMotiongraphLoadmotiondbordered()
{
	if(m_pMotionDB != NULL)
		delete m_pMotionDB;

	CFileDialog dlgFile(TRUE, L"raw data(*.raw)|*.raw|AMC(*.amc)|*.amc", NULL, 4|2, L"raw data(*.raw)|*.raw|AMC(*.amc)|*.amc||");
	if(dlgFile.DoModal()==IDOK)
	{
		m_pMotionDB = new CMotionDB();
		CString strFileName = dlgFile.GetPathName();
		int iSep = strFileName.ReverseFind('\\');
		CString strPath = strFileName.Mid(0, iSep);
		if(strFileName.Find(L".raw") > strFileName.Find(L".amc"))		
			m_pMotionDB->LoadFromRawInOrder(wToChar(strPath));
	}
}
void CMotionGraphRDoc::OnMotiongraphLoadmotiondb()
{
	if(m_pMotionDB != NULL)
		delete m_pMotionDB;

	CFileDialog dlgFile(TRUE, L"raw data(*.raw)|*.raw|AMC(*.amc)|*.amc", NULL, 4|2, L"raw data(*.raw)|*.raw|AMC(*.amc)|*.amc||");
	if(dlgFile.DoModal()==IDOK)
	{
		m_pMotionDB = new CMotionDB();
		CString strFileName = dlgFile.GetPathName();
		int iSep = strFileName.ReverseFind('\\');
		CString strPath = strFileName.Mid(0, iSep);
		if(strFileName.Find(L".raw") > strFileName.Find(L".amc"))		
			m_pMotionDB->LoadFromRaw(wToChar(strPath));
		else
			m_pMotionDB->LoadFromAmc(wToChar(strPath));
		::MessageBox(NULL, L"Load DB from AMC recursively completed!", L"Load DB Completed", MB_OK);
	}
}


void CMotionGraphRDoc::OnMotiongraphConstructmotiongraph()
{
	if(m_pMotionDB == NULL)
	{
		::MessageBox(NULL, L"Please load Motion DB first!", L"Alert",MB_OK); 
		return;
	}

	if(m_pMotionGraph == NULL)
		m_pMotionGraph = new CMotionGraphR(m_pMotionDB);

	m_pMotionGraph->ConstructMotionGraph();
}


void CMotionGraphRDoc::OnMotiongraphSavemotiongraph()
{
	if(m_pMotionGraph == NULL)
		return;

	CFileDialog dlgFile(FALSE, NULL, NULL, OFN_HIDEREADONLY, L"*(*.*)|*.*||");
	if(dlgFile.DoModal()==IDOK)
	{
		CString strFileName = dlgFile.GetPathName();
		int iSep = strFileName.ReverseFind('\\');
		CString strPath = strFileName.Mid(0, iSep);
		m_pMotionGraph->SaveTo(wToChar(strPath));
		::MessageBox(NULL, L"Save Motion Graph completed!", L"Save Motion Graph Completed", MB_OK);
	}
}



void CMotionGraphRDoc::OnMotiongraphLoadmotiongraph()
{
	CFileDialog dlgFile(FALSE, NULL, NULL, OFN_HIDEREADONLY, L"*(*.*)|*.*||");
	if(dlgFile.DoModal()==IDOK)
	{
		CString strFileName = dlgFile.GetPathName();
		int iSep = strFileName.ReverseFind('\\');
		CString strPath = strFileName.Mid(0, iSep);
		if(m_pMotionGraph == NULL)
			m_pMotionGraph = new CMotionGraphR(m_pMotionDB);
		m_pMotionGraph->LoadFrom(wToChar(strPath));
		::MessageBox(NULL, L"Load Motion Graph completed!", L"Load Motion Graph Completed", MB_OK);
	}
}

void CMotionGraphRDoc::OnMotiongraphGeneraterandomwalk()
{
	//test
	if(m_pMotionDB == NULL)
		m_pMotionDB = new CMotionDB();
	m_pMotionDB->LoadFromAmc("aa");
	CRawClip clipContinued;
	for(int i = 0; i < m_pMotionDB->m_arInitialClips.size(); ++i)
	{
		clipContinued = m_pMotionDB->m_arInitialClips[i]->GenerateClipLocalCoord();
		//clipContinued = clipContinued.GenerateClipGlobalCoord(0,90,0,0,0,0);
		//clipContinued.ContinueWith(*m_pMotionDB->m_arInitialClips[i]);		

		CAMCClip clipww;
		clipww.LoadFromRaw(clipContinued);
		char buff[20];
		sprintf(buff, "local_%d.amc",i);
		std::string strP = "c:\\wangyi\\motiongraph\\";
		strP.append(buff);
		clipww.SaveToFile(strP);
	}
	return;
	CAMCClip clipww;
		clipww.LoadFromRaw(clipContinued);
	//	char buff[20];
	//	sprintf(buff, "local_%d.amc",i);
		std::string strP = "c:\\wangyi\\motiongraph\\continued.amc";
	//	strP.append(buff);
		clipww.SaveToFile(strP);
	return;
	CFileDialog dlgFile(FALSE, NULL, NULL, OFN_HIDEREADONLY, L"*(*.*)|*.*||");
	if(dlgFile.DoModal()==IDOK)
	{
		CString strFileName = dlgFile.GetPathName();
		if(m_pMotionGraph == NULL)
			return;
		CRawClip* pRandomWalk = m_pMotionGraph->GenerateRandomWalk(0, -1, 2000);
		if(pRandomWalk == NULL)
			return;
		CAMCClip clipAMC;
		clipAMC.LoadFromRaw(*pRandomWalk);
		delete pRandomWalk;
		clipAMC.SaveToFile(wToChar(strFileName));
		::MessageBox(NULL, L"Random graph walk generated!", L"Random graph walk generated", MB_OK);
	}
}


void CMotionGraphRDoc::OnConstructmotiongraphCalculatedistancematrix()
{
	if(m_pMotionGraph == NULL)
		return;
	m_pMotionGraph->CalculateDistanceMatrix(10);
}


void CMotionGraphRDoc::OnConstructmotiongraphCalculatetransitionmatrix()
{
	if(m_pMotionGraph == NULL)
		return;
	m_pMotionGraph->CalculateTransitionMatrix(10);
}


void CMotionGraphRDoc::OnConstructmotiongraphInterpolatetransitionedges()
{
	if(m_pMotionGraph == NULL)
		return;
	m_pMotionGraph->CreateTransitionEdge(50);
}


void CMotionGraphRDoc::OnConstructmotiongraphConstructmotiongraph()
{
	if(m_pMotionDB == NULL)
	{
		::MessageBox(NULL, L"Please load Motion DB first!", L"Alert",MB_OK); 
		return;
	}

	if(m_pMotionGraph == NULL)
		m_pMotionGraph = new CMotionGraphR(m_pMotionDB);

	m_pMotionGraph->ConstructMotionGraph();
}

void CMotionGraphRDoc::OnMotiongraphFloydwarshallshortestpathsearch()
{
	if(m_pMotionGraph == NULL)
		return;

	m_pMotionGraph->InitializeWeightAndPredMatrix();
	m_pMotionGraph->FloydWarshallSearch();
}

void CMotionGraphRDoc::OnMotiongraphGenerateshortestpathclip()
{
	CFileDialog dlgFile(FALSE, NULL, NULL, OFN_HIDEREADONLY, L"*(*.*)|*.*||");
	if(dlgFile.DoModal()==IDOK)
	{
		CString strFileName = dlgFile.GetPathName();
		if(m_pMotionGraph == NULL)
			return;

		CRawClip clipShortestPath = m_pMotionGraph->GetShortestPathClip(-1, -1);
		CAMCClip clipAMC;
		clipAMC.LoadFromRaw(clipShortestPath);
		clipAMC.SaveToFile(wToChar(strFileName));
	}
}
