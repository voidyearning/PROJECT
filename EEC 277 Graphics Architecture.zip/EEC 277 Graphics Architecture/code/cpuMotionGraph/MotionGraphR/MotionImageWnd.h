#include "MotionImage.h"
#pragma once

class CMotionImageWnd : public CWnd
{
public:
    CMotionImageWnd();
	virtual ~CMotionImageWnd();
    CMotionImage m_imgMotion;

	void InitGL();
	void SetGLPixelFormat(HDC hdc);
	void DrawImage();
	HDC hdc ;
	HGLRC hglrc;
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
};