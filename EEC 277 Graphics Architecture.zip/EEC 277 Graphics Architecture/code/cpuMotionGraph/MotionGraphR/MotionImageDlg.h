#pragma once
#include "MotionImageWnd.h"
#include "RawAnimation.h"

// CMotionImageDlg dialog

class CMotionImageDlg : public CDialog
{
	DECLARE_DYNAMIC(CMotionImageDlg)

public:
	CMotionImageDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CMotionImageDlg();

	 CMotionImageWnd m_wndMotionImage;
	 CRawClip m_clipData;

	 virtual BOOL OnInitDialog();

// Dialog Data
	enum { IDD = IDD_MOTION_IMAGE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonLoadMotionImage();
	afx_msg void OnBnClickedButtonGenerateMotionImage();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
};
