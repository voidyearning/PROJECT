#pragma once
#include "RawAnimation.h"

class CMotionImage
{
public:
    CMotionImage(); 

    int m_iWidth;
    int m_iHeight;
    COLORREF** m_arPixels;

	void Initialize(int iWidth, int iHeight);
	void Clear();
	void LoadFromRaw(CRawClip& clipRaw, float fVMin, float fVMax);
};