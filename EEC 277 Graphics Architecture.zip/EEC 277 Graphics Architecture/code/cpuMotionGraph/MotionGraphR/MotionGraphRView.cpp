// MotionGraphRView.cpp : implementation of the CMotionGraphRView class
//

#include "stdafx.h"
#include "MotionGraphR.h"

#include "MotionGraphRDoc.h"
#include "MotionGraphRView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMotionGraphRView

IMPLEMENT_DYNCREATE(CMotionGraphRView, CView)

BEGIN_MESSAGE_MAP(CMotionGraphRView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
END_MESSAGE_MAP()

// CMotionGraphRView construction/destruction

CMotionGraphRView::CMotionGraphRView()
{
	// TODO: add construction code here

}

CMotionGraphRView::~CMotionGraphRView()
{
}

BOOL CMotionGraphRView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CMotionGraphRView drawing

void CMotionGraphRView::OnDraw(CDC* /*pDC*/)
{
	CMotionGraphRDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: add draw code for native data here
}


// CMotionGraphRView printing

BOOL CMotionGraphRView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMotionGraphRView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMotionGraphRView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CMotionGraphRView diagnostics

#ifdef _DEBUG
void CMotionGraphRView::AssertValid() const
{
	CView::AssertValid();
}

void CMotionGraphRView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMotionGraphRDoc* CMotionGraphRView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMotionGraphRDoc)));
	return (CMotionGraphRDoc*)m_pDocument;
}
#endif //_DEBUG


// CMotionGraphRView message handlers
