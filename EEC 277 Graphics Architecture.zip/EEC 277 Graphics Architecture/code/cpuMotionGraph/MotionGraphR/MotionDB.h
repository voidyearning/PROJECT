#pragma once
#include <vector>
#include <string>
#include "RawAnimation.h"

class CMotionDB
{
public:
	std::vector<CRawClip*> m_arInitialClips;
	void Clear();
	void LoadFromRawInOrder(std::string strPath);
	void LoadFromAmc(std::string strPath);
	void LoadFromRaw(std::string strPath);
	void SaveToRaw(std::string strPath);
private:
	void recursiveLoadFromRaw(std::string strPath);
	void recursiveLoadFromAmc(std::string strPath);
};
