#include "stdafx.h"
#include "MotionGraph.h"
#include <fstream>
#include "math.h"
#include <assert.h>
#include "AMCAnimation.h"
#include <time.h>

#include "MatlabUtil.h"


void CMotionGraphR::test()
{
	//CPos3D posLocal = CMatlabEngine::GlobalToLocal(CPos3D(50,50,50), CPos3D(49,45,45), CPos3D(30, 30, 0));
	//CPos3D posGlobal = CMatlabEngine::LocalToGlobal(posLocal, CPos3D(49,45,45), CPos3D(30, 30, 0));
	int i = 0;
}
//shortest path

void CMotionGraphR::ClearWeightAndPredMatrix()
{
	int I = m_pClipBase1->m_arFrame.size();
	int J = m_pClipBase2->m_arFrame.size();

	//clear initial weight matrix
	if(m_arInitialWeightMatrix)
	{
		for(int i = 0; i < I; ++i)
		{
			delete [] m_arInitialWeightMatrix[i];
		}
		delete [] m_arInitialWeightMatrix;
	}

	//clear initial pred matrix
	if(m_arInitialPredMatrix)
	{
		for(int i = 0; i < I; ++i)
		{
			delete [] m_arInitialPredMatrix[i];
		}
		delete [] m_arInitialPredMatrix;
	}
	
	//clear shortest path pred matrix
	if(m_arShortestPathPredMatrix)
	{
		for(int i = 0; i < I; ++i)
		{
			delete [] m_arShortestPathPredMatrix[i];
		}
		delete [] m_arShortestPathPredMatrix;
	}

	//clear shortest path weight matrix
	if(m_arShortestPathWeightMatrix)
	{
		for(int i = 0; i < I; ++i)
		{
			delete [] m_arShortestPathWeightMatrix[i];
		}
		delete [] m_arShortestPathWeightMatrix;
	}	
}
void CMotionGraphR::InitializeWeightAndPredMatrix()
{
	ClearWeightAndPredMatrix();

	int I = m_pClipBase1->m_arFrame.size();
	int J = m_pClipBase2->m_arFrame.size();

	//initialize the two matrices
	m_arInitialWeightMatrix = new float* [I];
	m_arInitialPredMatrix = new float* [I];
	m_arShortestPathPredMatrix = new float* [I];
	m_arShortestPathWeightMatrix = new float* [I];
	for(int i = 0; i < I; ++i)
	{
		m_arInitialWeightMatrix[i] = new float [J];
		m_arInitialPredMatrix[i] = new float [J];
		m_arShortestPathPredMatrix[i] = new float [J];
		m_arShortestPathWeightMatrix[i] = new float [J];

		for(int j = 0; j < J; ++j)
		{
			int iClipStart;
			bool bSameClip = isFromSameClip(i, j, iClipStart);
			bool bNaturalTransition = bSameClip && (j == i+1);

			if(m_arTransitionMatrix[i][j] == true || bNaturalTransition)
			{
				if(bNaturalTransition)
					m_arInitialWeightMatrix[i][j] = 0;
				else 
					m_arInitialWeightMatrix[i][j] = m_arDistanceMatrix[i][j];
				m_arInitialPredMatrix[i][j] = i;
			}
			else
			{
				m_arInitialWeightMatrix[i][j] = MAX_WEIGHT;
				m_arInitialPredMatrix[i][j] = -1;

			}
			if(i == j)
			{
				m_arInitialWeightMatrix[i][j] = 0;
				m_arInitialPredMatrix[i][j] = -1;
			}
			m_arShortestPathWeightMatrix[i][j] = m_arInitialWeightMatrix[i][j];
			m_arShortestPathPredMatrix[i][j] = m_arInitialPredMatrix[i][j];
		}
	}
}

void CMotionGraphR::FloydWarshallSearch()
{	
	if(m_arShortestPathPredMatrix == NULL || 
		m_arShortestPathWeightMatrix == NULL)
		return;

	int I = m_pClipBase1->m_arFrame.size();
	int J = m_pClipBase2->m_arFrame.size();
	int iEdgeCount = 0;
	for(int i = 0; i < I; ++i)
		for(int j = 0; j < J; ++j)
			if(m_arShortestPathPredMatrix[i][j] != -1)
				iEdgeCount ++;

	time_t begFloydWarshall = clock();	

	float** arWeightMatrixTemp = new float* [I];
	float** arPredMatrixTemp = new float* [I];
	for(int i = 0; i < I; ++i)
	{
		arWeightMatrixTemp[i] = new float [J];
		arPredMatrixTemp[i] = new float [J];
	}

	for(int k = 0; k < I; ++k)//run I times, 
	{
		for(int i = 0; i < I; ++i)
		{
			for(int j = 0; j < J; ++j)
			{
				if(m_arShortestPathWeightMatrix[i][j] <= m_arShortestPathWeightMatrix[i][k] + m_arShortestPathWeightMatrix[k][j])
				{
					arWeightMatrixTemp[i][j] = m_arShortestPathWeightMatrix[i][j];
					arPredMatrixTemp[i][j] = m_arShortestPathPredMatrix[i][j];
				}
				else
				{
					arWeightMatrixTemp[i][j] = m_arShortestPathWeightMatrix[i][k] + m_arShortestPathWeightMatrix[k][j];
					arPredMatrixTemp[i][j] = m_arShortestPathPredMatrix[k][j];
				}
			}
		}

		//update
		for(int i = 0; i < I; ++i)
		{
			for(int j = 0; j < J; ++j)
			{
				m_arShortestPathWeightMatrix[i][j] = arWeightMatrixTemp[i][j];
				m_arShortestPathPredMatrix[i][j] = arPredMatrixTemp[i][j];
			}
		}
	}
	time_t endFloydWarshall = clock();

	
	std::ofstream fout(L"c:\\wangyi\\motiongraph\\r\\FloydWarshallTime.txt");
	fout << "total vertex number: " << I << std::endl;
	fout << "total edge number: " << iEdgeCount << std::endl;
	fout << "all pairs shortest path search time: " << endFloydWarshall - begFloydWarshall << " ms" << std::endl;
	fout.flush();

	SaveWeightAndPredMatrix("c:\\wangyi\\motiongraph\\r");
}

CRawClip CMotionGraphR::GetShortestPathClip(int iNodeI, int iNodeJ)
{
	int I = m_pClipBase1->m_arFrame.size();
	if(iNodeI == -1)
		iNodeI = rand() % I;

	if(iNodeJ == -1)
		iNodeJ = rand() % I;

	CRawClip clipShortestPath;
	int iCurrentPred = iNodeJ;
	int iLoop = 0;
	do
	{
		iLoop++;
		if(iLoop > 100000)
			return clipShortestPath;

		int iPredPred = m_arShortestPathPredMatrix[iNodeI][iCurrentPred];
		if(iPredPred == -1)//graph connectivity is too low, no path
			return clipShortestPath;

		//the sub clip is from iPredPred to iCurrentPred
		CRawClip* pClipTransition = m_arTransitionEdgeMatrix[iPredPred][iCurrentPred];

		if(pClipTransition == NULL)
		{
			if(iCurrentPred != iPredPred + 1)
				return clipShortestPath;

			CRawClip clipTemp;
			clipTemp.m_arFrame.push_back(m_pClipBase1->m_arFrame[iPredPred]);
			clipTemp.MergeWith(clipShortestPath);
			clipShortestPath = clipTemp;
		}
		else
		{
			CRawClip clipTemp(*pClipTransition);
			clipTemp.ContinueWith(clipShortestPath);
			clipShortestPath = clipTemp;
		}

		//now iCurrentPred is changed to iPredPred
		iCurrentPred = iPredPred;

	}while(iCurrentPred != iNodeI);

	char buffer [100];
	sprintf(buffer, "Shorteste Path from %d to %d is generated!", iNodeI, iNodeJ);
	CString strTitle(buffer);
	::MessageBox(NULL, strTitle, strTitle, MB_OK);

	return clipShortestPath;
}

void CMotionGraphR::SaveWeightAndPredMatrix(std::string strPath)
{
	if(m_pClipBase1 == NULL || m_pClipBase2 == NULL)
		return;

	int I = m_pClipBase1->m_arFrame.size();
	int J = m_pClipBase2->m_arFrame.size();

	CRawClip clipInitialWeightMatrix;
	CRawClip clipInitialPredMatrix;
	CRawClip clipShortestPathWeightMatrix;
	CRawClip clipShortestPathPredMatrix;
	
	for(int i = 0; i < I; ++ i)	
	{
		CRawFrame frmInitialWeightMatrix;
		CRawFrame frmInitialPredMatrix;
		CRawFrame frmShortestPathWeightMatrix;
		CRawFrame frmShortestPathPredMatrix;
		for(int j = 0; j < J; ++ j)
		{
			if(m_arInitialWeightMatrix)
				frmInitialWeightMatrix.m_arData.push_back(m_arInitialWeightMatrix[i][j]);
			if(m_arInitialPredMatrix)
				frmInitialPredMatrix.m_arData.push_back(m_arInitialPredMatrix[i][j]);
			if(m_arShortestPathWeightMatrix)
				frmShortestPathWeightMatrix.m_arData.push_back(m_arShortestPathWeightMatrix[i][j]);
			if(m_arShortestPathPredMatrix)
				frmShortestPathPredMatrix.m_arData.push_back(m_arShortestPathPredMatrix[i][j]);
		}
		clipInitialWeightMatrix.m_arFrame.push_back(frmInitialWeightMatrix);
		clipInitialPredMatrix.m_arFrame.push_back(frmInitialPredMatrix);
		clipShortestPathWeightMatrix.m_arFrame.push_back(frmShortestPathWeightMatrix);
		clipShortestPathPredMatrix.m_arFrame.push_back(frmShortestPathPredMatrix);
	}
	clipInitialWeightMatrix.SaveToFile(strPath + "\\initialWeight.raw");
	clipInitialPredMatrix.SaveToFile(strPath + "\\initialPred.raw");
	clipShortestPathWeightMatrix.SaveToFile(strPath + "\\shortestPathWeight.raw");
	clipShortestPathPredMatrix.SaveToFile(strPath + "\\shortestPathPred.raw");
}
CMotionGraphR::CMotionGraphR(CMotionDB* pDB)
{
	m_pMotionDB = pDB;
	m_pClipBase1 = NULL;
	m_pClipBase2 = NULL;

	m_arDistanceMatrix = NULL;
	m_arTransitionMatrix = NULL;
	m_arTransitionEdgeMatrix = NULL;

	m_arInitialWeightMatrix = NULL;
	m_arInitialPredMatrix = NULL;
	m_arShortestPathPredMatrix = NULL;
	m_arShortestPathWeightMatrix = NULL;
}
void CMotionGraphR::saveD(std::string strPath)
{
	if(m_pClipBase1 == NULL || m_pClipBase2 == NULL)
		return;

	CRawClip clipD;
	std::string strPathEX = strPath;
	strPathEX.append("\\");

	int I = m_pClipBase1->m_arFrame.size();
	int J = m_pClipBase2->m_arFrame.size();
	for(int i = 0; i < I; ++i)
	{
		CRawFrame frmD;
		for(int j = 0; j < J; ++j)
		{
			frmD.m_arData.push_back(m_arDistanceMatrix[i][j]);
		}
		clipD.m_arFrame.push_back(frmD);
	}

	//save distance matrix to D.raw
	std::string strDPath = strPath;
	strDPath.append("\\D.raw");
	clipD.SaveToFile(strDPath);
}
void CMotionGraphR::saveT(std::string strPath)
{
	if(m_pClipBase1 == NULL || m_pClipBase2 == NULL)
		return;

	CRawClip clipT;
	std::string strPathEX = strPath;
	strPathEX.append("\\");

	int I = m_pClipBase1->m_arFrame.size();
	int J = m_pClipBase2->m_arFrame.size();
	for(int i = 0; i < I; ++i)
	{
		CRawFrame frmT;
		for(int j = 0; j < J; ++j)
		{
			frmT.m_arData.push_back(m_arTransitionMatrix[i][j]);
		}
		clipT.m_arFrame.push_back(frmT);
	}
	
	//save transition matrix to T.raw
	std::string strTPath = strPath;
	strTPath.append("\\T.raw");
	clipT.SaveToFile(strTPath);
}
void CMotionGraphR::saveTEdges(std::string strPath, bool bRaw)
{
	if(m_pClipBase1 == NULL || m_pClipBase2 == NULL)
		return;

	CRawClip clipD, clipT;
	std::string strPathEX = strPath;
	strPathEX.append("\\");

	int I = m_pClipBase1->m_arFrame.size();
	int J = m_pClipBase2->m_arFrame.size();
	for(int i = 0; i < I; ++i)
	{
		for(int j = 0; j < J; ++j)
		{
			CRawClip* pClipEdge = m_arTransitionEdgeMatrix[i][j];
			if(pClipEdge == NULL)
				continue;

			//save edge
			std::string strEdgePath = strPathEX;
			char buffer[20] = {0};			
			if(bRaw)
			{
				sprintf(buffer, "%d_%d.raw",i, j);
				strEdgePath.append(buffer);
				pClipEdge->SaveToFile(strEdgePath);
			}
			else
			{
				sprintf(buffer, "%d_%d.amc",i, j);
				strEdgePath.append(buffer);
				CAMCClip clipAMC;
				clipAMC.LoadFromRaw(*pClipEdge);
				clipAMC.SaveToFile(strEdgePath);
			}
		}
	}
}
void CMotionGraphR::SaveTo(std::string strPath)
{
	if(m_pClipBase1 == NULL || m_pClipBase2 == NULL)
		return;

	CRawClip clipD, clipT;
	std::string strPathEX = strPath;
	strPathEX.append("\\");

	int I = m_pClipBase1->m_arFrame.size();
	int J = m_pClipBase2->m_arFrame.size();
	for(int i = 0; i < I; ++i)
	{
		CRawFrame frmD, frmT;
		for(int j = 0; j < J; ++j)
		{
			frmD.m_arData.push_back(m_arDistanceMatrix[i][j]);
			frmT.m_arData.push_back(m_arTransitionMatrix[i][j]);
			CRawClip* pClipEdge = m_arTransitionEdgeMatrix[i][j];
			//save edge
			if(pClipEdge == NULL)
				continue;
			std::string strEdgePath = strPathEX;
			char buffer[20] = {0};
			sprintf(buffer, "%d_%d.raw",i, j);
			strEdgePath.append(buffer);
			pClipEdge->SaveToFile(strEdgePath);
		}
		clipD.m_arFrame.push_back(frmD);
		clipT.m_arFrame.push_back(frmT);
	}

	//save distance matrix to D.raw
	std::string strDPath = strPath;
	strDPath.append("\\D.raw");
	clipD.SaveToFile(strDPath);

	//save transition matrix to T.raw
	std::string strTPath = strPath;
	strTPath.append("\\T.raw");
	clipT.SaveToFile(strTPath);

	//save base1 to base1.raw
	std::string strB1Path = strPath;
	strB1Path.append("\\base1.raw");
	m_pClipBase1->SaveToFile(strB1Path);

	//save base2 to base2.raw
	std::string strB2Path = strPath;
	strB2Path.append("\\base2.raw");
	m_pClipBase2->SaveToFile(strB2Path);
}
void CMotionGraphR::LoadFrom(std::string strPath)
{
	//load base1 from base1.raw
	std::string strB1Path = strPath;
	strB1Path.append("\\base1.raw");
	if(m_pClipBase1 == NULL)
		m_pClipBase1 = new CRawClip();
	m_pClipBase1->m_arFrame.clear();
	m_pClipBase1->LoadFromFile(strB1Path);	
	
	//load base2 from base2.raw
	std::string strB2Path = strPath;	
	strB2Path.append("\\base2.raw");
	if(m_pClipBase2 == NULL)
		m_pClipBase2 = new CRawClip();
	m_pClipBase2->LoadFromFile(strB2Path);

	//load distance matrix from D.raw
	std::string strDPath = strPath;
	strDPath.append("\\D.raw");
	CRawClip clipD; 
	clipD.LoadFromFile(strDPath);	
	
	//load transition matrix from T.raw
	std::string strTPath = strPath;	
	strTPath.append("\\T.raw");
	CRawClip clipT;
	clipT.LoadFromFile(strTPath);

	if(clipD.m_arFrame.size() == 0 || clipD.m_arFrame[0].m_arData.size() ==0)
		return;

	Initialize();
	int I = clipD.m_arFrame.size();
	int J = clipD.m_arFrame[0].m_arData.size();
	std::string strPathEX = strPath;
	strPathEX.append("\\");
	assert(clipD.m_arFrame.size() == clipT.m_arFrame.size());
	for(int i = 0; i < I; ++i)
	{
		CRawFrame frmD = clipD.m_arFrame[i];
		CRawFrame frmT = clipT.m_arFrame[i];
		for(int j = 0; j < J; ++j)
		{
			m_arDistanceMatrix[i][j] = frmD.m_arData[j];
			m_arTransitionMatrix[i][j] = frmT.m_arData[j];
			if(m_arTransitionMatrix[i][j] == false)
				continue;

			//load edge
			m_arTransitionEdgeMatrix[i][j] = new CRawClip();
			std::string strEdgePath = strPathEX;
			char buffer[20] = {0};
			sprintf(buffer, "%d_%d.raw",i, j);
			strEdgePath.append(buffer);
			m_arTransitionEdgeMatrix[i][j]->LoadFromFile(strEdgePath);
		}
	}

}

void CMotionGraphR::Initialize()
{
	if(m_pMotionDB != NULL)
		constructBaseClipsFromDB();	
	ClearGraph();

	int I = m_pClipBase1->m_arFrame.size();
	int J = m_pClipBase2->m_arFrame.size();
	
	m_arDistanceMatrix = new float* [I];
	m_arTransitionMatrix = new bool* [I];
	m_arTransitionEdgeMatrix = new CRawClip** [I];

	for(int i = 0; i < I; ++i)
	{
		m_arDistanceMatrix[i] = new float[J];
		m_arTransitionMatrix[i] = new bool[J];
		m_arTransitionEdgeMatrix[i] = new CRawClip* [J];

		for(int j = 0; j < J; ++j)
		{
			m_arDistanceMatrix[i][j] = 0;
			m_arTransitionMatrix[i][j] = false;
			m_arTransitionEdgeMatrix[i][j] = NULL;
		}
	}

}
void CMotionGraphR::ClearGraph()
{
	if(m_arDistanceMatrix == NULL ||
		m_arTransitionMatrix == NULL ||
		m_arTransitionEdgeMatrix)
		return;

	int I = m_pClipBase1->m_arFrame.size();
	int J = m_pClipBase2->m_arFrame.size();

	for(int i = 0; i < I; ++i)
	{
		delete [] m_arDistanceMatrix[i];
		delete [] m_arTransitionMatrix[i];

		for(int j = 0; j < J; ++j)
		{
			delete m_arTransitionEdgeMatrix[i][j];
		}		
		delete [] m_arTransitionEdgeMatrix[i];
	}
	delete [] m_arDistanceMatrix;
	delete [] m_arTransitionMatrix;
	delete [] m_arTransitionEdgeMatrix;
}

void CMotionGraphR::ConstructMotionGraph()
{	
	Initialize();
	time_t generateMotionGraph_start = clock();
	ConstructBaseGraphFromDB();
	//::MessageBox(NULL, L"ConstructBaseGraphFromDB completed!", L"ConstructBaseGraphFromDB Completed", MB_OK);

	time_t calculateDistanceMatrix_start = clock();
	CalculateDistanceMatrix(WINDOW_K);
	//::MessageBox(NULL, L"CalculateDistanceMatrix completed!", L"CalculateDistanceMatrix Completed", MB_OK);
	//saveD("c:\\wangyi\\motiongraph");
	time_t calculateDistanceMatrix_stop = clock();

	time_t calculateTransitionMatrix_start = clock();
	CalculateTransitionMatrix(DISTANCE_THRESHOLD);
	//::MessageBox(NULL, L"CalculateTransitionMatrix completed!", L"CalculateTransitionMatrix Completed", MB_OK);
	//saveT("c:\\wangyi\\motiongraph");
	time_t calculateTransitionMatrix_stop = clock();

	time_t createTransitionEdge_start = clock();
	CreateTransitionEdge(TRANSITION_EDGE_LENGTH);
	//::MessageBox(NULL, L"CreateTransitionEdge completed!", L"CreateTransitionEdge Completed", MB_OK);
	//saveTEdges("c:\\wangyi\\motiongraph", false);
	time_t createTransitionEdge_stop = clock();
	time_t generateMotionGraph_stop = clock();

	std::ofstream fout("c:\\wangyi\\motiongraph\\r\\time.txt");
	fout << "calculate distance matrix: " << (calculateDistanceMatrix_stop - calculateDistanceMatrix_start) << " ms"<< std::endl;
	fout << "calculate transition matrix: " << (calculateTransitionMatrix_stop - calculateTransitionMatrix_start) << " ms"<< std::endl;
	fout << "create transition edge: " << (createTransitionEdge_stop - createTransitionEdge_start) << " ms" << std::endl;
	fout << "generate motion graph: " << (generateMotionGraph_stop - generateMotionGraph_start) << " ms" << std::endl;
	fout.flush();

	SaveTo("c:\\wangyi\\motiongraph\\r");
}

void CMotionGraphR::ConstructBaseGraphFromDB()
{
	if(m_pMotionDB == NULL)
		return;

	int iStart = 0;
	int iEnd = 0;
	for(int i = 0; i < m_pMotionDB->m_arInitialClips.size(); ++ i)
	{
		CRawClip* pClipDB = m_pMotionDB->m_arInitialClips[i];
		iEnd = iStart + pClipDB->m_arFrame.size() -1;
		m_arTransitionMatrix[iStart][iEnd] = true;
		CRawClip* pClipEdge = new CRawClip();
		pClipEdge->MergeWith(*pClipDB);
		m_arTransitionEdgeMatrix[iStart][iEnd] = pClipEdge;
		iStart = iEnd + 1;
	}
}
void CMotionGraphR::CalculateDistanceMatrix(int iWindowK)
{
	if(m_pClipBase1 == NULL || m_pClipBase2 == NULL)
		return;

	for(int i = 0; i < m_pClipBase1->m_arFrame.size(); ++i)
	{
		for(int j = 0; j < m_pClipBase2->m_arFrame.size(); ++j)
		{
			m_arDistanceMatrix[i][j] = distanceInWindow(i, j, iWindowK);
		}
	}

}
void CMotionGraphR::CalculateTransitionMatrix(float fThreshold)
{
	if(m_pClipBase1 == NULL || m_pClipBase2 == NULL)
		return;

	for(int i = 0; i < m_pClipBase1->m_arFrame.size(); ++i)
	{
		for(int j = 0; j < m_pClipBase2->m_arFrame.size(); ++j)
		{
			m_arTransitionMatrix[i][j] = m_arTransitionMatrix[i][j] | transitionInWindow(i,j,5,fThreshold);			
		}
	}
}
void CMotionGraphR::CreateTransitionEdge(int iEdgeLength)
{
	if(m_pClipBase1 == NULL || m_pClipBase2 == NULL)
		return;

	int I = m_pClipBase1->m_arFrame.size();
	int J = m_pClipBase2->m_arFrame.size();
	for(int i = 0; i < I; ++i)
	{
		for(int j = 0; j < J; ++j)
		{	
			//case 1: original clip
			if(true != m_arTransitionMatrix[i][j] ||
				NULL != m_arTransitionEdgeMatrix[i][j])//already existed an edge
				continue;

			CRawClip* pClipEdge = new CRawClip();

			//case 2: subclip from the original clip
			int iClipStartIndex = -1;
			CRawClip* pClipDB = isFromSameClip(i, j, iClipStartIndex);
			if(pClipDB)
			{
				CRawClip clipSub = pClipDB->GetSubClip(min(i,j)-iClipStartIndex, max(i,j)-iClipStartIndex);
				if(i > j)
					clipSub = clipSub.GetReverseClip();
				pClipEdge->MergeWith(clipSub);
				m_arTransitionEdgeMatrix[i][j] = pClipEdge;
				continue;
			}

			//case 3: need to synthesize by blending			
			for(int p = 0; p < iEdgeLength; ++p)
			{
				int iIndexOne = min(i+p, I-1);
				CRawFrame frmOne = m_pClipBase1->m_arFrame[iIndexOne];
				int iIndexTwo = max(j-iEdgeLength+1+p, 0);
				CRawFrame frmTwo = m_pClipBase2->m_arFrame[iIndexTwo];
				//linear blending
				CRawFrame frmEdge = CRawFrame::LinearBlend(frmOne, frmTwo, p, iEdgeLength);
				pClipEdge->m_arFrame.push_back(frmEdge);
			}
			m_arTransitionEdgeMatrix[i][j] = pClipEdge;
		}
	}
}
CRawClip* CMotionGraphR::GenerateRandomWalk(int iOutwardIdx, int iMinNode, int iMinFrames)
{
	CRawClip* pClipResult = NULL;
	int I = m_pClipBase1->m_arFrame.size(), J = m_pClipBase2->m_arFrame.size();
	if(iOutwardIdx < 0 || iOutwardIdx >= I)
		return pClipResult;

	pClipResult = new CRawClip();
	int iNodeCount=0, iFrameCount=0;
	int iSrcIdx = iOutwardIdx;
	while(iNodeCount < iMinNode || iFrameCount < iMinFrames)
	{
		int iDestIdx = -1;
		CRawClip clipEdge = getRandomEdge(iSrcIdx, iDestIdx);
		assert(iDestIdx != -1);
		assert(clipEdge.m_arFrame.size());
		pClipResult->ContinueWith(clipEdge);

		//for the next round
		iSrcIdx = iDestIdx;
		iNodeCount ++;
		iFrameCount += clipEdge.m_arFrame.size();		
	}
	return pClipResult;
}


CRawClip CMotionGraphR::getRandomEdge(int iOutwardIdx, int& iDestIdx)
{
	CRawClip clipResult;
	//find if iStartIdx connects to any node
	int iClipStartIdx = 0;
	CRawClip* pClipDB = getClip(iOutwardIdx, iClipStartIdx);
	int J = m_pClipBase2->m_arFrame.size();
	int iOutwardIdx2 = -1;
	//look forward along the same clip
	for(int i = iOutwardIdx; i < iClipStartIdx + pClipDB->m_arFrame.size(); ++i)
	{
		for(int j = 0; j < J; ++j)
		{
			//can transit out
			if(m_arTransitionEdgeMatrix[i][j] != NULL)
			{
				iOutwardIdx2 = i;
				break;
			}
		}
		if(iOutwardIdx2 != -1)
			break;
	}
	//if not connected, look backward along the same clip
	if(iOutwardIdx2 == -1)
	{
		for(int i = iOutwardIdx; i >= iClipStartIdx; --i)
		{
			for(int j = 0; j < J; ++j)
			{
				//can transit out
				if(m_arTransitionEdgeMatrix[i][j] != NULL)
				{
					iOutwardIdx2 = i;
					break;
				}
			}			
			if(iOutwardIdx2 != -1)
				break;
		}
	}
	//merge with the connected one
	if(iOutwardIdx2 != iOutwardIdx)
	{
		CRawClip clipSub = pClipDB->GetSubClip(min(iOutwardIdx, iOutwardIdx2)-iClipStartIdx, max(iOutwardIdx, iOutwardIdx2)-iClipStartIdx);
		if(iOutwardIdx2 < iOutwardIdx)
			clipSub = clipSub.GetReverseClip();
		clipResult.MergeWith(clipSub);
	}

	//now really, find the transition edge randomly
	int iRandomJ = rand() % J;
	for(int j = iRandomJ; j < J; ++j)
	{
		if(m_arTransitionEdgeMatrix[iOutwardIdx2][j] != NULL)
		{
			clipResult.ContinueWith(*m_arTransitionEdgeMatrix[iOutwardIdx2][j]);
			iDestIdx = j;
			return clipResult;
		}
	}
	//if not found;
	for(int j = iRandomJ; j >=0; --j)
	{
		if(m_arTransitionEdgeMatrix[iOutwardIdx2][j] != NULL)
		{
			clipResult.ContinueWith(*m_arTransitionEdgeMatrix[iOutwardIdx2][j]);
			iDestIdx = j;
			return clipResult;
		}
	}
	return clipResult;
}
void CMotionGraphR::constructBaseClipsFromDB()
{
	delete m_pClipBase1;
	delete m_pClipBase2;

	if(m_pMotionDB == NULL)
	{
		m_pClipBase1 = NULL;
		m_pClipBase2 = NULL;
		return;
	}

	m_pClipBase1 = new CRawClip();
	for(int i = 0; i < m_pMotionDB->m_arInitialClips.size(); ++i)
	{
		CRawClip* pClipDB = m_pMotionDB->m_arInitialClips[i];
		if(pClipDB == NULL)
			continue;

		m_pClipBase1->MergeWith(*pClipDB);
	}
	m_pClipBase2 = new CRawClip();
	m_pClipBase2->MergeWith(*m_pClipBase1);
}
#include "AMCAnimation.h"

bool CMotionGraphR::transitionInWindow(int iIndexI, int iIndexJ, int iWindowK, float fThreshold)
{
	int iStartI = -1, iStartJ = -1;
	CRawClip* pClipI = getClip(iIndexI, iStartI);
	CRawClip* pClipJ = getClip(iIndexJ, iStartJ);
	if(pClipI == NULL || pClipJ == NULL)
		return -1;	
	
	int iEndI = iStartI + pClipI->m_arFrame.size() -1;
	int iEndJ = iStartJ + pClipJ->m_arFrame.size() -1;
	
	bool bLocalMinima = true;
	float fDistance = m_arDistanceMatrix[iIndexI][iIndexJ];
	for(int p = 0; p < LOCAL_MINIMA_REGION; ++p)
	{
		//top
		float fDistanceNeighbor = m_arDistanceMatrix[max(iStartI, iIndexI-p)][iIndexJ];
		bLocalMinima = bLocalMinima && (fDistance <= fDistanceNeighbor);
		//left
		fDistanceNeighbor = m_arDistanceMatrix[iIndexI][max(iStartJ,iIndexJ-p)];
		bLocalMinima = bLocalMinima && (fDistance <= fDistanceNeighbor);
		//bottom
		fDistanceNeighbor = m_arDistanceMatrix[min(iEndI, iIndexI+p)][iIndexJ];
		bLocalMinima = bLocalMinima && (fDistance <= fDistanceNeighbor);
		//right
		fDistanceNeighbor = m_arDistanceMatrix[iIndexI][min(iEndJ, iIndexJ+p)];
		bLocalMinima = bLocalMinima && (fDistance <= fDistanceNeighbor);

		//up left
		fDistanceNeighbor = m_arDistanceMatrix[max(iStartI, iIndexI-p)][min(iEndJ, iIndexJ+p)];
		bLocalMinima = bLocalMinima && (fDistance <= fDistanceNeighbor);
		//up right
		fDistanceNeighbor = m_arDistanceMatrix[min(iEndI, iIndexI+p)][min(iEndJ, iIndexJ+p)];
		bLocalMinima = bLocalMinima && (fDistance <= fDistanceNeighbor);
		//bottom left
		fDistanceNeighbor = m_arDistanceMatrix[max(iStartI, iIndexI-p)][max(iStartJ,iIndexJ-p)];
		bLocalMinima = bLocalMinima && (fDistance <= fDistanceNeighbor);
		//bottom right	
		fDistanceNeighbor = m_arDistanceMatrix[min(iEndI, iIndexI+p)][max(iStartJ,iIndexJ-p)];
		bLocalMinima = bLocalMinima && (fDistance <= fDistanceNeighbor);
	}
	//below threshold value
	bool bTransition = bLocalMinima && (fDistance <= fThreshold) && (iIndexI != iIndexJ) && (fDistance != 0);
	return bTransition;
}
float CMotionGraphR::distanceInWindow(int iIndexI, int iIndexJ, int iWindowK)
{
	int iStartI = -1, iStartJ = -1;
	CRawClip* pClipI = getClip(iIndexI, iStartI);
	CRawClip* pClipJ = getClip(iIndexJ, iStartJ);
	if(pClipI == NULL || pClipJ == NULL)
		return -1;

	CRawFrame frmWeights = CAMCFrame::GetWeights();

	int iFrameCount = 0;
	float fDistance = 0;

	for(int p = 0; p < iWindowK; ++p)
	{
		int i = min(pClipI->m_arFrame.size()-1, (iIndexI-iStartI)+p);
		CRawFrame frmOne = pClipI->m_arFrame[i];

		int j = max(0, (iIndexJ-iStartJ)-iWindowK+1+p);
		CRawFrame frmTwo = pClipJ->m_arFrame[j];
				
		fDistance += frmOne.DistanceToWeighted(frmTwo, frmWeights);
		iFrameCount ++;
	}
	fDistance = fDistance / iFrameCount;
	return fDistance;
}
CRawClip* CMotionGraphR::isFromSameClip (int iIndexI, int iIndexJ, int& iClipStartIndex)
{
	if(m_pMotionDB == NULL)
		return NULL;

	int iFrameCount = 0;
	for(int c = 0; c < m_pMotionDB->m_arInitialClips.size(); ++ c)
	{
		CRawClip* pClipDB = m_pMotionDB->m_arInitialClips[c];
		if(iIndexI >= iFrameCount && iIndexI < iFrameCount + pClipDB->m_arFrame.size() &&
			iIndexJ >= iFrameCount && iIndexJ < iFrameCount + pClipDB->m_arFrame.size())
		{
			iClipStartIndex = iFrameCount;
			return pClipDB;
		}
		iFrameCount = iFrameCount + pClipDB->m_arFrame.size();
	}
	return NULL;
}
CRawClip* CMotionGraphR::getClip(int iFrameIndex, int& iClipStartIndex)
{
	if(m_pMotionDB == NULL)
		return NULL;

	int iFrameCount = 0;
	for(int c = 0; c < m_pMotionDB->m_arInitialClips.size(); ++ c)
	{
		CRawClip* pClipDB = m_pMotionDB->m_arInitialClips[c];
		if(iFrameIndex >= iFrameCount && iFrameIndex < iFrameCount + pClipDB->m_arFrame.size())
		{
			iClipStartIndex = iFrameCount;
			return pClipDB;
		}
		iFrameCount = iFrameCount + pClipDB->m_arFrame.size();
	}
	return NULL;

}

