#pragma once
#include <vector>
#include <string>



class CRawFrame 
{
public:
	std::vector<float> m_arData;
	CRawFrame();
	CRawFrame(const std::vector<float>& arData);
	static CRawFrame GetEmptyFrame(int iDataNum = 31);
	bool operator == (const CRawFrame& frame);
	float DistanceTo(CRawFrame& frmRaw);
	float DistanceToWeighted(CRawFrame& frmRaw, CRawFrame& frmWeights);
	static CRawFrame LinearBlend(CRawFrame& frm1, CRawFrame& frm2, int iPos, int iLength);
};
class CRawClip 
{
public:
	std::vector<CRawFrame> m_arFrame;
	void SaveToFile(std::string strPath);
	void LoadFromFile(std::string strPath);
	int GetFrameCount();
	CRawFrame GetAveragePose();
	void MergeWith(const CRawClip& clipToMerge);
	void ContinueWith(CRawClip& clipToContinue);//realign root
	bool HasFrame(const CRawFrame& frame);
	void EliminateInputRedundancy();
	CRawClip GetSubClip(int iBegIdx, int iEndIdx);
	CRawClip GetReverseClip();

	CRawClip GenerateClipLocalCoord();
	CRawClip GenerateClipGlobalCoord(float fRotationX, float fRotationY, float fRotationZ, float fTranslationX, float fTranslationY, float fTranslationZ);
};
