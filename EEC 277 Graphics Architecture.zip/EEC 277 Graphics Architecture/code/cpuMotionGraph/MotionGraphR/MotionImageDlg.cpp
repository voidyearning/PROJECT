// MotionImageDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MotionGraphR.h"
#include "MotionImageDlg.h"
#include "afxdialogex.h"


// CMotionImageDlg dialog

IMPLEMENT_DYNAMIC(CMotionImageDlg, CDialog)

CMotionImageDlg::CMotionImageDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMotionImageDlg::IDD, pParent)
{

}

CMotionImageDlg::~CMotionImageDlg()
{
}

void CMotionImageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMotionImageDlg, CDialog)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_LOAD_MOTION_IMAGE, &CMotionImageDlg::OnBnClickedButtonLoadMotionImage)
	ON_BN_CLICKED(IDC_BUTTON_GENERATE_MOTION_IMAGE, &CMotionImageDlg::OnBnClickedButtonGenerateMotionImage)
	ON_WM_HSCROLL()
END_MESSAGE_MAP()


// CMotionImageDlg message handlers
BOOL CMotionImageDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	

	GetDlgItem(IDC_EDIT_V_MIN)->SetWindowText(L"-90.0");
	GetDlgItem(IDC_EDIT_V_MAX)->SetWindowText(L"90.0");
	CRect rect;
	::GetClientRect(GetDlgItem(IDC_STATIC_IMAGE)->m_hWnd, rect);
	m_wndMotionImage.Create(NULL, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE, rect, GetDlgItem(IDC_STATIC_IMAGE), 0);  

	return TRUE;  // return TRUE  unless you set the focus to a control
}

#include "MotionGraphRDoc.h"
void CMotionImageDlg::OnBnClickedButtonLoadMotionImage()
{
	CFileDialog dlgFile(TRUE, L"raw data(*.raw)|*.raw", 0, 4|2, L"raw data(*.raw)|*.raw||");
	if(IDOK != dlgFile.DoModal())
		return;

	m_clipData.m_arFrame.clear();
	m_clipData.LoadFromFile(CMotionGraphRDoc::wToChar(dlgFile.GetPathName()));
}


void CMotionImageDlg::OnBnClickedButtonGenerateMotionImage()
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_V_MIN);
	CString strVMin;
	pEdit->GetWindowText(strVMin);
	float fVMin = _wtof(strVMin.GetBuffer());

	pEdit = (CEdit*)GetDlgItem(IDC_EDIT_V_MAX);
	CString strVMax;
	pEdit->GetWindowText(strVMax);
	float fVMax = _wtof(strVMax.GetBuffer());

	CMotionImage imgMotion;
	imgMotion.LoadFromRaw(m_clipData, fVMin, fVMax);
	m_wndMotionImage.m_imgMotion = imgMotion;
	m_wndMotionImage.MoveWindow(0,0,imgMotion.m_iWidth,imgMotion.m_iHeight);
	SetScrollRange(SB_HORZ, 0, imgMotion.m_iWidth);
	SetScrollRange(SB_VERT, 0, imgMotion.m_iHeight);
}


void CMotionImageDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	int nMin, nMax;
	GetScrollRange(SB_HORZ, &nMin, &nMax);

	CRect rect;
	::GetClientRect(GetDlgItem(IDC_STATIC_IMAGE)->m_hWnd, rect);

	int iPage = rect.Width();
	int iPos = GetScrollPos(SB_HORZ);
	int iNewPos = iPos;
	switch (nSBCode)
	{
	case SB_THUMBTRACK:
		iNewPos = nPos;
		break;
	case SB_LINELEFT:
		iNewPos = max(nMin, iPos - 5);
		break;
	case SB_PAGELEFT:
		iNewPos = max(nMin, iPos - iPage);
		break;
	case SB_LINERIGHT:
		iNewPos = min(nMax, iPos + 5);
		break;
	case SB_PAGERIGHT:
		iNewPos = min(nMax, iPos + iPage);
		break;	
	}
	GetDlgItem(IDC_STATIC_IMAGE)->ScrollWindow(-(iNewPos - iPos), 0);
	SetScrollPos(SB_HORZ, iNewPos);
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}
