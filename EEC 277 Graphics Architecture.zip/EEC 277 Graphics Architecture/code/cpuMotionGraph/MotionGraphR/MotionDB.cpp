#include "stdafx.h"
#include "MotionDB.h"
#include <fstream>
#include "math.h"

#include "MotionGraphRDoc.h"
#include "AMCAnimation.h"
void CMotionDB::recursiveLoadFromRaw(std::string strPath)
{
	CString strToFind(strPath.c_str());
	strToFind = strToFind + L"\\*.*";
	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(strToFind);
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		CString strTitle = finder.GetFileTitle();
		if(finder.IsDirectory())
		{
			if(strTitle == L"." || strTitle == L".." || strTitle.IsEmpty())
				continue;
			std::string strNext = strPath;
			strNext.append("\\");
			strNext.append(CMotionGraphRDoc::wToChar(strTitle));
			recursiveLoadFromRaw(strNext);
		}
		else
		{
			CString strFileName = finder.GetFileName();
			if(strFileName.Find(L".raw") == -1)
				continue;
			CRawClip* pClipDB = new CRawClip();
			pClipDB->LoadFromFile(CMotionGraphRDoc::wToChar(finder.GetFilePath()));
			m_arInitialClips.push_back(pClipDB);
		}
	}
}
void CMotionDB::recursiveLoadFromAmc(std::string strPath)
{
	/*CString strToFind(strPath.c_str());
	strToFind = strToFind + L"\\*.*";
	CFileFind finder;
	BOOL bNotFinished = finder.FindFile(strToFind);
	while(bNotFinished)
	{
		bNotFinished = finder.FindNextFile();
		CString strTitle = finder.GetFileTitle();
		if(finder.IsDirectory())
		{
			if(strTitle == L"." || strTitle == L".." || strTitle.IsEmpty())
				continue;
			std::string strNext = strPath;
			strNext.append("\\");
			strNext.append(CMotionGraphRDoc::wToChar(strTitle));
			recursiveLoadFromRaw(strNext);
		}
		else
		{
			CString strFileName = finder.GetFileName();
			if(strFileName.Find(L".amc") == -1)
				continue;
			CAMCClip clipAMC;
			clipAMC.LoadFromFile(CMotionGraphRDoc::wToChar(finder.GetFilePath()));
			CRawClip* pClipDB = new CRawClip();
			clipAMC.SaveToRaw(*pClipDB);
			m_arInitialClips.push_back(pClipDB);
		}
	}
	return;*/

	CAMCClip clipAMC;
	CRawClip* pClipDB;
	
	//jump =======================================================================================================
	clipAMC.LoadFromFile("C:\\wangyi\\course\\EEC277\\final project\\db\\jump\\16_05_jump_forward.amc");
	pClipDB = new CRawClip();
	clipAMC.SaveToRaw(*pClipDB);
	m_arInitialClips.push_back(pClipDB);	
	
	/*clipAMC.LoadFromFile("C:\\wangyi\\course\\EEC277\\final project\\db\\jump\\16_03_jump_high.amc");
	pClipDB = new CRawClip();
	clipAMC.SaveToRaw(*pClipDB);
	m_arInitialClips.push_back(pClipDB);*/
	
	//running=======================================================================================================
	clipAMC.LoadFromFile("C:\\wangyi\\course\\EEC277\\final project\\db\\running\\16_36_run.amc");
	pClipDB = new CRawClip();
	clipAMC.SaveToRaw(*pClipDB);
	m_arInitialClips.push_back(pClipDB);//

	/*clipAMC.LoadFromFile("C:\\wangyi\\course\\EEC277\\final project\\db\\running\\16_48_run_left.amc");
	pClipDB = new CRawClip();
	clipAMC.SaveToRaw(*pClipDB);
	m_arInitialClips.push_back(pClipDB);

	clipAMC.LoadFromFile("C:\\wangyi\\course\\EEC277\\final project\\db\\running\\16_49_run_right.amc");
	pClipDB = new CRawClip();
	clipAMC.SaveToRaw(*pClipDB);
	m_arInitialClips.push_back(pClipDB);
	
	clipAMC.LoadFromFile("C:\\wangyi\\course\\EEC277\\final project\\db\\running\\16_41_run_left_sharp.amc");
	pClipDB = new CRawClip();
	clipAMC.SaveToRaw(*pClipDB);
	m_arInitialClips.push_back(pClipDB);
	
	clipAMC.LoadFromFile("C:\\wangyi\\course\\EEC277\\final project\\db\\running\\16_54_run_right_sharp.amc");
	pClipDB = new CRawClip();
	clipAMC.SaveToRaw(*pClipDB);
	m_arInitialClips.push_back(pClipDB);//*/


	//walk ========================================================================================================	
	/*clipAMC.LoadFromFile("C:\\wangyi\\course\\EEC277\\final project\\db\\walking\\16_23_walk_left.amc");
	pClipDB = new CRawClip();
	clipAMC.SaveToRaw(*pClipDB);
	m_arInitialClips.push_back(pClipDB);
	
	clipAMC.LoadFromFile("C:\\wangyi\\course\\EEC277\\final project\\db\\walking\\16_25_walk_right.amc");
	pClipDB = new CRawClip();
	clipAMC.SaveToRaw(*pClipDB);
	m_arInitialClips.push_back(pClipDB);*/

	clipAMC.LoadFromFile("C:\\wangyi\\course\\EEC277\\final project\\db\\walking\\16_47_walk.amc");
	pClipDB = new CRawClip();
	clipAMC.SaveToRaw(*pClipDB);
	m_arInitialClips.push_back(pClipDB);

	
}

void CMotionDB::LoadFromAmc(std::string strPath)
{
	recursiveLoadFromAmc(strPath);
}
void CMotionDB::LoadFromRaw(std::string strPath)
{
	recursiveLoadFromRaw(strPath);
}

void CMotionDB::Clear()
{
	for(int i = 0; i < m_arInitialClips.size(); ++ i)
		delete m_arInitialClips[i];
	
	m_arInitialClips.clear();
}
void CMotionDB::LoadFromRawInOrder(std::string strPath)
{
	Clear();
	int i = 0;
	while(true)
	{
		char buff[100];
		sprintf(buff, "_%d.raw", i);
		std::string strFileName = strPath;
		strFileName.append("\\");
		strFileName.append(buff);

		CRawClip* pClipDB = new CRawClip();
		pClipDB->LoadFromFile(strFileName);
		if(pClipDB->m_arFrame.size() == 0)
		{
			delete pClipDB;
			break;
		}
		m_arInitialClips.push_back(pClipDB);
	};
}
void CMotionDB::SaveToRaw(std::string strPath)
{
	for(int i = 0; i < m_arInitialClips.size(); ++i)
	{
		CRawClip* pClipDB = m_arInitialClips[i];
		char buff[100];
		sprintf(buff, "_%d.raw", i);
		std::string strFileName = strPath;
		strFileName.append("\\");
		strFileName.append(buff);
		pClipDB->SaveToFile(strFileName);
	}
}