#include "stdafx.h"
#include "MotionImage.h"

COLORREF scalar2RGB(double v,double vmin,double vmax)
{
	float r = 0, g = 0, b = 0;
	double dv;

   if (v < vmin)
      v = vmin;
   if (v > vmax)
      v = vmax;
   dv = vmax - vmin;

   if (v < (vmin + 0.25 * dv)) 
   {
	   r = 0;
	   g = 4 * (v - vmin) / dv;
   } 
   else if (v < (vmin + 0.5 * dv))
   {
	   r = 0;
	   b = 1 + 4 * (vmin + 0.25 * dv - v) / dv;
   } 
   else if (v < (vmin + 0.75 * dv)) 
   {
	   r = 4 * (v - vmin - 0.5 * dv) / dv;
	   b = 0;
   } 
   else 
   {
	   g = 1 + 4 * (vmin + 0.75 * dv - v) / dv;
	   b = 0;
   }

   COLORREF color = RGB(r*255,g*255,b*255);
   return color;
}

CMotionImage::CMotionImage()
{
    m_iWidth = 0;
    m_iHeight = 0; 
	m_arPixels = 0;
}
void CMotionImage::Clear()
{
	for(int l = 0; l < m_iHeight; ++l)
		delete [] m_arPixels[l];
	delete [] m_arPixels;
}
void CMotionImage::Initialize(int iWidth, int iHeight)
{
	Clear();

	m_iWidth = iWidth;
	m_iHeight = iHeight;

	m_arPixels = new COLORREF* [iHeight];
	for(int l = 0; l < iHeight; ++l)
	{
		m_arPixels[l] = new COLORREF [iWidth];
		for(int c = 0; c < iWidth; ++c)
		{
			m_arPixels[l][c] = 0;
		}
	}
}
void CMotionImage::LoadFromRaw(CRawClip& clipRaw, float fVMin, float fVMax)
{
	if(clipRaw.m_arFrame.size() == 0 ||
		clipRaw.m_arFrame[0].m_arData.size() == 0)
		return;

	Initialize(clipRaw.m_arFrame.size(), clipRaw.m_arFrame[0].m_arData.size());
	for(int c = 0; c < clipRaw.m_arFrame.size(); ++c)
	{
		CRawFrame frmRaw = clipRaw.m_arFrame[c];
		for(int l = 0; l < frmRaw.m_arData.size(); ++l)
		{
			float fData = frmRaw.m_arData[l];
			COLORREF color = scalar2RGB(fData, fVMin, fVMax);
			m_arPixels[l][c] = color;
		}
	}
}
