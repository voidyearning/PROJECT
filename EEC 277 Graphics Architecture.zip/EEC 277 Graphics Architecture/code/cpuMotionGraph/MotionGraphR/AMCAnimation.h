#pragma once
#include <vector>
#include <string>
#include "RawAnimation.h"

class CAMCFrame 
{
public:
	//upper body 
	//torso
	float m_root[6];
    float m_lowerback[3];
    float m_upperback[3];
    float m_thorax[3];
    float m_lowerneck[3];
    float m_upperneck[3];
    float m_head[3];

	//right
    float m_rclavicle[2];
    float m_rhumerus[3];
    float m_rradius[1];
    float m_rwrist[1];
    float m_rhand[2];
    float m_rfingers[1];
    float m_rthumb[2];

	//left
    float m_lclavicle[2];
    float m_lhumerus[3];
    float m_lradius[1];
    float m_lwrist[1];
    float m_lhand[2];
    float m_lfingers[1];
    float m_lthumb[2];

	//lower body
	//right
	float m_rfemur[3];
    float m_rtibia[1];
    float m_rfoot[2];
    float m_rtoes[1];

    float m_lfemur[3];
    float m_ltibia[1];
    float m_lfoot[2];
    float m_ltoes[1];

	void LoadFromRaw(CRawFrame& frmRaw);
	void SaveToRaw(CRawFrame& frmRaw);
	static CRawFrame GetWeights();
};

class CAMCClip
{
public:
	CAMCClip();
	std::vector<CAMCFrame> m_arFrame;

	void LoadFromFile(std::string strPath);
	void SaveToFile(std::string strPath);

	void LoadFromRaw(CRawClip& clipRaw);
	void SaveToRaw(CRawClip& clipRaw);

	CAMCClip GetSubClip(int iBegIdx, int iEndIdx);

};



