#include "engine.h"
#include "mat.h"

class CPos3D
{
public:
	CPos3D()
	{
		m_fX = m_fY = m_fZ = 0;
	}
	CPos3D(float x, float y, float z)
	{
		m_fX = x; m_fY = y; m_fZ = z;
	}

	float m_fX;
	float m_fY;
	float m_fZ;	
};
class CMatlabEngine
{
public:
	static Engine* GetEngine()
	{
		if(s_pMatlabEngine == NULL)
			s_pMatlabEngine = engOpen(NULL);
		return s_pMatlabEngine;
	}
	virtual ~CMatlabEngine()
	{
		delete s_pMatlabEngine;
	}
	static Engine* s_pMatlabEngine;

	static CPos3D GlobalToLocal(CPos3D posGlobalTranslation, CPos3D posGlobalRotation, CPos3D posRootTranslation, CPos3D posRootRotation);
	static CPos3D LocalToGlobal(CPos3D posLocal, CPos3D posRootTranslation, CPos3D posRootRotation);
	static CPos3D LocalToGlobalRotation(CPos3D posLocalRotation, CPos3D posRootRotation);
private:
	CMatlabEngine(){}
};