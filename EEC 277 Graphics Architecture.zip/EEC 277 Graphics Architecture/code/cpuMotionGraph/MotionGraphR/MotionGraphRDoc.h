// MotionGraphRDoc.h : interface of the CMotionGraphRDoc class
//


#pragma once

#include "MotionDB.h"
#include "MotionGraph.h"

class CMotionGraphRDoc : public CDocument
{
public:
	static char* wToChar(CString strWide);
protected: // create from serialization only
	CMotionGraphRDoc();
	DECLARE_DYNCREATE(CMotionGraphRDoc)

// Attributes
public:

// Operations
public:
	CMotionGraphR* m_pMotionGraph;
	CMotionDB* m_pMotionDB;

// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CMotionGraphRDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnFileOpen();
	afx_msg void OnViewMotionimage();
	afx_msg void OnMotiongraphLoadmotiondb();
	afx_msg void OnMotiongraphConstructmotiongraph();
	afx_msg void OnMotiongraphSavemotiongraph();
	afx_msg void OnMotiongraphLoadmotiondbordered();
	afx_msg void OnMotiongraphSavemotiondb();
	afx_msg void OnMotiongraphLoadmotiongraph();
	afx_msg void OnMotiongraphGeneraterandomwalk();
	afx_msg void OnConstructmotiongraphCalculatedistancematrix();
	afx_msg void OnConstructmotiongraphCalculatetransitionmatrix();
	afx_msg void OnConstructmotiongraphInterpolatetransitionedges();
	afx_msg void OnConstructmotiongraphConstructmotiongraph();
	afx_msg void OnMotiongraphFloydwarshallshortestpathsearch();
	afx_msg void OnMotiongraphGenerateshortestpathclip();
};


