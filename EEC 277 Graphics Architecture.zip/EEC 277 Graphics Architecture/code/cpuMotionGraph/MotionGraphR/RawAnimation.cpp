#include "stdafx.h"
#include "RawAnimation.h"
#include <fstream>
#include "math.h"



CRawFrame::CRawFrame()
{
}
CRawFrame::CRawFrame(const std::vector<float>& arData)
{
	m_arData.clear();
	for(int i = 0; i < arData.size(); ++i)
		m_arData.push_back(arData[i]);
}

bool CRawFrame::operator == (const CRawFrame& frame)
{
	if(m_arData.size() != frame.m_arData.size())
		return false;
	for(int i = 0; i < m_arData.size(); ++i)
	{
		if(m_arData[i] != frame.m_arData[i])
			return false;
	}
	return true;
}
float CRawFrame::DistanceTo(CRawFrame& frmRaw)
{
	float fDist = 0;
	for(int i = 0; i < m_arData.size(); ++i)
		fDist += (m_arData[i] - frmRaw.m_arData[i]) * (m_arData[i] - frmRaw.m_arData[i]);

	fDist = sqrt(fDist);
	return fDist;
}
float CRawFrame::DistanceToWeighted(CRawFrame& frmRaw, CRawFrame& frmWeights)
{
	float fDist = 0;
	for(int i = 0; i < m_arData.size(); ++i)
		fDist += frmWeights.m_arData[i] * (m_arData[i] - frmRaw.m_arData[i]) * (m_arData[i] - frmRaw.m_arData[i]);

	fDist = sqrt(fDist);
	return fDist;
}
CRawFrame CRawFrame::GetEmptyFrame(int iDataNum)
{
	CRawFrame frmEmpty;
	for(int i = 0; i < iDataNum; ++ i)
		frmEmpty.m_arData.push_back(0);
	return frmEmpty;
}

CRawFrame CRawFrame::LinearBlend(CRawFrame& frm1, CRawFrame& frm2, int iPos, int iLength)
{
	CRawFrame frmBlended;
	if(iPos >= iLength || iPos < 0)
		return frmBlended;

	if(frm1.m_arData.size() != frm2.m_arData.size())
		return frmBlended;

	float fTerm = float(iPos+1.0) / float(iLength);
	float fAlpha = 2 * fTerm * fTerm * fTerm 
		- 3 * fTerm * fTerm + 1;

	for(int i = 0; i < frm1.m_arData.size(); ++i)
	{
		float fData1 = frm1.m_arData[i];
		float fData2 = frm2.m_arData[i];
		float fDataBlended = fAlpha * fData1 + (1-fAlpha) * fData2;
		if(i<6)//root translation
			fDataBlended = 0;
		frmBlended.m_arData.push_back(fDataBlended);
	}
	return frmBlended;
}
CRawFrame CRawClip::GetAveragePose()
{
	CRawFrame frmAvePose;
	if(m_arFrame.size() <= 0)
		return frmAvePose;
	
	frmAvePose = CRawFrame::GetEmptyFrame(m_arFrame[0].m_arData.size());
	for(int f = 0; f < m_arFrame.size(); ++f)
	{
		CRawFrame frmCur = m_arFrame[f];
		for(int d = 0; d < frmCur.m_arData.size(); ++d)
			frmAvePose.m_arData[d] += frmCur.m_arData[d];
	}
	for(int d = 0; d < frmAvePose.m_arData.size(); ++d)
		frmAvePose.m_arData[d] = frmAvePose.m_arData[d] / m_arFrame.size();

	return frmAvePose;
}
void CRawClip::SaveToFile(std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frm = m_arFrame[i];
		for(int j = 0; j < frm.m_arData.size(); ++j)
		{
			fout << frm.m_arData[j];
			if(j < frm.m_arData.size()-1)
				fout << " ";
		}
		fout<<std::endl;
	}
	fout.flush();
	fout.close();
}

void CRawClip::LoadFromFile(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	m_arFrame.clear();
	char* pLineBuffer = new char [1024*1024];
	while(fin.good())
	{
		fin.getline(pLineBuffer, 1024*1024);
		CRawFrame frm;
		std::string strData(pLineBuffer);
		int iStart = 0, iEnd = strData.find(" ");
		int iCount = 0;
		while(iEnd > iStart)
		{
			std::string strOneData = strData.substr(iStart, iEnd - iStart);//strData.Mid(iStart, iEnd - iStart);
			//strOneData.Trim();
			float fData = atof(strOneData.c_str());
			frm.m_arData.push_back(fData);
			iStart = iEnd + 1;
			iEnd = strData.find(" ", iStart);
		}
		//last one
		std::string strOneData = strData.substr(iStart);//strData.Mid(iStart);
		//strOneData.Trim();
		if(!strOneData.empty())
		{
			float fData = atof(strOneData.c_str());
			frm.m_arData.push_back(fData);
		}

		if(frm.m_arData.size() != 0)
			m_arFrame.push_back(frm);
	}
	delete [] pLineBuffer;
}
bool CRawClip::HasFrame(const CRawFrame& frame)
{
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		if(m_arFrame[i] == frame)
			return true;
	}
	return false;
}
void CRawClip::MergeWith(const CRawClip& clipToMerge)
{
	for(int i = 0; i < clipToMerge.m_arFrame.size(); ++i)
	{
		CRawFrame frmToMerge = clipToMerge.m_arFrame[i];
		m_arFrame.push_back(frmToMerge);
	}
}
#include "MatlabUtil.h"
CRawClip CRawClip::GenerateClipGlobalCoord(float fRotationX, float fRotationY, float fRotationZ, float fTranslationX, float fTranslationY, float fTranslationZ)
{
	CRawClip clipGlobal;
	if(m_arFrame.size() == 0)
		return clipGlobal;

	CPos3D posOriginGlobalT(fTranslationX, fTranslationY, fTranslationZ);
	CPos3D posOriginGlobalR(fRotationX, fRotationY, fRotationZ);

	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmGlobal = m_arFrame[i];
		
		CPos3D posGlobalT = CMatlabEngine::LocalToGlobal(CPos3D(frmGlobal.m_arData[0], frmGlobal.m_arData[1], frmGlobal.m_arData[2]), 
			posOriginGlobalT, posOriginGlobalR);
		
		frmGlobal.m_arData[0] = posGlobalT.m_fX;
		frmGlobal.m_arData[1] = posGlobalT.m_fY;
		frmGlobal.m_arData[2] = posGlobalT.m_fZ;

		CPos3D posGlobalR = CMatlabEngine::LocalToGlobalRotation(CPos3D(frmGlobal.m_arData[3], frmGlobal.m_arData[4], frmGlobal.m_arData[5]), 
			posOriginGlobalR);

		frmGlobal.m_arData[3] = posGlobalR.m_fX;
		frmGlobal.m_arData[4] = posGlobalR.m_fY;
		frmGlobal.m_arData[5] = posGlobalR.m_fZ;

		clipGlobal.m_arFrame.push_back(frmGlobal);
	}
	return clipGlobal;


}
CRawClip CRawClip::GenerateClipLocalCoord()
{
	CRawClip clipLocal;
	if(m_arFrame.size() == 0)
		return clipLocal;

	//local origin
	CPos3D posOriginLocalT(m_arFrame[0].m_arData[0], m_arFrame[0].m_arData[1], m_arFrame[0].m_arData[2]);
	CPos3D posOriginLocalR(m_arFrame[0].m_arData[3], m_arFrame[0].m_arData[4], m_arFrame[0].m_arData[5]);

	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmLocal = m_arFrame[i];

		CPos3D posLocalT = CMatlabEngine::GlobalToLocal(CPos3D(frmLocal.m_arData[0], frmLocal.m_arData[1], frmLocal.m_arData[2]),
			CPos3D(frmLocal.m_arData[3], frmLocal.m_arData[4], frmLocal.m_arData[5]),
			posOriginLocalT, posOriginLocalR);
		
		frmLocal.m_arData[0] = posLocalT.m_fX;
		frmLocal.m_arData[1] = posLocalT.m_fY;
		frmLocal.m_arData[2] = posLocalT.m_fZ;

		CPos3D posLocalR;
		posLocalR.m_fX = frmLocal.m_arData[3] - posOriginLocalR.m_fX;
		posLocalR.m_fY = frmLocal.m_arData[4] - posOriginLocalR.m_fY;
		posLocalR.m_fZ = frmLocal.m_arData[5] - posOriginLocalR.m_fZ;

		frmLocal.m_arData[3] = posLocalR.m_fX;
		frmLocal.m_arData[4] = posLocalR.m_fY;
		frmLocal.m_arData[5] = posLocalR.m_fZ;

		clipLocal.m_arFrame.push_back(frmLocal);
	}
	return clipLocal;
}
void CRawClip::ContinueWith(CRawClip& clipToContinue)
{
	if(clipToContinue.m_arFrame.size() == 0)
		return;
	CRawFrame frmFirst = clipToContinue.m_arFrame[0];
	CRawFrame frmLast = frmFirst;
	if(m_arFrame.size() != 0)
		frmLast = m_arFrame[m_arFrame.size()-1];
	
	CRawClip clipLocal = clipToContinue.GenerateClipLocalCoord();
	CRawClip clipNewGlobal = clipLocal.GenerateClipGlobalCoord(
		frmLast.m_arData[3], frmLast.m_arData[4], frmLast.m_arData[5], 
		frmLast.m_arData[0], frmLast.m_arData[1], frmLast.m_arData[2]);

	MergeWith(clipNewGlobal);
}
CRawClip CRawClip::GetSubClip(int iBegIdx, int iEndIdx)
{
	CRawClip clipResult;
	for(int i = iBegIdx; i < iEndIdx; ++i)
	{
		CRawFrame frmSub = m_arFrame[i];
		clipResult.m_arFrame.push_back(frmSub);
	}
	return clipResult;
}
CRawClip CRawClip::GetReverseClip()
{
	CRawClip clipResult;
	for(int i = m_arFrame.size()-1; i >=0; --i)
	{
		CRawFrame frmRaw = m_arFrame[i];
		clipResult.m_arFrame.push_back(frmRaw);
	}
	return clipResult;
}
