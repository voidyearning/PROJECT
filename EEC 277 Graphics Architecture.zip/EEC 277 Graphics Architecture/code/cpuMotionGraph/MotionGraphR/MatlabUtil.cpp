#include "stdafx.h"
#include "MatlabUtil.h"
Engine* CMatlabEngine::s_pMatlabEngine = NULL;

#define wToRadian(x) (x * 3.1315926 / 180)
#define wToDegree(x) (x * 180 / 3.1415926)
CPos3D CMatlabEngine::GlobalToLocal(CPos3D posGlobalTranslation, CPos3D posGlobalRotation, CPos3D posRootTranslation, CPos3D posRootRotation)
{
	double* arGlobalPos = new double[4];	
	double* arGlobalRot = new double[4];
	double* arRootPos = new double[4];	
	double* arRootRot = new double[4];
	arGlobalPos[0] = posGlobalTranslation.m_fX; 
	arGlobalPos[1] = posGlobalTranslation.m_fY; 
	arGlobalPos[2] = posGlobalTranslation.m_fZ; 
	arGlobalPos[3] = 1;

	arGlobalRot[0] = wToRadian(posGlobalRotation.m_fX); 
	arGlobalRot[1] = wToRadian(posGlobalRotation.m_fY); 
	arGlobalRot[2] = wToRadian(posGlobalRotation.m_fZ); 
	arGlobalRot[3] = 1;


	arRootPos[0] = posRootTranslation.m_fX; arRootPos[1] = posRootTranslation.m_fY; arRootPos[2] = posRootTranslation.m_fZ; arRootPos[3] = 1;
	arRootRot[0] = wToRadian(posRootRotation.m_fX); arRootRot[1] = wToRadian(posRootRotation.m_fY); arRootRot[2] = wToRadian(posRootRotation.m_fZ);

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	mxArray* pMxGlobalPos = mxCreateDoubleMatrix(4, 1, mxREAL);
	mxSetClassName(pMxGlobalPos, "globalPos");
	memcpy(mxGetPr(pMxGlobalPos), (double*)arGlobalPos, 4*sizeof(double));
	engPutVariable(pMatlabEngine, "globalPos", pMxGlobalPos);

	mxArray* pMxGlobalRot = mxCreateDoubleMatrix(4, 1, mxREAL);
	mxSetClassName(pMxGlobalRot, "globalRot");
	memcpy(mxGetPr(pMxGlobalRot), (double*)arGlobalRot, 4*sizeof(double));
	engPutVariable(pMatlabEngine, "globalRot", pMxGlobalRot);
	
	mxArray* pMxRootPos = mxCreateDoubleMatrix(4, 1, mxREAL);
	mxSetClassName(pMxRootPos, "rootPos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 4*sizeof(double));
	engPutVariable(pMatlabEngine, "rootPos", pMxRootPos);
	
	mxArray* pMxRootRot = mxCreateDoubleMatrix(4, 1, mxREAL);
	mxSetClassName(pMxRootRot, "rootRot");
	memcpy(mxGetPr(pMxRootRot), (double*)arRootRot, 4*sizeof(double));
	engPutVariable(pMatlabEngine, "rootRot", pMxRootRot);

	char strCmd[200];
	sprintf(strCmd, "localPos = eec277GlobalToLocal(globalPos, rootPos, rootRot);");	
	engEvalString(pMatlabEngine,strCmd);

	double* arLocalPos = new double[4];
	mxArray* pMxLocalPos = engGetVariable(pMatlabEngine, "localPos");
	memcpy((char*)arLocalPos, (char*)mxGetPr(pMxLocalPos), 4*sizeof(double));
	
	CPos3D posLocal;
	posLocal.m_fX = arLocalPos[0]; posLocal.m_fY = arLocalPos[1]; posLocal.m_fZ = arLocalPos[2];

	//release
    delete arGlobalPos;
	delete arGlobalRot;
	delete arLocalPos;
	delete arRootPos;
	delete arRootRot;
	mxDestroyArray(pMxGlobalPos);
	mxDestroyArray(pMxGlobalRot);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxRootRot);

	return posLocal;
}
CPos3D CMatlabEngine::LocalToGlobal(CPos3D posLocal, CPos3D posRootTranslation, CPos3D posRootRotation)
{
	double* arLocalPos = new double[4];	
	double* arRootPos = new double[4];	
	double* arRootRot = new double[4];
	arLocalPos[0] = posLocal.m_fX; arLocalPos[1] = posLocal.m_fY; arLocalPos[2] = posLocal.m_fZ; arLocalPos[3] = 1;
	arRootPos[0] = posRootTranslation.m_fX; arRootPos[1] = posRootTranslation.m_fY; arRootPos[2] = posRootTranslation.m_fZ; arRootPos[3] = 1;
	arRootRot[0] = wToRadian(posRootRotation.m_fX); arRootRot[1] = wToRadian(posRootRotation.m_fY); arRootRot[2] = wToRadian(posRootRotation.m_fZ);

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	mxArray* pMxLocalPos = mxCreateDoubleMatrix(4, 1, mxREAL);
	mxSetClassName(pMxLocalPos, "localPos");
	memcpy(mxGetPr(pMxLocalPos), (double*)arLocalPos, 4*sizeof(double));
	engPutVariable(pMatlabEngine, "localPos", pMxLocalPos);
	
	mxArray* pMxRootPos = mxCreateDoubleMatrix(4, 1, mxREAL);
	mxSetClassName(pMxRootPos, "rootPos");
	memcpy(mxGetPr(pMxRootPos), (double*)arRootPos, 4*sizeof(double));
	engPutVariable(pMatlabEngine, "rootPos", pMxRootPos);
	
	mxArray* pMxRootRot = mxCreateDoubleMatrix(4, 1, mxREAL);
	mxSetClassName(pMxRootRot, "rootRot");
	memcpy(mxGetPr(pMxRootRot), (double*)arRootRot, 4*sizeof(double));
	engPutVariable(pMatlabEngine, "rootRot", pMxRootRot);

	char strCmd[200];
	sprintf(strCmd, "globalPos = eec277LocalToGlobal(localPos, rootPos, rootRot);");	
	engEvalString(pMatlabEngine,strCmd);

	double* arGlobalPos = new double[4];
	mxArray* pMxGlobalPos = engGetVariable(pMatlabEngine, "globalPos");
	memcpy((char*)arGlobalPos, (char*)mxGetPr(pMxGlobalPos), 4*sizeof(double));
	
	CPos3D posGlobal;
	posGlobal.m_fX = arGlobalPos[0]; posGlobal.m_fY = arGlobalPos[1]; posGlobal.m_fZ = arGlobalPos[2];

	//release
    delete arGlobalPos;
	delete arLocalPos;
	delete arRootPos;
	delete arRootRot;
	mxDestroyArray(pMxGlobalPos);
	mxDestroyArray(pMxLocalPos);
	mxDestroyArray(pMxRootPos);
	mxDestroyArray(pMxRootRot);

	return posGlobal;
}
CPos3D CMatlabEngine::LocalToGlobalRotation(CPos3D posLocalRotation, CPos3D posRootRotation)
{
	double* arLocalRot = new double[4];	
	double* arRootRot = new double[4];
	arLocalRot[0] = wToRadian(posLocalRotation.m_fX); arLocalRot[1] = wToRadian(posLocalRotation.m_fY); arLocalRot[2] = wToRadian(posLocalRotation.m_fZ); arLocalRot[3] = 1;
	arRootRot[0] = wToRadian(posRootRotation.m_fX); arRootRot[1] = wToRadian(posRootRotation.m_fY); arRootRot[2] = wToRadian(posRootRotation.m_fZ);

	Engine* pMatlabEngine = CMatlabEngine::GetEngine();
	mxArray* pMxLocalRot = mxCreateDoubleMatrix(4, 1, mxREAL);
	mxSetClassName(pMxLocalRot, "localRot");
	memcpy(mxGetPr(pMxLocalRot), (double*)arLocalRot, 4*sizeof(double));
	engPutVariable(pMatlabEngine, "localRot", pMxLocalRot);
	
	mxArray* pMxRootRot = mxCreateDoubleMatrix(4, 1, mxREAL);
	mxSetClassName(pMxRootRot, "rootRot");
	memcpy(mxGetPr(pMxRootRot), (double*)arRootRot, 4*sizeof(double));
	engPutVariable(pMatlabEngine, "rootRot", pMxRootRot);

	char strCmd[200];
	sprintf(strCmd, "globalRot = eec277LocalToGlobalRot(localRot, rootRot);");	
	engEvalString(pMatlabEngine,strCmd);

	double* arGlobalRot = new double[4];
	mxArray* pMxGlobalRot = engGetVariable(pMatlabEngine, "globalRot");
	memcpy((char*)arGlobalRot, (char*)mxGetPr(pMxGlobalRot), 4*sizeof(double));
	
	CPos3D posGlobalRot;
	posGlobalRot.m_fX = wToDegree(arGlobalRot[0]); posGlobalRot.m_fY = wToDegree(arGlobalRot[1]); posGlobalRot.m_fZ = wToDegree(arGlobalRot[2]);

	//release
    delete arGlobalRot;
	delete arLocalRot;
	delete arRootRot;
	mxDestroyArray(pMxGlobalRot);
	mxDestroyArray(pMxLocalRot);
	mxDestroyArray(pMxRootRot);

	return posGlobalRot;

}