#include "stdafx.h"
#include "MotionImageWnd.h"

CMotionImageWnd::CMotionImageWnd()
{
}
CMotionImageWnd::~CMotionImageWnd()
{
	wglMakeCurrent(NULL, NULL) ; 
	wglDeleteContext(hglrc);
	::ReleaseDC (m_hWnd, hdc);
}


BEGIN_MESSAGE_MAP(CMotionImageWnd, CWnd)
	//{{AFX_MSG_MAP(CGLImageWnd)
	ON_WM_CREATE()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

GLfloat LightAmbient[]=		{0.2f, 0.2f, 0.2f, 0.2f };
GLfloat LightDiffuse[]=		{0.8f, 0.8f, 0.8f, 0.8f };
GLfloat LightPosition[]=	{0.0f, 0.0f, 2.0f, 0.0f };

void CMotionImageWnd::InitGL()										// All Setup For OpenGL Goes Here
{
	glEnable(GL_NORMALIZE);
	glShadeModel(GL_FLAT);
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LESS);								// The Type Of Depth Testing To Do
    glClearDepth(1.0f);									// Depth Buffer Setup
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);								// Enable Light One
  	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_FALSE);
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
	glLightfv(GL_LIGHT0, GL_AMBIENT, LightAmbient);		// Setup The Ambient Light
	glLightfv(GL_LIGHT0, GL_DIFFUSE, LightDiffuse);		// Setup The Diffuse Light
	glLightfv(GL_LIGHT0, GL_POSITION,LightPosition);	// Position The Light
}
void CMotionImageWnd::SetGLPixelFormat(HDC hdc)
{
    static	PIXELFORMATDESCRIPTOR pfd=	// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),	// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |					// Format Must Support Window
		PFD_DOUBLEBUFFER 	 |					// Must Support Double Buffering
		PFD_SUPPORT_OPENGL,					// Format Must Support OpenGL
		PFD_TYPE_RGBA,							// Request An RGBA Format
		32,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,						// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,								// Accumulation Bits Ignored
		16,										// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,						// Main Drawing Layer
		0,											// Reserved
		0, 0, 0									// Layer Masks Ignored
	};
	int  iPixelFormat; 

	if((iPixelFormat = ChoosePixelFormat(hdc, &pfd)) == 0)
	{
		MessageBox(L"ChoosePixelFormat Failed", NULL, MB_OK);
		return;
	}

	if(SetPixelFormat(hdc, iPixelFormat, &pfd) == FALSE)
	{
		MessageBox(L"SetPixelFormat Failed", NULL, MB_OK);
		return;
	}
    InitGL();

    glViewport(0,0,1000, 1000);
}
int CMotionImageWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	SetGLPixelFormat(::GetDC(m_hWnd));

	hdc = ::GetDC(m_hWnd);
	hglrc = wglCreateContext(hdc);
	wglMakeCurrent(hdc, hglrc);	
	return 0;
}

void CMotionImageWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPushMatrix();
    DrawImage();
    glPopMatrix();
    glFlush();
	SwapBuffers(hdc);
}

void CMotionImageWnd::DrawImage()
{
	glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, m_imgMotion.m_iWidth, 0, m_imgMotion.m_iHeight, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
        
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    glDrawPixels(m_imgMotion.m_iWidth, m_imgMotion.m_iHeight, GL_RGB, GL_UNSIGNED_BYTE, &(m_imgMotion.m_arPixels));
}