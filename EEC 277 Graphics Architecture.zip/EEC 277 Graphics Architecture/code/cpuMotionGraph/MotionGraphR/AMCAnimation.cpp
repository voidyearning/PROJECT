#include "stdafx.h"
#include "AMCAnimation.h"
#include <fstream>
#include "math.h"

void getDataFromLine(float* arDOF, std::string strLine)
{
	int iBegIdx = strLine.find(" ");
	int iEndIdx = strLine.find(" ", iBegIdx+1);
	int iDataCount = 0;
	while(iBegIdx != -1)
	{
		std::string strData = strLine.substr(iBegIdx+1, iEndIdx);
		arDOF[iDataCount] = atof(strData.c_str());

		//for next round
		iDataCount ++;
		iBegIdx = iEndIdx;
		iEndIdx = strLine.find(" ", iBegIdx+1);
	}
}
void CAMCFrame::LoadFromRaw(CRawFrame& frmRaw)
{
	m_root[0] = frmRaw.m_arData[0];
	m_root[1] = frmRaw.m_arData[1];
	m_root[2] = frmRaw.m_arData[2];
	m_root[3] = frmRaw.m_arData[3];
	m_root[4] = frmRaw.m_arData[4];
	m_root[5] = frmRaw.m_arData[5];

	m_lowerback[0] = frmRaw.m_arData[6];
	m_lowerback[1] = frmRaw.m_arData[7];
	m_lowerback[2] = frmRaw.m_arData[8];

	m_upperback[0] = frmRaw.m_arData[9];
	m_upperback[1] = frmRaw.m_arData[10];
	m_upperback[2] = frmRaw.m_arData[11];

	m_thorax[0] = frmRaw.m_arData[12];
	m_thorax[1] = frmRaw.m_arData[13];
	m_thorax[2] = frmRaw.m_arData[14];

	m_lowerneck[0] = frmRaw.m_arData[15];
	m_lowerneck[1] = frmRaw.m_arData[16];
	m_lowerneck[2] = frmRaw.m_arData[17];

	m_upperneck[0] = frmRaw.m_arData[18];
	m_upperneck[1] = frmRaw.m_arData[19];
	m_upperneck[2] = frmRaw.m_arData[20];

	m_head[0] = frmRaw.m_arData[21];
	m_head[1] = frmRaw.m_arData[22];
	m_head[2] = frmRaw.m_arData[23];

	//right
	m_rclavicle[0] = frmRaw.m_arData[24];
	m_rclavicle[1] = frmRaw.m_arData[25];

	m_rhumerus[0] = frmRaw.m_arData[26];
	m_rhumerus[1] = frmRaw.m_arData[27];
	m_rhumerus[2] = frmRaw.m_arData[28];

	m_rradius[0] = frmRaw.m_arData[29];
	
	m_rwrist[0] = frmRaw.m_arData[30];
	
	m_rhand[0] = frmRaw.m_arData[31];
	m_rhand[1] = frmRaw.m_arData[32];

	m_rfingers[0] = frmRaw.m_arData[33];
    
	m_rthumb[0] = frmRaw.m_arData[34];
	m_rthumb[1] = frmRaw.m_arData[35];
	
	//left
	m_lclavicle[0] = frmRaw.m_arData[36];
	m_lclavicle[1] = frmRaw.m_arData[37];

	m_lhumerus[0] = frmRaw.m_arData[38];
	m_lhumerus[1] = frmRaw.m_arData[39];
	m_lhumerus[2] = frmRaw.m_arData[40];

	m_lradius[0] = frmRaw.m_arData[41];
    
	m_lwrist[0] = frmRaw.m_arData[42];
	
	m_lhand[0] = frmRaw.m_arData[43];
	m_lhand[1] = frmRaw.m_arData[44];

	m_lfingers[0] = frmRaw.m_arData[45];

	m_lthumb[0] = frmRaw.m_arData[46];
	m_lthumb[1] = frmRaw.m_arData[47];

	//lower body
	//right
	m_rfemur[0] = frmRaw.m_arData[48];
	m_rfemur[1] = frmRaw.m_arData[49];
	m_rfemur[2] = frmRaw.m_arData[50];
    
	m_rtibia[0] = frmRaw.m_arData[51];
    
	m_rfoot[0] = frmRaw.m_arData[52];
	m_rfoot[1] = frmRaw.m_arData[53];
    
	m_rtoes[0] = frmRaw.m_arData[54];

	m_lfemur[0] = frmRaw.m_arData[55];
	m_lfemur[1] = frmRaw.m_arData[56];
	m_lfemur[2] = frmRaw.m_arData[57];
    
	m_ltibia[0] = frmRaw.m_arData[58];
    
	m_lfoot[0] = frmRaw.m_arData[59];
	m_lfoot[1] = frmRaw.m_arData[60];
    
	m_ltoes[0] = frmRaw.m_arData[61];

}
void CAMCFrame::SaveToRaw(CRawFrame& frmRaw)
{
	frmRaw.m_arData.clear();
	frmRaw.m_arData.push_back(m_root[0]);
	frmRaw.m_arData.push_back(m_root[1]);
	frmRaw.m_arData.push_back(m_root[2]);
	frmRaw.m_arData.push_back(m_root[3]);
	frmRaw.m_arData.push_back(m_root[4]);
	frmRaw.m_arData.push_back(m_root[5]);

	frmRaw.m_arData.push_back(m_lowerback[0]);
	frmRaw.m_arData.push_back(m_lowerback[1]);
    frmRaw.m_arData.push_back(m_lowerback[2]);

    frmRaw.m_arData.push_back(m_upperback[0]);
	frmRaw.m_arData.push_back(m_upperback[1]);
	frmRaw.m_arData.push_back(m_upperback[2]);

	frmRaw.m_arData.push_back(m_thorax[0]);
	frmRaw.m_arData.push_back(m_thorax[1]);
    frmRaw.m_arData.push_back(m_thorax[2]);

	frmRaw.m_arData.push_back(m_lowerneck[0]);
	frmRaw.m_arData.push_back(m_lowerneck[1]);
    frmRaw.m_arData.push_back(m_lowerneck[2]);
    
	frmRaw.m_arData.push_back(m_upperneck[0]);
	frmRaw.m_arData.push_back(m_upperneck[1]);
	frmRaw.m_arData.push_back(m_upperneck[2]);
    
	frmRaw.m_arData.push_back(m_head[0]);
	frmRaw.m_arData.push_back(m_head[1]);
	frmRaw.m_arData.push_back(m_head[2]);

	//right
    frmRaw.m_arData.push_back(m_rclavicle[0]);
	frmRaw.m_arData.push_back(m_rclavicle[1]);

    frmRaw.m_arData.push_back(m_rhumerus[0]);
	frmRaw.m_arData.push_back(m_rhumerus[1]);
	frmRaw.m_arData.push_back(m_rhumerus[2]);

    frmRaw.m_arData.push_back(m_rradius[0]);

    frmRaw.m_arData.push_back(m_rwrist[0]);

    frmRaw.m_arData.push_back(m_rhand[0]);
	frmRaw.m_arData.push_back(m_rhand[1]);

	frmRaw.m_arData.push_back(m_rfingers[0]);

    frmRaw.m_arData.push_back(m_rthumb[0]);
	frmRaw.m_arData.push_back(m_rthumb[1]);

	//left
    frmRaw.m_arData.push_back(m_lclavicle[0]);
    frmRaw.m_arData.push_back(m_lclavicle[1]);

	frmRaw.m_arData.push_back(m_lhumerus[0]);
	frmRaw.m_arData.push_back(m_lhumerus[1]);
	frmRaw.m_arData.push_back(m_lhumerus[2]);
    
	frmRaw.m_arData.push_back(m_lradius[0]);

    frmRaw.m_arData.push_back(m_lwrist[0]);
    
	frmRaw.m_arData.push_back(m_lhand[0]);
	frmRaw.m_arData.push_back(m_lhand[1]);
    
	frmRaw.m_arData.push_back(m_lfingers[0]);

	frmRaw.m_arData.push_back(m_lthumb[0]);
    frmRaw.m_arData.push_back(m_lthumb[1]);

	//lower body
	//right
	frmRaw.m_arData.push_back(m_rfemur[0]);
	frmRaw.m_arData.push_back(m_rfemur[1]);
	frmRaw.m_arData.push_back(m_rfemur[2]);

    frmRaw.m_arData.push_back(m_rtibia[0]);

	frmRaw.m_arData.push_back(m_rfoot[0]);
    frmRaw.m_arData.push_back(m_rfoot[1]);

    frmRaw.m_arData.push_back(m_rtoes[0]);

    frmRaw.m_arData.push_back(m_lfemur[0]);
    frmRaw.m_arData.push_back(m_lfemur[1]);
    frmRaw.m_arData.push_back(m_lfemur[2]);

    frmRaw.m_arData.push_back(m_ltibia[0]);

    frmRaw.m_arData.push_back(m_lfoot[0]);
	frmRaw.m_arData.push_back(m_lfoot[1]);

    frmRaw.m_arData.push_back(m_ltoes[0]);
}
CRawFrame CAMCFrame::GetWeights()
{
	CRawFrame frmWeights;
	//root
	frmWeights.m_arData.push_back(0);
	frmWeights.m_arData.push_back(0);
	frmWeights.m_arData.push_back(0);
	frmWeights.m_arData.push_back(0);
	frmWeights.m_arData.push_back(0);
	frmWeights.m_arData.push_back(0);
	//lowerback
	frmWeights.m_arData.push_back(1);
	frmWeights.m_arData.push_back(1);
	frmWeights.m_arData.push_back(1);
	//upperback
	frmWeights.m_arData.push_back(1);
	frmWeights.m_arData.push_back(1);
	frmWeights.m_arData.push_back(1);
	//thorax
	frmWeights.m_arData.push_back(1);
	frmWeights.m_arData.push_back(1);
	frmWeights.m_arData.push_back(1);
	//lowerneck
	frmWeights.m_arData.push_back(1);
	frmWeights.m_arData.push_back(1);
	frmWeights.m_arData.push_back(1);
	//upperneck
	frmWeights.m_arData.push_back(1);
	frmWeights.m_arData.push_back(1);
	frmWeights.m_arData.push_back(1);
	//head
	frmWeights.m_arData.push_back(0);
	frmWeights.m_arData.push_back(0);
	frmWeights.m_arData.push_back(0);

	//right 
	//rclavicle
	frmWeights.m_arData.push_back(2);
	frmWeights.m_arData.push_back(2);
	//rhumerus
	frmWeights.m_arData.push_back(2);
	frmWeights.m_arData.push_back(2);
	frmWeights.m_arData.push_back(2);
	//rradius
	frmWeights.m_arData.push_back(2);
	//rwrist
	frmWeights.m_arData.push_back(2);
	//rhand
	frmWeights.m_arData.push_back(0.5);
	frmWeights.m_arData.push_back(0.5);
	//rfingers
	frmWeights.m_arData.push_back(0);
	//rthumb
	frmWeights.m_arData.push_back(0);
	frmWeights.m_arData.push_back(0);
		
	//left
	//lclavicle
	frmWeights.m_arData.push_back(2);
	frmWeights.m_arData.push_back(2);
	//lhumerus
	frmWeights.m_arData.push_back(2);
	frmWeights.m_arData.push_back(2);
	frmWeights.m_arData.push_back(2);
	//lradius
	frmWeights.m_arData.push_back(2);
    //lwrist
	frmWeights.m_arData.push_back(2);
	//lhand
	frmWeights.m_arData.push_back(0.5);
	frmWeights.m_arData.push_back(0.5);
	//lfingers
	frmWeights.m_arData.push_back(0);
	//lthumb
	frmWeights.m_arData.push_back(0);
	frmWeights.m_arData.push_back(0);

	//lower body
	//right
	//rfemur
	frmWeights.m_arData.push_back(2);
	frmWeights.m_arData.push_back(2);
	frmWeights.m_arData.push_back(2);
	//rtibia
	frmWeights.m_arData.push_back(2);
	//rfoot
	frmWeights.m_arData.push_back(0.5);
	frmWeights.m_arData.push_back(0.5);
	//rtoes
	frmWeights.m_arData.push_back(0);
	
	//left
	//lfemur
	frmWeights.m_arData.push_back(2);
	frmWeights.m_arData.push_back(2);
	frmWeights.m_arData.push_back(2);
	//ltibia
	frmWeights.m_arData.push_back(2);
	//lfoot
	frmWeights.m_arData.push_back(0.5);
	frmWeights.m_arData.push_back(0.5);
	//ltoes
	frmWeights.m_arData.push_back(0);

	float fSum = 0;
	for(int i = 0; i < frmWeights.m_arData.size(); ++i)
		fSum += frmWeights.m_arData[i];

	for(int i = 0; i < frmWeights.m_arData.size(); ++i)
		frmWeights.m_arData[i] = frmWeights.m_arData[i] / fSum;

	return frmWeights;
}

CAMCClip::CAMCClip()
{

}
void CAMCClip::LoadFromFile(std::string strPath)
{
	std::ifstream fin(strPath.c_str());
	m_arFrame.clear();
	int iFrameCount = 1;
	while(fin.good())
	{
		char buf[1024] = {0};
		fin.getline(buf, sizeof(buf));
		std::string strLine(buf);

		char buf2[20] = {0};
		sprintf(buf2, "%i", iFrameCount);
		std::string strFrameNum(buf2);
		
		//start of a new frame
		if(strLine.find_first_of(strFrameNum) == 0)
		{
			CAMCFrame frmAMC;
			m_arFrame.push_back(frmAMC);
			iFrameCount ++;
			continue;
		}
		//update data to the last frame
		CAMCFrame frmAMCRecent;
		if(m_arFrame.size() > 0)
			frmAMCRecent = m_arFrame[m_arFrame.size()-1];

		//1.root		
		if(strLine.find("root") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_root, strLine);
		}
		//2.lowerback
		if(strLine.find("lowerback") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_lowerback, strLine);
		}
		//3.upperback
		if(strLine.find("upperback") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_upperback, strLine);
		}
		//4.thorax
		if(strLine.find("thorax") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_thorax, strLine);
		}
		//5.lowerneck
		if(strLine.find("lowerneck") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_lowerneck, strLine);
		}
		//6.upperneck
		if(strLine.find("upperneck") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_upperneck, strLine);
		}
		//7.head
		if(strLine.find("head") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_head, strLine);
		}
		//8.rclvavicle
		if(strLine.find("rclavicle") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_rclavicle, strLine);
		}
		//9.rhumerus 
		if(strLine.find("rhumerus") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_rhumerus, strLine);
		}
		//10.rradius 
		if(strLine.find("rradius") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_rradius, strLine);
		}
		//11.rwrist 
		if(strLine.find("rwrist") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_rwrist, strLine);
		}
		//12.rhand
		if(strLine.find("rhand") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_rhand, strLine);
		}
		//13.rfingers 
		if(strLine.find("rfingers") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_rfingers, strLine);
		}
		//14.rthumb
		if(strLine.find("rthumb") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_rthumb, strLine);
		}
		//15.lclavicle
		if(strLine.find("lclavicle") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_lclavicle, strLine);
		}
		//16.lhumerus
		if(strLine.find("lhumerus") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_lhumerus, strLine);
		}
		//17.lradius
		if(strLine.find("lradius") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_lradius, strLine);
		}
		//18.lwrist
		if(strLine.find("lwrist") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_lwrist, strLine);
		}
		//19.lhand
		if(strLine.find("lhand") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_lhand, strLine);
		}
		//20.lfingers 
		if(strLine.find("lfingers") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_lfingers, strLine);
		}
		//21.lthumb
		if(strLine.find("lthumb") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_lthumb, strLine);
		}
		//22.rfemur
		if(strLine.find("rfemur") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_rfemur, strLine);
		}
		//23.rtibia
		if(strLine.find("rtibia") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_rtibia, strLine);
		}
		//24.rfoot
		if(strLine.find("rfoot") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_rfoot, strLine);
		}
		//25.rtoes
		if(strLine.find("rtoes") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_rtoes, strLine);
		}
		//26.lfemur
		if(strLine.find("lfemur") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_lfemur, strLine);
		}
		//27.ltibia
		if(strLine.find("ltibia") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_ltibia, strLine);
		}
		//28.lfoot
		if(strLine.find("lfoot") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_lfoot, strLine);
		}
		//29.lfoot
		if(strLine.find("ltoes") != std::string::npos)
		{
			getDataFromLine(frmAMCRecent.m_ltoes, strLine);
		}

		if(m_arFrame.size() > 0)
			m_arFrame[m_arFrame.size()-1] = frmAMCRecent;
	}
}
void CAMCClip::SaveToFile(std::string strPath)
{
	std::ofstream fout(strPath.c_str());
	fout << "#!OML:ASF F:\VICON\USERDATA\INSTALL\rory3\rory3.ASF" << std::endl;
	fout << ":FULLY-SPECIFIED" << std::endl;
	fout << ":DEGREES" << std::endl;

	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CAMCFrame frmAMC = m_arFrame[i];
		fout << i+1 << std::endl; 
		//1.root  m_root[6];
		fout << "root " << frmAMC.m_root[0] << " " << frmAMC.m_root[1] << " " << frmAMC.m_root[2]
			<< " " << frmAMC.m_root[3] << " " << frmAMC.m_root[4] << " " << frmAMC.m_root[5] << std::endl;
		//2.lowerback m_lowerback[3];
		fout << "lowerback " << frmAMC.m_lowerback[0] << " " << frmAMC.m_lowerback[1] << " " << frmAMC.m_lowerback[2] << std::endl;
		//3.upperback m_upperback[3];
		fout << "upperback " << frmAMC.m_upperback[0] << " " << frmAMC.m_upperback[1] << " " << frmAMC.m_upperback[2] << std::endl;
		//4.thorax    m_thorax[3];
		fout << "thorax " << frmAMC.m_thorax[0] << " " << frmAMC.m_thorax[1] << " " << frmAMC.m_thorax[2] << std::endl;
		//5.lowerneck     float m_lowerneck[3];
		fout << "lowerneck " << frmAMC.m_lowerneck[0] << " " << frmAMC.m_lowerneck[1] << " " << frmAMC.m_lowerneck[2] << std::endl;
		//6.upperneck     float m_upperneck[3];
		fout << "upperneck " << frmAMC.m_upperneck[0] << " " << frmAMC.m_upperneck[1] << " " << frmAMC.m_upperneck[2] << std::endl;
		//7.head     float m_head[3];
		fout << "head "<< frmAMC.m_head[0] << " " << frmAMC.m_head[1] << " " << frmAMC.m_head[2] << std::endl;
		//8.rclavicle     float m_rclavicle[2];
		fout << "rclavicle " << frmAMC.m_rclavicle[0] << " " << frmAMC.m_rclavicle[1] << std::endl;
		//9.rhumerus   float m_rhumerus[3];
		fout << "rhumerus " << frmAMC.m_rhumerus[0] << " " << frmAMC.m_rhumerus[1] << " " << frmAMC.m_rhumerus[2] << std::endl;
		//10.rradius     float m_rradius[1];
		fout << "rradius " << frmAMC.m_rradius[0] << std::endl;
		//11.rwrist     float m_rwrist[1];
		fout << "rwrist " << frmAMC.m_rwrist[0] << std::endl;
		//12.rhand    float m_rhand[2];
		fout << "rhand " << frmAMC.m_rhand[0] << " " << frmAMC.m_rhand[1] << std::endl;
		//13.rfingers     float m_rfingers[1];
		fout << "rfingers " << frmAMC.m_rfingers[0] << std::endl;
		//14.rthumb  float m_rthumb[2];
		fout << "rthumb " << frmAMC.m_rthumb[0] << " " << frmAMC.m_rthumb[1] << std::endl;
		//15.lclavicle    float m_lclavicle[2];
		fout << "lclavicle " << frmAMC.m_lclavicle[0] << " " << frmAMC.m_lclavicle[1] << std::endl;
		//16.lhumerus float m_lhumerus[3];
		fout << "lhumerus " << frmAMC.m_lhumerus[0] << " " << frmAMC.m_lhumerus[1] << " " << frmAMC.m_lhumerus[2] << std::endl;
		//17.lradius float m_lradius[1];
		fout << "lradius " << frmAMC.m_lradius[0] << std::endl;
		//18.lwrist float m_lwrist[1];
		fout << "lwrist " << frmAMC.m_lwrist[0] << std::endl;		
		//19.lhand float m_lhand[2];
		fout << "lhand " << frmAMC.m_lhand[0] << " " << frmAMC.m_lhand[1] << std::endl;
		//20.lfingers float m_lfingers[1];
		fout << "lfingers " << frmAMC.m_lfingers[0] << std::endl;
		//21.lthumb float m_lthumb[2];
		fout << "lthumb " << frmAMC.m_lthumb[0] << " " << frmAMC.m_lthumb[1] << std::endl;
		//22.rfemur 	float m_rfemur[3];
		fout << "rfemur " << frmAMC.m_rfemur[0] << " " << frmAMC.m_rfemur[1] << " " << frmAMC.m_rfemur[2] << " " << std::endl;
		//23.rtibia     float m_rtibia[1];
		fout << "rtibia " << frmAMC.m_rtibia[0] << std::endl;		
		//24.rfoot     float m_rfoot[2];
		fout << "rfoot " << frmAMC.m_rfoot[0] << " " << frmAMC.m_rfoot[1] << std::endl;
		//25.rtoes     float m_rtoes[1];
		fout << "rtoes " << frmAMC.m_rtoes[0] << std::endl;
		//26.lfemur     float m_lfemur[3];
		fout << "lfemur " << frmAMC.m_lfemur[0] << " " << frmAMC.m_lfemur[1] << " " << frmAMC.m_lfemur[2] << std::endl;
		//27.ltibia     float m_ltibia[1];
		fout << "ltibia " << frmAMC.m_ltibia[0] << std::endl;
		//28.lfoot     float m_lfoot[2];
		fout << "lfoot " << frmAMC.m_lfoot[0] << " " << frmAMC.m_lfoot[1] << std::endl;	
		//29.ltoes    float m_ltoes[1];
		fout << "ltoes " << frmAMC.m_ltoes[0] << std::endl;
	}
	fout.flush();
}
void CAMCClip::LoadFromRaw(CRawClip& clipRaw)
{
	m_arFrame.clear();
	for(int i = 0; i < clipRaw.m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw = clipRaw.m_arFrame[i];
		CAMCFrame frmAMC;
		frmAMC.LoadFromRaw(frmRaw);
		m_arFrame.push_back(frmAMC);
	}
}
void CAMCClip::SaveToRaw(CRawClip& clipRaw)
{
	clipRaw.m_arFrame.clear();
	for(int i = 0; i < m_arFrame.size(); ++i)
	{
		CRawFrame frmRaw;
		m_arFrame[i].SaveToRaw(frmRaw);
		clipRaw.m_arFrame.push_back(frmRaw);
	}
}
CAMCClip CAMCClip::GetSubClip(int iBegIdx, int iEndIdx)
{
	if(iEndIdx >= m_arFrame.size())
		iEndIdx = m_arFrame.size() - 1;
	
	CAMCClip clipSub;
	for(int i = iBegIdx; i <= iEndIdx; ++i)
	{
		CAMCFrame frmAMC = m_arFrame[i];
		clipSub.m_arFrame.push_back(frmAMC);
	}
	return clipSub;
}